# Deployment receiver contract author handoff

This is an author report. It does not award Source, Reader, Quality or live acceptance. The module is ready for integration and independent review. Its record coverage is complete; source and runtime qualifications are retained and must be evaluated by the independent reviewer.

## Owned artifact and revision

Only the assigned new repository file was written: `scripts/docs-kubernetes-apps-receiver-contracts.mjs`. Shared schema authorities, inventory generators, published documentation and other owners' files were not edited. No main generation, commit, push, deployment, cluster mutation or live command was run.

The module exports a deterministic `receiverContracts` array and performs no network or filesystem operations. It authors receiver behavior and immutable evidence URLs. It does not duplicate node schema types, property trees, schema required/default keywords or other generated schema facts. Existing `docs-api-schema-authorities.mjs` remains the sole schema-fact authority. Internal operational family tuples express validator/decode distinctions, not a second schema tree.

Kubernetes source revision: `66452049f3d692768c39c797b21b793dce80314e` (v1.35.0). Module SHA256: `edb2843af2c4b3c083b5b17ea401428abe042e5f8a01feda3249e276c8dc608a`.

## Scope and every assigned workitem

There are 1,268 unique Deployment records: 1,267 nonmetadata `$.spec` boundaries plus the root `$` request record. The parent count of 1,267 is exactly the spec subset; the earlier extra count was root `$`, not an additional spec boundary. All shared ObjectMeta metadata boundaries at every depth are excluded. Typed map values retain the accepted `[<exact-key>]` path alias; integration may normalize it to `["*"]`.

`workitem-record-map.json` maps all 347 assigned Deployment nonmetadata workitems to the exact record, immutable source claim links and qualifications. All 201 unique projected nonmetadata boundaries are present. The frozen source ledger's 36 Deployment contexts and actual instance routes are in `frozen-instance-routes.json`. That reviewed revision is preserved rather than presented as a current-HEAD render acceptance. API behavior of direct create/update is documented after typed decoding and defaults. A GitOps or apply client must separately establish its effective patch, field ownership and admission route; no live result is inferred from the client label.

`recursive-unresolved.json` is empty. The pinned OpenAPI was traversed independently through every property, list item and typed map value, excluding metadata, to detect omitted optional public fields and deeper alternatives. This static check confirms record presence, not correctness of each authored receiver claim. No unmatched authored paths were found.

## Behavior authored

The module covers Deployment selector immutability, replica/controller settings, strategy branches, deadlines and pause. Template changes are tied to future ReplicaSets and Pods, with immutable code links for the Deployment strategy, template copy into ReplicaSets and template spec copy into created Pods. Existing Pod mutation is not inferred from a template change.

Every exposed regular, init and ephemeral container child has a receiving boundary. Init policy and probe/lifecycle/resize conditions are explicit. A nonempty ephemeral container list is categorically rejected in a Deployment template rather than claimed to reach a standalone Pod debug-container runtime. Lifecycle TCP actions have the important API/runtime distinction: the API handler validator permits the branch, but the lifecycle runner has no TCP implementation and returns an invalid-handler error.

Environment and image/command relationships, namespace-local Secret/ConfigMap lookups, optional lookup and missing-key distinctions, probes, lifecycle actions, request/limit quantities, restart policies, resize policies, security context, affinity terms, topology spread, resource claims and all exposed volume alternatives are authored. Null differs by typed pointer, ordinary scalar, list/map, list element and Quantity decoder. A null quantity map value keeps its key and sets numeric zero. Boolean pointers and ordinary booleans do not share a generic null outcome. Created-Pod request-from-limit defaults are distinguished from authored Deployment template defaults.

Deep volume children include legacy and CSI option maps/references, Secret/ConfigMap file payloads, downward API field/resource selectors, projected union branches, tokens, trust anchors and certificates. The projected union permits zero branches in one item under the direct pinned validator and forbids more than one; runtime then contributes no payload for the zero branch. Generic ephemeral PVC templates are connected to the later controller that copies the spec into a Pod-owned namespace-local PVC; existing PVC resize/binding is not implied by a Deployment template update.

## Evidence and meaningful checks

The cached primary manifest and every additional exact pinned source file were SHA256-verified. Additional files and hashes are recorded in `extra-source-manifest.json`. Each of the 221 distinct evidence URLs has the immutable revision and a valid line range in a verified local primary file; details are in `source-link-range-check.json`. Line bounds and hashes are integrity checks and do not automatically approve the text of a claim.

Executed: Node syntax check; module evaluation and record shape/uniqueness checks; immutable revision/source-path/line-range checks; all cached/additional source hashes; every assigned workitem mapping; recursive primary-OpenAPI missing/extra boundary detection; two independent module evaluations with identical JSON output. Export payload SHA256 was `9e3133b3f465f848a95305acacb106d4ee3f1731df3dd90b347724ad873f21f3`.

Not executed: primary Go decoder/default/validator probes because the environment has no `go` executable; Kubernetes API server acceptance; kubelet execution; controller reconciliation; scheduling; Secret resolution against a live namespace; storage mounts; certificate/token issuance; application startup; chart rendering; main generation; documentation publication. No mirrored implementation test is presented as a Kubernetes runtime test.

## Qualifications and remaining review work

`qualification-register.json` contains the exact qualifications and candidate evidence for every record; `specific-qualification-counts.json` makes recurring field-family limits inspectable. These are explicit proof limits, not fake PASS results. Common qualifications separate typed create/update from patch/null ownership, Deployment defaults from Pod-create defaults, source analysis from live execution, and admission from built-in behavior.

Specific unresolved receiver proof includes runtime extractor scaling/fallback details, image-dependent startup values, scheduler namespace fallback and some feature preservation options, ordered restart-rule runtime execution, inherited security/runtime identity and node capabilities, legacy or migrated storage driver support and credentials, filesystem permission/refresh/subPath effects, emptyDir capacity enforcement, trust manager selector and refresh behavior, certificate manager issuance/default lifetime, token issuer policy, PVC admission/default class/binding/provisioning and expansion. The records identify those limits at their relevant boundaries. They do not assert that an unavailable cluster or immutable image executed a case.

Required next steps are integration by the parent and independent fresh Source, Reader and Quality reviews. The Source reviewer must judge each claim and each qualification against the actual route and determine whether any remaining source-only gap prevents publication. Structural presence alone does not satisfy the AP09/quality07 acceptance contract.
