# Independent current Source review: Capacity and Retention

Verdict: **FAIL for the complete current page**. The former service-budget-record defect is **PASS on its current documentation facet**. These are separate conclusions; neither is a Reader, Quality, participant, full-gate, or AP09 acceptance.

Reviewer identity: `/root/capacity_complete_current_source_fresh`. Role: independent Source reviewer, fresh context, initially and continuously read-only in the repository. I did not author this page, act as its Reader/Quality reviewer, execute a participant exercise, or inherit another review's verdict. The assignment identifies the configured model as `gpt-6.1-sol`, reasoning `medium`; I have no backend-routing certificate and do not invent one.

Repository: `/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04`. Initial and final HEAD: `ad312e3e4f15223809fadef90bd90e1f689ce941`. Frozen complete page: 236 lines, 13925 bytes, SHA-256 `39aae50f9105bf0f6ce8d4704dc098cc551d063a3af146403e5e5432769d1e06`. The page hash was captured before its first read. The extended necessary-input guard was captured after discovery/source inspection and before final frozen-page verification; its actual timing is recorded, not misrepresented. Final guard found no changed guarded input. Existing unrelated working-tree modifications are listed in both guards; this is not a clean-checkout acceptance bundle. No repository file was changed by this reviewer.

## Contract and catalogue interpretation

I read the complete quality standard 07, complete AP09 acceptance contract, fixtures and execution plan, and the OPR-009 entry. The current product boundary includes KubeClaw-owned controls and the upstream configurations KubeClaw selects; it does not require a Kubernetes course or every unused upstream alternative. OPR-009 requires a complete service budget with measurement, warning, stop, growth, owner and response. The current A98-13 explicitly makes two independent live operator executions recommended product validation, not mandatory documentation completion. No live reading or current-production threshold may be fabricated to fill this record.

Capacity lines 111-182 correctly supply a reproducible record contract: discover enabled services rather than assume a fixed count; identify absent ones with release evidence; record method, location, version, permissions, selector, units/window, t0/t1, usable capacity/configured limit, growth, owner-approved warning/stop boundaries, lead time, forecast, responder and actions; stop for missing values. A nonpositive growth sample does not prove future safety. Free-space comparisons reverse. Owner approval is distinct from measurement. This closes the missing record structure at this frozen SHA, without claiming actual measurements or successful operation.

OPR-009 whole-page Source result remains FAIL because the service-budget contract does not substitute for the selected product controls and operable source mapping described in Finding S1. The precise correction is to connect the existing budget procedure to those controls, not to populate guessed live numbers.

## All material findings

### S1 — Selected KubeClaw capacity/retention controls are not reachable from the canonical procedure

Location: `docs/site/use/capacity.md:104-109`, `:143-161`, `:184-200`, `:230-236`.

The rows delegate nearly all selection, measurement and response to an owner, but the page never links its readers to the canonical store contracts, effective service/profile configuration, current pressure signals or narrow implemented controls. Line 159 says to read a generated reference without identifying or linking it. Only Prism backup and one Nova evidence-reader assertion receive primary-source links. The omission is material: an operator must budget resources that stop accepting work or discard temporary/projection data well before a PVC becomes full. This is KubeClaw-selected behavior, not an optional upstream-schema catalogue.

Current primary authorities inspected in whole operative bodies establish these distinctions:

- `skills/prism/server/ingestion.ts:12-20,60-67,75-80` and `charts/prism/templates/ingestion.yaml:23-40`: digest-named acquisition quarantine, one-hour default TTL clamped to one minute–one day, periodic reaping and authenticated exact-digest DELETE, 4 GiB ephemeral `emptyDir`; acquisition loss requires reacquisition. This is separate from durable artifacts, logs and reports. The current page's generic ingestion row does not expose it.
- `skills/prism/engine/execution-cache.ts:1-15,33-79`: RAM cache defaults 4 in-flight, 32 completed entries and 16 MiB completed bytes; rejects excess execution and evicts only reconstructible completed cache. It is not durable Control replay or an artifact-deletion policy.
- `skills/prism/server/worker-config.ts:17-29`, `worker-lifecycle.ts:41-69`, `native-worker-execution.ts:12-16,29-46`, `skills/prism/config/native-worker.ts:28-41,57-89`, and `scripts/native-worker-node-capacity.mjs:24-88`: ingress request/connection/body bounds, separately reserved probe capacity, 503 capacity signal, host CPU/memory/task reservations, ownership/journal/input/output/result budgets and native admission fences. Pod CPU alone does not describe these limits.
- `my-values/infra/redis-values.yaml:7-33` versus `gitops/platform/values/redis.yaml:7-23`: different selected profiles. The direct profile explicitly selects AOF, 1 GiB maxmemory and `noeviction`; the GitOps values declare a 2 GiB PVC and smaller Pod resources and do not themselves select that direct-profile memory policy. The operator must identify effective profile, memory/persistence and projection policies rather than assume one global Redis budget.
- `charts/prism/files/prism-backup.sh:66-117`, `charts/prism/values.yaml:62-74`, and `charts/prism/templates/jobs.yaml:61-74`: separate per-group/retained/duration ceilings, a 1 MiB subtraction from retained allowance, retained incomplete attempts, no automatic group expiry, fixed 100 GiB backup claim with conditionally selected/default class. `scripts/postgresql-recovery.sh:56-95` and `my-values/infra/postgresql-recovery.yaml:3-15` select separate LiteLLM backup ceilings and 64 MiB allowance subtraction. Data, backups and failed staging need separate headroom records.
- `scripts/retire-telemetry.mjs:24-60`, `retire-admission.mjs:26-64`, `retire-attempt-result.mjs:25-58`, `retire-nova-dispatch.mjs:75-94`, `retire-operator-request.mjs:58-77`, and `compact-buster-job.mjs:28-46`: narrow explicit local projection/inline-copy compaction or retirement exists, subject to original run/import/wait/effect/receipt/evidence/identity fences. These controls do not implement connected history deletion or generic aged-data cleanup. The planner in `scripts/observability-retirement-plan.mjs:83-125` explicitly returns `executable:false`, zero release and unimplemented/completeness blockers. An owner string, scope JSON, age, or terminal record cannot replace these authorities.
- `gitops/platform/values/prometheus.yaml:39-50` and `loki.yaml:5-30`: selected 15-day/20 GiB metric and 720-hour/20 GiB log controls. They do not guarantee that the requested time window fits; diagnostic projections remain separate from product authority.

Necessary correction: add precise canonical links and a per-service selected-control map beside the budget rows, identifying configured/effective authority, actual pressure signal and supported response or exact blocked step. Link `understand/data-and-state.md`, its current acquisition and LiteLLM-retention acquisition procedure, `understand/telemetry.md`, Prism runtime/configuration and native-host boundaries, the configuration reference and relevant primary source callouts. Distinguish implemented narrow projection retirement from unavailable full run/evidence deletion. Do not invent a general CLI, credential, owner, selector, receipt, approval, production measurement, or broad deletion surface. Where a supported mutation procedure is not published, retain data and state the precise owner/closure condition. Existing environment-native measurement methods may remain owner supplied, but must be concrete before execution.

### S2 — The start-state rule omits the shared client/version acceptance boundary

Location: `docs/site/use/capacity.md:19-27`, `:41-55`, `:75-99`.

The page says to use versions recorded for the installed release and correctly denies an established upstream compatibility range. It neither links the shared version rule nor requires the platform owner to accept the actual client/server combination before proceeding. `docs/site/use/README.md:109-123` explicitly distinguishes recorded kubectl/Helm build inputs from compatibility and requires recording actual versions and stopping until the combination is accepted. `versions.json:19-23,65-72` also has different build and selected Ops tool inputs. Binding in `install.md:176-255` confirms context/server/cluster UID and independent namespace authorities; it does not perform this version acceptance.

Necessary correction: link and apply the shared version/tool boundary explicitly. Record actual kubectl/server and selected storage/product tool versions and acceptance before measurements. Name the required read access for namespace UID and inventory/metrics resources, or link a concrete access prerequisite; owner-supplied product queries must record their exact permissions. No invented compatibility range or default cluster is required.

## Individual Source facets

Each decision below is local to the complete capacity-page Source scope; it is not a full registered gate verdict.

| Requirement/gate facet | Decision | Evidence and meaning |
| --- | --- | --- |
| OPR-009 complete measured-record procedure | PASS | Lines 111-182 require real readings, limits, growth, owner, actions and evidence; template is honestly unpopulated. |
| OPR-009 full current capacity/retention surface | FAIL | S1; record schema alone cannot identify selected current controls. |
| A98-02 purpose/start location | PASS | Lines 10-30 identify task, existing cluster and independent administration. |
| A98-02 explicit cluster binding | PASS | Lines 32-39 and command blocks inherit the dedicated frozen kubeconfig and check it; no default authority assumed. |
| A98-02 supported tools/version/access prerequisites | FAIL | S2; accepted version combination and concrete read rights are not stated. |
| A98-02 placeholders/ordered inventory/syntax | PASS | Context matches bound authority, namespace capture iterates discovered scope; evidence dir is new/private/outside PVC; all three Bash blocks parse. |
| A98-02 product-native methods and impact | FAIL | S1; method fields correctly demand concrete methods, but selected KubeClaw controls and pressure effects are not navigable. |
| A98-02 stop/retry/evidence rules | PASS | Missing owner/readings stop mutation; metrics absence is unavailable evidence; uncertain deletion cannot repeat; outputs and receipts retained. |
| A98-02 final check/recovery boundary | PASS | Same measurements, retained readers and backups must be checked; canonical recovery link does not promise an unsupported restore. |
| A98-04 inventory/usage versus functional proof | PASS | Bound PVC and successful top are expressly insufficient for free space; closure demands application readers and scheduled backup observations. No Pod/HTTP readiness conflation found. |
| A98-04 exact selected service pressure signals | FAIL | S1; native request admission and cache/retention pressure signals are absent. |
| A98-06 unavailable metrics and growth distinction | PASS | Lines 101-109 and 173-178 preserve missing/undefined observation rather than infer zero usage. |
| A98-06 product-specific cause/stop/recovery mapping | FAIL | S1; generic canonical diagnosis link does not identify the selected capacity mechanisms beside their rows. |
| A98-07 backup-group scope/retention claims | PASS | The published Prism no-expiry/per-backup/retained-byte claims agree with whole script and chart. External copy remains subject to canonical integrity and independent-destination procedure. |
| A98-07 selected backup headroom and temporary retention | FAIL | S1; separate Prism/LiteLLM allowances and failed staging are not mapped into records. |
| A98-07 honest restore status | PASS | No current full-platform or isolated application restore is claimed by this page; linked recovery explicitly distinguishes component proof and stops before unsupported cutover. |
| A98-09 retention versus decommission boundary | PASS | Lines 196-204 provide no broad age/glob deletion and direct full removal to canonical dedicated-scope, identity/exclusion/export procedure. |
| A98-09 retained evidence and uncertain cleanup | PASS | Lines 206-228 require receipt/state reconciliation and retained before/after evidence; do not retry uncertain deletion. |
| A98-13 template and truthful unexecuted live status | PASS | Line 8 and 122 deny live measurements; operator methods and approvals must be collected, not invented. Live exercise is recommended, not demanded for documentation acceptance. |
| A98-13 fresh-reader Source sufficiency | FAIL | S1/S2 leave shipped control selection and accepted version prerequisite outside the canonical procedure's navigable path. This is Source assessment, not a performed Reader exercise. |
| Published three pinned claims: currency and ranges | PASS | All three cited Git objects exist, ranges are in bounds, and complete linked files are byte-identical to current files. Older link age alone is not drift. |
| Required source callout depth/coverage | FAIL | S1: only three source links, no service-setting/test/limit callout coverage for selected controls; content, not link counts, establishes the failure. |
| Upstream scope boundary | PASS | No requirement inferred for unused variants or complete foreign schemas. Any added field definitions should link applicable upstream references. |
| Resource units/positive-growth/forecast math | PASS | Correct usage ordering, signed growth, explicit reversed free-space direction, shortest exhaustion forecast and owner-approved lead time. CPU/request-rate windows are not treated as storage bytes. |

## Executed checks and limits

Executed: local `git rev-parse HEAD`, `git status --short`, SHA-256 capture, `rg` discovery, complete capacity-page read, complete governing documents and fixtures, whole operative source reads listed above, cited-page relevant binding/recovery/diagnosis/decommission and store/control passages, `git show` pinned source object comparison and line bounds, private Python link/heading/budget-field verification, and `bash -n` on all three published Bash blocks. Check logs are retained in `local-checks.json`. Parser exits were zero; local targets/headings resolve; pinned sources are current. Tools: GNU Bash 5.3.9, Python 3.14.8, Git 2.54.0. Presence/parsing and hashes do not prove semantic completeness or execution.

Not executed: any kubectl/Helm/deploy command, service query, live capacity reading, backup/restore, mutation, retention or deletion, provider request, credential/secret inspection, network action, host install, generator/build, global mutation or gate run, publication/render/browser proof, registered participant/Reader/Quality/Astra work, parity/deletion approval, full AP09 or AP98 acceptance. Whole operative selected source bodies were inspected to understand control behavior, not run. Upstream LiteLLM source URLs in the canonical store page were not fetched under the assigned no-network boundary; therefore this review does not certify the upstream cleanup scheduler itself. Its existing exact acquisition page is an appropriate link target; no upstream fact is promoted to executed live evidence.

The source guard binds selected inputs and frozen page; it does not certify all repository files, the unrelated generator corrections, or their currency. New generator outputs may be stale and none was used as semantic PASS. Root's other Source proofs do not cover this page. Parent coordination remains responsible for writers, review repetitions, commits and global acceptance. No author request was made during collection. All review artifacts are outside the repository and are sealed read-only with a SHA-256 manifest.
