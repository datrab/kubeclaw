# Raw audit entry family correction — author evidence

Repository: `/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04`.
Branch: `docs/documentation-overhaul`. Source/starting documentation revision:
`1864cd8c9d82cafb2f259ac72bb8dfba67388882`. Date: 2026-10-11 UTC.
Writer: `/root/raw_audit_entry_complete_family_writer`.

Read-only preparation was completed before the root's explicit release. No
repository edits were made during the adjacent four-page Source review's guard.
The released exclusive assignment covers only the four files below. The report
addresses F01 in the independent operator wait/resume/cancellation Source report
and independently confirmed F4 in the install/evidence/retirement Source report.
No commit or push was made. Other working-tree changes are concurrent work.

## Changed reader paths

* `recovery.md`: Pipeline State Recovery now starts from original run, platform,
  project/graph, package, storage and configuration identities; stopped Nova and
  adapter writers; checksum/ownership checks; verified canonical raw run and
  adapter copies; strict copied-journal inspection; stop retaining rejected bytes;
  only then audit, reconciliation and supported recovery. Node/cluster-loss and
  Nova verification rows route through this prerequisite. Final recovery audit
  repeats preservation. Later owner-authorized canonical repair retains original
  bytes and records its actual changes. Retention includes fence and raw-copy proof.
* `diagnose.md`: Durable Run Inspection is self-contained from its entry and links
  exact `operate.md#inspect-a-run` before action. It explains lock creation and
  tail truncation with narrow current source links; captures JSON/stderr/exit
  after verified raw preservation. Diagnosis order, resume symptom, uncertain
  effects and recovery routes retain the prerequisite. Redis before/after and Git
  failed/successful audits invoke the existing canonical preservation helper with
  the actual original identities. Git start and audit fences are separated so
  each run's stopped-writer and adapter-copy checks precede audit.
* `plugins.md`: controlled activation and each drained pinned run require the
  same preservation and strict-inspection contract before audit. Drain no longer
  instructs auditing active writers. Active work must finish under its owner;
  unknown ownership or unavailable adapter backup stops audit and disablement.
  Containment does not establish terminal success. Audit output/exit are captured.
* `workflows/buster-suite.md`: production audit/recovery, cleanup routing and
  healthy deployment terminal audit use the canonical prerequisite. The healthy
  journey must first return its required terminal success; no forced interruption
  replaces that result. Stopped writer and adapter-copy proof is a separate
  mandatory step before terminal audit. Original provider-chain, graph, receipt,
  source and cleanup assertions remain intact.

No new storage-copy implementation was introduced. Every command uses the
existing canonical `preserve_run_state` helper; adapter stores retain their
owned backup procedures. Missing store procedures or ownership stop execution.
Source evidence establishes that `readPipelineAudit` constructs `FileJournal`,
which creates/acquires an append lock and truncates an incomplete tail before
parse. A later error does not reconstruct discarded evidence. The copied strict
parser detects incomplete records and chain errors without repairing source.

## Verification and preserved boundaries

| Check | Observed result | Scope |
| --- | --- | --- |
| Whole pinned source files and narrow range inventory | 1,676 links; 176 unique revision/file pairs; zero stale files or invalid ranges | Mechanical currentness, not full independent semantic approval |
| Assigned-page local links | 214 links; zero missing files or headings | Repository Markdown routes, not rendered publication proof |
| Exact changed executable fences | 13 fences; each `bash -n` exit 0 | Syntax only; no commands executed against product state |
| Generated plugin matrix | Exact bytes unchanged, SHA-256 `96ceecddeb4dc58d6d1ba205566f6d706b1cf904906df460b0ede27a989a4e3d` | Every generated row retained |
| Reviewed recovery backup/component content before Pipeline State Recovery | Exact bytes unchanged, SHA-256 `07020c76809baa44320e34ef04546421bcf6f8d2d45a6c924dc4d45e17ba985c` | Prism/LiteLLM native and bounded backup/restore boundaries retained |
| `npm run docs:operator-tasks:check` | Exit 0; current 13-task registry, 14 lifecycle capabilities, required mutation fixtures | Task ownership/structure, not execution or acceptance |
| `git diff --check` | Exit 0 | Focused diff whitespace |
| `npm run docs:check:refs` | Exit 1; three unassigned generated-anchor failures below | Full references gate remains open |

The full reference gate reports only three references from
`docs/site/understand/buster-namespace-controller.md` to missing generated anchors
in `docs/site/reference/helm-values.md`: `api-field-2d7090db945e3299f8e7`,
`api-field-e5b8003a74b771aad5b3`, `api-field-446072fe13a4ef01e5dc`.
These files are outside exclusive ownership and were not edited. Retained full
log and actual exit explain the gate result; assigned-page checks do not override
this failure. No renderer, publication, browser or global acceptance was run.

The quality standard, applicable A98-02/A98-05/A98-13 contract, OPR-004/OPR-005
catalogue records, AP09.8 execution plan and three deployment fixtures informed
this correction. All authored sections of the four assigned pages and canonical
Inspect a Run were read. Generated plugin rows were mechanically inventoried,
source-pin checked and preserved exactly. Controlled-language author review uses
plain English, one term per mechanism, explicit required conditions before
commands, stop and retention rules, and separate evidence classes. It is not
formal ASD-STE100 certification or independent Quality/Reader approval.

## Semantic family search and remaining work

The complete `docs/site/use` command search finds explicit `--audit`, `--recover`
and `--signal` entry paths only in these assigned pages, `operate.md` and
`workflows/wait-resume.md`. Canonical operate has the raw-copy/strict parser
contract; wait-resume already calls its verified run/adapter preservation wrapper
before audits and signals. The demo-delivery active-wait path links canonical
run control rather than introducing a command. No additional unsafe command
entry outside the assigned four files was identified. Shorthand diagnosis,
restoration, symptom and cleanup routes in the assigned pages were corrected.
Retained `audit-entry-search.txt` records the final whole-tree command search.

The deployment receipts for `EXEC-WAIT-RESUME`, `EXEC-CANCELLATION` and
`EXEC-RESTART-RECOVERY` remain absent/open. This author correction does not waive
fixtures, report deployment PASS, treat parser or unit evidence as deployment,
or turn process containment into a complete journey. Full-platform, independent
Prism and isolated LiteLLM operator restore product limits remain stated.

Fresh independent Source, Reader and Quality review of changed routes remains
necessary; author checks grant no gate, package, publication or global approval.
No pipeline, signal, restore, cluster, provider, network, destructive operation,
product code change or product test-tool change was performed.

## Final file identities

| File | Bytes | SHA-256 |
| --- | --- | --- |
| `docs/site/use/recovery.md` | 52264 | `c026a1c3acc992c12ae8e5351aee22c87cdba2a56087496ed423a13c027243fb` |
| `docs/site/use/diagnose.md` | 122460 | `5437f53eb5ed3c1ff1911efe33fc37da82f4a6af4374b51fabffe30e9a0e10d8` |
| `docs/site/use/plugins.md` | 642918 | `1d931d0bd9eb5b9d32a331f8e6a9727b17518c68717002232fe7c3d5765205ea` |
| `docs/site/use/workflows/buster-suite.md` | 38216 | `719d6506e157a1509776bbd27ea530b16e961f25b18f46ee9dabb16a8954b101` |

`before.json` retains released baseline identities; `after.json` retains final
identities. `assigned.diff` is the complete focused four-file diff. Exact changed
fences, their syntax results, all source pins, local links and check logs are
retained. `manifest.json` gives the bytes and SHA-256 of each evidence artifact.
