# Independent developer handbook Quality review

Verdict: **FAIL** for the assigned content Quality scope. One material finding, QF-01, remains. All assigned facets were reviewed before this report; this is not a preliminary finding list.

Reviewer identity: `/root/developer_handbook_complete_quality_fresh`, a separate Codex GPT-6-based agent. Exact runtime model subtype is not exposed to this reviewer; no Astra identity is claimed. Role: independent Quality/architecture/controlled-language reviewer, fresh-context and initially and continuously read-only for the repository. This identity did not author the handbook, act as Source reviewer, act as Reader reviewer, or participate in the registered exercise. Only private evidence files were written.

Repository: `/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04`; branch requested: `docs/documentation-overhaul`; actual HEAD at initial guard: `ad312e3e4f15223809fadef90bd90e1f689ce941`. The two assigned files are untracked author candidates, so this is a frozen-byte Quality review, not a clean documentation-commit or publication acceptance. Published product citations use `671234b056bf5f5f503e51e8db30f843e781ba6e`. No applicable AGENTS.md was found in the repository or ancestors. Managed-cloud runtime skill was read; no managed environment status tool was callable, and no network, credentials, container, deployment or host installation work was performed.

Frozen files:

| Path | Bytes | SHA-256 |
| --- | ---: | --- |
| `docs/site/extend/developer-handbook.md` | 87656 | `b3f07aed9cebaf35a1b0a5c3ff210f8b45a0cf8092d4facab200319c7a844139` |
| `docs/site/extend/examples/platform-change-nova-lifecycle.json` | 5763 | `2a1d752198305331536e73a771fb0e2096eb501266f43612f6286ca786e406fc` |

## Complete scope and method

Read the complete 1,182-line handbook and complete corrected public fixture; complete quality standard, acceptance contract, registered acceptance fixtures, execution plan; all DEV-001–009 catalogue records and QUA-001–010 meanings. Reviewed all ten routes: Nova, Worker, Buster, Prism, Registry, SDK, telemetry, Charts/GitOps, Ops MCP, UI. Reviewed checkout/workspaces/toolchains/services/credentials, build/start/debug/log/cleanup, check selection, CI/security/performance/version/release/compatibility, and source-to-page maintenance.

Followed relevant canonical references: request-to-result forwarding, Nova durable-state/lifecycle/decisions/recovery sections, Worker ownership/native/recovery boundaries, Buster Core owner/decision/change map, Prism owner/contract/setup routes, extension contracts, shared glossary, documentation governance, and Ops MCP auth/state/config semantics. Read relevant primary files directly for the lifecycle recorder/reducer/recovery, file mutex/journal, lifecycle/process-death test boundaries, TypeScript settings, SDK exports, Prism scripts/browser configuration, MCP config/auth, scale fixture, governance generator, and CI trust/prerequisite paths. Exact source-file byte/range currency is separately recorded by the private guard, not promoted into full Source-semantic approval.

Language method: manual complete-text review for clear English, direct actor/action, prerequisite-before-action, defined terms, consistent terms, mechanism and reason depth, and truthful status. Exact identifiers/commands are retained. No readability score or automated vocabulary list substitutes for this review. Full licensed ASD-STE100 dictionary/rules were not supplied; review applies the project's declared ASD-STE100 principles and makes no certification claim.

Technical vocabulary examined: workspace, runtime role, contract, projection, digest, fixture, lifecycle, attempt, retry, repair, wait, durable event, schema, identity, replay, recovery, generated source, package export, erasable TypeScript, capability/grant/RBAC, cgroup, ownership/fencing, receipt, promotion/rollback, source revision, benchmark budget, fsync, inode. Most central handbook terms are defined or explained through the canonical component route; the two storage-safety terms below are not.

## QF-01 — Explain the storage-safety terms before the setup rule depends on them

**Location:** `docs/site/extend/developer-handbook.md:30–34`; the cleanup rule depends on the same unexplained inode term at `:327–328`.

**Finding:** The first setup paragraph requires “fsync-backed records”, prohibits unlinking a stable lock inode, and distinguishes journal fsync from persistence of the parent directory. Neither `fsync` nor `inode` has a plain definition at first use. The shared glossary has no definition of either term, and the linked Nova durable-state section (`docs/site/understand/nova-core.md:343–355`) merely says the journal uses `fsync`. The code callout explains where to inspect implementation, but does not supply the missing explanation to a reader with practical IT knowledge. These terms carry a consequential safety rule, not incidental jargon: removing/replacing a lock path can break the intended shared lock, and file synchronization is not a general host-crash persistence guarantee.

**Binding authority:** `docs/blueprint/07-documentation-quality-standard.md:94–97` requires definitions at first use, an ordinary-word explanation before depending on an identifier, and shared technical vocabulary; its Purpose and reader section requires practical IT knowledge without project or academic assumptions. Acceptance contract rule 15 requires clear English, and the controlled-language facet applies to the entire assigned prose and fixture.

**Primary product authority:** `skills/nova/core/state/file-mutex.ts:4–23`, `FileMutex.withLock`, opens and locks a stable file object, explicitly says never unlink it, and retains the descriptor until operation completion. `skills/nova/core/state/journal.ts:125–156`, `FileJournal.#appendUnlocked`, appends the complete serialized record and calls `fs.fsyncSync(descriptor)` on that file. These primary sources support the importance of the published distinction; this finding does not claim they prove host-crash survival.

**Necessary correction:** Add short plain definitions immediately before the safety rules: explain that `fsync` requests synchronization of the file's data/metadata with its storage and that synchronization of a journal file does not by itself prove that its parent directory entry survives a host crash. Explain an inode here as the underlying filesystem object that the lock protects, and why unlinking/replacing the pathname while a process can use it can give another process a different file object and a competing lock. Retain the qualification of the filesystem and the stated product/environment limits. Add or link canonical shared definitions if available; do not add a general filesystem course or invent a durability guarantee.

**Affected verdicts:** DEV-002 assigned Quality facet; A910-01 assigned setup Quality facet; QUA-001 and QUA-002 assigned language/understandability facets; defined-technical-terms facet. Recheck the corrected setup paragraph and its cleanup reuse with a new fresh-context Quality reviewer.

No additional material Quality finding was found in the rest of the assigned scope.

## Individual catalogue Quality findings

These decisions concern assigned Quality facets only. A PASS below does not award the full catalogue requirement, practical execution, Source approval, publication inclusion or a gate outside this role.

| ID | Verdict | Quality evidence and limits |
| --- | --- | --- |
| DEV-001 | PASS | Lines 11–23 and ownership/component routes give a central owner-based route, linked complete system trace and distinct Core/service/UI/contract/data/deployment/release ownership. Navigation integration is outside this content review. |
| DEV-002 | FAIL | Lines 25–191 give Linux/Node/npm/lock/tool/package/browser/service/credential prerequisites and safe setup failures; QF-01 leaves consequential storage terms unexplained. No clean-checkout setup run is claimed. |
| DEV-003 | PASS | Lines 193–286 and all component routes distinguish source builds from service starts, library-only components, inspection/log evidence and scoped cleanup; adjacent canonical operation pages own exact deployed inputs. No native/service/browser execution is awarded. |
| DEV-004 | PASS | Lines 288–348 give six change questions, evidence limits, baseline/after-change retention, and Nova's concrete unit/contract/journal/recovery/historical/SDK/docs selection at 390–482. Additional boundary checks are conditional and no universal aggregate is substituted. |
| DEV-005 | PASS | Lines 997–1052 describe all 13 workflows, trust, required-check setting uncertainty, jobs/timeouts/conditional paths, secrets, artifacts, cancellation and release effects. Precise workflow triggers are pinned primary references, not invented server settings. No hosted run or branch protection proof is awarded. |
| DEV-006 | PASS | Lines 224–286 plus SDK/lifecycle/release routes explain exports, relative extension/import-type/erasable rules, owner direction, schema-first generation, closed-schema compatibility and retained-byte/replay identity consequences. Build freshness and semantic compatibility remain separate. |
| DEV-007 | PASS | Lines 934–995 provide authority questions, secure fixture and scanner dependency selection, actual scale parameters/ceiling, comparable baselines and predeclared retention budgets; failure or missing tool is never an empty finding set. No security enforcement/capacity result is awarded. |
| DEV-008 | PASS | Lines 1054–1127 distinguish version/lock/schema/package/source/image/bundle/deployment identities, synchronization, compatibility pairs, notes/deprecation, receipts, promotion and irreversible rollback boundaries. Missing general data-pair support stops the incompatible release with an owner. |
| DEV-009 | PASS | Lines 1129–1160 give source-to-page ownership, generated/authored separation, mapped generator/check selection, current citation refresh, add/change/remove/rename and redirects. No full drift coverage or pending integration proof is awarded. |

## Individual assigned gate Quality findings

| Gate | Verdict | Assigned Quality facet |
| --- | --- | --- |
| A910-01 | FAIL | Setup conditions and failures are explicit, but QF-01 fails first-use clarity for the storage-safety prerequisite. This is not a clean-checkout participant result. |
| A910-02 | PASS | Ownership, workspace/role distinction, build/generated boundaries, generator order and prohibited import directions are explained with reasons/costs/reconsideration and source callouts. |
| A910-03 | PASS | Build/test/Lint/version/release/compatibility routes state exact commands, starting environment, result/stop meaning and evidence limits. Named source APIs and canonical adjacent task pages bound prerequisites and cleanup. No successful execution of every shell example is awarded. |
| A910-11 | PASS | All ten required component routes select changed invariants and adjacent boundaries; Nova's desired diagnostic, negative input, crash/restart, compatibility and removal task is coherent. No READER-PLATFORM-02 practical PASS is awarded. |

## Individual assigned QUA facets

| ID | Verdict | Scope and reason |
| --- | --- | --- |
| QUA-001 | FAIL | Mechanism depth and English structure are strong, but the consequential storage terms in QF-01 remain undefined. |
| QUA-002 | FAIL | Complete manual controlled-language review found QF-01; no formal ASD-STE100 claim exists. |
| QUA-003 | PASS | Handbook labels local historical reason as unknown and current ownership benefit as inference, states cost/reconsideration; canonical component/decision pages carry deeper design reasons/status/implementation limits. No history is inferred from code. |
| QUA-004 | PASS | Quality facet: six-part narrow source callouts place evidence beside claims, use full revisions and explicit actual/unexecuted test limits. Structural currency is independently guarded. Full semantic Source approval remains separate. |
| QUA-005 | PASS | Environment failures and product limits remain honest; no clean-checkout/native/image/deployment/live/release/restore result is inferred. |
| QUA-006 | PASS | Assigned content Quality facet: reader route and foundational terms support the technical explanation except QF-01, already assigned to QUA-001/002. End-to-end reader execution and global site scope are not awarded. |
| QUA-007 | PASS | Assigned boundary facet: linked operator setup/recovery/maintenance owns operational authority; handbook does not fabricate live operator or restore success. Operator exercise is outside this role. |
| QUA-008 | PASS | Assigned boundary facet: handbook routes public extension creation/activation/removal to canonical extension guides and does not equate compilation with activation. Extension-reader practical approval is outside this role. |
| QUA-009 | PASS | Assigned developer-change content facet: ten routes and desired Nova diagnostic provide the complete selection/negative/restart/compatibility/removal conditions. A registered independent participant has not executed this review. |
| QUA-010 | PASS | Assigned maintenance-content facet: discovery/ownership mapping, stale source, generator separation and add/change/remove proof obligations are explicit. No 84-mutation or global drift execution is awarded. |

## Remaining facet matrix

| Facet | Verdict | Result |
| --- | --- | --- |
| English and direct plain sentences | PASS | All assigned prose, tables, command framing and fixture fields are English; exact identifiers are kept. |
| Defined technical terms | FAIL | QF-01. |
| Mechanism, sequence, depth and complete-flow connection | PASS | Owner-based handbook connects the request trace and detailed canonical mechanism; ten routes preserve state and adjacent responsibilities. |
| Reasons, costs, limits, reconsideration | PASS | Present inference is separated from missing historical evidence; significant consequences and deeper decision authorities are linked. |
| Ownership and safe actionability | PASS | Component/environment/store/deployment owners and measurable closure conditions accompany blocked routes. QF-01 separately affects setup clarity. |
| Command prerequisites, failure, cleanup and retained state | PASS | Conditions precede commands; failed prerequisites stop affected routes; owned disposable state is separated from journals/results/effects. Practical execution remains separate. |
| Version authority and compatibility | PASS | Independent identities, historical fixtures, incompatible release stop and irreversible data boundaries are explicit. |
| Source-citation quality | PASS | Narrow current full-SHA callouts and explicit evidence limitations; no full Source semantics or rendered-output claim. |
| Future maintenance | PASS | Canonical owners/generated sources/checks and drift/remove/rename/redirect duties are actionable; pending navigation/classification/inclusion is outside content scope. |
| Public fixture boundary | PASS | Descriptive ID, full product baseline/purpose, desired not-shipped diagnostic, bounded condition and neighboring invariants, invalid pending-state rejection, durable-block crash/restart, compatibility, removal, retained evidence and not-executed status. No internal acceptance/facilitator/time limit/source path/test-command hints. |
| Internal working-language exclusion | PASS | No AP/review/handoff/migration-history/facilitator assessment material in assigned content. Product code review, data migration, separate human acceptance and honestly bounded check results are legitimate contextual uses. |

## Actual execution and evidence boundary

Reviewer executed only read-only inspection and private hash/range/manifest checks. The retained exact private command is `python3 /home/node/Documents/Codex/a98-evidence/developer-handbook-complete-quality-fresh/check-quality-inputs.py`; exit 0. Its log and JSON record 7 initial/final frozen authority guards, 107 source pins on 60 files, linked-reader hashes and retained author-manifest integrity. These counts are structural, not acceptance scores. No broad product, generator, publication, mutation or deployment command was run; no host installs, source edits or runtime change occurred.

The original author REPORT/MANIFEST/input-manifest/sourceguard/executions and superseding public-fixture correction were read as attributed evidence. Their test results are **author executions**, not this reviewer's independent executions: lifecycle/registry contracts, SDK helper, source-snapshot compatibility and Nova typecheck passed; journal/lifecycle recovery, portable SDK and scale attempts failed on the GNU absolute-flock prerequisite; Ops local startup failed on separately locked missing MCP dependency. These failed attempts are preserved honestly in the handbook and do not independently constitute QF-01 or another documentation defect. No author successful proof is promoted to clean-checkout, registered reader, target-image, native, deployed or live proof.

Administrative matrix/HEAD movement by parallel owners does not change the assigned frozen bytes; full initial/final hashes govern the reviewed content and binding authorities. No file other than the two candidates and necessary authority/primary/reference dependencies is claimed frozen. Root's composite seal describes author candidates only. Publication navigation, classification and asset allowance integration remain outside this Quality review. Source/Reader roles, all examples execution, READER-PLATFORM-02 participant execution, global gates and full package acceptance remain unawarded.

Correct QF-01 and commission a new fresh-context Quality check of the affected setup/cleanup wording. This report itself edits no repository file.
