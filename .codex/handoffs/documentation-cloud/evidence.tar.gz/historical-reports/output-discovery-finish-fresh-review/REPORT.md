# Independent source review: FAIL

Review baseline: 1c1cf68d522d5b7d36475a7657b89a382da1c8c7. Actual fresh probe revision: f01d766a5c6cd06a0a733ebd09a6e75e8215dd71. source-binding.json proves all reviewed generators, api-reference tests and actual producer files are byte-identical across these revisions. Receiver-only changes are listed separately. Root started separate default corrections after this reviewer’s probe modules loaded; mutable workspace changes are excluded from the immutable Git binding. No reviewer repository edits, output generation, deployment, global acceptance, or live operator exercise.

Scope: product output discovery; actual used/supported Kubernetes configurations, conditional branches and relevant defaults; recursive product-owned API schemas; downstream inventory/publication join. General unused upstream schemas remain links. Read the full quality standard; relevant A98-02/06/10/11/13 contract and CFG-009. Read discovery/product scope/Go helper/adapter registry/reference/schema authority and api-reference tests; inspected applicable inventory builder/publication/check paths. This is a source partition review, not acceptance of unrelated 7,274-line configuration inventory mechanisms or all operator prose.

## F01 — FAIL: Existing Python producer omitted
Source: ops/pod/bootstrap.py:29-31,56-71; scripts/deploy-ops-pod.sh:19,32; docs-api-output-discovery.mjs:286,478,496.
Evidence: Actual setup emits bearer/token and optional GitHub/Tailscale stringData Secrets and copies ghcr type/data. No Python scan or adapter exists; fresh actual-producers.json has zero Python contexts.
Correction: Discover deployment caller graph and classify every emitting language. Intercept original Python functions offline with synthetic environment/kube responses; never execute real kubectl or credentials. Retain conditional branches and exact source/input evidence.

## F02 — FAIL: Existing returned GitOps transform omitted
Source: scripts/gitops-continuous.mjs:15-20,37-55,83-84; docs-api-output-discovery.mjs:305-320,449-474.
Evidence: Actual continuousDocuments rewrites Application source to main/gitops/production/apps/directory.include applications.yaml, returns it, serializes bootstrap.yaml and applies it. Constructor-only scan returns zero continuous contexts; base gitops.mjs retains charts/gitops/helm source instead.
Correction: Call original pure transform/render with controlled supported inputs and bind its serialized output and source ancestry. Follow returned documents and file/output sinks, not only object literals or stdout.

## F03 — FAIL: Unknown serialized dynamic output silently disappears
Source: docs-api-output-discovery.mjs:289,436-443,453-461.
Evidence: Fresh probe dynamic template with apiVersion/kind and interpolation returns [] without error. JSON literal constructor positive control is found.
Correction: Classify all serialization/file/API sinks before shape parsing; unresolved potentially API-bearing template/string/return/file publication must raise a named qualification error. Preserve literal support and avoid executing external-effect producers.

## F04 — FAIL: Terminal JS object updates omitted
Source: docs-api-output-discovery.mjs:313,387-390,438-452.
Evidence: Fresh extra-probes: emitted body with body["immutable"]=true and conditional body.immutable=true still yields base ConfigMap lacking immutable. AST mutation collection includes only dot assignment and constructor evaluation uses literal rather than terminal binding.
Correction: Resolve terminal published binding and mutations, including computed keys/control-flow variants; unqualified mutation/branch must fail. Record source position and test actual output change, not only changed source hash.

## F05 — FAIL: Shell pipeline output misidentified
Source: docs-api-output-discovery.mjs:535-559.
Evidence: Fresh kubectl ConfigMap | sed s/ConfigMap/Secret/ | kubectl apply is accepted as ConfigMap; pipeline transform never modeled.
Correction: Parse full pipeline and classify transforms/sinks. Unsupported transforms must raise before accepting constructor shape; maintain direct kubectl constructors and heredoc provenance.

## F06 — FAIL: Hash refresh authorizes stale hardcoded operation recipe
Source: docs-api-output-discovery.mjs:14-24,566-575,697-704; docs-api-producer-adapter-authorities.json:4.
Evidence: Fresh actual Cilium mutation disables relay/UI in original script, refreshes only source hash; discovery accepts and retains relay-client Secret while actual flagged render removes it. closureCondition prose is not enforced.
Correction: Derive adapters from source operation or compare structured current invocation/values/transforms to authenticated adapter recipe. Bind operation equivalence and tests structurally; nonempty operation plus hash cannot prove it. Apply to local charts, transforms, infrastructure and installer callers.

## F07 — FAIL: Relevant per-instance defaults omitted
Source: docs-api-product-scope.mjs:64-213,354-390; charts/kubeclaw/templates/deployment.yaml optional-agent-output.
Evidence: Actual extra container index1 has digest image and no imagePullPolicy; wildcard is selected only via indices0/2, so omitted instance not covered. terminationMessagePolicy applicability absent. Synthetic selected Service ports[{port:80}] lacks protocol/targetPort and sessionAffinity omission evidence.
Correction: Add bounded receiving routes for present Container/ContainerPort/Service objects and materialized defaults with source qualifiers; cover per-item image/tag semantics, termination message fields, port protocol/targetPort and selected Service defaults. Account for explicit empty values when defaulting uses zero-value predicates. Do not expand unused schema alternatives.

## F08 — FAIL: Discovery search space is not defensible for new emitters
Source: docs-api-output-discovery.mjs:286,478,496; docs-api-product-scope.mjs:238-265.
Evidence: Synthetic JS bin/new.mjs emitter is silently absent while bin shell is scanned. No declared classification catches unrecognized producer languages/locations; actual Python omission proves practical impact. There is no current bin directory, so bin test is mutation evidence only.
Correction: Define whole supported product producer search space and explicit source/caller classifications/exclusions. Addition/rename of emitting source in a public supported path must fail closed. Exclude tests/vendor/unused upstream only with source-grounded reason.

## Bounded PASS evidence and corrections to earlier leads
- Exact unresolved root JSON.parse spread is rejected at apiProductSelection with API_PRODUCT_OUTPUT_DYNAMIC_UNRESOLVED. Both prior and fresh dynamic-spread-primary-proof.json show rejection; it is not a reproduced silent-spread defect. Do not weaken this closure. Scalar/string templates and terminal mutation holes remain separate failures.
- Fresh api-reference.test.mjs: 36/36 pass, zero skips. This demonstrates existing tests, not producer completeness. Tests currently exercise source-hash mismatch but do not exercise refreshed-hash operation mismatch.
- Typed Go new Kubernetes constructor rejects with API_PRODUCT_GO_TYPED_CONSTRUCTOR_UNQUALIFIED using declared evidence Go binary; first exploratory run lacked Go PATH, then repeated correctly. JSON object literal discovery, malformed YAML rejection, instance-local schema defaults and source binding retain bounded positive evidence.
- Actual Cilium archive 06210eef7c23d15f7699c79e2fe3a1ec9c389024c5c5c006ea04022d322449a2 independently rendered twice for install and twice for upgrade. Full document comparison finds only six varying contexts: cilium-ca (ca.crt/ca.key), hubble-relay-client-certs and hubble-server-certs (ca.crt/tls.crt/tls.key), three each per install/upgrade. After replacing only those bytes, corresponding documents are identical. Source qualification pins archive/templates/helper and role/data keys; supplied CA bytes stay deterministic; live Secret lookup/reuse is expressly outside offline rendering. This narrow nondeterminism classification PASS applies to current selected profiles only.
- Raw YAML, local chart branch witnesses, pure manifest renderers, immutable infrastructure charts, Go controller map/request outputs and external Application/installer charts are all part of the examined architecture; no blanket exclusion is approved. Full fresh replay: 1,199 contexts, 39 GVK groups, zero selection errors, receiver errors or missing receiver paths. This only counts discovered contexts and cannot prove omitted producers.

## Correction acceptance required
Reproduce F01–F08 against original source with controlled offline evidence, add/change/remove/rename and variant tests at responsible docs gates, verify exact source→operation→selected output→receiver→publication joins, and rerun independent fresh source review. Preserve authored product-owned recursive schemas and pinned upstream links. No count assertion, default render, saved inventory, or refreshed hash alone can close these findings. A98-10/11 and CFG-009 source completeness remain FAIL. This partition does not independently accept A98-02/06/13 procedure text; these need correction/reader checks where changed discovered values affect prerequisites, recovery or expectations.

Limitations: no cluster calls, no live source/render lookup, no fresh-context reader execution, no documentation regeneration, no global AP09 verdict. A finite probe set is not an exhaustive guarantee. Report flags architectural residual uncertainty rather than calling unknown sources unused.
