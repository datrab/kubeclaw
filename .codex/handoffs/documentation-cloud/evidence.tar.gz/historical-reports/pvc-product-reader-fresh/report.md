# Independent PVC product reader review

Verdict: **FAIL** for this affected reader route at `443e138c33ae7b83ffc33aed79f5fa04d784f4b0`.
Reviewer: `/root/pvc_product_reader_fresh`, reader only, fresh context, initially and throughout read-only on the repository. I did not author the page, provide Source acceptance, or provide Quality acceptance. This is not whole-package A98 or AP09 acceptance.

The bound-claim addition is understandable and passes its manual reader task. The remaining material failure is in the conditional SMB investigation: the page asks the reader to determine effective policy/options and select the actual component, but does not provide the necessary runtime discovery path. The symptom navigation also lacks the affected storage symptoms. No actual Kubernetes, mount, deletion, backup, restore, deployment, or application operation was executed.

## Authority and scope

All product-documentation observations came from frozen Git blobs exported into `frozen/docs/site`. The working checkout had moved to `2cfab37c9b121d64427475e8d86abc7e41771527` and contained unrelated generator edits (recorded in environment.json). Those files were not evidence. Thus this is an immutable-blob review, not a claim of a clean mutable checkout. No repository files were written or committed. Evidence files are outside the repository.

Read the entire quality standard `docs/blueprint/07-documentation-quality-standard.md`, the acceptance contract including the 10 October product boundary and A98-02/06/10/11/13, and the reader fixture definitions. Fixture facilitator fields were not used to answer these supplemental storage tasks. The four inputs in manual-fixtures.json were independently devised, synthetic observations, not hidden author answers or real command outputs. These are supplemental manual Find/Understand/Act exercises, not reported executions of READER-OPERATOR-01 through -04. Those registered live tasks are post-documentation product validation under the frozen contract and were not run.

Examined the complete `reference/configuration-change-impact.md`, including all of its affected PVC route, the complete site entry and operator entry, the reference entry and product surface navigation, the storage-related parts of `understand/data-and-state.md`, `understand/platform-and-operations.md`, and `understand/prism-data.md`, and the connected diagnosis, retention, maintenance/decommission, recovery prerequisites, nonnegotiable rules, restore qualification and application-verification boundaries. Related-file review is limited to the connected sections, not acceptance of every procedure on those large pages. Frozen exports include the other site pages only to allow read-only searches for an existing explanation of the required runtime inputs; their presence is not proof that they were fully reviewed.

Linked upstream evidence read where needed: pinned SMB chart values, DeleteVolume, NodeStageVolume, existing-target check and timeout wrapper, and Kubernetes bound-claim reconciliation. Exact downloaded bytes and URLs are in upstream/. This narrow reader use of linked code does not substitute for independent Source audit. No author report, chat solution, package README, migration narrative, mutable metadata, or generator result supplied the exercise answers. A preliminary filename search of the parent workspace found only unrelated AGENTS paths, whose contents were not opened or used; the review then used the exact frozen standard path supplied by the task owner.

## Manual task results

### PVC-READER-01 — empty chart class and actual driver: PASS

Find: site entry → Reference → Configuration change impact → PVC reclamation and retained data. The reference entry links the page at line 39; product-surfaces.md line 59 provides another configuration route.

Understand: chart `storageClass: ""` omits the API field (impact lines 444–451). This permits default admission or later default assignment. Explicit API `storageClassName: ""` means no class; it is not an instruction to choose the default. A currently default SC does not overwrite the stored bound claim's class in the reasoning here. Installing the configured SMB Application does not prove this claim uses SMB.

Act selected, not executed: `kubectl --context <context> -n <namespace> get pvc <claim> -o yaml`, then `describe pvc`; take pv-101 and fast-rwo from that stored object; `get pv pv-101 -o yaml`; `get storageclass fast-rwo -o yaml`. Inspect the PV CSI driver and SC provisioner. Synthetic results identify disk.example.test, so do not apply the SMB-specific table. For scratch's explicitly empty class, skip class-name lookup. A claim with no bound volume name stops before PV commands. The procedure gives the basic placeholders, read authority, access failure stop, identities to retain and no-resource cleanup rule. This PASS shows selection and interpretation, not default admission or provisioning on a cluster.

### PVC-READER-02 — a previously Bound claim loses binding: PASS

Find: same page, new subsection at lines 500–511; read-only diagnostic sequence at 576–619.

Understand: incident A is a missing bound reference and ClaimLost; B is a recorded PV absent from the API observation and ClaimLost, without proving why the controller cache lacked it; C is a different claim lifetime and ClaimMisbound. Same namespace/name is insufficient when UID differs. A PV without claimRef is a separate repairable branch; none of these object observations establishes server data erasure.

Act selected, not executed: read PVC YAML and describe output for each incident, compare retained prior namespace/name/UID/volumeName to current objects. In A, obey the explicit empty-volumeName stop before a guessed `get pv`. In B, retain the prior PV identity, the NotFound and event timestamps; stop rather than inventing a replacement PV. In C, read the named PV and record c-203 versus c-older. Retain identities and ask the storage owner for the volume inspection before replacement storage or recovery. Do not edit claimRef, force finalizers, delete storage, or infer application recovery. The source-backed interpretation and safe escalation are available without author context. This PASS does not prove a controller transition, rebinding, or data recovery.

### PVC-READER-03 — release removal versus explicit retirement: PASS

Find: reference PVC route plus site entry → Operate → canonical task map → Maintain and Retire, canonical decommission procedure. Maintenance lines 690–773 supply the explicit destructive scopes.

Understand: retention annotations control release/GitOps removal; they do not establish erasure. Kept PVCs remain different from a deliberately deleted PVC. PV Retain prevents reclaim; PV Delete delegates selected external-driver cleanup. The disk.example.test PV requires its own contract and cannot inherit SMB directory behavior. The Prism database claim template's Argo retention is separately described, rather than falsely claiming it has the artifact claim's Helm keep annotation.

Act selected, not executed: capture PVC/PV identities, retention annotations, reclaim policy and actual driver. Identify the intended removal command and signed inventory in the decommission route. `teardown-agents`/`teardown-prism` differ from `teardown`, which explicitly deletes remaining application PVCs, and from namespace-wide `teardown-all`. Since independent application restore is unverified, stop before destructive cleanup. Recovery's nonnegotiable rules preserve the old environment, require independent media and isolated application proof, and state the current external Prism/full-platform boundaries. A deletion would require final backup and destruction authority; no deletion was selected for execution. The task outcome is correct safe refusal, not completed retirement. A direct link from impact line 474's “route below” to maintenance would improve navigation, but the existing task navigation was sufficient for this manual task and is not separately counted as material failure.

### PVC-READER-04 — conditional SMB uncertainty: FAIL

Find: the configuration route reaches SMB deletion and mount sections. Starting with the ordinary diagnosis task, the symptom index lacks Lost/ClaimMisbound, reclaim deletion uncertainty, and SMB mount timeout entries (see finding R2).

Understand succeeds: a credentials lookup failure can still reach a driver with no secrets; subsequent API disappearance is not erasure proof. Archive can remove an earlier archive before failing rename, leaving partial loss. Mount timeout does not establish that the worker stopped; the 110-second wait/lock explanation is explicitly an inference. Bound does not prove application reads or a backup. Do not repair these outcomes by retry, finalizer removal, or replacement storage. Selected image overrides/different drivers are explicit stop boundaries.

Act selected, not executed: start with the provided PVC/PV/SC reads and retained incident record. Read VolumeAttachments and correlate PV name. If an independently selected component identity is available, the documented image and timestamped log commands are valid for it. Retain the failure chronology, object identities, handle, image versions, and backup evidence. Request storage-owner observation of the actual share and both original/archive locations; no mount or share operation was executed.

The exercise cannot complete the published effective-input investigation from this reader route. The page names `removeArchivedVolumePath` and an empty onDelete fallback, but does not identify how to read their selected runtime value. The downloaded linked chart values do not supply those runtime options. The provided image-only JSONPath omits container names, command/args, and actual image IDs; it cannot establish the missing policy or select the log container. I could invent a general pod-discovery/argument-inspection workflow from Kubernetes experience, but that would be an undocumented required step and still would not identify which arguments/defaults to interpret. The linked DeleteVolume branch shows a driver member fallback, not where an operator reads its effective configuration. Missing staging-target/worker observation likewise leaves inspection unresolved. The correct interim action is a safe stop and storage-owner escalation; this safety outcome does not make the procedure's required effective-input investigation complete.

## Material findings and necessary correction

**R1 — runtime input and component discovery is incomplete.** `reference/configuration-change-impact.md:539`, `:547`, `:564`, `:588`, `:600`, `:605`, `:606` and `:609`.

The prose requires effective SMB policy/options, non-secret deletion credential references, actual driver/provisioner images, staging target and continuing work. It only supplies already-selected-Pod image and log reads, PV/SC YAML and attachment reads. The reader is told what `<driver-namespace>`, `<driver-pod>` and `<container>` mean, but not how to identify them from the actual PV driver, nor which component and node to inspect for deletion versus mount. There is no mapping from volume handle/configuration to effective onDelete and driver fallback or removeArchivedVolumePath. An all-site frozen search found only one removeArchivedVolumePath mention, four onDelete mentions, no defaultOnDeletePolicy, no default-ondelete or remove-archived explanations, and no other staging-target explanation. This is necessary input for a documented supported conditional path, not a demand for every unused upstream Kubernetes field.

Correction: provide a narrow read-only path from recorded PVC/PV/Pod/node and CSI driver to selected controller/node Pods and named containers; retain name/image/imageID and relevant configuration without exposing Secrets. Explain the exact runtime sources and precedence for handle policy, empty-policy default, archive-removal option, and deletion-versus-node-stage credential references. Provide concrete permitted observations for the selected staging target and worker state, or explicitly name the unsupported inspection step, required external owner procedure/input and stop before retry until supplied. Stop when actual versions or required runtime inputs cannot be established; a default chart tag alone is insufficient.

**R2 — affected symptoms have no canonical diagnosis entry.** `use/diagnose.md:192` through `:213`, connected to impact `:500`, `:513`, `:556` and `:576`.

The symptom index contains no PVC Lost/ClaimLost/ClaimMisbound, released PV/deletion uncertainty, or SMB FailedMount/timeout route. Its general restart/storage row gives no distinguishing storage checks or link to the new detailed procedure. The task can be found from the broad reference route, but the canonical observable-symptom path does not lead to it.

Correction: add concise symptom rows linking the PVC diagnosis route, with volumeName/PV/UID checks and a safe stop, plus a conditional selected-SMB mount/deletion uncertainty row. Keep actual-driver selection ahead of SMB assumptions. No large upstream schema catalogue is needed.

## Bounded acceptance criteria

These are judgments only on the affected reader slice, not full gate acceptance.

| Criterion | Reader-slice verdict | Reason |
| --- | --- | --- |
| A98-02 | FAIL | R1 prevents completion of prerequisites/effective runtime-input and component selection for the conditional investigation. Basic object commands and placeholders are otherwise intelligible and read-only. |
| A98-06 | FAIL | R2 omits the symptom-to-distinguishing-check path; R1 leaves conditional uncertainty investigation incomplete. |
| A98-10 | FAIL | Selected conditional defaults/options materially needed by this task are named without a concrete effective-value check. This is not an inventory/generator audit. |
| A98-11 | FAIL | Empty onDelete fallback and archive-removal selection cannot be traced from observed runtime input to consumer using this route. Omitted chart class versus empty API class is correctly explained. No test execution or global precedence acceptance is claimed. |
| A98-13 | FAIL | Three manual tasks succeed, but conditional SMB task still needs undocumented selection/inspection knowledge. No fake execution claim was found. |

Read-only commands shown on the page have valid kubectl shape after placeholder replacement, and RFC3339 since-time has a clear source. Do not paste literal angle-bracket placeholders into a shell. The procedure specifies approved context/read access, failure/UID stops, protected evidence, no resources created and no cluster cleanup. Its execution location could be clearer by directly linking the independent administration/bound-cluster procedure; I have not counted that as another material failure. The missing environment itself is not a failure: these manual tasks evaluate whether the reader can select safe action and recognize the honest unsupported boundary.

## Evidence and not run

Executed only local Git reads, frozen export, local file searches/reads, environment observation, and retrieval of the pinned public files linked by the reader page. Successful local commands exited zero; no kubectl or cluster tool was invoked. Commands selected in task prose are hypothetical read-only choices, not logged successful product operations. The manual fixture observations are expressly synthetic. No fake cluster PASS, erasure, restore, version compatibility, driver deployment, publication rendering, browser layout/search-rank result, automatic drift check, or complete source audit is claimed.

Full source and publication acceptance, all unused/general Kubernetes fields, every other site procedure, all A98 catalogue IDs, live READER-OPERATOR tasks, execution scenarios and mutation runs are outside this affected-route reader assignment. The missing full-platform/external application recovery remains an honestly documented product boundary, not the reason for this FAIL. Evidence retention and support-limit explanations are satisfactory for the selected stop outcomes. A fresh independent reader must repeat the affected conditional task and symptom route after R1/R2 correction.
