# Nova boundary author report

Author contribution only; no independent acceptance verdict.

Repository: /home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04
Source HEAD: a1569b61663e4bc85e11d38bd896bb99ed0bd396
Retained implementation pin: 4f089958db97a551f406c157d774bda143a38946
Exclusive authored page: docs/site/understand/nova-core.md

Read the documentation quality standard and the AP09 acceptance contract, including missing historical reasons, supported product limits, evidence classes, and independent acceptance requirements. NVC-009 requires the full signal-type/payload/consumer boundary, not only the generic envelope.

Delivered changes:
- Effect recovery identifies the exact blocked next-attempt admission, both errors, absence of a generic receipt-import/manual repair interface, and the shared guard reached by administrative retry/remediation. External checking does not become Core authority. Safe stop, original identities, raw-before-audit preservation, owners, and measurable continuation acceptance conditions are explicit.
- Production signal table includes generic and architecture approval, Core ordinary and repair orchestrator signals, review's returned kubeclaw.review.resolve and its rewrite to the platform issuer/core.orchestrator.resume, missing original request context, and conditional Prism approval. Payload consumers, closed/open keys, expiry, issuer checks, and guidance limits remain separate from envelope acceptance.
- Prism trace identifies stage.ts:28's architectureDigest, payload.ts:4/95's rejection before delivery reservation/publication, failed external receipt wrapping, and stage.ts:34's blocked dispatch_failed result. Earlier dispatch/wait-adapter records do not create an active Core wait. No success or implementation fix is claimed.
- Design explanations use current technical inference, unknown local historical disposition, problem/approach, benefits/costs, implementation limits, reconsideration conditions, and adjacent implementation evidence. The broader canonical decision records remain linked for their separate recorded history.
- Existing raw-before-audit and post-resolution stop rules remain intact.

Evidence:
- full-file-equivalence.json compares entire bytes of 64 current source files with both HEAD and the retained pin. It covers all 98 final Nova blob links and code entries from the previous full-file manifest. All files match both revisions; all linked ranges fit. Directory index links are not treated as exact behavioral evidence.
- core-guide-check.log: final existing full guide check exits 0; 3 pages, 52 requirements, 211 pinned links, 121 current source files. This is bounded automated verification, not content or execution acceptance.
- diff-check.log: final git diff --check exits 0.
- reader-boundary-check.log: exits 1 solely for existing Helm phrases at 1824, 1925, 3869. The initial run also identified two Nova phrases; corrected them to direct product limits. The final run has no Nova findings. No global reader-boundary success is claimed.
- source-links.txt lists the page's precise source URLs. nova-core.diff is the current page diff against HEAD, including preserved earlier boundary work.

Language author pass: read the whole page, revise the bounded new sections using named actors and explicit conditions, preserve exact identifiers, and remove internal source-inspection bookkeeping phrases found by the existing reader check. Technical terms retained include wait, signal envelope, guidance, receipt, fencing, idempotency, digest, issuer, and lifecycle; their meaning is connected to the existing page mechanisms. This is a project controlled-language author pass, not formal ASD-STE100 certification or an independent language review.

Limits: no production lifecycle, wait/resume, adapter publication, recovery, deployment, renderer, fresh-reader, or independent acceptance exercise was performed by this author. The Prism path remains blocked by the real publication contract. General external-effect continuation remains unimplemented. No runtime code, repository scripts, other pages, acceptance status, commits, or remote state were changed by this author. The page is released for independent review; no author self-acceptance.
