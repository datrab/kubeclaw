# Prism and platform controlled-language author correction

Date: 2026-10-10. Role: assigned-page author only. Source HEAD: `f68a7294abf0928c1aabf290c6a7e486c651a808`. Branch: `docs/documentation-overhaul`. The shared repository contains unrelated concurrent changes; this task does not treat it as a clean checkout.

## Assignment and changes

Only `docs/site/use/prism-studio.md` and `docs/site/reference/pipeline-platform.md` were edited in the main repository. The saved before/after files and `assigned-pages.diff` identify the exact authored changes.

All nine diagnostics in the supplied `publication-style-partial-current.log` were addressed. Long sentences now split at the unchanged deployment, model-route, tool-commit, worker-health, package-version, and browser-failure boundaries. Evidence statements use direct wording without claiming an unexecuted check. Historical revisions, dates, test counts, exit statuses, browser builds, aggregate stop order, and local/fixture/live limits remain intact.

Prism Step 3 corrects independent Source finding S-01. Studio shows a direction's title and summary, any trade-offs, and the count when references exist. Otherwise it reports no matched approved corpus reference. It does not display individual reference IDs or summaries. A new adjacent source link points to `skills/prism/studio/app.tsx#L615-L620` at the page's existing `ec2a42ed...` evidence pin. That complete source file matches the independent finding's `7e413cf...` pin and the current source HEAD (`finding-source-continuity.json`). The schema's ability to carry reference IDs/summaries does not prove UI display.

Platform change-impact prose names Nova as the component that supplies `effectLockTtlMs` when it creates the coordinator. Nova supplies 300,000 ms when the field is absent; the coordinator retains that duration. Editing a file does not update an existing coordinator. `createAdapterRuntime` and the complete `EffectCoordinator` implementation were inspected. The existing adjacent source pins remain unchanged. No reload, hot update, or new owner behavior was invented.

## Review method and sources

The complete project `docs/blueprint/07-documentation-quality-standard.md`, applicable A98-02/04/10/11/12/13 contract entries, and CFG-002/013/014 plus OPR-010 catalogue descriptions were read. Both complete authored pages were read, including prerequisites, all eleven journey steps, interruptions, trust and provider ownership, worker diagnostics, historical evidence, and product limits. The independent Source finding/report supplied the correction requirement, not an acceptance verdict for these new bytes.

Source reading included the full Studio `app.tsx`, `design-round-client.ts`, `agent-job-runner.mjs`, `openclaw-plugin/index.mjs`, `worker-service.ts`, `engine-runtime.ts`, `effects/coordinator.ts`, `configmap-gateway.yaml`, both spike package definitions and Playwright configurations, and the actual `cmd_prism` deployment/CSI guard/smoke sequence. Source checks were tied to the current immutable HEAD and the preserved published evidence pins. The deployed cluster and remote provider routes were not inspected or exercised.

This is project controlled-language author revision using the declared ASD-STE100 principles: direct actors, explicit conditions, small connected explanations, exact identifiers and evidence limits. It is not formal or certified ASD-STE100 compliance; the complete licensed dictionary/rules were not available here. Technical vocabulary remains the existing glossary/contract vocabulary: SPIFFE, CSI, Control, Nova, coordinator, TTL, HMAC, nonce, OpenClaw, Codex, LiteLLM, embedding, idempotency, revision, approval, baseline, ARIA, Playwright and Chromium. No glossary or technical-term exemption changed.

## Executed bounded checks

`commands-results.json` records exact argv, working directory, start time, duration, exit status and stdout/stderr artifact for the final bytes.

| Check | Actual result | Scope |
| --- | --- | --- |
| `python3 preservation-check.py` | Exit 0 | All 17 fenced examples preserve exact before bytes; all 14 Bash blocks pass `bash -n`. All 243 original pinned links remain; exactly one UI evidence pin was added. All 244 current links resolve to in-bounds ranges; all 86 distinct pin/file combinations match complete immutable current-source and working-file bytes. |
| `git diff --check -- <two assigned pages>` | Exit 0 | Assigned diff has no whitespace errors. |
| Original `npm run docs:publication:check` | Exit 0, 147 pages and 51 plugins | Unmodified checker run against the current shared site. This reports the checker result only, not independent reader/source/quality or whole-package acceptance. |

The `preservation-results.json` contains each source URL, pin, path, range, pinned/current/working SHA-256, page before/after hashes, and every Bash syntax result. The supplied nine-diagnostic list identifies the initial findings. Earlier publication invocations also exited zero; only `publication-current` represents the final released bytes. No policy, checker, lint configuration, helper, source, register, glossary, generated page, inventory or completion matrix changed in this author assignment. No full generation or duplicate mutation package ran. No commit, push, deployment, browser run, model request, native attempt, or live operator execution occurred.

## Limits and required independent continuation

No A98 gate, catalogue ID, Source role, Reader role, Quality role, or global AP09 status is accepted by this author report. The bounded command and preservation checks cannot replace full independent acceptance. In particular, an old independently frozen review cannot accept the revised page bytes. The lead must obtain fresh independent affected Source review and Reader/Quality review after these edits. The unchanged live and local product limitations remain documented, including absent runtime release selection, fixed spike browser path, uncertain job/retry boundaries and missing browser recovery surfaces.

## Explicit file release

Both assigned main files are released now for lead integration and fresh independent review: `docs/site/use/prism-studio.md` and `docs/site/reference/pipeline-platform.md`. This author will make no further edits unless reassigned. The after snapshot and hash manifest identify released bytes. Release grants no self-acceptance and no merge/publish approval.
