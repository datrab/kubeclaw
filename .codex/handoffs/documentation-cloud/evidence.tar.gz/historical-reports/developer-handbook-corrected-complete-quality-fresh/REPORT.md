# Corrected Developer handbook: independent complete Quality review

Verdict: **PASS for every assigned Quality facet. No residual material Quality finding.** This is an individual content/architecture/language review of the two exact candidates. It does not award a complete acceptance gate, package, AP09/global result, Source approval, formal Reader exercise, or successful execution of every example.

## Identity, assignment, and method

Reviewer identity: `/root/developer_handbook_corrected_complete_quality_fresh`, separate fresh-context child of the coordinating agent. Role: Quality only. I did not author either candidate and did not act as its Source reviewer, clean-reader participant, or integrator. Repository access remained read-only; all writes are private evidence in this directory. No commit, push, repository edit, install, host modification, provider or cluster call occurred. No applicable ancestor/repository AGENTS.md was found.

The session describes this agent as Codex based on GPT-6. The installed tool configuration at `/home/node/.codex/config.toml`, lines 7–8, reports `model = "gpt-6.1-sol"` and `model_reasoning_effort = "medium"`. These are actual visible configuration values, not an independently attested backend model certificate. The parent confirms that the actual spawn tool explicitly selected `fork_turns="none"`, `model="gpt-6.1-sol"`, and `reasoning_effort="medium"`. This is parent tool/task configuration attribution; it does not attest backend routing. `identity.json` records this attribution and its limits.

The method was a complete manual reading of all 1,342 handbook lines and the entire 5,763-byte public JSON exercise, followed by requirement-by-requirement assessment, primary-source reading, and bounded read-only byte/mode/range guards. I read the full quality standard, acceptance contract and fixture file; the execution-plan scope and relevant Core/Developer/Reference/Publication/integrated acceptance sections; all DEV-001…009 and QUA-001…010 catalogue records. I read the earlier complete Quality FAIL and the author correction report as historical evidence, not approval. No new Source PASS report was used to establish this verdict.

Controlled-language method: project ASD-STE100-inspired review, applied manually to the complete candidate, including tables, command framing, technical vocabulary, source callouts, failures, and JSON input. The licensed full dictionary/writing rules were not supplied; formal ASD-STE100 certification/compliance is not claimed. Reviewed vocabulary includes workspace, runtime role, contract, projection, digest, fixture, fsync, metadata, inode, pathname, lock, journal/replay, attempt, administrative result, discovery/admission/activation, artifact, provider, source/result authority, native scope, capability/grant, receipt, image/bundle/deployment identity, compatibility, irreversible data boundary, and remaining state. Six foundational definitions are inline; fsync/metadata/inode/pathname and the competing-lock consequence are defined before the setup safety rules. Component-specific meanings use the adjacent canonical architecture/extension/task links. Practical IT prerequisites and exact product/API names remain intact. This review does not turn unused upstream Kubernetes alternatives into a course.

## Exact candidate and authority boundary

Repository: `/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04`; branch `docs/documentation-overhaul`. Product evidence revision: `671234b056bf5f5f503e51e8db30f843e781ba6e`.

| Candidate | Bytes | SHA-256 |
| --- | ---: | --- |
| `docs/site/extend/developer-handbook.md` | 97248 | `ccebdd16f6aee7445784433e9fa298669e2f47dc2516dd4cf19e3d1bc438f36e` |
| `docs/site/extend/examples/platform-change-nova-lifecycle.json` | 5763 | `2a1d752198305331536e73a771fb0e2096eb501266f43612f6286ca786e406fc` |

`before-input-guard.json` and `after-input-guard.json` bind the two candidates, five assignment authorities, 68 pinned source files, and directly linked local reader dependencies: 109 distinct necessary inputs. These inputs stayed byte-identical across the captured guard interval. Candidate copies retain the reviewed bytes. The assigned hashes also match the complete candidate reading. `source-pin-validation.json` validates 117 full-SHA pins, regular Git modes, ascending in-file ranges and current/pinned byte equality. These counts describe structural scope and are not a quality score or exhaustive semantic Source approval.

First captured concurrent HEAD: `b8ffca0f637aa4e426281e58fded2afeb88c16f6`. Final captured concurrent HEAD: `e65738b302f0ad028e564f8f6f556fe26d3e144c`. The shared tree had concurrent unrelated capacity/documentation-tool work. HEAD equality and a globally clean or immutable checkout are **not** claimed. The guarded necessary bytes and final candidate equality, rather than a whole-tree seal, bind this report. The first full guard was captured after initial reading; the exact assigned candidate hashes and saved copies are explicit, and no unobserved earlier whole-tree freeze is asserted.

## Material findings and correction check

No additional correction is required in the assigned Quality scope.

Previous QF-01 remains a historical FAIL for its old candidate. It is resolved in the new candidate at handbook lines 32–43: fsync is explained as a synchronization request, metadata as information about a file, and inode/pathname as object/name selection. The explanation states why pathname replacement can permit a competing lock on a different object. The safety rules preserve filesystem qualification and do not promise parent-directory-entry durability. Cleanup at lines 340–343 reuses the defined term. Primary authority: `skills/nova/core/state/file-mutex.ts:4–23` and `state/journal.ts:125–156` at the product SHA; I read both mechanisms directly.

I also reviewed all surrounding text and the four prerequisite/CI corrections, not only QF-01. Ops steps at 949–1005 define isolated Python/venv/pip setup, pinned PyYAML verification, the actual assertion command, retained failure evidence, and exact path cleanup after an exited shell. Telemetry at 799–852 distinguishes PATH Go/gofmt from the independent Go 1.24 module and fixed absolute executable, fresh caches, and locked dependency access. Nova at 446–454 links the archive preflight before selecting remote checks; Buster at 584–630 names absolute `/usr/bin/tar`, GNU identity, failure/stop, retained evidence and fixture-owned cleanup. The CI row at 1169 separates the 20-minute upstream-checksums timeout from undeclared policy/Envoy job limits. I read the actual Python imports and both CI pins, Go module/lock and invocation/cleanup, telemetry generation/test invocations, all three archive consumers, and complete update workflow. The new prose is actionable and does not invent success.

## Individual DEV Quality decisions

Each PASS is only the assigned Quality/content facet of the named catalogue record, with its catalogue owner/target preserved. Canonical target for all nine records is `docs/site/extend/developer-handbook.md`; owner is developer experience maintainers.

| ID | Verdict | Reader result, location, and authority |
| --- | --- | --- |
| DEV-001 | PASS | Lines 11–23, 206–263 and ten routes give a central owner-based path for Core, services, UI, contracts, data, deployment and release; request-to-result and extension choices connect the system view. Ownership authority: package-ownership dependency rules and component entrypoints. Navigation inclusion remains integrator work. |
| DEV-002 | PASS | Lines 25–204 give checkout/revision/root/tool/install/build/baseline order and distinct Go, Python, browser, service, package-lock and credential prerequisites. Defined storage terms explain the safety consequence. Authority: root lock/workspaces, launcher, FileMutex/journal, module declarations and CI tool selections. No clean-checkout execution is awarded. |
| DEV-003 | PASS | Lines 206–304 and 408–1092 identify entry/build/check/debug/log/start/cleanup ownership. Nova/Worker library boundaries and Prism/MCP/UI listeners are distinguished; canonical operations own deployed inputs. Authority: package scripts, server entrypoints/configuration and native/Archviewer fixtures. No service/native/browser execution is awarded. |
| DEV-004 | PASS | Lines 306–360 give six ordered selection questions and evidence classes, followed by exact conditional component chains. Nova 428–497 supplies unit/contract/replay/recovery/historical/SDK/docs plus new assertions and removal. Authority: root scripts and lifecycle/compatibility fixtures. Required environment failure stays unexecuted/failed. |
| DEV-005 | PASS | Lines 1154–1202 cover 13 workflow triggers, conditions, limits, trust/secrets, concurrency, artifacts and merge/release consequences. Required branch protection is explicitly external/unknown. Authority: actual workflow files, including update-checks timeout. No hosted run/settings proof is awarded. |
| DEV-006 | PASS | Lines 237–304, 408–474, 745–786 and release compatibility describe erasable ESM TypeScript, exports/import type, prohibited aliases/dependencies, schema-first generation, unchanged event identities, closed-schema and retained-byte consequences. Authority: tsconfig, owner/check scripts, schema generators and replay source. |
| DEV-007 | PASS | Lines 1094–1152 define authority questions, denial/fixture/scanner selection, real database/tool prerequisites, exact journal load/ceiling and comparable/predeclared budgets. Authority: real security CI, journal scale and retention measurement code. No enforcement, measurement or capacity result is inferred. |
| DEV-008 | PASS | Lines 1204–1272 distinguish independent version identities, synchronization, supported pairs, notes/deprecation, receipts, promotion and irreversible rollback. Authority: versions, release workflows and rollback contract. Missing compatibility facts stop release and name an owner; no universal private-package SemVer rule is invented. |
| DEV-009 | PASS | Lines 1274–1324 map changed authority to owner/page/check, separate generated/authored sources, refresh source pins, and require addition/change/removal/rename/redirect proof. Authority: documentation governance and map routing. No complete dynamic discovery/mutation integration is awarded. |

## Individual assigned acceptance-gate Quality decisions

| Gate | Verdict | Assigned facet and practical limit |
| --- | --- | --- |
| A910-01 | PASS | Setup/baseline text is clear, prerequisites precede action, storage safety is defined, and missing tools/packages stop the affected route. It can be assessed without hidden personal/global assumptions. This is not a clean-checkout participant execution or full A910-01 approval. |
| A910-02 | PASS | Ownership/build/generated boundaries, dependency direction and codegen order have reasons, consequences and precise source callouts. It is more than a directory tree. Full integration and Source approval are separate. |
| A910-03 | PASS | Build/test/Lint/version/release/compatibility routes name commands, selected environment, observations, safe stops, retained evidence and cleanup. Aggregates carry prerequisites and do not mask partial failures. All-example execution is unawarded. |
| A910-11 | PASS | All ten prescribed routes select checks by changed invariants and adjacent boundaries. Nova's desired change/error/crash/compatibility/removal input is coherent and bounded. `READER-PLATFORM-02` is associated but not executed by this reviewer. |

## Individual assigned QUA Quality decisions

QUA catalogue owner is independent documentation reviewers, canonical aggregate target `docs/site/status/acceptance.md`. The locations below are this candidate's contribution, not a global result at that aggregate page.

| ID | Verdict | Assigned facet and limit |
| --- | --- | --- |
| QUA-001 | PASS | Whole candidate uses connected technical English and preserves mechanisms, ownership, state, failure and practical limits. Corrected storage definitions resolve the old consequential ambiguity. |
| QUA-002 | PASS | Complete manual project controlled-language review found no residual material finding; necessary terms have inline or canonical contextual explanation and exact identifiers remain. No formal ASD-STE100 claim. |
| QUA-003 | PASS | Lines 253–263 mark missing historical reason unknown, current benefit inference, cost and reconsideration. Significant operational/compatibility choices explain consequence and link the deeper canonical decision/task authority; code is not invented history. |
| QUA-004 | PASS | Six-part claim/source/contract/test/revision/limit callouts sit beside claims and honestly separate actual and unexecuted checks. Pin currency/ranges are guarded. Full Source semantic and published-render approval remain separate. |
| QUA-005 | PASS | Failed GNU-lock, portable SDK, scale, MCP and missing Python/Go/tar proof remain failed/unexecuted. No clean-reader, native, image, deployment, live, release or restore success is inferred. |
| QUA-006 | PASS | Assigned content-readability facet: foundational terms, owner selection and linked task/mechanism paths let a practical IT reader interpret the route. No end-to-end new-reader/navigation exercise or whole-site result is awarded. |
| QUA-007 | PASS | Assigned operator-boundary facet: exact operation/recovery/maintenance links carry deployed authority; isolated fixture handling and failed readiness are explicit. No operator live/restore exercise is awarded. |
| QUA-008 | PASS | Assigned extension-boundary facet: compilation, registration/activation, compatibility/removal and remaining state are distinguished, and creation is routed to canonical guides. No extension-class/complex-plugin practical result is awarded. |
| QUA-009 | PASS | Assigned platform-change content facet: ten routes plus the public Nova change input provide ownership, baseline, negative/recovery, compatibility and removal conditions. No registered participant execution is awarded. |
| QUA-010 | PASS | Assigned maintenance-content facet: source-to-page/owner, separate generators/authored explanations and add/change/remove/rename drift obligations are explicit. No 84-mutation or global maintenance proof is awarded. |

## Complete component and facet coverage

| Route/facet | Verdict | Specific reviewed boundary |
| --- | --- | --- |
| Nova, 408–497 | PASS | Result guard, attempt accounting, administrative stop, replay, exact targeted chains, debug timing limit and baseline/change/crash/removal exercise. |
| Worker, 499–552 | PASS | Generic library versus native authority, delegated scope prerequisites, trust separation, denial/cancel/deadline/crash/adoption and retained ownership/spool cleanup. |
| Buster, 554–641 | PASS | Resolver/provider/report/import authority, fixed GNU archive tool, conditional service/launcher/provider checks, duplicate/result-response loss, signatures and retained records. |
| Prism, 643–693 | PASS | Contract/domain/storage/native/service selection, database ownership, listeners/access, exact start table, signals and durable failure cleanup. |
| Registry, 695–743 | PASS | Inert plugin admission versus writable OCI storage, absolute Distribution binary, offline garbage collection, restart/digest retention and rollback images. |
| SDK, 745–786 | PASS | Public/testing exports, schema authority, portable identity and historical compatibility, generated versus runtime semantics and failed GNU-lock proof. |
| Telemetry, 788–873 | PASS | Source event versus derived view, two Go execution boundaries, module/lock/cache prerequisites, duplicate/order/correlation/redaction/restart/checkpoint/remaining journal. |
| Charts/GitOps, 875–930 | PASS | Supported product fields, conditional/omitted defaults, render versus cluster, release selection, backup/health/irreversible boundaries and preserved PVC/data. |
| Ops MCP, 932–1041 | PASS | Independent npm and isolated pinned Python dependencies, exact fail-fast ordered policy steps, local bearer/listener/read errors, namespace limits, image/live split and owned cleanup. |
| UI, 1043–1092 | PASS | Studio operation revision/conflict and browser checks; Archviewer static authentication with absent publisher stop; report/log/listener cleanup. |
| English/necessary terms | PASS | Whole prose/table/fixture scan; no unexplained consequential storage noun remains. Exact names are preserved, technical routes link canonical meaning. |
| Ordered tasks/prerequisites/results | PASS | Common root/stop rule, setup order, generators before consumers, selected environment before dependent checks, meaningful observation and failure interpretation. |
| Reasons/costs/limits | PASS | Owner separation and evidence classes explain cost; inference/unknown history is explicit; missing environments and product capability boundaries have owners and closure conditions. |
| Safety/error/cleanup/remaining data | PASS | Owned fixture scope, uncertain effect reconciliation, durable journal/lock/result preservation, isolated databases/host, secrets and irreversible release/data rules. |
| Source-citation quality | PASS | Full SHA and six fields; valid/current pinned bytes; no Source/Pub renderer outcome inferred. |
| Versions/releases/maintenance | PASS | Independent identities, generator/write distinction, old/new pairs, immutable receipts, write-authority promotion, deployment rollback limits and drift/remove/rename obligations. |
| Public exercise boundary | PASS | Desired behavior is task input, not shipped change or execution evidence. Bounded administrative retry and neighboring cases, invalid state, durable-block crash, projection distinction, unchanged identities and clean removal are precise. No internal facilitator/scoring/time-limit/source-file/test-command hints are embedded. |
| Internal work-language exclusion | PASS | Candidate contains no AP/handoff/review/migration-history artifacts. Product source review, data migration, real human acceptance and bounded test status are legitimate reader concepts. |

## Actual executions, attribution, and exclusions

I executed only filesystem/source reads, Git object/mode/status reads, private candidate copies, JSON/hash extraction and the private guard. Exact retained command: `python3 /home/node/Documents/Codex/a98-evidence/developer-handbook-corrected-complete-quality-fresh/check-quality-inputs.py`, exit 0, log `check-quality-inputs.log`. It verifies input equality, all 117 pins and 20 recorded artifacts from the original author manifest. `attributed-evidence-integrity.json` also hashes the author execution/environment/report inputs and previous Quality/correction reports. Evidence counts are inspection scope only.

Earlier author executions remain attributed to the author. They include passing lifecycle/registry contracts, SDK helper, snapshot compatibility and Nova typecheck, and failing journal/lifecycle recovery, portable SDK, scale and MCP startup attempts. The corrected author retained missing-yaml and absent absolute Go/tar prerequisite diagnostics; these are failures/prerequisite stops, not Python policy, cross-language or archive recovery success. I read the original delivery and correction evidence and primary prerequisites; I did not rerun product checks or borrow their success as my own Reader/Source approval.

Not executed: new clean checkout/install/baseline sequence, native GNU-lock/journal/SDK/scale recovery, Python environment/install/assertions, telemetry generation/Go execution, remote archive/provider/restart, broad product/docs gates, generators, publication or browser rendering, mutation suite, image build/scan, OCI fixture, PostgreSQL, cluster/provider/service/live paths, release/promotion/rollback/restore and registered independent reader exercises. The public fixture remains `not-executed`. Honest failure and unsupported-boundary prose can pass this assigned text-quality review; they do not satisfy a required practical execution gate.

Final captured candidates equal both requested hashes and all captured necessary inputs are unchanged. Concurrent HEAD movement is separately recorded. No material Quality correction remains; integration, formal Reader execution, distinct Source approval and global gates remain the coordinating owner's separate work.
