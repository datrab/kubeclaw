# Finite JavaScript caller and Ops fixture correction author proof

Scope: exclusive changes to `scripts/docs-api-output-role-classification.mjs` and `scripts/tests/api-reference.test.mjs`. Repository: `/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04`. Existing uncommitted integration changes were retained. No registry, discovery, schema, product file, host configuration, commit or push changes were made.

Read project documentation quality standard and AP09 acceptance contract. Author/unit/render proof only; this is not independent review or acceptance.

The finite caller failure reproduced at test line 700: selectedCommand existed, but accepted only the exact subprocess expression while the fixture selected enclosing function `query` and its actual caller. The correction accepts a source-bound enclosing function symbol, requires a closed direct caller set, rejects function escapes/aliases and parameter uses beyond the selected argv expression, and resolves a receipt-qualified bodyless query before unknown subprocess-return tracing. Explicit input bodies still undergo root qualification.

The regression now refreshes valid symbol-only query receipts for changed apply argv, a new apply caller, function alias, parameter mutation, unknown input body, and dynamic argv. All must fail despite fresh receipts; the original finite GET-only caller must pass.

Ops source failed at deploy-ops-pod.sh line 38 because its fixture omitted the actual image/CLI, shell, supervisor, verifier and request dependencies required by frozen cross-source qualification. The fixture now copies ops/pod and tools/ops-mcp/src sources and retains their applicable shell and Python serialization contracts. Existing StatefulSet and changed rendered ConfigMap field assertions remain in place. Discovery was not modified.

Commands (repository cwd):

```sh
node --test --test-name-pattern='changed native Kubernetes callers' scripts/tests/api-reference.test.mjs
KUBECLAW_DOCS_GO_BINARY=/home/node/Documents/Codex/a98-evidence/argo-receiver-writer/go/bin/go node --test --test-name-pattern='changed native Kubernetes callers|actual authenticated ops render' scripts/tests/api-reference.test.mjs
KUBECLAW_DOCS_GO_BINARY=/home/node/Documents/Codex/a98-evidence/argo-receiver-writer/go/bin/go node --test scripts/tests/api-reference.test.mjs
git diff --check -- scripts/docs-api-output-role-classification.mjs scripts/tests/api-reference.test.mjs
sha256sum scripts/docs-api-output-role-classification.mjs scripts/tests/api-reference.test.mjs
```

Final bounded result: exit 0, 2 tests, 2 PASS, 0 FAIL (`final-bounded.log`). Full api-reference result: terminal exit 0, 130 tests, 130 PASS, 0 FAIL (`full-api-reference.log`). Go: go1.26.3 linux/amd64, SHA256 d68b7abbc40d0844f673f6cf06ae3cded225c50437c6454fa37ef178d079fe65. Helm: /usr/local/bin/helm v3.22.0+g144ca65. Before/after file hashes are separate artifacts.

Limitations: finite grammar deliberately rejects unresolved callers rather than granting a role from metadata. Ops rendering uses controlled offline discovery inputs. No live deployment, authentication, host or cluster behavior was exercised. The full eight-file integrated suite is root-owned.
