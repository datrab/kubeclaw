# Complete fresh corrected Network/Admission Source review

**Network: FAIL. Admission: FAIL. Common recursive traversal: FAIL.** Reviewer `/root/a98_network_admission_source_corrected_complete_fresh` is independent Source only, read-only toward the repository. The complete assigned scopes were reviewed after the first failure; this is not a findings-only recheck. Reader, Quality and Astra remain separate.

The exact subject is an immutable git archive of `2efe7bb395c83f7e74f035f3c26bd61bc8e62d13` with only `scripts/docs-kubernetes-admission-receiver-contracts.mjs` overlaid. Full tracked-file comparison confirms 5527 files and this sole difference. Base archive SHA256 `eb5ab766e9dd547c0d233b3cf67563d32e60e06498d350bb8e79e5aec4df866e`. Network module SHA256 `3f5470835b028646cbf9d6b1101ff8aad499b6504b7e39bd0d07e00154cadf85`; sole Admission overlay SHA256 `145f3e02b3a3d3c2f0d690934cb3611d5d12a7438450da3f6a944ec4b1097571`. Private `node_modules/yaml` is a review dependency link, excluded from the tracked subject manifest. Mutable Apps/Argo modules, other workingtree changes, and root's subsequent production inventory integration are not approval subjects.

## Complete independent scopes and individual results

| Component | Complete scope | Individual Source decisions |
| --- | --- | --- |
| Network |122 records,707 cases;120 spec/status paths plus2 roots;175 original boundaries,69 workitems,21 contexts |Records65 PASS/57 FAIL; cases701 PASS/6 FAIL; boundaries129 PASS/46 FAIL; workitems57 PASS/12 FAIL; contexts4 PASS/17 FAIL |
| Admission |132 spec records,751 cases; actual raw62 fields/4 documents plus33 Helm syntax appearances;95 appearances,29 workitems |Records12 PASS/120 FAIL; cases737 PASS/14 FAIL; appearances15 PASS/80 FAIL; workitems5 PASS/24 FAIL |
| Common helpers |Full frozen traversal/join implementations and both test files;10 new controlled schema variants |Existing9 tests PASS; new control decisions2 PASS/8 FAIL |

These are binary individual results, not percentage acceptance. Every record includes full original prose/cases, each dimension, independently reconstructed receiving Go declaration, pinned hashes, attached ranges and precise finding IDs. Every case has its own decision and explicit Source-only execution limit. All254 records were compared; Network behavior comparisons agree. Admission45 records have incorrect collection-boundary wording or an omitted material operation condition;87 others agree behaviorally. Missing adjacent implementation proof still makes the full record fail. All1458 case outcome comparisons agree with the actual bounded Source;20 case decisions fail for incomplete attached proof. These comparisons are not executed Go/CEL/API tests.

Independent recursion of freshly fetched official swagger equals exports: NetworkPolicy74 and Ingress46 spec/status paths; Admission policy69 and binding63 spec paths. Independent original Go traversal, including recursively embedded inline RuleWithOperations/Rule, exactly matches the same sets. Network receiver categories:24 structs,5 maps,43 values,25 slices,23 pointers. Admission:15 structs,5 maps,55 values,39 slices,18 pointers. IntOrString remains its custom scalar boundary. All132 Admission declaration file/line/type attachments exactly match the independently reconstructed actual declarations. Fresh official swagger bytes equal frozen vendored decompressed bytes, SHA256 `483500149ee52ce5753d75f5639101d985bb4f5e902cc05b1ba7627465d62446`.

Actual YAML discovery reconstructs Network's21 contexts from22 container appearances/35 fields in2 documents; original175/69 identities were retained as scope inputs only and independently matched to actual appearances.33 original structural placeholders are independently absent from the schema/Go node set. Admission raw/Helm discovery produces95/29 without enforcing a historical baseline. Helm generated scalar expressions remain opaque:33 is actual syntax, not rendered field count. All3 attached local-route sources freshly fetched at `6fa4830a48244d29655104a5be58957d5fa87d2f` equal frozen local bytes.

The entire257-line quality07 standard was read, with binding AP09 rules, relevant configuration fixtures, CFG-009 and A98-10/A98-11. Canonical target remains `docs/site/reference/helm-values.md`, owner `configuration owners`. This unpublished component review approves no published page, configuration package, global A98, integration, publication, Reader, Quality, Astra, Render, Deployment or Live acceptance. Real product limits remain separate from missing available Source proof. No additional mandatory live prerequisite is invented.

## Complete findings

New IDs deliberately differ from the previous report's NF/AF IDs. Counts overlap when a record has several failures. Exact affected identities and evidence/excerpts are in `findings.json` and the individual ledgers.

### CS01 — unqualified structural branches evade recursive coverage

Subject: `scripts/docs-api-schema-authorities.mjs`, lines 305, 306, 345, 383, 386, 390.

Claim: Complete boundaries and explicit rejection of newly added structural branches.

Actual: apiSchemaNodeContract accepts prefixItems, contains, additionalItems, unevaluatedItems and unevaluatedProperties, but visit traverses only properties/items/additionalProperties. hasStructure omits the same structural locations inside compositions. Seven fresh variants containing lostChild are accepted and expose only $.spec; no child boundary or named qualification error is produced.

Necessary correction: Explicitly reject every unsupported structural schema branch at any nesting depth, or add separately qualified traversal preserving branch identity/conditions. Add mutations for each listed keyword directly and inside compositions; enforce rejection or complete discovery. Do not flatten alternatives or call their presence runtime acceptance.

Source: [reproduction](helper-mutation-results.json).

### CS02 — nested keyword qualification absent

Subject: `scripts/docs-api-schema-authorities.mjs`, lines 321, 322, 366, 372.

Claim: A new vendor/unknown keyword cannot pass without explicit contract review.

Actual: apiSchemaNodeContract validates only keys on visited nodes. A oneOf scalar branch containing unknownNestedConstraint:true is preserved and accepted without qualification. Structural branches from CS01 also hide that unknown child keyword.

Necessary correction: Recursively qualify schema-bearing fragments, including scalar/nonstructural composition branches. Preserve constraint fragments but reject unknown nested schema keywords, with bounded recursion/reference handling and mutation tests.

Source: [reproduction](helper-mutation-results.json).

### NS01 — Service DNS grammar implementation missing (4 records)

Subject: `scripts/docs-kubernetes-network-receiver-contracts.mjs`, lines 136, 137.

Claim: Exact DNS1035/DNS1123 Service-name acceptance, 63-character limit and digit-first conditional case.

Actual: 507–554 and701–743 select and invoke named validators but no attached Network evidence supplies DNS1035/DNS1123 regex/length bodies or NameIsDNSLabel/NameIsDNS1035Label delegation. Parent Service records link the core alias; Service.name records do not. Actual pinned bodies support the claimed behavior, but exact grammar/1service claims lack attached implementation proof.

Necessary correction: Attach the receiving core alias287–290, api/validation/generic.go50–64 and util/validation155–181,222–243 to both Service and Service.name occurrences. Keep actual feature/old-object branch701–743.

Source: [Default Service alias.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L287-L290), [False-prefix DNS1123/DNS1035 delegation.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apimachinery/pkg/api/validation/generic.go#L50-L64), [DNS1123 label grammar and body.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apimachinery/pkg/util/validation/validation.go#L155-L181), [DNS1035 grammar and body.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apimachinery/pkg/util/validation/validation.go#L222-L243).

### NS02 — exact enum/default literal declarations missing (8 records)

Subject: `scripts/docs-kubernetes-network-receiver-contracts.mjs`, lines 101, 102, 120, 121, 122, 123.

Claim: PolicyTypes Ingress/Egress and port default/accepted TCP/UDP/SCTP strings.

Actual: policyTypes records attach defaults37–47 and validation175–188 but omit actual v1 PolicyType literals55/57. Six ports/list/item/protocol records assert TCP defaults or exact accepted strings while attaching ProtocolTCP/UDP/SCTP symbol uses and no literal declarations. Actual literals agree; this is missing attached literal proof analogous to corrected Admission enum findings.

Necessary correction: Attach networking/v1/types.go53–58 to both policyTypes records and core/v1/types.go1241–1250 to the six port/list/item/protocol records.

Source: [Actual policy-type literals.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/api/networking/v1/types.go#L53-L58), [Actual protocol string literals.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/api/core/v1/types.go#L1241-L1250).

### NS03 — selector conjunction implementation missing (45 records)

Subject: `scripts/docs-kubernetes-network-receiver-contracts.mjs`, lines 82, 86.

Claim: All map and expression requirements combine with AND.

Actual: Attached helpers34–72 builds and adds all requirements but ends before return; it does not show how a combined selector matches them. No Network record attaches labels/selector.go419–426, the actual AND loop. The pinned implementation supports the claim; actual network enforcement stays the separate installed implementation limit.

Necessary correction: Attach helpers34–74 for complete conversion and labels/selector.go419–426 for actual requirement conjunction to all selector records carrying this claim. No live network proof is required for this Source correction.

Source: [Complete map/operator conversion and returned selector.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apimachinery/pkg/apis/meta/v1/helpers.go#L34-L74), [Actual combined-selector AND loop.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apimachinery/pkg/labels/selector.go#L419-L426).

### AS01 — scalar/map-entry semantics inherited from enclosing collection (31 records)

Subject: `scripts/docs-kubernetes-admission-receiver-contracts.mjs`, lines 146, 147, 148, 155, 172, 173, 174, 175, 176, 107, 372.

Claim: Individual omission, explicit empty and fresh null outcomes for retained scalar/map entries.

Actual: 31 scalar/map-entry records reuse list/map prose: five values[] say [] is valid with Exists/DoesNotExist though array tokens cannot decode into string; twenty rule scalar items and validationActions[] describe list [] rather than an item. Five exact matchLabels entries describe omission/empty map as removing all requirements. Fresh null is retained as empty string: values:[null] is nonempty and accepted for In/NotIn but forbidden with Exists/DoesNotExist; apiGroups:[null] is the core group; resourceNames:[null] restricts to the empty request name. A null map entry preserves its key and empty-value equality. These are semantic documentation failures, not missing runtime tests.

Necessary correction: Author distinct semantics for retained scalar items and exact map entries before constructing nullValue. State removal of one item/key, remaining-parent constraints, actual empty string and retained null outcomes; reject []/{} tokens for scalar entries. Add exact field-level cases for each family. Preserve all identities and existing broader rule cases.

Source: [Array tokens reject string receivers.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/vendor/sigs.k8s.io/json/internal/golang/encoding/json/decode.go#L535-L560), [Retained array items.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/vendor/sigs.k8s.io/json/internal/golang/encoding/json/decode.go#L568-L625), [Null leaves string zero.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/vendor/sigs.k8s.io/json/internal/golang/encoding/json/decode.go#L991-L1004), [Fresh map element.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/vendor/sigs.k8s.io/json/internal/golang/encoding/json/decode.go#L765-L776), [Map key write-back.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/vendor/sigs.k8s.io/json/internal/golang/encoding/json/decode.go#L893-L895), [Rule group/version/resource/scope receiver.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/admissionregistration/validation/validation.go#L144-L173), [ResourceNames retention and duplicates.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/admissionregistration/validation/validation.go#L947-L961), [Nonzero values length and label-value validation.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apimachinery/pkg/apis/meta/v1/validation/validation.go#L74-L103).

### AS02 — Namespace selector label-source operation condition omitted (18 records)

Subject: `scripts/docs-kubernetes-admission-receiver-contracts.mjs`, lines 160, 162.

Claim: For a Namespace request, test the Namespace object labels.

Actual: All18 namespaceSelector records state this without an operation/subresource condition. The attached103–136 calls GetNamespaceLabels but omits its implementation. Actual73–101 uses request object labels only for namespace main-resource CREATE/UPDATE; DELETE and other branches use NamespaceLister, with API fallback when not found. The available implementation distinguishes the received object from stored/cached Namespace labels; no live cache freshness is established.

Necessary correction: State the CREATE/UPDATE main-resource versus DELETE/other lookup distinction, failure/fallback boundary, and attach namespace/matcher.go73–101 in every affected record. Do not claim observed cache freshness or API success.

Source: [Actual request-object versus cached/fetched Namespace label source.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apiserver/pkg/admission/plugin/webhook/predicates/namespace/matcher.go#L73-L101).

### AS03 — underlying selector/rule matcher implementations absent (97 records)

Subject: `scripts/docs-kubernetes-admission-receiver-contracts.mjs`, lines 160, 162, 183, 185.

Claim: All selector requirements combine with AND; all rule fields match together with list alternatives ORed.

Actual: 45 selector records link only single Requirement.Matches236–283 and omit LabelSelectorAsSelector34–74/operator mapping and combined selector Matches419–426.52 rule records link callers in policy/matching124–194, which invokes rules.Matcher.Matches; no record attaches the actual scope/operation/group/version/resource matching body. Actual pinned sources support these claims, but the declared consumer mechanisms are available and not attached.

Necessary correction: For selector records attach complete meta/helpers34–74 and labels/selector419–426. For rule records attach webhook/predicates/rules/rules.go35–125, preserving namespace special cases, wildcard/list alternatives and AND. Keep existing rule-name/equivalent/exclusion caller evidence.

Source: [Map/operator conversion.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apimachinery/pkg/apis/meta/v1/helpers.go#L34-L74), [Combined requirement matching.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apimachinery/pkg/labels/selector.go#L419-L426), [Actual complete rule matching mechanisms.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apiserver/pkg/admission/plugin/webhook/predicates/rules/rules.go#L35-L125).

### AS04 — nil selector default body missing (4 records)

Subject: `scripts/docs-kubernetes-admission-receiver-contracts.mjs`, lines 142, 162.

Claim: Nil namespace/object selector defaults to {}.

Actual: Four namespace/object selector root records assert this and attach generated defaulting calls81–94/96–108, but neither attaches SetDefaults_MatchResources106–119, which performs the pointer assignment. The matchConstraints/matchResources parent records do attach that body; a parent record link is not attached proof beside these independent root claims.

Necessary correction: Attach defaults.go106–119 to the four affected selector root records, retaining generated traversal proof.

Source: [Actual nil selector/default matchPolicy assignments.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/admissionregistration/v1/defaults.go#L106-L119).

### AS05 — group/version wildcard helper missing (52 records)

Subject: `scripts/docs-kubernetes-admission-receiver-contracts.mjs`, lines 172, 173, 185.

Claim: Wildcard cannot occur alongside another API group/version.

Actual: All52 rule records attach validation60–173 which invokes hasWildcard for API groups/versions but omits its actual body49–57. The corrected hasWildcardOperation528–535 handles a different typed list; it does not supply the omitted string-list helper. Real implementation supports the text.

Necessary correction: Attach validation.go49–57 to all rule records carrying these inherited group/version constraints; retain the operation helper and resource algorithm.

Source: [Actual string-list wildcard detection.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/admissionregistration/validation/validation.go#L49-L57).

### AS06 — remaining action/reason literal declarations missing (8 records)

Subject: `scripts/docs-kubernetes-admission-receiver-contracts.mjs`, lines 109, 111, 196, 201, 202, 352.

Claim: Exact Deny/Warn/Audit action values and Forbidden/Invalid/RequestEntityTooLarge accepted reason values.

Actual: Action records link498–535 type comments and688 named-string kind, not actual validation-action literal declarations692/696/701. Six validations records copy reason-Unauthorized rejection and the reason supported-set proof509–513, but attached meta839 gives string kind, not accepted reason literal values. Actual literal declarations agree; nominal type and symbol uses do not establish literal mapping.

Necessary correction: Attach admissionregistration/v1/types.go688–702 to both action records and meta/v1/types.go863,905,975 to all six validations records carrying reason claims/cases. Keep supported-set/default/runtime/error proof.

Source: [Actual action literal strings.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/api/admissionregistration/v1/types.go#L688-L702), [Forbidden literal.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apimachinery/pkg/apis/meta/v1/types.go#L863-L863), [Invalid literal.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apimachinery/pkg/apis/meta/v1/types.go#L905-L905), [RequestEntityTooLarge literal.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apimachinery/pkg/apis/meta/v1/types.go#L975-L975).

### AS07 — paramKind version parsing helper missing (3 records)

Subject: `scripts/docs-kubernetes-admission-receiver-contracts.mjs`, lines 75, 76, 86.

Claim: Core apiVersion v1 needs no slash; optional group/version syntax.

Actual: Three paramKind records attach validateParamKind832–865, which invokes parseGroupVersion, but not the actual no-slash/one-slash/multi-slash parser869–885. Real implementation supports the claimed core-version branch.

Necessary correction: Attach validation.go869–885 to all three paramKind records alongside the existing exact grammar bodies and validation call.

Source: [Actual core/group-version parsing branches.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/admissionregistration/validation/validation.go#L869-L885).

### AS08 — ordered variable compilation caption omits the loop (4 records)

Subject: `scripts/docs-kubernetes-admission-receiver-contracts.mjs`, lines 211, 212, 213.

Claim: Ordered storage and duplicate overwrite; earlier declarations available to later variables.

Actual: Four variables records attach composition93–111 captioned Ordered storage and duplicate overwrite.93 closes CompileAndStoreVariables; the ordered range loop is89–92 and is outside the excerpt. The record attaches validateVariable999–1031, not the enclosing create-validation range loop803–807. Actual source supports order and overwrite, but the exact caption/range omits the ordering action.

Necessary correction: Extend composition93–111 to89–111 and attach validation803–807 for ordered create traversal. Retain95–100 overwrite and current lazy-map evidence.

Source: [Ordered runtime variable traversal and storage.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apiserver/pkg/admission/plugin/cel/composition.go#L89-L111), [Ordered create validation traversal.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/admissionregistration/validation/validation.go#L803-L807).

### AS09 — CEL compiler/environment and budget enforcement consumer proof missing (21 records)

Subject: `scripts/docs-kubernetes-admission-receiver-contracts.mjs`, lines 21, 86, 200, 202, 211, 213, 222, 233, 387.

Claim: Dynamic object declarations, optional params/authorizer, compile result-type rejection and cumulative CEL work-budget handling.

Actual: 18 validation/variable/matchCondition/audit records attach receiver validators, ReturnTypes contracts, configured budget constants and calls to CompileCELExpression/ForInput, but no actual compiler/environment body or condition/activation budget implementation. Three paramKind records also assert params absence/presence without the environment constructor. Freshly fetched compile.go169–205 enforces compile/result type;251–266 declares dynamic objects and optional variables. condition.go90–112 initializes and threads the budget; activation.go119–189 charges composed-variable and expression costs and returns internal/budget errors. These available consumer mechanisms support the assertions and cannot be waived as product limits.

Necessary correction: Attach compile.go179–205 and251–266 to relevant compile/environment claims, condition.go90–112 plus activation.go119–189 to budget/error claims, and actual object conversion/activation35–58 plus condition76–85 for null object/params conditions. Select applicable ranges per family and retain existing validator/filter/dispatcher/default/limit evidence. No CEL execution is required to correct missing Source evidence.

Source: [Actual compile/result-type enforcement.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apiserver/pkg/admission/plugin/cel/compile.go#L179-L205), [Actual environment declarations.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apiserver/pkg/admission/plugin/cel/compile.go#L251-L266), [Budget initialization and cumulative threading.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apiserver/pkg/admission/plugin/cel/condition.go#L90-L112), [Actual cost/error handling.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apiserver/pkg/admission/plugin/cel/activation.go#L119-L189), [Actual object/parameter activation preparation.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apiserver/pkg/admission/plugin/cel/activation.go#L35-L58), [Actual nil runtime-object conversion.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apiserver/pkg/admission/plugin/cel/condition.go#L76-L85), [CREATE attributes have nil old object.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apiserver/pkg/endpoints/handlers/create.go#L182-L182), [DELETE attributes have nil new object.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apiserver/pkg/endpoints/handlers/delete.go#L139-L139), [Versioned object/old-object preservation.](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apiserver/pkg/admission/conversion.go#L67-L90).

## Full semantic/call-chain review and legitimate product boundaries

Network review covered empty spec and target selection, nonzero-egress direction defaulting, explicit deny-all egress, duplicate policy types, every rule/peer/port alternative, five selectors and operator/value conditions, peer namespace AND/OR meanings, old-selector compatibility, TCP pointer default versus explicit empty, quoted/numeric/custom IntOrString tokens, inclusive ports/endPort, CIDR subsets/families/gate and normal+update error combination. Ingress covered class create registration and annotation/default/list-error/order/update conditions; required rules/default backend and Service/resource exclusivity; feature/old-object Service-name branches; namespace-local references and path-segment checks; host-only versus empty HTTP; pathType early return, Exact/Prefix unsafe literals and ImplementationSpecific; old wildcard exceptions; TLS optional host/Secret, name-only validation and old invalid-name relaxation; status versus spec ownership, optional address checks and absent handwritten port checks.

Admission review covered all policy/binding spec trees, fresh value/pointer/slice/map/item decoding, defaults/register/generated conversion, required parents and retained children, status/generation/version-checked update/authz, paramKind syntax/resolution/bypass, paramRef scope/synchronization/null/zero/multiple lookup/action branches, namespace/object/rule/name/equivalent/exclusion matching, protected admission-resource recovery exclusion, type-check warning limits, dynamic compiler/environment, stateless condition creation versus runtime composition, ordered/duplicate/unused/old-expression variables, matchCondition false/error/filter order and nil namespace, false assertion versus evaluation/config errors, static/dynamic reason/message behavior, TrimSpace before size/LF and internal CR, overall message preemption/audit replacement, separate/shared budgets, audit authorizer absence/count/size/truncation/deduplication/join/publication/direct-denial behavior, Fail/Ignore versus Deny/Warn/Audit and informer refresh.

Decoder review followed actual typed serializer delegation, case-sensitive/strict JSON, returned saved errors, dispatch/indirect traversal, all incompatible token families, retained slice growth/items and map temporary/writeback. Original Go fields establish receiver kinds independently of schema. YAML conversion precedes typed JSON; patch/apply has its own object-construction boundary. Default/register and generated conversion preserve relevant lists/pointers/scalars before the named validators. Source support was not promoted into observed runtime acceptance.

All actual raw/Helm appearances were read and mapped, including broker/role/version predicates, generated identities, CREATE/DELETE selection, separate raw UPDATE and ownership-label rules, and deployment delegation. Frozen Network input and renderer/deploy route were read: the renderer mutates CiliumNetworkPolicy, while authored NetworkPolicy passes through. The authored Ingress selects tailscale and argocd-server:80, TLS host argocd and no named Secret.

Installed API/network/controller versions, enabled plugins and authorization, current informer/cache contents, live manager winners, actual rendered/applied resources, traffic enforcement/convergence, Tailscale class implementation and certificate load/rotation/reachability remain bounded unproved product observations with declared owner/stop conditions. Those honest limits do not waive CS/NS/AS documentation failures. Root's separately bounded Decoder Unit24 and old7e full mutation result are not this review's Go or current global proof and were not inherited.

## Prior correction recheck, execution and reproducibility

The prior sealed report hash was independently verified as `84e702be686cbe36ed628a54ee8725397dfa826f04a5b4f69f705257e3754a5d`. Its eight groups supplied leads only. Actual fresh sources establish that prior Network token/declaration/map/list evidence, IPBlock86–90 and class61–65 corrections are present. Prior Admission path body24–48/wrapper61–68, executable missing-policy continue320, namespace matcher74–132, operation/set/literal additions and lazy-map implementation are present. The old suggested wrapper69–76 is outside the68-line file and was never inherited; the actual missing-policy action is320, not319. Prior group correction does not clear newly discovered whole-scope failures.

Executed successfully: exact archive/sole overlay/full5527 tracked-file comparison;66 fresh immutable official primary downloads and byte/hash verification; both standalone export imports; non-evidence preservation against prior exports122/707 and132/751; fresh independent schema/Go inventory equality;132 exact declaration assertions; original Network contexts against fresh YAML; Admission raw and opaque Helm syntax extraction;3 pinned local route byte comparisons;302 exact attached/correction-range bounds and saved excerpts; every individual ledger; private schema mutation reproductions; existing9 helper tests (twice, initial and sealed-subject verification). Attached claim appearances: Network2360 narrow-caption PASS; Admission5340 PASS/4 FAIL, all four ordered-storage captions AS08. Narrow caption PASS does not prove other unlinked prose.

Existing helper tests invoke Helm on the frozen vendored Argo chart to load CRD schema authorities; this limited schema-loader render occurred with Helm3.22.0. No authored Network/Admission Helm release/template rendering was executed. Node24.21.0 and Python3.14.8 were used. The mutation diagnostic exits0 because it records outcomes; eight unexpectedly accepted variants are Source FAIL, not successful negative coverage tests. Test/read diagnostics and Source outcomes remain separate.

Private YAML library and two parser scaffolds were reused transparently and reexecuted; prior verdict ledgers, behavior PASS and review.py were not reused. Prior immutable Network ledger supplied original scope identities only. `scaffolding-provenance.json` names dependencies and their hashes. The first independent Go parser missed a second anonymous-inline level; recursive expansion was fixed and rerun before any final scope decision. Initial SHA lookup guessed the absent shortened Network filename; the actual Kubernetes-prefixed file was immediately hash-verified. A final compound diagnostic ended128 because git status ran inside the evidence directory; a subsequent status ran in the repository. Two line/log diagnostics initially used that repository cwd with evidence-relative names and returned missing-file errors; exact frozen paths were subsequently read. Some broad tool reads truncated and were completed with narrower ranges. These diagnostics are not component test passes. Environment-status tool was unavailable and network-policy file absent; no credentials or secret files were read.

Not executed: registered complete mutation/Reader/Render fixtures, authored Helm rendering, Go decoder/default/validator tests, CEL programs, actual API/manager/authz/Secret/controller/traffic requests, GitOps sync, main generation/integration/publication, deployment, commit/push or global acceptance. The subsequent dirty production inventory integration is expressly outside this frozen review subject.

Reproduce from this evidence directory with the saved subject: `python bootstrap.py`, `python independent-inventory.py`, `node source-contexts.mjs`, `node helm-template-contexts.mjs`, `node network-contexts.mjs`, `node helper-mutations.mjs`, `node --test subject/scripts/tests/api-schema-boundaries.test.mjs subject/scripts/tests/api-receiver-coverage.test.mjs`, `python assemble.py`, `python verification.py`. `python seal.py` additionally verifies the immutable Git base in the named repository and recreates base archive comparison. These scripts reproduce mechanical artifacts; Source reasoning is recorded in this report/findings and is not replaced by their successful exit.

No repository/generated module was changed by this reviewer. Full subject, primary bytes, exact excerpts, controls, individual scope ledgers and scripts are bound by the artifact manifest. This release is complete Source FAIL and requires correction plus a new immutable fresh review.
