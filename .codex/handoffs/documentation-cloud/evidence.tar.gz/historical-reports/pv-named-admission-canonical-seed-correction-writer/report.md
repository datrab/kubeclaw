# Corrective writer evidence: named admission and canonical finite seeds

Status: both reported defect classes are corrected in the assigned documentation discovery code, with the bounded checks below completed. This is writer implementation and test evidence. It grants no independent Source, Reader, Quality, package, global or AP09 acceptance. A fresh independent full Source review is required after the prior sealed FAIL.

Repository: `/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04`. Branch: `docs/documentation-overhaul`. Evidence HEAD: `51975b92ed5154b76c65793e55933b4d8659d05d`. The checkout contains preceding root-owned documentation changes; status.txt records the actual tree. Root HEAD movement is separate from the assigned source identity. No commit, push, product edit, generated inventory, shared matrix or publication change was performed by this writer.

## Governing evidence and scope

Read the complete documentation quality standard, the applicable AP09 contract rules, A97-12 and A98-14, and the entire sealed independent Source report at `../pv-transitive-custody-corrected-complete-source-fresh/report.md`. The earlier report remains FAIL for its earlier source. Correctness and drift completeness cannot be inferred from existing green inventory counts or a green test suite. This correction addresses F1/F2 intrinsically and preserves the source-bound finite authority boundary.

Only `scripts/docs-api-output-discovery.mjs` and `scripts/tests/api-output-publication.test.mjs` were edited. The assigned registry was inspected and preserved byte for byte. Frozen snapshots and source-hashes.json bind all 84 prior review inputs at the current observed source. The assigned final SHA256 values are:

- `scripts/docs-api-output-discovery.mjs`: `f3576c41006180edf300d5829333a185d5b163001372fef49f34175bba85d3d7`.
- `scripts/docs-api-producer-adapter-authorities.json`: `c64a6acbf641f2b72696dcc2e7872bd1b03e0dcccb503f30b5737d292327e337`.
- `scripts/tests/api-output-publication.test.mjs`: `e3fa4c70e5f5f295f506431808fa7c218a26df5579d0f9016a0df5282a832a3a`.

## F1 correction: finite named builtin admission

The discovery implementation now contains an intrinsic finite reviewed domain for named imports from both `module` and `node:module`: `createRequire`, `Module`, `default`, `builtinModules`, `stripTypeScriptTypes`, and `syncBuiltinESMExports`. Static named admission checks the original export name before local aliases, declarations, capability transfers, dynamic-operation inventories or refreshable registry fingerprints. Every other name throws `DOCUMENTATION_TOOL_GRAPH_UNQUALIFIED` at admission, including future unknown names and imports that are never invoked. This is an allowlist, not a blacklist of `_load`.

`createRequire` retains factory and created-require custody. Named `Module` and `default`, default clauses and namespace imports retain node-module custody. The existing qualified finite projections, direct literal dependencies, call/apply forms and awaited Promise custody remain active. The first unsupported custody transfer still fails closed. Object destructuring from an acquired namespace now checks its selected properties against the same finite admission domain; an unknown property cannot become an unclassified identifier. Nested, array, defaulted and rest binding transfers remain unsupported. Builtin import-assignment syntax is explicitly rejected because the scanner does not implement that custody grammar; its previous probe was an admission investigation, not a valid default Node .mjs execution witness.

The three reviewed nonloader exports keep their actual roles, rather than becoming fake loader capabilities. `builtinModules` supplies names for the actual scripts/plugin-source-closure.mjs builtin inventory; it does not load the named modules. `stripTypeScriptTypes` transforms source text in foundation/packages/install.ts before the installer syntax check; it does not execute the stripped module. `syncBuiltinESMExports` updates named ESM builtin bindings from the corresponding CommonJS builtin properties, used by the source-pinned import-audit-child.mjs guard after it replaces denied methods. These roles do not admit any other Node module export. A new test independently executes all three on Node, including replacing fs.readFile with a denied method and verifying that synchronization updates its named ESM binding.

The new named-admission regression group enumerates the current runtime namespace only to generate negative tests. Runtime enumeration does not determine the implementation allowlist. Each current unreviewed export and a deliberately unknown future export are tested under both specifiers, local aliases and immediate object transfer. Unknown destructured `_load`, `register` and future exports also reject. The saved Source capability probes additionally cover actual named `_load`, `_preloadModules`, register and registerHooks forms, containers, unknown runtime-selected arguments, namespace private access, constructor transfer and Promise custody.

## F2 correction: canonical finite seeds before closure and caching

Each selected finite recipe seed is canonicalized before its source bytes enter the graph. The scanner checks the canonical path against repository containment and node_modules/vendor/.git exclusions before reading its source. Its canonical path enters the finite closure and source inventory, including a seed that was already a product root. When the selected path is a symlink, the original alias is retained as metadata, and the canonical source replaces that alias as the scanned module identity. Relative imports therefore resolve from the real module directory, matching the independently observed default Node symlink semantics.

The graph cache now binds the selected resolution paths as explicit seed facts, including their current realpath and content hash. The canonical seed's bytes and source identity also remain in the graph key. Each resolved local dependency contributes its alias resolution path, canonical path and bytes to the existing dependency facts; canonical targets propagate through the unchanged finite fixed-point closure. Shared roots and cycles use the same closure. A cache hit recomputes these facts. A changed canonical bridge, changed selected alias target, missing dependency or changed edge forces a fresh graph, so stale success cannot hide a new consumer. The implementation retains safe repository-contained seed symlinks.

Regression checks execute a safe canonical seed baseline twice, with a benign alias-directory decoy sibling. Node independently imports the selected symlink and returns zero receiver records. Subsequent canonical bridge-only mutation, retargeting to a second canonical directory, canonical cycles and shared product roots cause discovery rejection; each independently executed default Node import returns all seven helper records. Vendor and external repository escapes reject. The copied Source probes also test initial selected-symlink exposure without first caching the safe version, cached canonical bridge mutation, extension fallback, missing-after-cache and unknown bridges. Extension fallback preserves the scanner's pre-existing conservative .js/.ts and extensionless resolution; it is not a claim that Node ESM runs extensionless imports without another loader.

## Finite semantic authorities and preservation

All 12 actual input recipes and 27 operations were inspected against their source and current callers. recipe-audit.json recomputes all primary/caller/schema hashes, canonical unaliased authority paths and compiled recipe hashes. All match. operation-audit.json checks each actual TypeScript AST call expression and its actual owning-function fingerprint; all 27 match. The recipes, compiled trust anchors and refreshable registry operation inventory are unchanged. Caller/schema/digest mutations from the prior 80 probes still fail, including mutations that refresh JSON hashes.

The reviewed classes remain fixed repository guide imports, finite ESLint input arrays, finite documentation runtime semantic inputs, three fixed Renovate suffixes under its externally selected root, registered provider/report/isolation protocols, trusted package registration and bounded import-audit builtins. The provider parent checks canonical package containment and copied digest; the report parent checks original/snapshot digest and canonical copied-module containment; the isolation parent selects a canonical module inside its package with bounded fs read permissions. Registry build checks canonical registration containment; discovery determines trust provenance; digest rejects package symlinks; activation brackets trusted import audit with integrity checks. The audit parent chooses its validated registration path/export and the child installs denied builtin methods before synchronizing named ESM bindings. These are actual parent-authorized protocols. The helper does not execute arbitrary child stdin/argv inputs to certify them. Renovate external package integrity remains external authority.

preservation.json proves every byte from `documentationEdgeOrder` to the end of discovery is identical to the preceding sealed Source. The registry and pure seven-row helper are also byte-identical. This preserves generic producer discovery, public scope, output-role checks, shlex and token behavior without adding a general JavaScript interpreter or publication framework.

## Executed commands and observed results

| Check | Actual terminal result | Artifact |
| --- | --- | --- |
| `node --test scripts/tests/api-output-publication.test.mjs` | exit0, 18 PASS, 0 FAIL, 0 skipped | focused-tests.log |
| `node old-probes.mjs` | exit0, 55 PASS | old-probes.json |
| `node new-probes.mjs` | exit0, 25 PASS | new-probes.json |
| `node additional-probes.mjs` | exit0, 16 PASS | additional-probes.json |
| `node closure-probes.mjs` | exit0, 7 PASS | closure-probes.json |
| `node runtime-witness.mjs` | exit0, six finite forms each return seven records | runtime-witness.json |
| `node new-runtime-witness.mjs` | exit0, five finite forms each return seven records | new-runtime-witness.json |
| `node operation-audit.mjs` | exit0, 27 actual operations verified | operation-audit.json |
| Current recipe/source/caller audit | 12 compiled recipes, all hashes verified | recipe-audit.json |
| `node checkout-probe.mjs` | exit0, 36 script outputs, 111 shell outputs, 0 false helper PV outputs | checkout-probe.json/.log |

All copied private harnesses point into this new evidence directory; the preceding sealed directory was read only. execution-results.json records each exit code. Source paths still refer to the actual repository. The final focused run followed the new synchronization witness refinement; discovery bytes did not change after the 103 private probes. Node version is v24.21.0. The checkout probe retained existing YAML warnings in its log.

Actual shell discovery preserves one `scripts/remove-qdrant.sh` PersistentVolume JSON PATCH with three claimRef tests and one `add` of reclaim policy `Delete`. The selected helper still has exactly seven fields: `$`, `$.spec`, `$.spec.claimRef`, claimRef name/namespace/uid, and `$.spec.persistentVolumeReclaimPolicy`. This proves source/offline discovery preservation, not a served request, controller behavior or storage deletion outcome.

## Limits and handoff

The assigned source is frozen at the hashes above. Root owns the complete nine-file API integration suite and the fresh independent Source review. This writer did not run or infer global/package/self acceptance. No product runtime, cluster/provider/media/SQL/real Secret exercise, deployment, installation or published-site acceptance occurred. Tests establish their finite forms; no universal JavaScript interpretation, all arbitrary module inputs, all runtime package effects, preservation under Node --preserve-symlinks, or Reader task success is claimed.

The F1/F2 correction is ready for fresh independent whole-claim-group Source review. Prior FAIL remains historical evidence for its exact earlier source. Only that fresh review can decide current Source acceptance, and it does not replace Reader or Quality review.
