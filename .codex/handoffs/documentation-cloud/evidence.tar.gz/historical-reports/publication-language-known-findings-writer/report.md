# Frozen known publication-language correction

Scope: only docs/site/use/maintenance.md, docs/site/understand/nova-core.md and docs/status/open-issues.json. No generated page, product, installation page, gate, commit, push or live operation changed by this writer. Ready for checked source commit.

The exact original production checkLanguage implementation, constants, sentence tokenizer, exclusions and limits reproduced all ten findings from the supplied actual terminal publication failure. Its after check reports zero findings across both complete authored pages and the complete privately generated status page. This is mechanical project language evidence, not formal ASD-STE100 certification, whole-page correctness acceptance or full publication PASS.

## Individual corrections

1. Maintenance unbound claim: the script explicitly records `-` when volumeName is absent (pinned remove-qdrant.sh line 29; lines 35 onward skip that sentinel). Preserves no PV patch/wait, continued name-only PVC deletion, allocation/provisioning exclusion, stop rules and owner decisions.
2. Maintenance accepted selection: the existing release owner explicitly accepts the selection, consistent with the same page’s accepted-checkout authority and the source’s promotion/PR-acceptance boundary. Preserves required approved selection before installation, owner-approved repository, workflow/App authority, review/merge and receipt/configuration checks, GitOps consequence and no observed promotion.
3. Maintenance 31-word claim: three connected sentences name the fixed selector and script. Preserve captured name/UID/volumeName, reference precheck, release/access removal before patches, three reference tests plus `add Delete`, PVC name deletion and PVC/PV API waits.
4. Maintenance 30-word implementation list: periods divide the five existing source links. The four labels after full stops now start with capitals. All link targets are exactly unchanged; no technical source claim removed.
5. Core effect-recovery paragraph: Core implements no general procedure; this page establishes no execution verification. Preserve unresolved versus interrupted effect gates, external reconciliation's lack of continuation authority, operator/adapter/Nova responsibilities, authenticated issuer, exact outcome/request binding, append-only history, fence and duplicate/interruption tests.
6. Core decision cost: Core implements the guard and does not implement general receipt import or external continuation. Preserve stopped-run consequence, uncertainty boundary, historical reasons unknown/current inference, reconsideration conditions and linked source.
7. Prism issue 26-word problem: split after top-level notification field. Keep condition that Nova selects installed kubeclaw.operator-messaging for operator.request, exact architectureDigest field and closed-contract rejection.
8. Prism issue 27-word impact: split after already committed wait-store record. Preserve possible admitted Control work and committed wait-store record, blocked stage, absent active Core approval wait and unsuccessful intended Studio-to-Nova handoff.
9. Prism issue 32-word reproduction: split isolated exercise from observation distinctions. Preserve separately authorized repair prerequisite, actual selected installed adapter plus Core path, isolation and all five distinctions: committed Control work, wait-store records, effect receipts, notification delivery and active Core stage wait.
10. Prism issue 27-word acceptance: split installed journey from documentation evidence rule. Preserve separately recorded installed journey, original authorized signal, exact approved-bundle verification/storage and separate local/live reporting.

## Complete affected family semantics

Qdrant remains a former-release retirement procedure, not generic cleanup. Exact selector OR/AND/fallback behavior, PVC/PV identity fields, namespace/cluster permissions, reference-only guards, absent UID/version/policy preconditions, required external exclusion and comparisons, discovery-denial branch, unbound claims, controller/backend distinction, storage-owner disposal/restore evidence, all failure paths and no live proof remain unchanged. Release planning still has no established generic upgrade pair and no generic rotation command. All other maintenance prose is unchanged.

Core still rejects missing accepted-effect outcomes and unsafe interrupted external continuations before adapter startup. Administrative retry/remediation use the same gate; cancellation does not certify external success. It still has no general import/manual receipt-repair interface. No source functionality or executed recovery claim was introduced. All other Core prose is unchanged.

PRISM-NOVA-NOTIFICATION-001 remains high severity and open, with identical ID, title, origin, components, owners, current state, remaining work, live boundary, dependencies, evidence, source commits, URLs, all other reproduction and acceptance items. Dispatch/wait-store commit precede notification parsing failure; parse failure precedes reservation/secrets/network; AdapterRuntime wraps it; blocked result lacks Core wait authority. Parser-only evidence remains parser-only. Safe stop, preserved raw identities, owner reconciliation, forbidden manufactured wait/import/new run and original-identity recovery remain intact. No issue was closed through prose.

## Proof and validation

- Read full quality standard, both affected pages, complete affected source issue, A98 acceptance rows and controlled-language publication contract.
- Inspected relevant producer, receiver, effect, wait-store, reducer, decision, release-selection and promotion authorities. authority-manifest.json records 14 pinned whole-file inputs; all match current working source bytes.
- scoped-language.mjs uses the exact unchanged production language body and renderStatus/validateStatus. Before: 4 maintenance, 2 Core, 4 status findings. After: zero. Full privately rendered status page also has zero other mechanical language findings.
- diff-check.log: git diff --check exits zero on exactly three assigned files.
- unchanged-body-proof.json: 25 maintenance fences and one Core Mermaid fence byte-identical; all source/external URLs identical in order. Complete JSON comparison proves only four named fields of the one issue differ. bounded.diff provides all eight source edit locations (ten findings).
- before/ and after/ retain exact file snapshots; baseline.json and after-manifest.json record input/output identities. open-issues-before.md and open-issues-after.md are private outputs only.
- Not executed: global generation, full publication check, full Quality/source/reader review, live operator run, install, promotion, teardown, deployment or product tests. Their previous approvals do not automatically approve revised prose.

Remaining: Root must regenerate tracked status and other stale generated publication outputs, integrate installation writer correction, then run the fresh applicable full checks/reviews. Known stale plugin outputs are outside this writer's scope. No remaining mechanical language finding exists in this bounded three-page family check.
