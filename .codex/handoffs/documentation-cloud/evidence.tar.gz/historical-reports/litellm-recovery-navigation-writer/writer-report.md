# Recovery navigation and writer-fence author report

Repository: `/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04`
Branch: `docs/documentation-overhaul`
Input HEAD: `ebcc04066d42c94b4a4e0fc85e3393dae3d61f78`
Exclusive repository edit: `docs/site/use/recovery.md`.
File frozen after bounded author checks; no commit, push, generator run, product change, cluster command, registry call, image execution, or secret inspection.

## Exact changed paragraphs

Do not stop normal writers unless the selected backup contract requires it.
If the component contract requires a stronger fence, follow that contract.
Record the exact fence and its start time.

The selected installation can create `cronjob/litellm-postgresql-backup` and
`pvc/litellm-postgresql-backup`. This is an executable backup and verification
path, not a complete isolated operator restore. Read the
[selected LiteLLM source and image boundary](../understand/data-and-state.md#selected-litellm-source-and-image-boundary)
and [rows and encryption inputs](../understand/data-and-state.md#rows-and-encryption-inputs)
before selecting the application image or recovering keys. Start with the
deployed source revision, its selected immutable LiteLLM image, externally owned
master/salt keys, a healthy LiteLLM PostgreSQL service, and enough backup-PVC
capacity.

Before creating the manual backup Job, fence LiteLLM writes as required by its
[backup-group contract](../understand/data-and-state.md#backup-groups).
This component contract requires a stronger fence than the generic routine
backup guidance. Use the database and LiteLLM owners' procedure for the deployed
service. Stop before creating the Job if that procedure is missing or does not
clearly specify how to apply and verify the writer fence. Record the fence and
its start time. Run the following commands from the independently administered
cluster context only after that check passes:

## Canonical navigation

New links all resolve from `use/recovery.md` to `understand/data-and-state.md`:
- `#selected-litellm-source-and-image-boundary`: selected direct/GitOps immutable images and bounded source-byte provenance.
- `#rows-and-encryption-inputs`: whole-database scope, retained encryption inputs, decryption failures, and effective settings.
- `#backup-groups`: existing component-specific LiteLLM write fence.

## Contract support and scope

Read the full documentation quality standard; its language rules require conditions before actions, and its operation rules prohibit invented commands or live success. A97-06 requires explicit writer/fencing, backup, restore and honest unavailable-path limits. A97-08 prohibits treating repository evidence as live enforcement. Read the current recovery page, data/state page, and both assigned fresh Reader artifacts. Reader findings 2 and 3 and decisions D06/D07 identify precisely these navigation and fence-placement advisories.

The existing `data-and-state.md` S15 operating contract and LiteLLM backup-group row already require fencing LiteLLM writes. This change makes that current component contract visible immediately before the manual Job commands. It does not claim that the repository supplies a deployment fencing command or owner procedure. An absent or unclear procedure stops the Job. The generic step still allows normal writers when its selected component contract permits them; the change does not impose the LiteLLM fence on other components. No new implementation claim required external upstream inspection.

All fenced code blocks remain byte-for-byte equal to the input, including cluster-binding assertions. Restore primitive, unsupported self-contained isolated restore, native-test limits, image/application acceptance limits, private credential handling, and every later section remain identical. No live proof or independent acceptance is asserted.

## Bounded author checks

`git diff --check -- docs/site/use/recovery.md`: exit 0.
Verified all three heading anchors exist in the actual canonical target.
Compared every fenced command/code block to the saved input: identical.
Compared `assert_cluster_binding` counts: unchanged.
Compared the restore primitive and all later text: identical.
Publication/rendered-route checks and subsequent fresh Reader/Source/Quality review belong to the root's separate validation; these local checks do not establish them.

Input file identities are in `input-artifacts.json`; exact diff, input/output snapshots, bounded-check record and artifact hashes accompany this report.

Frozen recovery output SHA-256: `011c385765c0529fca46fdf8d46ec7fa51a811f047091c642d18bdd021cc0d4b`.
