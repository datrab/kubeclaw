# Complete two-finding Core author correction — frozen

Only docs/site/understand/nova-core.md changed. This is an author candidate for checked source commit and a new independent complete affected Core Quality review. It does not approve itself. Original f212bd14273a7357fca23a338933afbcc2d95902 four-page Quality remains FAIL exactly QF-01/QF-02; original report and findings are copied without modification and hashed in edit-release.json. The other three operator pages and complete source issue remain byte-identical to their reviewed f212 inputs.

## Read-only preparation and released application

Preparation inspected the complete unchanged Core page (exact same hash as this writer’s earlier complete page read), complete final independent REPORT.md/findings, quality standard, relevant acceptance contract/fixtures and owning source behavior. Twenty-four whole pinned implementation files were saved and matched current bytes. Private candidate checks occurred before application. No repository page changed during preparation.

Root subsequently explicitly released Core-only edits after final Quality sealing and Source88056's observed API-only terminal failure. The writer then checked baseline/protected/authority hashes, applied the complete two-finding correction as one batch, checked the actual revised page and froze it. No global known-failure gate was rerun. Concurrent unrelated API/tooling/generated changes were preserved; global cleanliness is not claimed.

## QF-01: complete adjacent diagram fallback

The adjacent text alternative now names all thirteen exact diagram nodes and fourteen directed relationships. It preserves the compiler/definition/registry/snapshot/scheduler/attempt chain, the attempt's separate effects/result branches, effects→receipts, both receipt/result relationships to the reducer, reducer→journal, journal→scheduler feedback and journal→audit branch. It retains package/registration/grant/provider resolution and snapshot contents.

Receipt and journal arrows describe authority/information flow, not invented direct calls. Durable authorized effects produce durable receipts; confidential effects retain their distinct later-described boundary. Receipts constrain the reducer through adapter responses and the attempt's typed result, and the text explicitly says the reducer does not read the receipt journal directly. Core records decisions, then scheduling uses consistent state; journal replay supplies recovered state. New adjacent narrow links bind these explanations to actual adapter, executor, scheduling and audit sources. The entire original Mermaid block is unchanged, hash 60c19903d9da0302dcdc9485367451caa374b5544b6deeea1eb2b171dfcf776c.

final-scoped-checks.json records every node/edge with the adjacent sentence that expresses it: thirteen nodes, fourteen edges, zero omissions. This is static content mapping, not rendered accessibility/browser evidence.

## QF-02: exact dispatch failure and interruption branches

The false promise that every failed request causes remote lookup plus persisted reconciliation is removed. The complete corrected explanation separates:

- Original-job status lookup before submission; classified 404 schedules stored-job submission.
- Classified retryable transport failures return to status polling under the existing deadline; other transport/response-validation/identity errors propagate while that deadline stays active, without an interruption record.
- Dispatch job validation marks prepared before durable dispatch storage finishes. Timeout/caller cancellation after preparation enters interruption cleanup; interruption before validation skips cleanup.
- Cleanup has a separate deadline, default ten seconds. It first attempts cancellation under the original job ID, then polls the same identity until a verified terminal completed/failed/cancelled state or cleanup end. Cancellation requests and 404 do not prove cancellation; a lost submission can arrive later.
- Failure to establish a terminal state retains unknown. The interruption stream stores job/request identities, reason, observed state/time and last error. Only this branch writes interruption evidence. Its persistence failure retains interruption and persistence causes.
- Later result/evidence import failures do not enter the dispatch cleanup. The existing shared overall gate deadline, remaining-time handoff, timeout/cancellation meanings and retry ceiling remain intact.
- Unknown or unreconciled outcomes require stopped new dispatch, retained original identities, job/archive/output/interruption evidence and the canonical effect-recovery boundary. An interruption record is not an effect receipt or continuation authority.

Narrow existing-evidence-revision links now identify dispatcher catch/poll/cleanup, cleanup default, interruption store and outer import caller. All current whole-file bytes match their fixed pins. No runtime behavior, supported receipt import, new-run recovery, historical reason, live success or guaranteed resolved cancellation is invented.

## Final observed checks and exact preservation

Actual complete Core page: unchanged production checkLanguage body returns zero findings; shared actual Markdown link/anchor parser resolves all eleven local links and canonical publication classification. Eight newly unique narrow source ranges match pinned/current whole-file bytes and valid bounds. These static route checks make no HTTP, renderer, built-output or browser claim.

All final 107 product blob link occurrences have valid current/pinned line bounds; 99 unchanged range occurrences reuse exact original f212 proof while current source bytes are independently rehashed. All 57 unique final product blob authorities match current bytes. This is source/range verification, not a borrowed Source or Quality verdict.

Scoped git diff --check exits zero. final-byteguard.json proves every byte outside the two bounded sections is identical, the original diagram/code fence is identical, and install/Worker Trust/maintenance/source issue are identical. final-bounded.diff exposes the complete 60-added/11-removed-line correction. final-nova-core.md retains the exact reviewed author output.

Final Core SHA-256: 1300af85e4772fe87b431cabef63e6c5eb7f26c2e93ae1343e29cb885c75a712.
Before Core SHA-256: 6503c25869d627134bff582ffff544bd5b82f42a2b509844648853be97d2875a.

Executed/unexecuted commands and limits are recorded in final-check-execution.json. No product test, API mutation, global generator, full publication check, installation/deployment, public rendering/browser/accessibility/HTTP route run, commit or push occurred. The needed new independent complete affected Core Quality review remains unexecuted by this author. No original failure or wider acceptance record was rewritten as PASS.

Ready and frozen for Root's checked source commit and independent complete affected Core Quality review.
