# Apps receiver bounded C01–C15 author correction

Exclusive repository edit: `scripts/docs-kubernetes-apps-receiver-contracts.mjs`. Baseline module SHA256 `e96425368a043dd5bc23604577adf6016fd17e725c9553327c74bc590a315e58`; corrected module SHA256 `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`. Kubernetes proof revision: `66452049f3d692768c39c797b21b793dce80314e`.

Deterministic export SHA256 `e9528f84da95ff6b1943ed1d41ab7769045fda31e8e1717c6c3fa32b815f9d53`. Both fresh imports are identical. The frozen corrected module and complete export are `receiver-corrected.mjs` and `after-records.json`.

All 1,285 record identities/order are retained. All 7,712 original case identities are retained: 7,596 byte-unchanged and 116 revised. All 47 old narrow FAIL outcomes were revised. Of the 69 earlier narrow PASS cases with changed text, 67 retain the supported Linux outcome with an explicit OS boundary and separate Windows route; two selector null/empty cases retain their typed shape and cache-miss meaning while adding the now-proven cache-hit qualification. No existing case was deleted. 738 new Source cases yield 8,450 cases. `case-changes.json`, `added-cases.json` and `old-failed-case-corrections.json` supply the full comparison.

The 347 sealed assignment workitems, 36 original contexts and original boundary identities are retained as read-only navigation snapshots in `sealed-input-*`; their old verdicts are not a verdict on this corrected candidate. All 453 distinct formerly failed records were included through C01–C15 group identities. Group counts overlap.

## Concrete changes

| Group | Assigned records receiving new cases | Correction |
| --- | ---: | --- |
| C01 | 21/21 | OS build selection, Windows effective username/gMSA/HostProcess and case-insensitive nonroot; normal getImageUser zero fallback. |
| C02 | 14/14 | Trust nil/empty shared string key before optional handling; conditional hit/miss, 100 KiB, TTL equality/expiry, LRU/informer invalidation, security-owner safe boundary. |
| C03 | 10/10 | Rollout counts, rounding and zero fencepost, Recreate ordering, paused scaling, MaxInt32 sentinels, history eligibility, deadline reporting and explicit recovery. |
| C04 | 10/10 | Node resolver base/fallback, authored option precedence, deduplication/truncation, literals 3/32/2048 and ndots:5, relaxed gate/old-search predicate. |
| C05 | 14/14 | Hostname override/fallback/FQDN, hosts-file selected mount/HostProcess suppression and actual namespace/user-mapping route. |
| C06 | 16/16 | Missing/non-True readiness, scheduling gate removal/requeue, profile/nodeName routing, preemption Never and toleration matching/timed NoExecute deletion. |
| C07 | 34/34 | Scheduler/Pod/init/overhead accounting, Linux/Windows/Pod-cgroup limits and pressure, claim creation/allocation/ownership/reservation/UID/cache/CDI/unprepare. |
| C08 | 226/226 | Probe threshold/startup/readiness/kill policy, actual init route, StartContainer-before-PostStart, PreStop/termination ordering grace, TCP handler limit and Sleep API/node gates. |
| C09 | 29/29 | Safe subpath expansion/open/bind, source readOnly/propagation/RRO capability errors, mapper/device permissions and exact HostPath Unset/create/type branches. |
| C10 | 32/32 | Actual service namespace-and-enable branch, gated restart-drop caller, Pod validation dispatch and removal of irrelevant Pod resource/hugepage evidence from PVC maps. |
| C11 | 8/8 | Actual image manager presence/credential/backoff/error route; file/log fallback and literal 4096/2048/80/12288 message limits with declared-container budget. |
| C12 | 17/17 | Actual vs desired status aggregation, availability/minReady, terminating nil aggregate, generation/completion, hash collisions and all condition/timestamp publishers. |
| C13 | 13/13 | Node authorization/bound identity/token lifetime/cache, actual generated certificate lifetime default, request policy/key errors, pending/denied/issued/refresh/expiry/noop cleanup. |
| C14 | 4/4 | Exact Workload/group/replica key identity, membership, absent-state/group diagnostics and selected gang quorum/deadline/binding consequences. |
| C15 | 14/14 | Parent API→ReplicaSet→Pod→admission/scheduling/node sequence, selected children/OS/gates/defaults/failure owners and metadata other-owner boundary. |

`group-coverage.json` has every exact assigned path and its new cases. `source-ranges.json` has every attached evidence claim, URL, full file SHA256 and actual numbered excerpt. Source manifests preserve 203 original independently fetched files and additional fresh current pinned caller implementations; 223 distinct primary paths are available. No source link was accepted from file existence or author summary alone.

## Checks and qualifications

Syntax/import, deterministic exports, full identity/case comparison, complete group attachment and full source-byte/range checks passed as author checks. An initial author range check found five overlong new ranges; each was corrected to the actual file end and the complete check rerun. `checks.json` states executed and nonexecuted checks separately.

The conditional vSphere inline translator nil source dereference and storage-owner CSI/PVC follow-up remain unchanged static product-limit evidence; no panic was executed. Trust selector shared-key behavior is also a conditional static deduction. Fresh/WaitRefresh certificate state returns bytes even after NotAfter while reporting expiry; documentation does not turn these bytes into valid credentials. TCP-only lifecycle has API compatibility but no runner dispatch. These are product/source limitations, not excuses for missing available implementation proof.

The full quality standard, AP09 contract, fixture catalogue and CFG-009 catalogue entry were inspected. CFG-009/A98-10/A98-11 retain authority, owner/consumer, recursive shape, complete precedence and failure-case obligations. No separate direct A98-10/A98-11 fixture was invented. Metadata remains explicitly global under the other owner and is not optional.

Remaining required step: a full NEW independent Source review of this exact corrected module and complete exports. Reader, Quality, Astra, global acceptance and publication/integration remain separate root work. This author report provides no self-PASS and no global acceptance. Actual runtime/live checks listed in `checks.json` were not run. No commit, push, generation, application/cluster change or repository edit outside the exclusive module occurred.

Ownership is released after this sealed delivery; the author will not modify the module during the new independent review.
