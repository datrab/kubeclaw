# Independent SOURCE review — Prism trust and worker diagnosis

Review completed 2026-10-10 (UTC). Identity: `/root/a98_prism_trust_source_fresh`, independent SOURCE only; not author, Reader, or Quality. The prior Source report was not opened or reused as proof. No author probe totals or build accumulation were used to establish correctness.

## Candidate and isolation

Reviewed FULL immutable Git archive of commit `187df367ba1009c8f08b2b7704174201c90fceaa`, from the requested documentation branch. Input is `archive/`; test dependencies and reviewer probes are isolated in `run/`. Archive SHA-256: `6dcb0bc29af32ce4d150706fe4f255f938250583ff3cf32525db757d737bd173`.

| Candidate | Lines | SHA-256 |
| --- | ---: | --- |
| docs/site/use/prism-studio.md | 2272 | a4738017edbbb039cb12767e95daff922a686815cd36ebbe834d1e167b44dbaf |
| docs/site/reference/glossary.md | 274 | 25aa9f129ccaaa67badedc48cf73c3aa7693b0af851d03a3ea193d43115bc1db |

Final byte verification checked every archived regular file against `archive-manifest.json`, and every corresponding original product file in `run/`: zero mismatches; no archive symlinks. Original repository, generated files, products, branch, and commit were not changed. There were no commits, pushes, network dependency downloads, browser downloads, cluster mutations, or live requests. Offline npm installation used cached dependencies and disabled scripts. No subagents were spawned.

## Assigned SOURCE verdicts

These verdicts apply only to the assigned Prism/glossary contribution at the exact candidate. They do not accept all 30 AP09.8 catalogue IDs or the Demo contribution.

| ID | SOURCE verdict | Candidate authority and reason | Required correction |
| --- | --- | --- | --- |
| OPR-010 | FAIL | prism-studio.md:472,653,2211 conflate the LiteLLM embedding dependency with agent completion; the central journey otherwise covers round, selection, revision, preview, approval, publication, handoff and interruption. | F01 below. |
| A98-02 | FAIL | prism-studio.md:398-445,467-490 gives the LiteLLM Secret a managed-model purpose without separating the actual reasoning route. Locations, selected version, authority, stop/retry/retention boundaries otherwise match the scoped procedures. | F01: accurately name the two dependency purposes and their authority. |
| A98-04 | PASS | prism-studio.md:596-633,1569-1906 and glossary.md:143-170 distinguish process, native bootstrap, mode-dependent nonce readiness, and actual functional proof. Current worker-service.ts:72-106, worker-lifecycle.ts:43-64, worker.ts:11-48 and worker-readiness.ts:8-10 support this. | None for this SOURCE scope; live health stays UNPROVEN. |
| A98-06 | PASS | prism-studio.md:1301-1989 starts from trust/worker/uncertain-write symptoms, separates discriminating checks, keeps owner repair unsupported where necessary, and binds retry to original identities. Current agent-job-routes.ts:6-12, Control guards, worker/readiness/ownership and Nova engine checks support these stop decisions. The pending-direction path explicitly requires trust checks before attributing delay to a provider. | None for the inspected diagnosis semantics; F01 still requires the journey's provider labels to be corrected. |
| A98-12 | FAIL | prism-studio.md:640-657,2211 identifies direction completion through OpenClaw/LiteLLM, but current reasoning uses the managed OpenAI/Codex route. Setup through human approval, abort, resume and cleanup is otherwise represented honestly as implemented/fixture/source/unavailable. | F01. Preserve every interruption and unavailable/live distinction. |
| A98-13 | FAIL | prism-studio.md:472,653,2211 directs a fresh operator to the wrong model-dependency label when mapping secrets and completion. Other checked authority/context/namespace/UID/permissions, observations, stops and owner closure boundaries are explicit. | F01. A fresh reader must be able to distinguish embedding credentials/checks from reasoning credentials/checks. |

Glossary SOURCE result: PASS for its complete candidate text. The SVID, HMAC/nonce, gateway/session, fence, receipt and render/evidence distinctions match the inspected implementations. No glossary correction was identified. Independent Reader comprehension and Quality remain UNPROVEN.

## F01 — Split LiteLLM memory search from agent reasoning

This is a current-source contradiction, not a demand to manufacture a live provider demonstration.

The Secrets row at prism-studio.md:472 assigns the LiteLLM key the purpose “managed model route”; the direction step at :653 labels completion “OpenClaw/LiteLLM”; the capability at :2211 names the agent path “through OpenClaw and LiteLLM”. Taken together these identify LiteLLM as the route that produces directions/revisions.

Current regular-blob authorities at the reviewed revision:

- `charts/kubeclaw/values.yaml:162-165`: LiteLLM is used **only** for OpenClaw memory-search remote embeddings; agent reasoning uses the managed OpenAI route directly.
- `charts/kubeclaw/templates/configmap-gateway.yaml:55-74`: `.Values.litellm.endpoint` and `LITELLM_API_KEY` configure memory-search embeddings, with `gemini-embedding-001`.
- `charts/kubeclaw/templates/configmap-gateway.yaml:84-108`: selected OpenAI models use the `codex` agent runtime; `:285-290` enables the OpenAI/Codex plugin configuration separately.
- `charts/kubeclaw/templates/deployment.yaml:458-460` and `:498-519`: the LiteLLM Secret configures memory search, while reasoning models are configured separately.
- `skills/prism/server/agent-job-runner.mjs:16-46` and `skills/prism/openclaw-plugin/index.mjs:10-19,54-56,77-79`: a bounded OpenClaw invocation and Control commits provide no evidence that reasoning traverses LiteLLM.

Required correction: label the LiteLLM Secret/endpoint as memory-search embeddings; label direction/revision completion as the managed OpenAI/Codex reasoning path in OpenClaw; name the separate owner/configuration or link its canonical credential boundary. Keep both real dependencies, but distinguish their failure observations and closure conditions. At :423, either link the actual embedding functional check or narrow the statement that this page contains explicit LiteLLM functional checks. Do not suggest that a LiteLLM embedding success establishes direction completion, or that the deterministic native worker exercises either managed route. No new token values, invented API endpoint, generic trust repair or live-success claim is requested.

## Whole-journey and diagnosis source findings

### Agent admission and trust

The page correctly requires SPIFFE-enabled Control plus the exact trusted agent identity for durable claim/finish and direction/revision commit. `agent-job-routes.ts:6-12` gates the entire internal job prefix before reading the body. `control-server.ts:243-245,265-267` gates both commit routes before their transaction. Worker Core's proxied-peer guard requires a loopback peer and an exact permitted SPIFFE URI; a supplied header alone is insufficient.

Current config/chart sources support the page's separation of service default `false`, development agent overlay `true`, effective rendered settings and actual issued identity. Chart/source inspection cannot prove a deployed match. CSI registration is unconditionally required by `scripts/deploy.sh:1757-1760`; HMAC does not bypass it. A healthy HMAC worker cannot open the governed agent journey. The page's owner-held trust repair, stop-before-submission and no uncertain external replay rules are correct.

### Worker health, lifecycle and counters

`/health` reports process survival. `/bootstrap` checks native ownership readiness. `/ready` first checks native readiness; HMAC additionally queries `prism.worker_request_nonce`, whereas SPIFFE skips that nonce query. None authenticates an actual attempt or proves provider completion. Lifecycle admission can independently return stopping/capacity responses. Native ownership and journal reconciliation precede listening; failures can occur before HTTP exists.

`worker-readiness.ts:41-56,59-97` produces the four fields exactly as documented at prism-studio.md:1803-1820. `durationMs` is rounded operation elapsed time; idle error handling starts a fresh timer, so it is not connection age. `active` is admitted nonce operations at event creation, with the failing operation still included until `finally`; cap four, rejected admission does not increment. `open` is private pool `totalCount`, including idle and checked-out clients. `pending` is pool acquisition `waitingCount`. They are event-time snapshots, not native attempts, jobs, proof of leaks, capacity left for native work, or current health. The counter probe's simultaneous connect failures all report active=4 before final decrements, consistent with this description.

Worker diagnosis binds the original context/namespace, approved mode, one selected Pod UID, contract/container/port and minimum permissions. It uses three bounded local routes, no attempt submission, sanitized selected logs, and stops on Pod/authority changes. Its filter excludes raw messages, environment/connection URLs and unknown unsanitized codes. Fresh route results and retained event-time logs are distinguished. Native ownership, engine/pool/cgroup/journal repair remains an owned procedure with measurable closure; no deletion or restart shortcut is promised.

### Interruption, revisions, approval and Nova

All thirteen interruption rows at :680-702 were compared with Studio handlers/helpers and Control/storage transactions, rather than treated as a checklist. Tab storage, component-memory keys, typed edits without a receipt key, new revision on each successful restore, exact wire preference replay and UI failure-screen limitations differ as documented. A typed request that committed before response loss can conflict when repeated at the old base revision; a reload/history comparison is necessary before a new edit.

Approval and publication are separate writes. Studio's approval identity is local and can be lost before publication receipt display; uniqueness of project/digest does not recover it. Same-approval baseline return is a narrow server capability, not restored Studio UI or renewed current architecture authority. Capture/worker outcome uncertainty still requires reconciliation; no repeat click, digest alteration or destructive approval repair is safe. The page preserves these boundaries and separate human acceptance.

Nova `engine-run.ts:84-122` checks terminal status and active wait before exact signal-journal deduplication. A resolved wait can reject `WAIT_UNKNOWN_OR_STALE`; terminal runs can reject `WAIT_RUN_TERMINAL`. Identical signal content does not make the CLI retrieve a saved completion after the wait disappears. The canonical audit/unchanged-signal/expiry/owner STOP rules match source. Prism stage and baseline archive import verify the original architecture/approval/bundle linkage and governed capability; payload identity is not caller authentication.

The fixed absolute build-1228 browser choice in both spikes, package-local build 1187/root 1234 distinction and aggregate `&&` failure boundary are accurate. No package-local browser install or unit run is presented as full aggregate proof. Cleanup retains canonical revisions, decisions, ownership/journal/backup evidence and removes only owned temporary resources; no unimplemented cancellation, isolated restore or browser-download action is invented.

## Independently executed evidence

Environment: Linux 6.8.0-139-generic x86_64; Node v24.21.0; npm 11.19.0. Commands ran in the private `run/`, using unmodified archived original implementation bytes. Exit/status/stdout/stderr artifacts are in `logs/`.

| Check | Result and substantive scope |
| --- | --- |
| `npm ci --offline --include=dev --ignore-scripts --no-audit --no-fund` | Exit0, dependency preparation only. |
| Original Node suites: internal-auth, worker-readiness, worker-ingress-capacity, worker-shutdown-boundaries, control-server-config, design-round-client, agent-revision-client, control-decisions, design-rounds, domain-storage, agent-job-http | Exit0. HMAC body/replay/expiry negatives; real pg TCP refusal/stalled startup and sanitized dependency failure; ingress health capacity and shutdown/drain boundary; original embedded-PGlite transaction rollback/round/revision/decision exact replay distinctions; original actual HTTP/agent claim/fence/foreign/stale/outcome-binding negatives. Real PostgreSQL-server fixture skipped (`REAL_POSTGRES_DATABASE_REQUIRED`). Counts 28 passed/1 skipped are inventory only. |
| `source-review-probes.mjs` | Exit0. Original Control routes reject HMAC mode and wrong SPIFFE peer before any DB query. Exact peer crosses admission but malformed JSON stops; **no valid commit/live identity proof**. Original worker health routes distinguish native/nonce/mode combinations. Explicit nonexecuting DB stub and native/nonce stubs; all ephemeral loopback servers closed/shut down. |
| `nonce-counter-probe.mjs` | Exit0. Original nonce producer imported with an explicitly substituted `pg.Pool` class; cap four, rejection and event-time counter semantics including idle timer observed. Every held acquisition rejected and awaited; pool closed and module hook deregistered. No actual PostgreSQL or native attempt was used. |
| Published diagnostic log-filter code | Exit0 with explicit synthetic timestamped log input. Allowed codes/counters survive; private token/URL/message content does not; unsupported phase discarded and unknown native code mapped to UNRECOGNIZED_CODE. This is a filter check, not Kubernetes execution. |
| All fourteen published Bash blocks | `bash -n` passes; syntax parsing only, not command execution. |
| `node tests/verification/contracts/check-worker-trust-spiffe.mts` | Exit0, structural trust contract only. |
| `npm run verify:prism:deploy-script` | Exit0, workflow YAML/deploy contract/Bash syntax only; no deploy. |
| `node scripts/updates/materialize-release.mjs --family=runtime --check` | Exit1: missing `releases/runtime-images.json`; selected release/live route remains unavailable in this checkout. No files generated. |
| `node --test skills/prism/openclaw-plugin/index.test.mjs` | Exit0: exact two tools and three-design schema, not provider completion. |
| `node tests/verification/contracts/check-plugin-system-v2-resume.mjs` | Exit1 **before a wait was created**: local BusyBox `/usr/bin/flock` rejects `--timeout`, causing FILE_MUTEX_ACQUIRE_FAILED. Original error retained. Nova resume execution remains UNPROVEN; source inspection supports its rules. No wrapper/product edit masked this local prerequisite failure. Temporary test directory removed by original `finally`. |

First failures are preserved. Initial dependency preparation could not launch because the proposed `run/` cwd did not yet exist; it was created from the evidence root and preparation retried. The first reviewer counter assertion expected sequential active=[4, 3, 2, 1], but original catch callbacks correctly yielded [4, 4, 4, 4] before finally. All operations had already been rejected/awaited before that assertion failed. The failed script/output are retained; only the reviewer assertion was corrected and rerun, with no product mutation. The materialization and Nova tool-incompatibility failures were not converted into passing runs. These local failures do not establish a universal product defect or supported recovery path.

## Read scope and evidence limits

FULL read: both candidate pages; full `07-documentation-quality-standard.md` and `AP09-acceptance-contract.md`; OPR-010 and SPC/CDV catalogue context; applicable A98 definitions, post-documentation product validation, EXEC-PRISM-JOURNEY, READER-OPERATOR01-04, READER-QUALITY01 and local failure classification. These fixtures were understood as separate obligations, not claimed executed.

FULL implementation reads: Control 942 lines; Studio app 889 lines; worker service/readiness/lifecycle/entrypoint/config/native execution/host; internal auth and Control config; native-worker config and ownership implementation; Worker Core trust; agent routes/runner/bridge and OpenClaw plugin; Studio request/config/entrypoint/design-round and revision clients/preview files; Prism storage index/artifacts, agent jobs/admission, generations/direction decisions/preferences/native-operation store/execution; evaluation; baseline archive contract; Nova Prism stage/archive and Nova engine-run; Prism values/workloads/trust configmap; both spike configs and Studio browser config; bootstrap test preparation. Relevant original suite files were read in full before interpreting their outputs.

TARGETED reads: common-chart values16-63,132-220; common deployment438-530 and1637-1640; gateway config55-110,253-308; Prism schema59-108,510-531 and service20-23; deploy script100-103,974-982,1590-1818; package scripts1-90,265-292; Nova CLI; role overlay1-40,45-103 (private authority40-44 deliberately excluded); Dockerfile/Spire/package-lock/domain/render/pipeline adapter/product-decision/worker-trust contract and relevant pinned ranges. Other unrelated code, generated whole-package correctness, all other canonical guides and every transitive Worker Core implementation were not fully reviewed. The FULL archive is retained, but a full archive does not imply every file was read.

`source-pins.json` independently checks all 209 implementation links in both candidate pages: real regular Git blobs, valid actual ranges, and complete pinned-file byte equality with the reviewed archive. This validates the cited source bytes, not all semantic claims or AP09 machine-ledger/render requirements. Historical execution SHA/date remain historical: byte equality does not relabel an old execution as performed at this candidate. My current results are newly executed in this private archive and are labelled separately.

Not executed: full mutation/generation/render gates, native cgroup/worker attempts, PostgreSQL server/query fixtures, installed identity/proxy/socket enforcement, chart deployment, browser spikes/aggregate/interactive journey, model completion, actual Nova Prism import, backup/restore/cutover/cleanup or independent Reader/Quality/live operator tasks. Whole package acceptance, machine gates, independent Reader, independent Quality and live product validation are **UNPROVEN / outside this SOURCE scope**.

## Artifact and freeze disposition

Artifacts include `commit.tar`, `archive-manifest.json`, `archive-final-verification.json`, `source-pins.json`, reviewer probe sources, every execution log (including first failures), `verdicts.json`, this report and `artifact-manifest.json`. The artifact manifest records SHA-256/size and does not recursively hash itself. Report hash and manifest hash are delivered to the parent separately. Immutable archive input and finalized report/evidence are read-only.

**Freeze release:** this full SOURCE report releases the parent's freeze on the two authored pages. Release permits corrections; it does not grant candidate acceptance. Any changed candidate requires the appropriate review at its new hashes. F01 remains open at the hashes above.
