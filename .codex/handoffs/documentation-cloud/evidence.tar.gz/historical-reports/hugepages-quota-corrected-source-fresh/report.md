Independent complete affected Source review: **FAIL** at `46249582430c71013e67f7cc90923535228ce607`.

The independently derived affected union contains all85 records:11 Deployment,10 Job,10 CronJob,10 StatefulSet,10 DaemonSet and34 ResourceQuota. Full old/new factory exports against parent838949cc25755cf7abfb1b3944094d5ef3552ce8 show exactly85 changed identities, with no additions/removals. Git-show candidate script bytes match the immutable Git archive. All records, preexisting clauses, case conditions/outcomes, direct captions and dependency routes were manually assessed; no blanket case PASS comes from tests. Exact occurrence texts, memberships, hashes, evidence and verdicts are in the record/dimension/case/caption ledgers. Exact-equality groups retain mixed parent-specific verdicts rather than promote shared text to a universal PASS.

Record aggregate:42 PASS and43 FAIL. Dimension occurrences:1592 PASS and22 FAIL (1614 total). Cases:556 PASS and10 FAIL (566 total). Caption occurrences:4310 PASS and41 FAIL (4351 total);188 distinct exact caption/URL pairs comprise187 PASS and1 FAIL. The bounded Source result for all34 ResourceQuota records is PASS. A passing predicate within a failed record is retained as PASS; it cannot erase a separate caption or route error.

`HQ462-SOURCE001` — scripts/docs-kubernetes-apps-receiver-contracts.mjs:714, exact CAP059: “Hugepage resource names encode a page size and quantities must be divisible by it.” The cited helper41–57 defines the boolean predicate at43–54; it does not impose a validation requirement. Parser72–77 is a dependency outside that window. Core validation7955–7964 deliberately skips the predicate when AllowIndivisibleHugePagesValues is true. This unconditional caption conflicts with the newly qualified validation clauses. It occurs on41 affected identities:8 Deployment resource map/exact-key records plus Deployment overhead exact-key, and8 each Job/CronJob/StatefulSet/DaemonSet. Full exact membership and original inclusive span are in caption-groups.json/CAP059 and findings.json. Caption the boolean predicate at43–54; retain the independently supported conditional validator evidence.

`HQ462-SOURCE002` — scripts/docs-kubernetes-workload-receiver-contracts.mjs:330 imports unconditional invalidValue clauses from the apps factory100–103 into all10 affected StatefulSet resource records. Pinned apps validation238–254 enables SkipValidatePodTemplateSpec when ANY old-spec validation error remains under update setOpts. New spec214 reaches template guard71–73, which skips the complete core ValidatePodTemplateSpec call. Core resource validation is therefore not guaranteed on ordinary update. The frozen parent rows do not explain this skip. Source counterexample: an old persisted negative CPU request triggers an old core validation error; changing the template to another negative request can avoid the skipped new core resource check when independent Stateful checks pass. This is source control-flow proof, not a compiled Go or API execution result. Preserve selector matching, labels/annotations/Pod-specific annotations, policy/strategy/retention/replicas/timing/ordinals/selector, Always/no-activeDeadline, root metadata and immutable-field checks. ServiceName and PVC template update skips are separate. Qualify core resource/init rejection and add the old-invalid ordinary-update case.

The corrected huge-page option derivation itself is supported. Each receiving kind uses its actual old template (CronJob its old JobTemplate.Spec.Template), while create passes no old template. The option defaults false. Its old scan covers init, regular and ephemeral categories, both limits and requests, and otherwise overhead; it short-circuits on the first indivisible value. It is not restricted to unchanged/new values matching old quantities. With true, only divisibility is waived by that option; negative quantities, integer/name constraints, requests<=limits/nonovercommittable equality and CPU/memory key presence remain independent when the core validator runs. StatefulSet has the separate broad skip above. Job suspension/resource/scheduling options and immutability remain distinct.

Fresh typed null/zero decoding was read through serializer, indirect/literalStore, map initialization and writeback, Quantity and Time custom decoders. A null quantity map member retains a zero numeric key; a zero request key is present and prevents Pod-create copy from limits. Empty/omitted map/object/list behavior has its immediate-parent guard. ResourceList defaults round existing values without adding keys. Generated workload template defaults do not call SetDefaults_Pod; later Pod creation fills missing regular/init requests from limits. These are complete resulting typed-object facts, not authored patch omission/null deletion outcomes.

All inherited consumer/operation clauses were checked: scheduler request accounting, regular/restartable-init sums and init maxima, supported Pod-level replacement, overhead, NodeResourcesFit, distinct Linux/Windows CRI limits, QoS/cgroup completeness/MemoryQoS/quota, pressure and storage eviction, controller template-to-new-Pod copying, client-side strategic three-way/retainKeys and conditional Argo CSA/SSA/replacement/force/migration. Actual resources, schema, options, ownership, gates, admission and runtime observations remain external inputs. Bounded selected deploy.sh/GitOps paths were read in exact462; this is not final complete active producer closure.

ResourceQuota’s correction independently resolves historical QD838-SOURCE001 for this new identity:311 is the DNS-subdomain alias and8068–8070 is the namespaced ObjectMeta call with that alias. All34 records retain both separate supported captions. Ordinary create clears status and does not initialize generation; ordinary update restores status without strategy generation increment; common update restores generation. AllowUnconditionalUpdate130–132 returns true. Status restores spec and excludes its ownership, while root metadata still follows common validation. Metadata review covers names/namespace/generated-name retry, server UID/timestamps, version preconditions, generation, labels/annotation bounds, DELETE propagation/finalizer predicates, owner identity/scope/authorization and graph-based GC/orphan partial failure, and managedFields fallback/reset/bootstrap/identity/trie/caps/timestamps/exact kubectl migration. CRD empty-list comparisons were independently checked as dependencies; they are not applied to ResourceQuota’s typed [] decoding. Quota admission/accounting, GC completion and live recovery are not proved.

A98-10 affected Source: **FAIL**, because CAP059 is materially inaccurate; exported affected identity completeness is proven, while final current product closure is separately unproved. A98-11 affected Source: **FAIL**, because StatefulSet ordinary-update rejection/compatibility is incomplete. Typed/default/merge/runtime facts that pass are retained individually. A98-14 assigned Source verification: **FAIL** for lack of accepted frozen current producer and registered Add/Change/Remove mutation evidence in this review; this is an evidence boundary, not a new assertion that the mutation implementation is defective. Its applicability/acceptance status remains pending. No whole-gate/global, Reader, Quality, Astra, deployment or live acceptance is issued. The binding product-scope/upstream-reference rule, complete quality/contract/fixtures/execution documents and CFG-009 were read; unused upstream fields are not promoted to full-schema product obligations.

82 full original primary files were freshly retrieved by HTTPS:80 Kubernetes at66452049f3d692768c39c797b21b793dce80314e and2 Argo ate258ee23c3e52266d407572f4bcdfe7d9ed36cb5. Calculated Git blobs exactly match independently retrieved nontruncated pinned trees, with no mismatches. Primary URLs, byte counts/SHA256/Gitblob and all inclusive caption excerpts are retained. This claims full-file retrieval/authentication and relevant-definition reading, not that every unrelated line in these large source files was reviewed.

All5577 regular files in the original archive match committed Git blobs; no extra/missing/mismatched regular files or Git symlinks were found. No candidate/live product file was modified. Private script copies used external installed node_modules symlinks; dependency-disclosure.json records their targets and separately captures/hash-binds current yaml bytes without claiming an immutable install. Final factory-export recheck exited0. Structural checks establish bindings/completeness, never Source truth. Some initial oversized reads truncated and were followed by bounded rereads. One supplemental strategy print requested beyond EOF and returned IndexError after the full166-line file; the subsequent bounded reads completed remaining dependencies. No failed check is hidden.

Historical838 report remains untouched and FAIL, QD838-SOURCE001, SHA256 `aa21c0cee6c52b47a861ba6ce7b38f442a8072db92c15e02810c9c25a0e49d7d`. No old Source PASS or v6 applicability evidence was reused. Later root corrections do not change this exact462 verdict. Source-control-flow counterexamples and failed checks are preserved. No compiled KubernetesGo/API/admission/controller/GC/node/recovery, registered mutation suite, Reader/Quality/Astra or final producer closure exercise ran. Hash manifest and read-only seal bind this private evidence; they do not claim cryptographic signing or eliminate the ability of the filesystem owner to change permissions.

Every assigned record follows. Full dimension/case/caption IDs and verdicts are in record-ledger.jsonl; current producer applicability is UNPROVED_PENDING_FINAL_FROZEN_PRODUCER for each.

| Identity | Source | Finding |
| --- | --- | --- |
| `apps:apps/v1:Deployment:$.spec.template.spec.containers[].resources` | PASS | — |
| `apps:apps/v1:Deployment:$.spec.template.spec.containers[].resources.requests` | FAIL | HQ462-SOURCE001 |
| `apps:apps/v1:Deployment:$.spec.template.spec.containers[].resources.requests[<exact-key>]` | FAIL | HQ462-SOURCE001 |
| `apps:apps/v1:Deployment:$.spec.template.spec.containers[].resources.limits` | FAIL | HQ462-SOURCE001 |
| `apps:apps/v1:Deployment:$.spec.template.spec.containers[].resources.limits[<exact-key>]` | FAIL | HQ462-SOURCE001 |
| `apps:apps/v1:Deployment:$.spec.template.spec.initContainers[].resources` | PASS | — |
| `apps:apps/v1:Deployment:$.spec.template.spec.initContainers[].resources.requests` | FAIL | HQ462-SOURCE001 |
| `apps:apps/v1:Deployment:$.spec.template.spec.initContainers[].resources.requests[<exact-key>]` | FAIL | HQ462-SOURCE001 |
| `apps:apps/v1:Deployment:$.spec.template.spec.initContainers[].resources.limits` | FAIL | HQ462-SOURCE001 |
| `apps:apps/v1:Deployment:$.spec.template.spec.initContainers[].resources.limits[<exact-key>]` | FAIL | HQ462-SOURCE001 |
| `apps:apps/v1:Deployment:$.spec.template.spec.overhead[<exact-key>]` | FAIL | HQ462-SOURCE001 |
| `workload:batch/v1:Job:$.spec.template.spec.containers[].resources` | PASS | — |
| `workload:batch/v1:Job:$.spec.template.spec.containers[].resources.requests` | FAIL | HQ462-SOURCE001 |
| `workload:batch/v1:Job:$.spec.template.spec.containers[].resources.requests[<exact-key>]` | FAIL | HQ462-SOURCE001 |
| `workload:batch/v1:Job:$.spec.template.spec.containers[].resources.limits` | FAIL | HQ462-SOURCE001 |
| `workload:batch/v1:Job:$.spec.template.spec.containers[].resources.limits[<exact-key>]` | FAIL | HQ462-SOURCE001 |
| `workload:batch/v1:Job:$.spec.template.spec.initContainers[].resources` | PASS | — |
| `workload:batch/v1:Job:$.spec.template.spec.initContainers[].resources.requests` | FAIL | HQ462-SOURCE001 |
| `workload:batch/v1:Job:$.spec.template.spec.initContainers[].resources.requests[<exact-key>]` | FAIL | HQ462-SOURCE001 |
| `workload:batch/v1:Job:$.spec.template.spec.initContainers[].resources.limits` | FAIL | HQ462-SOURCE001 |
| `workload:batch/v1:Job:$.spec.template.spec.initContainers[].resources.limits[<exact-key>]` | FAIL | HQ462-SOURCE001 |
| `workload:batch/v1:CronJob:$.spec.jobTemplate.spec.template.spec.containers[].resources` | PASS | — |
| `workload:batch/v1:CronJob:$.spec.jobTemplate.spec.template.spec.containers[].resources.requests` | FAIL | HQ462-SOURCE001 |
| `workload:batch/v1:CronJob:$.spec.jobTemplate.spec.template.spec.containers[].resources.requests[<exact-key>]` | FAIL | HQ462-SOURCE001 |
| `workload:batch/v1:CronJob:$.spec.jobTemplate.spec.template.spec.containers[].resources.limits` | FAIL | HQ462-SOURCE001 |
| `workload:batch/v1:CronJob:$.spec.jobTemplate.spec.template.spec.containers[].resources.limits[<exact-key>]` | FAIL | HQ462-SOURCE001 |
| `workload:batch/v1:CronJob:$.spec.jobTemplate.spec.template.spec.initContainers[].resources` | PASS | — |
| `workload:batch/v1:CronJob:$.spec.jobTemplate.spec.template.spec.initContainers[].resources.requests` | FAIL | HQ462-SOURCE001 |
| `workload:batch/v1:CronJob:$.spec.jobTemplate.spec.template.spec.initContainers[].resources.requests[<exact-key>]` | FAIL | HQ462-SOURCE001 |
| `workload:batch/v1:CronJob:$.spec.jobTemplate.spec.template.spec.initContainers[].resources.limits` | FAIL | HQ462-SOURCE001 |
| `workload:batch/v1:CronJob:$.spec.jobTemplate.spec.template.spec.initContainers[].resources.limits[<exact-key>]` | FAIL | HQ462-SOURCE001 |
| `workload:apps/v1:StatefulSet:$.spec.template.spec.containers[].resources` | FAIL | HQ462-SOURCE002 |
| `workload:apps/v1:StatefulSet:$.spec.template.spec.containers[].resources.requests` | FAIL | HQ462-SOURCE001, HQ462-SOURCE002 |
| `workload:apps/v1:StatefulSet:$.spec.template.spec.containers[].resources.requests[<exact-key>]` | FAIL | HQ462-SOURCE001, HQ462-SOURCE002 |
| `workload:apps/v1:StatefulSet:$.spec.template.spec.containers[].resources.limits` | FAIL | HQ462-SOURCE001, HQ462-SOURCE002 |
| `workload:apps/v1:StatefulSet:$.spec.template.spec.containers[].resources.limits[<exact-key>]` | FAIL | HQ462-SOURCE001, HQ462-SOURCE002 |
| `workload:apps/v1:StatefulSet:$.spec.template.spec.initContainers[].resources` | FAIL | HQ462-SOURCE002 |
| `workload:apps/v1:StatefulSet:$.spec.template.spec.initContainers[].resources.requests` | FAIL | HQ462-SOURCE001, HQ462-SOURCE002 |
| `workload:apps/v1:StatefulSet:$.spec.template.spec.initContainers[].resources.requests[<exact-key>]` | FAIL | HQ462-SOURCE001, HQ462-SOURCE002 |
| `workload:apps/v1:StatefulSet:$.spec.template.spec.initContainers[].resources.limits` | FAIL | HQ462-SOURCE001, HQ462-SOURCE002 |
| `workload:apps/v1:StatefulSet:$.spec.template.spec.initContainers[].resources.limits[<exact-key>]` | FAIL | HQ462-SOURCE001, HQ462-SOURCE002 |
| `node-workloads:apps/v1:DaemonSet:$.spec.template.spec.containers[].resources` | PASS | — |
| `node-workloads:apps/v1:DaemonSet:$.spec.template.spec.containers[].resources.limits` | FAIL | HQ462-SOURCE001 |
| `node-workloads:apps/v1:DaemonSet:$.spec.template.spec.containers[].resources.limits[<exact-key>]` | FAIL | HQ462-SOURCE001 |
| `node-workloads:apps/v1:DaemonSet:$.spec.template.spec.containers[].resources.requests` | FAIL | HQ462-SOURCE001 |
| `node-workloads:apps/v1:DaemonSet:$.spec.template.spec.containers[].resources.requests[<exact-key>]` | FAIL | HQ462-SOURCE001 |
| `node-workloads:apps/v1:DaemonSet:$.spec.template.spec.initContainers[].resources` | PASS | — |
| `node-workloads:apps/v1:DaemonSet:$.spec.template.spec.initContainers[].resources.limits` | FAIL | HQ462-SOURCE001 |
| `node-workloads:apps/v1:DaemonSet:$.spec.template.spec.initContainers[].resources.limits[<exact-key>]` | FAIL | HQ462-SOURCE001 |
| `node-workloads:apps/v1:DaemonSet:$.spec.template.spec.initContainers[].resources.requests` | FAIL | HQ462-SOURCE001 |
| `node-workloads:apps/v1:DaemonSet:$.spec.template.spec.initContainers[].resources.requests[<exact-key>]` | FAIL | HQ462-SOURCE001 |
| `metadata:v1:ResourceQuota:$.metadata` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.name` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.generateName` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.namespace` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.uid` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.resourceVersion` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.generation` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.creationTimestamp` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.deletionTimestamp` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.deletionGracePeriodSeconds` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.selfLink` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.labels` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.labels[<exact-key>]` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.annotations` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.annotations[<exact-key>]` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.finalizers` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.finalizers[]` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.ownerReferences` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.ownerReferences[]` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.ownerReferences[].apiVersion` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.ownerReferences[].kind` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.ownerReferences[].name` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.ownerReferences[].uid` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.ownerReferences[].controller` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.ownerReferences[].blockOwnerDeletion` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.managedFields` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.managedFields[]` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.managedFields[].apiVersion` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.managedFields[].fieldsType` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.managedFields[].fieldsV1` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.managedFields[].manager` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.managedFields[].operation` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.managedFields[].subresource` | PASS | — |
| `metadata:v1:ResourceQuota:$.metadata.managedFields[].time` | PASS | — |
