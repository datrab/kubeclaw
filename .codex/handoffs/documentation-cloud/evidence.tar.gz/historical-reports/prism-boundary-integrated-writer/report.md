# Prism notification boundary author report

Changed only docs/site/use/prism-studio.md, docs/status/open-issues.json and docs/status/finding-identities.json. Ownership released to root.

The Studio guide now describes the intended journey conditionally. It distinguishes Control admission and job creation, the separate wait-store record, failed operator notification, and the absent active Core approval wait. With the selected installed operator-messaging adapter, the top-level architectureDigest field is rejected before delivery reservation, secrets or network. AdapterRuntime wraps the failed effect; the stage returns blocked prism_design.dispatch_failed without a returned wait. Safe-stop and recovery text preserves original identities and raw state before copied-journal strict parsing and audit, and assigns Core/effects, wait-store and Control reconciliation to their actual owners. No new run, identities, receipt import or manufactured wait is provided.

Permanent PRISM-NOVA-NOTIFICATION-001 is Open with owner, impact, safe actions, future acceptance and pinned narrow source evidence. Historical executed checks and original findings were preserved. No generated status file was manually edited.

Observed checks on 2026-10-11:
- Complete-byte comparison against 8cba013ac84537cefbaa356b19fb236c1cf05587: PASS for 10 newly cited files; SHA-256 and path list in source-equivalence.json.
- Direct producer-shaped parsePayload probe: PASS for expected OPERATOR_PAYLOAD_UNKNOWN_FIELD:architectureDigest rejection, exit 0. Scope parsing only; no stage, store, secret, network or deployment execution.
- validateStatus exported guard: PASS for schema, counts, stable identity dispositions and dependencies.
- docs:status:check: exit 1 because generated open-issues view is stale. Root owns regeneration.
- Reader-site boundary: exit 1, with no Studio or status-source violations. Remaining observed failures are Helm lines 1824/1925/3869 and Nova lines 675/852. Root owns those surfaces.
- git diff --check for all three owned files: PASS.

No product fix, full-stage test, installed-adapter delivery, active wait, resume, final import, commit, push or self-acceptance is claimed.
