# Shared metadata correction author report

Role: AUTHOR only. No independent acceptance is granted. Exclusive repository edit: scripts/docs-kubernetes-metadata-receiver-contracts.mjs. Module SHA-256: `e5ec69d72870b9eff2515d205ab8063204f0cea0c0bddd6695e7d9c4792f7042`. Repository HEAD: `79a5eaef0870bd1d6cdb290cf7565fa3b8f021e0`; concurrent Root edits are outside this report.

The author read the full documentation quality standard and AP09 acceptance contract, the CFG-009 catalogue binding, A98-10/A98-11 and fixtures, and the sealed SOURCE report/findings/ledgers. No applicable AGENTS.md was present at repository or ancestor/script paths. Pinned primary Git objects and additional pinned archive bytes were read; source-provenance.json verifies each exact URL/caption blob and range. Captions are bounded evidence, not a source-review verdict.

## Changes and finding correspondence

- F1: typed explicit reset is distinguished from tracking. Existing live UID plus empty ownership skips non-apply tracking. Create uses default probability 1; later Apply bootstraps before-first-apply ownership.
- F2: full CRD decoding round-trips typed ObjectMeta into unstructured. omitempty removes empty managedFields:[] before field management; [{}] survives. Complete-body outcomes do not claim every patch path.
- F4: Pod-template creationTimestamp JSON null is zero nested Time. Root lifecycle initialization/preservation does not apply and GetPodFromTemplate does not copy it.
- F5: NetworkPolicy unconditional-update evidence includes executable function and true return at lines 98-101.
- F6: NetworkPolicy and Binding update captions claim their spec comparison/generation change; no protected-content preservation claim is retained for those bodies.
- F7: exact manager kubectl can internally retry force=true for complete eligible same-version last-applied conflict coverage. Missing/empty/malformed/version/conversion failures preserve the original conflict; changed live fields are ineligible; partial coverage returns uncovered conflicts. Different managers bypass migration.
- Default wrappers: installed wrapper chain, full GVK checking, exact StripMeta ownership exclusions, timestamp update/no-change distinctions, Update-only ancient-changes version buckets and default cap 10, and existing-nonempty last-applied annotation updating are explained. Distinct versions can prevent reduction to ten; no total-count guarantee is invented.
- Additional consumer discovery led to source-checked Application/AppProject event-label precedence and filtering, Application updateApp merge/replacement maps, manifest path forwarding/optimization, hydrate annotation consumption, external link collection versus managed-by URL validation, ApplicationSet RollingSync label selection, and CNP Parse/GetIdentityLabels.

## Retained scope and checks

identity-join.json proves exact 246 real-schema identities, 136 implicit reference identities and 4 descriptor identities match before.mjs. Every original case name and condition remains: 2553 original cases, 2589 final cases. The 36 additional cases occur only at nine affected root managedFields parent boundaries (four cases each). Wrong old outcomes were corrected; retaining coverage does not retain wrong claims.

schema-join.json proves each of the 246 real records joins the actual schema authority with zero invented/extra paths: Deployment102, Ingress34, NetworkPolicy34, Policy35, Binding35, Application3, AppProject3. The separate 136 obligations remain separate from opaque CRD schema rows. Root owns canonical renderer integration F3 and all generator/inventory/matrix edits.

- node --check scripts/docs-kubernetes-metadata-receiver-contracts.mjs: exit0. An initial invocation from the unrelated turn directory failed MODULE_NOT_FOUND; the corrected repository invocation passed.
- node --test scripts/tests/api-receiver-coverage.test.mjs scripts/tests/api-schema-boundaries.test.mjs scripts/tests/api-reference.test.mjs: exit0; final focused-tests.log has 17 PASS, zero failed/skipped. Concurrent Root additions account for the changed test count. This is static unit/render-fixture evidence only.
- node verify.mjs: exit0; exact export identities and original case names/conditions checked.
- node schema-join.mjs: exit0; metadata-only exact schema joins, not a full all-module join.
- python3 verify-ranges.py: exit0; 200 exact URL/caption ranges bounded, bytes verified against pinned Git SHA-1 and recorded SHA-256. The newly cited coerce.go range ends at151 (the actual final line).
- consumer-search-source-manifest.json verifies 3549 non-test/non-generated/non-vendored Go files against pinned primary tree blobs. Discovery rg results contain413 broad Argo metadata matches and11 targeted Cilium matches. They are candidates, not 424 proven in-scope consumers. Kubernetes ClusterNetworkPolicy in Cilium pkg/k8s/cluster_network_policy.go is a different API type and is not folded into CNP/CCNP behavior.

## Open proof obligations and safe limits

Complete semantic Argo/Cilium metadata-consumer discovery remains OPEN. The search register exposes additional paths requiring receiver/caller classification: ApplicationSet generation/update/deletion/owner references and child event predicates; hydration dependency status paths; metrics label/deletion paths; server Watch and response-field filtering; manifest-refresh path interpretation; UI and command clients; Cilium resource transforms/event identity, status/operator derivatives, service-driven updates and CLI policy consumers. Search coverage is not transitive call-graph proof. A separate Git-grep attempt produced316 Argo matches and193 Cilium matches before the Cilium child was terminated; these supplemental files are partial discovery artifacts, not successful comprehensive search evidence. The module states this unresolved completeness obligation for all affected CRD metadata records. Documentation owner/source-auditor must classify every candidate and complete caller discovery with exact source captions; no waiver or acceptance is claimed. Existing named consumers and operation cases are retained.

Root F3 renderer/inventory integration, generated site output and publication checks are not authored here. The required strict OPEN proof guards remain Root-owned; this author did not remove or bypass them. Fresh independent affected SOURCE re-review, independent Reader/Quality review and live API/controller/GC/recovery exercises remain required. No live create, replace, Apply, status, DELETE, admission, controller operation or cleanup ran. No generation, deployment, product edits, commit or push occurred.

Language method: manual project controlled-language revision of affected sentences, with direct named components, explicit branch conditions and exact API identifiers. Technical terms include ObjectMeta (standard resource metadata), managedFields (server ownership records), field-manager wrapper (logic around merge/tracking), GVK (group/version/kind), CRD (custom-resource definition), and field trie (encoded owned paths). No formal ASD-STE100 certification or independent language acceptance is claimed.

Exclusive module ownership is RELEASED at the SHA-256 above. This report is a correction handoff, not approval of CFG-009, A98-10/A98-11 or any AP09 package.
