# Author correction: compact precedence and platform timeout impact

Role: documentation author only. This is not an acceptance review.
Repository: `/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04`.
Branch: `docs/documentation-overhaul`.
Frozen source and new callout revision: `fe426bd75db277b04cf405cc2057063b75fa0a1d`.
Date: 2026-10-10 UTC.
Writes inside the repository: only `docs/site/reference/configuration-precedence.md` and `docs/site/reference/configuration-change-impact.md`. No product-code, generator, generated output, shared register or commit changes were made. No network or cluster action was performed. Concurrent writers' other changes were left intact.

## Input and source inspection

Read the entire released independent Source report `/home/node/Documents/Codex/a98-evidence/precedence-source-fresh/report.md`, including its limits and mandatory fresh-review continuation. The full quality standard was read earlier in this continuous author assignment, as were A98-10/A98-11 and CFG-009/013/014. Both assigned pages were read in full before the first edit and their final content was reread after this correction. The reviewer report was a lead; primary sources and independently authored executable checks establish the new claims.

Full primary files read for the affected mechanisms: compact platform-config.ts, optional-absence.ts, standard.json, SDK values.ts, platform.ts, platform.schema.json, engine-runtime.ts, engine-snapshots.ts, engine-run.ts, engine.ts, adapters.ts, effects/coordinator.ts, and effect-recovery.ts. Related registry activation.ts was read completely. Targeted supporting reads: adapter-startup.ts 82–164; real-run-workspace.mjs 1495–1543; core/cli.ts 42–72; durable-invocation.ts acquisition and renewal regions; locks.ts 1–105; registry/schema.ts 1–115; registry/discovery.ts 1–115; registry/build.ts 1–135; graph.ts 1–85; test fixture preparation examples. The linked run-control section was read before linking it. This is not a claim of complete human review of every imported registry, graph, isolation, runner, or E2E module.

A fresh external `product/` tree was extracted with `git archive fe426bd75db277b04cf405cc2057063b75fa0a1d`. Its third-party dependency link uses the installed node_modules tree. The custom frozen-loader.mjs resolves every @kubeclaw workspace package through frozen package manifests and their exports; it does not import those packages from mutable workspace symlinks, mock product functions or alter their source. The installed Node is v24.21.0. The normal Node experimental-loader warning is retained in both logs.

`source-and-preservation-check.json` validates all 23 new pinned source links/ranges and confirms their entire file bytes agree among frozen fe426, current main, and the earlier ec2 product revision. This byte agreement establishes source continuity for the correction, not global semantic revalidation.

## Full affected prose scope

configuration-precedence.md:

- Extend Evidence dependencies and add a section-specific fe426 verification record. Keep prior non-Helm and Helm revision records.
- Correct the compact family row in `## Precedence by family`: standard profile → supplied webhook/context → validated recursive overrides → placeholder substitution using the original root. State the caller can modify output later.
- Add `## Compact profile inputs and overrides` at line 41. Explain the complete accepted top-level field set, standard profile selection, exact fixed features/tuning values, override object restriction and webhook string rule. Explain the actual ordered operations, validation against the post-context object, pre-existing nested-target requirement, object-over-scalar rejection, recursive map preservation and other-value replacement without blanket type validation.
- Include a complete JSON input identical to the executed probe. Explain override project/root/run-ID winners versus the raw-root placeholder result and missing/invalid placeholder failure. State the diagnostic's REPO_ROOT name does not cause this function to read an environment variable.
- Bound the explanation to expandSwarmConfig. Describe source-established run-builder context insertion, later normalization, run-ID reassignment, webhook selection and scenario adjustment. Describe noncompact pass-through without calling it validated compact input.
- Add a coherent fe426 source callout, actual 17-check status and its limits.
- Widen the older approval schema source range from L24–L29 to L22–L29 so that it includes the property name and integer type. Preserve its historical revision and check status.

configuration-change-impact.md:

- Extend Evidence dependencies and add a section-specific fe426 verification record. Keep prior revision records.
- In `## Impact classes` (line 12), add `Recreate consumer` and narrow `New run` to actual violated graph/package/recorded-runtime-subset pins. Do not classify platform timeout capture as automatic run identity drift.
- Correct the platform-timeout row in `## Change matrix` (line 24) to name shutdownTimeoutMs and effectLockTtlMs and classify validated reload/consumer recreation. A new CLI invocation loads configuration; another owning process/caller may need its own restart or reload. State timeout-only changes do not themselves force a new ID in the compared subset.
- Add `## Platform timeout capture and recovery` at line 46. Give required/optional types, bounds and actual lock fallback; describe adapter activation/readiness/cleanup/shutdown capture and effect acquisition/renewal use. Enumerate the exact persisted subset and distinguish snapshot checks from consumer reconstruction.
- Explain current-platform recovery preparation, retained identity and current-timeout handoff only conditionally on other recovery gates. Keep terminal/wait/effect/graph/package/configuration stop boundaries explicit.
- Give operational preservation, validation, stop-new-work/drain and recovery-input guidance. Label choosing a new run after draining as a conservative operational choice rather than an implementation mandate. Preserve the distinction from graph-pinned stage execution.timeoutMs and recorded adapter-configuration fields.
- Add a coherent fe426 source callout, actual 11-check status and the explicit absence of full changed-timeout recovery execution.
- Narrow the older `pinned recovery and startup capture` source-callout claim to the recorded runtime configuration subset. Retain historical pin and test result rather than claiming a new complete replay of those tests.

All original families and mechanisms remain. Both Helm sections, including the earlier 24-case evidence and practical guidance, are byte-identical to before this correction. `source-and-preservation-check.json` asserts that fact. No Helm cases were rerun because their product source and documentation did not change. Scope-specific correction diffs compare with this turn's before copies, rather than conflating earlier Helm additions with the new correction.

## Actual checks and outcomes

Commands from the repository/evidence host (exact arguments are saved in commands.json):

1. `node --loader /home/node/Documents/Codex/a98-evidence/precedence-source-correction-writer/frozen-loader.mjs /home/node/Documents/Codex/a98-evidence/precedence-source-correction-writer/compact-probe.mjs` — exit 0, 17 assertions passed. Final log compact-checks.log and compact-results.json are retained. The probe was rerun after aligning its complete example input exactly with the published JSON; the result remains 17 passed assertions.
2. `node --loader /home/node/Documents/Codex/a98-evidence/precedence-source-correction-writer/frozen-loader.mjs /home/node/Documents/Codex/a98-evidence/precedence-source-correction-writer/timeout-probe.mjs` — exit 0, 11 assertions passed. timeout-checks.log, timeout-results.json, prepared-authority.json and the synthetic fixture files/snapshot remain available.
3. `node scripts/docs-check-refs.mjs` — initial exit 1 because a new platform.ts source link ended at L71 while the file ends at L70. The range was corrected to L51–L70; the original failure log is retained as references.log. Final exit 0: 3847 local links, 1755 local anchors, 6735 repository path references, 21035 pinned source links. references-final.log retains the actual result. This checks the contemporaneous shared docs tree; it is not acceptance of other writers' prose.
4. `git diff --check -- docs/site/reference/configuration-precedence.md docs/site/reference/configuration-change-impact.md` — exit 0.
5. Local source/JSON/preservation assertions — passed: 23 new pinned source ranges valid; full-file frozen/main/ec2 byte agreement; published compact JSON exactly equals the executed input; both Helm sections byte-identical. Retained as source-and-preservation-check.json.

Compact behavioral cases: context and webhook overrides; raw-root substitution distinct from effective root; unknown/new nested targets reject; object over scalar rejects; absent contextual target rejects; array/null replacements are not schema-type-checked; existing map sibling retained; empty override map preserves profile values; missing/whitespace placeholder root rejects; unsupported profile rejects; fixed feature switch rejects; partial tuning rejects; extra top-level key rejects; override array rejects; noncompact input returned unchanged. All product behavior comes from the actual frozen expander and SDK selection helpers.

Timeout behavioral cases use a synthetic local trusted plugin with real loader, discovery/registry preparation and snapshot functions. No plugin stage or adapter operation is executed. The probe asserts prepared.configuration excludes both fields; unchanged preparation passes pinned-package checks; shutdown-only, TTL-only, combined and omitted-TTL changes pass package/graph checks without rewriting the stored snapshot. A changed adapter config rejects with RECOVERY_RUNTIME_CONFIGURATION_MISMATCH; a changed stage execution timeout rejects with RECOVERY_GRAPH_DIGEST_MISMATCH. Zero shutdown, below-minimum TTL and above-maximum TTL reject at the actual platform loader. This is a narrow authority comparison exercise, not a resumed pipeline or deadline/lock experiment.

## Language and evidence method

Author self-check applied the project controlled-language rules: named consumers, ordered operations, explicit conditions before action, plain definitions/context, exact setting identifiers, narrow evidence, and separate source-based consequences versus executed checks. New technical terms include compact expander, override target, placeholder context, captured value, consumer recreation and recorded runtime configuration subset. No formal ASD-STE100 certification, independent Reader/Quality judgment or package acceptance is asserted.

## Full remaining limitations and required continuation

- This author correction does not overturn or accept the prior independent report. A new fresh-context independent Source review with new candidate hashes is mandatory for these changed paths. This author must not take that role or provide acceptance of its own changes.
- No full Nova pipeline start/resume/recovery under changed timeouts was executed. Passing package/graph checks does not establish recoverability, terminal/wait state, effect safety, native isolation, actual timing behavior or external success.
- Runtime construction/current timeout handoff, adapter deadline consumers, effect renewal behavior and run-builder later changes were inspected from primary source. No adapter activation/ready/shutdown deadline, real effect, lock acquisition/renewal, drain, runtime readiness or real E2E builder execution was performed.
- The compact probes exercise only expandSwarmConfig. They do not validate every profile leaf/replacement value or downstream schema, nor real repository, path, credential, deployment or caller behavior. Noncompact pass-through is not a schema validation result.
- The synthetic timeout fixture is an authority-check aid, not a supported production profile or extension acceptance exercise. It does not prove live credential, image, host, native capacity, registration activation effects or operational maintenance success.
- Earlier Helm claims/checks are preserved with their original ec2 identity and existing limits. No API admission, GitOps/controller reconciliation, pod rollout, PVC init execution, rotation, backup/restore/migration/rollback or cluster operation was performed in this correction.
- Existing nonaffected family evidence retains its earlier source pins/check status. No global configuration source/inventory coverage or every-field semantic closure is asserted.
- Repository source-link checking passed. Public renderer, source preview, public route build, GitHub/network reachability and deployed presentation were not checked.
- No generator run, shared dependency/authority-register update, generated-freshness test, drift mutation, global docs build or clean final package ledger was performed here. Root must refresh affected metadata and perform those separate checks after concurrent writers settle.
- New callouts consistently pin fe426; older callouts intentionally keep their historical pins. Final reviewed-revision/source-ledger alignment remains separate work, without silently replacing historical executed checks with unexecuted current results.

## Release and artifacts

The two assigned pages are released to root for the mandatory fresh independent Source review. No further edit is planned under this author turn. Final page copies, before copies, correction-only diffs, source/preservation JSON, frozen product tree, two probes, frozen package loader, synthetic fixture, result JSON and logs are retained in this directory. The preceding Helm author evidence remains under ../helm-precedence-doc-writer and was not altered.
