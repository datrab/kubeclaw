# Read-only retention and backup procedure correction

Status: **two-page candidate installed and ready for independent Source/Reader review**. No gate, DAT-006, package, live operation or restore PASS is awarded.

Repository: branch `docs/documentation-overhaul`, observed current HEAD `a629fcae2c6567e48f50c592c5c9455b4c853461`. The previous two reviewed input hashes were checked before installation. Root explicitly authorized exclusive writes to these two pages after sealing the prior Source and Reader reviews. No product, script, generator, review-matrix or other repository file was written; no commit or push was made.

## Correction scope

F1: added one exact mounted-file-only projection bound to an owner-selected Pod UID and actual `/app/config.yaml`, with arbitrary values withheld; exact READ ONLY repeatable-read SQL projection of only the three retention keys, live instance/schema/profile prerequisites and no Secret/credential output; absent/null/type/units and applied DB-overwrite rules; table cutoffs; explicit config-field/list limitations and effective-runtime `unknown` stop requiring the owner's versioned per-worker observation procedure. It does not present mounted values or current stored rows as loaded runtime policy.

F2: bound Job UID, Pod UID/controller/success and Pod log to one precise completed group. Scheduled reuse of a recent group is explicit. Owner-provided PVC access/export is a prerequisite; no completed-Pod exec/cp or new mount procedure is invented. The copied-root procedure uses the unchanged native script's `verify` with a frozen private root containing exactly one logged group, then compares returned path. Narrow supplementary owner/privacy/source/dump-tool/authority/TOC checks cover facts native verify does not establish. The native CLI remains latest-only; no production-PVC or later native check is attributed to the copied group. Separate privately recovered keys, actual tools, encryption/independent-storage transfer, destination proof and fence release remain required. Full isolated application restore remains unsupported.

## Source evidence

Read the full quality standard, A98-02/07/13 acceptance clauses, DAT-006 catalogue, sealed Reader report/ledger and complete prior Source report/claim table. Primary copies and bytes/SHA-256/Git blob identities are in `primary-source-hashes.json`. Eight selected upstream files were independently matched against the recorded official pinned Git-tree blob IDs. Both duration-parser files were independently fetched from official raw GitHub at the selected full revisions and also matched to those tree IDs. Source functions and both admin GET bodies were read directly; neither reviewer conclusions nor author summaries replaced those reads. Four current repository implementation/manifest files were copied privately and inspected.

`citation-spans.json` verifies 18 added precise source links against saved primary bytes and valid line bounds. `preservation-checks.json` proves the entire original data page is exact after removing the addition, and recovery's prefix plus everything from its restore-primitive boundary onward is unchanged. All prior detailed image/profile/schema/key, pool, migration, encryption and restore-proof limits remain. Source claims in the replaced backup block are retained with more specific instructions; only fresh review can award current Source acceptance.

## Executed checks and honest limits

`python3 check.py`: **51 bounded checks passed**. These cover primary Git-blob bindings, new Bash syntax/Python compilation, actual pinned duration/retention function behavior, safe output filter withholding, SQL READ ONLY/projection/timeout/rollback shape, exact-group/private/tool/source/authority guards and optimized-Python failed-Pod/multiple-path stops. Guard execution uses declared synthetic tools/media and explicitly skips native selection; it is not native archive acceptance. `git diff --check` for the two pages: exit 0.

An actual native `verify` attempt with synthetic inputs failed before media acceptance on this Alpine/musl worker: Bash rejected the existing `{1,256}` regular expression, and this worker supplies BusyBox instead of required GNU `realpath`. The unmodified script failure is retained in `native-local-blocked.txt`; there is **no native media verification PASS** here. The procedure requires the owner's compatible GNU/glibc recovery environment and exact PostgreSQL tools. No change to the product script was made to hide this result.

Not run: deployed Pod/config extraction, actual PyYAML extraction, SQL query execution, database connection, real `pg_restore` archive verification, backup Job, PVC mount/export, real keys or Secrets, encrypted offsite copy, fence operation, restore, selected-image application/API/decryption acceptance, cutover/rollback, publication renderer or full generator. No credentials or environment values were printed. The missing cloud environment-status tool and missing network-policy file did not establish managed readiness; official public source retrieval succeeded without credential access.

## Controlled language and terminal state

Applied project controlled-language review to the additions: direct component/action sentences, defined inputs before commands, explicit permissions, times/units, observations, stop/failure/cleanup boundaries and product limits. Technical identifiers remain exact. This is not certified ASD-STE100 compliance or an independent Language verdict. Narrow source links and repository Markdown were checked; published routes were not.

Final candidates and SHA-256 are in `output-hashes.json`. The final pages match the private drafts. Repository changes are limited to the two authorized pages; unrelated working-tree changes were preserved. The candidate pages will not be edited further before Root's next authorization.
