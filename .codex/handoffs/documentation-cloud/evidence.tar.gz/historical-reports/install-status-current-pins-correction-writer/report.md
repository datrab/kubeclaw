# Installation status and current source-pin correction

Writer: `/root/installation_eof_optional_prism_batch_writer`. Documentation correction only; no independent Source, Reader, Quality, package, publication, operational or live acceptance claim.

Repository: `/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04`, branch `docs/documentation-overhaul`, initial HEAD `2a8558d795054d25aa4b72dbdc296c9321ba38f6`. Worktree was already dirty. Root explicitly released the prior page freeze after completed Source and Reader reviews. Read both complete actual reports at `worker-trust-lifecycle-complete-source-fresh/report.md` and `worker-trust-lifecycle-complete-reader-fresh/report.md`, and actual source status branches/functions. Source/Reader historical outcomes remain bound to their prior bytes, not retrospectively changed.

Edited only `docs/site/use/install.md`, `docs/site/use/worker-trust.md`, and `docs/site/use/maintenance.md`. Root owns task registry/generated inventory correction; no such file was edited by this writer. No runtime/product changes, generators, commits, dependency installation, cluster/provider/GitHub/network operations or live effects occurred.

## Changes

S1: infrastructure observation now uses actual bound Helm release inventory and Kubernetes named namespace reads before Nova/Buster/Prism installation. No temporary Prism selection change, fictitious infrastructure-only status flag, ignored error or broad failure swallowing is introduced. Expected observation names selected infrastructure and preserves failed-read stop semantics. Comprehensive `bound_deploy status` remains in first-verification capture after selected workload installation; the infrastructure step links that later step.

S3: exactly 15 `scripts/deploy.sh` links formerly pinned at `1c30980c132e3ff0b45dc8eeaf4b46a37d6d77de` now pin current complete source commit `2a8558d795054d25aa4b72dbdc296c9321ba38f6`. Valid narrow ranges remain intact. Applicable callout Revision fields identify updated deployment source while retaining unchanged test/release pins. Historical execution dates, source check limits and all other valid pins remain unchanged. Every linked source file is compared in full, not only its cited span, as contract rule 8 requires.

The signer/lifecycle/profile and earlier EOF prose remains unchanged. Maintenance's former-Qdrant section is byte identical. A reversal check proves all changes are limited to the infrastructure observation section and explicit deployment source-pin/revision-label replacements; no unrelated prose or valid source citation was changed.

## Terminal local checks

Command: `python /home/node/Documents/Codex/a98-evidence/install-status-current-pins-correction-writer/check.py`; exit 0 on its first run.

- Four exact extracted installation/source fixtures: original fresh infrastructure status with actual extracted `cmd_prism_status`/main status branch returns 1 because synthetic Prism release is absent; corrected infrastructure block returns 0 without calling Prism Helm status; corrected infrastructure block with denied synthetic Kubernetes read returns 13 and does not continue; post-install first-verification block with selected synthetic Prism releases returns 0 and calls both `helm status prism` and `helm status agent-prism`. Exact commands, call lists, synthetic shell environment, stdout/stderr and expected exits are retained. Mock shell functions prevent real cluster/Helm/Git operations. Actual status functions and selection normalizers are extracted unchanged from product source; table/header helpers are local fixtures.
- All 49 Bash fenced examples across all three pages pass `bash -n`. This is syntax only for bodies other than the named fixtures.
- All 81 product source links have existing Git objects, valid in-file ascending ranges and full pinned-file bytes equal to the current working-tree source. The complete-source SHA-256 and bytes are retained for each link. Exactly 15 affected deploy-script replacements are separately enumerated.
- All 79 local Markdown links resolve to existing files and approximate matching heading/explicit IDs. Structural check only, not actual publication renderer/route/browser proof.
- Source `scripts/deploy.sh` bytes remain unchanged. Before/after page snapshots, status, exact focused diffs and preservation result are retained. Former-Qdrant and unrelated text/citations pass byte-preservation checks.

## Limits and frozen identity

No true infrastructure release, live API or Helm inventory, workload readiness, source/receipt authority installation, lifecycle capture/reconciliation, unit production request, live trust, image pull, storage/provider effect, cleanup or operational result was performed. Existing receipt/lifecycle product limits remain explicit. The registry mapping correction and revision-separated generation belong to root. Fresh full linked-route Source, Reader and Quality reviews remain required; these writer fixtures grant no acceptance.

Frozen pages:

- install.md: 75100 bytes, SHA-256 `b05606ae8eef0344ceab47ea3055d5f3e1b0b463dcdae4984a476d2b4f0d644d`.
- worker-trust.md: 28663 bytes, SHA-256 `c42a770a6967cf44d7b1fc3c8f06c8d2e1b2bbfc29eb5ceb369569c916e57ca1`.
- maintenance.md: 76654 bytes, SHA-256 `e9086895a1369f0d5409ac2876e87fe0706c5b0eacc3a2abebacaf9259caeefa`.

Artifact manifest records every retained artifact's byte count and SHA-256, excluding itself to avoid a self-reference. Local fixtures remain synthetic evidence, never deployment or live proof.
