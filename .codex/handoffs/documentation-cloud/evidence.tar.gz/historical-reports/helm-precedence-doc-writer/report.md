# Helm precedence and change-impact author report

Role: documentation writer, not acceptance reviewer.
Repository: `/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04`.
Branch: `docs/documentation-overhaul`.
Implementation baseline and final observed HEAD: `ec2a42ed215a2fa7dbd3172ef70ef446084963a9`.
Date: 2026-10-10.
Authorized repository writes: only `docs/site/reference/configuration-precedence.md` and `docs/site/reference/configuration-change-impact.md`. No commit, generation, shared-register edit, cluster mutation, deployment, or network check was performed. Other writers' in-progress changes were left intact.

## Requirements read and preserved scope

Read the complete documentation quality standard `docs/blueprint/07-documentation-quality-standard.md`. Read the A98-10/A98-11 acceptance conditions and adjacent task boundaries in `docs/blueprint/AP09-acceptance-contract.md`, and CFG-009/013/014 entries in `docs/blueprint/generated/ap09-catalogue.json`. Read both assigned pages in full before drafting. Read the independent Source report `../helm-source-current-7c85236/report.md` and its retained collection-precedence result JSON and probe. That report is a lead, not the authority for current behavior.

All original section headings and source evidence callouts are preserved. `preservation-check.json` records that check. The original Helm change-matrix row was corrected to distinguish a changed pod template from a changed replica count. The original null-value bullet was qualified for Helm's removal request. All other pre-existing explanations and non-Helm families remain in place; no renewed correctness or acceptance claim is made for their older evidence revisions.

## Exact edited sections

`configuration-precedence.md`:

- Metadata: append current Helm source dependencies and a section-specific verified revision; retain the original cross-family verification record.
- Add `## Helm collection precedence` at line 40: define map, array, scalar; explain recursive map merge, whole-array replacement, scalar replacement, and the bounded nodeSelector null removal request.
- Add `### Check an ordered overlay without a cluster` at line 59: complete base/empty/remove YAML files, exact render commands, tools/location/input prerequisites, observations, stop rule, evidence retention and cleanup. Explain reverse order, nested map retention and repeated scalar CLI precedence from executed cases.
- Add `### Validate the complete effective collection` at line 127: Prism imagePullSecrets minItems/item contract, operators uniqueness/max100/item/conditional minItems, four image pullPolicy restrictions and a runnable expected-negative command; describe CI synthetic binding. Add checked GitOps empty-group and complete-revision guards.
- Add `### Trace the render to the actual receiver` at line 162: empty gateway URL and file-payload fallbacks, synthetic Secret selection, schema default versus actual insertion, and authored-input-to-runtime boundaries. Add current narrow pinned source/schema callout with actual executed render status and limits.
- Extend `## Absence, empty, null, and false` at line 261: distinguish runtime null admission from Helm consuming null before schema validation.

`configuration-change-impact.md`:

- Metadata: append current Helm source dependencies and a section-specific verified revision; retain old cross-family verification record.
- Update the Helm resources/probes/replicas/service-account/volumes row in `## Change matrix` (line 22) to classify the actual rendered receiver and distinguish scaling from a pod-template change.
- Add `## Helm render and runtime impact` at line 44: separate render, Kubernetes admission/reconciliation, and runtime readiness; describe concrete no-change, rollout and failure boundaries for lists/maps/null/resources/URL/files/Secret references/Prism authority.
- Add `### ConfigMap payload and persistent startup files` at line 86: source-check init's unconditional swarm-config overwrite versus conditional existing Semgrep/ESLint preservation, exact swarmConfig.overrideOnRestart→OVERRIDE_SWARM_CONFIG handoff, and limited checksum paths. Link the existing lint effective-digest/replacement instructions and canonical maintenance/rotation paths.
- Add narrow pinned source/schema callout and explicit render-only/runtime-source-reading boundary. Safe-change, rollback and existing recovery/source-check material remain byte-identical.

## Source reading and current revision

Current behavior was inspected from checked-in implementation and schemas, not field-authority prose. `source-manifest.json` retains SHA-256 and current/pinned byte agreement for thirteen source files.

Relevant source reading included:

- KubeClaw values: scheduling/environment collection defaults, persistent override default, and relevant gateway/resource fields.
- KubeClaw deployment: template/checksum declarations; URL/env/Secret handoff; extraEnv, nested resource and selector receivers; init swarm/policy copy guards, runtime copy/webhook insertion, and override environment selection. Relevant narrow regions are recorded in the published source callouts. The entire 1,664-line deployment template was not manually read for this assignment.
- KubeClaw entire configmap-swarm-config template and gateway Secret helper definitions.
- Prism image, imagePullSecrets and product-operator schema sections, including conditional enabled minimum. The entire Prism schema was not manually reviewed.
- Prism workloads template's guards, checksum paths, pull-secret and image/env receivers; the complete product-decision helper template; complete CI render-values file and related default-value region.
- Complete Control config loader; product-decision operator parsing, key load and returned authority region. Other product-decision HTTP/signing mechanisms were not reviewed.
- Complete GitOps values and applications template. GitOps/controller execution was not performed.
- Existing lint-policy deployment/persistent precedence section and maintenance render/rotation sections before linking them.

Collection terminology was coordinated with `/root/a98_helm_collection_semantics_writer`. That writer confirmed independent collection receiver authority versus structural-parent aggregation, Prism minItems1/uniqueItems/max100/enabled-minimum constraints, and the same []/{}/null vocabulary. Their generator/authority work was not edited or accepted by this author.

## Executed author checks

The `snapshot/` chart tree was extracted with `git archive ec2a42ed215a2fa7dbd3172ef70ef446084963a9 charts`. The probe imports the existing installed YAML 2.9.0 parser; no dependency install was required. Helm is `v3.22.0+g144ca65`, Node is `v24.21.0`.

`node /home/node/Documents/Codex/a98-evidence/helm-precedence-doc-writer/probe.mjs` exited zero after 24 asserted cases. `render-results.json` records every exact tokenized argv, exit status and stdout/stderr path. Ten renders exited zero and fourteen exited one as expected. Assertions check parsed receiver objects and file payloads rather than mere output presence where applicable.

Successful render assertions:

1. Base environment entry and nodeSelector.
2. Later extraEnv [] removes its entry, while nodeSelector {} retains the earlier map.
3. Later nodeSelector null removes the selector receiver, with extraEnv [] removing its entry.
4. Later populated array replaces the earlier array; map replaces/adds keys; nested CPU changes while memory remains; later scalar port wins.
5. Reversed empty/base file order restores the populated environment list.
6. CLI scalar override after files with repeated --set selects the last gateway port.
7. Synthetic existing Secret name/key selected for the gateway token, with no generated Secret.
8. Explicit-empty gateway URL fallback and three ConfigMap file payloads match checked-in files after trailing-newline normalization.
9. Prism CI baseline renders.
10. GitOps synthetic complete revision/group/destination renders, with exact selected Application revision and destination.

Expected-negative assertions:

- Empty and Always pullPolicy for each of four Prism images (eight cases).
- Empty Prism imagePullSecrets list.
- Duplicate operator list.
- 101-element operator list.
- Enabled empty operator list (other enabled settings also reject; the operators minimum is explicitly asserted).
- Empty GitOps groups.
- GitOps branch revision main.

Two initial probe harness failures are retained: the first used an incorrect container name (`openclaw` instead of actual `kubeclaw`); the second expected the literal schema keyword uniqueItems in Helm's error, but Helm reports equal item positions. Correcting the selector and error-message assertion produced the passed runs. Neither failure is hidden or treated as a product defect. Initial logs/results are saved separately. The probe was rerun after adding GitOps cases; the final count and statuses are sealed in the final result JSON.

`git diff --check -- <the two assigned pages>` passed. Original-heading/callout preservation passed. `node scripts/docs-check-refs.mjs` passed before the last link additions, and passed again afterward (3843 local links, 1751 local anchors, 6722 repository path references, 20991 pinned source links). The repository reference check validates local anchors/objects/ranges; it does not contact GitHub or render the public site. Logs are `references.log` and `references-final.log`.

Routes are already present in generated-documentation-map.json as `/reference/configuration-precedence/` and `/reference/configuration-change-impact/`; the publication script includes both pages. This is route registration inspection only. Shared metadata regeneration and publication checks belong to root after all writers finish; this author did not write generated output.

## Language method

Applied the project ASD-STE100-inspired rules by an author self-check: explicit component/actions, defined map/array/scalar terms, bounded conditions, prerequisites before commands, observed success/expected rejection separated from live results, and current English reader prose without AP/review/chat history. Technical vocabulary retained: Helm, map, array, scalar, recursive merge, pod template, ConfigMap, Secret, schema, admission, reconciliation, startup snapshot, readiness, checksum, signing authority. This is a project controlled-language author check, not formal ASD-STE100 certification or independent Reader/Quality acceptance.

## Full residual limitations and continuation

- These are documentation author changes and local author checks. No whole CFG, A98, quality gate, package or project acceptance is asserted.
- Local probes cover the named cases, not every chart field, collection, schema condition, item bound or authority profile. The generator writer's complete mechanical publication and semantic authority closure are separate work.
- Null removal is demonstrated only for the current optional KubeClaw nodeSelector ordered-file case. Other schemas may reject absent/empty/null results; no blanket null contract is claimed.
- Ordered files, populated/empty array replacement, same-type scalar override, nested map retention and repeated same-kind --set were checked. Mixed CLI option kinds and helm upgrade reuse/reset options were not checked.
- Synthetic digests, host binding, Secret reference and Git revision do not prove image availability, host preparation, Secret data, credential validity or Git-object existence.
- No API admission, Argo CD reconciliation, external chart/controller semantics, scheduling/capacity, storage attachment, pod rollout, init execution on PVCs, effective live runtime loading, readiness, business operation, rotation, migration, rollback, recovery or retirement was executed.
- Init-copy and Control-startup effects are source-established statements, not live test results. No watcher was added or inferred.
- Existing non-Helm explanations and historical test status remain preserved; this assignment does not revalidate them at ec2.
- Pinned links/line ranges and local anchors passed repository checking. Public-site build, published-route rendering, source preview, network link reachability and deployed presentation were not checked.
- No registered drift-mutation suite, global docs build or generated-freshness gate was rerun by this author. Concurrent authority/generator changes were not generated or reviewed here. Root must regenerate source dependencies/publication metadata, run applicable final gates, and retain independent Reader/Source/Quality findings with their own identities.

## Durable artifacts

- `report.md`: this author report.
- `assigned.diff`, the two copied final pages, and `preservation-check.json`: exact prose output and preservation evidence.
- `source-manifest.json`: pinned/current source agreement.
- `snapshot/charts/`: isolated pinned source chart files.
- `probe.mjs`, `probe.log`, `render-results.json`: runnable local harness, final outcome and exact commands.
- Base/empty/remove/replace/excess-operators YAML and per-case stdout/stderr: retained synthetic inputs and results.
- Initial/second harness failure logs and result JSON: honest harness setup history.
- `references.log`, `references-final.log`: actual repository reference checks.
