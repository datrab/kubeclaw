# Independent AP09.7 Source applicability review

**Mapping-only verdict: FAIL — 49 row PASS, 4 row FAIL; 632 decision PASS, 4 decision FAIL of 636.**

Reviewer identity: `/root/ap097_store_trust_corrected_full_mapping_source_fresh`. Fresh independent Source assignment; initially and throughout read-only for repository/product. No author identity or acceptance authority is inherited from previous reviewers. The previous report was read as a correction lead, then all 53 current catalogue scopes and all twelve facets were independently reassessed.

Initial HEAD `57c98bf720efde1f4694c68ab03c83da48a7588f`; final HEAD `b6e4a0d774434b8c39b2575322436e3fba708914`. The complete 53 row objects, 53 catalogue entries, quality standard, acceptance contract, catalogue authorities and acceptance fixtures are unchanged. The 66 primary authorities cited by this semantic ledger are unchanged during their snapshot interval. `freeze-result.json` records this separately from HEAD and unrelated root working-tree changes. This is a dirty-working-tree mapping review, not clean-checkout content acceptance.

The quality standard and AP09 contract were read, including the owner-approved product scope. Product-selected Kubernetes branches, supported overrides, omitted/default storage selection, DNS/CNI, actual PVC/emptyDir/data lifetime and security boundaries stay in scope. No generic unused Kubernetes encyclopedia is required. Planned-only Git mirror does not become a current store. A read-only reader, external physical owner or incomplete writer/restore implementation does not remove an existing store contribution.

All five previously corrected assignments pass this mapping reassessment: SPC-005/006/010→06 and COM-004/005→08. Added Prism job/storage/schema, Nova values/deployment and runtime-dispatch dependencies are present. That does not accept content or gate execution. The whole-set reassessment finds the additional omissions below.

The decision boundary is each actual catalogue duty, not every fact located on its canonical page. Explicit physical state, authority, recovery/replay/remaining-data or lifecycle duties contribute 06; wire persistence annotations alone do not automatically create a whole store lifecycle duty. A bounded event catalogue or sink association alone differs from the TEL-001 authority/replay architecture and TEL-007 data lifetime. Workspace permissions for a read-only Ops caller differ from Forge workspace ownership/store or Archviewer persisted design input. Local hash-chain consistency/correlation is not automatically an external identity/Secret/supply-chain boundary. Actual selected RESP credentials are within COM-007 client-path duty, just as actual selected runtime-dispatch grants/credentials are within COM-004.

A97-11 is included on all 53 rows. It preserves BOTH full duties: independent Reader diagnosis/safe recovery for EVERY dependency and separate full Source comparison of ALL applicable matrices against current authorities. This applicability review does neither full content acceptance nor Reader execution. A97-12 is included on all 53 and preserves actual discovery/red-on-undocumented-addition plus change/remove/rename under quality-standard lines 68–75. Fixed counts, linked check names, pinned references, existing baseline or manual mapping do not establish automatic drift detection. No row exclusion waives a package-level gate.

## SOURCE-STORE-TRUST-01: COM-004 / A97-06 — Retained runtime dispatch result is a store contribution

Matrix: `docs/blueprint/documentation-completion-matrix.json:3387` (assignment), `:3422` (exclusion object), `:3428` (wrongly excluded facet). Catalogue: `docs/blueprint/AP09-completeness-audit.md#L207`. Contract: `docs/blueprint/AP09-acceptance-contract.md:264`.

The catalogue explicitly includes Model-/Agent-Host, Result Import, Lost Response and Retry. The registered OpenClaw runtime.dispatch adapter calls dispatchOpenClaw; completed dispatch reads durable result content. localResult reads the workspace result and persists it under repositoryRoot before Git cleanup, or persists a collector/history result. persistResult publishes immutable same-content results with no-follow paths, fsync and collision rejection. This is within the actual result-import duty, not an incidental unrelated store on the same page.

Primary authority: skills/common/plugins/runtime-dispatch/plugin.json:21–33; src/openclaw-adapter.ts:18–22; src/openclaw.ts:279–298; src/openclaw-result.ts:63–115; src/result-persistence.ts:44–95.

Correction: Add A97-06, remove its exclusion, and scope store authority to the local/remote durable result: JSON schema, writer/readers, result-root binding, immutable collision/cleanup/lifetime boundaries, loss/corruption/recovery and explicit unsupported backup/restore/retirement. runtime-dispatch sourceDependencies already cover the primary source directory.

## SOURCE-STORE-TRUST-02: COM-005 / A97-06 — Invocation recovery uses actual persisted authority

Matrix: `docs/blueprint/documentation-completion-matrix.json:3464` (assignment), `:3499` (exclusion object), `:3505` (wrongly excluded facet). Catalogue: `docs/blueprint/AP09-completeness-audit.md#L208`. Contract: `docs/blueprint/AP09-acceptance-contract.md:264`.

The catalogue expressly includes Invocation Authority and Recovery, Context, Effect and Observer Delivery. createAdapterRuntime uses FileEffectJournal at effects.jsonl; drainObservers uses observer-checkpoints.jsonl and observer-deliveries.jsonl. Recovery rejects unresolved persisted effects and invalid/conflicting observer checkpoints/delivery transitions. This is the same checkpoint/recovery store contribution correctly assigned to TEL-005; its existence cannot be reduced to an incidental log.

Primary authority: skills/nova/core/execution/engine-runtime.ts:75–94; skills/nova/core/execution/effect-recovery.ts:14–28; skills/nova/core/effects/journal.ts:84–115; skills/nova/core/telemetry/observers.ts:43–67; skills/nova/core/telemetry/observer-recovery.ts:33–81.

Correction: Add A97-06, remove its exclusion, and cover invocation effect/event/checkpoint/delivery store authorities and recovery consistency/remaining-data boundaries. Existing skills/nova/core dependency covers the sources.

## SOURCE-STORE-TRUST-03: COM-007 / A97-08 — Selected Redis RESP path crosses a credential boundary

Matrix: `docs/blueprint/documentation-completion-matrix.json:3618` (assignment), `:3654` (exclusion object), `:3660` (wrongly excluded facet). Catalogue: `docs/blueprint/AP09-completeness-audit.md#L210`. Contract: `docs/blueprint/AP09-acceptance-contract.md:266`.

The catalogue specifies Redis URL, writer/consumer pairs, RESP boundaries, replay/migration and consumer failures. The actual selected client refuses embedded URL credentials, requires passwordSecret, resolves that Secret through secrets.read, and sends AUTH on the Redis/rediss connection. These are the concrete client trust and credential-source duties analogous to corrected COM-004 and COM-008. Communications authentication under 05 and named dependency under 02 do not replace the credential/trust contribution under 08. This does not turn every Redis stored-data row into a Secret rotation matrix: DAT-007 governs the data model, while this row explicitly governs the RESP client path.

Primary authority: skills/common/plugins/redis-transport/src/adapter.ts:23–43,62–84; skills/common/plugins/redis-transport/src/exchange.ts:7–35.

Correction: Add A97-08, remove its exclusion, and scope it to actual passwordSecret authority/resolution, Redis versus rediss transport boundary, allowed targets/grants, rotation/revocation/reconnect behavior or honest limits, and negative access. Existing redis-transport/core sourceDependencies cover the primary sources.

## SOURCE-STORE-TRUST-04: TEL-001 / A97-06 — Telemetry authority architecture includes durable sink state

Matrix: `docs/blueprint/documentation-completion-matrix.json:4801` (assignment), `:4835` (exclusion object), `:4841` (wrongly excluded facet). Catalogue: `docs/blueprint/AP09-completeness-audit.md#L225`. Contract: `docs/blueprint/AP09-acceptance-contract.md:264`.

The catalogue requires the authority boundary and the complete producer-to-schema/observer/adapter/transport/sink/query/projection/failure/replay data path. telemetry-store constructs a bounded FileDurableRecordStore, reads it for readiness, and appends keyed telemetry projections. The canonical event journal and observer recovery stores determine replay and authority; projection store does not become lifecycle authority merely because it persists. The distinction is a real store-authority/lifetime contribution, comparable to TEL-005 and TEL-006; A97-07 signal-to-storage coverage cannot silently exempt the actual persistent store from A97-06.

Primary authority: skills/common/plugins/telemetry-store/src/adapter.ts:5–41; skills/nova/core/execution/engine-runtime.ts:75–94; skills/nova/core/telemetry/observer-recovery.ts:14–30; skills/nova/core/telemetry/audit.ts:14–28.

Correction: Add A97-06, remove its exclusion, and cover canonical journal versus durable sink/projection authorities, writer/readers, bounded capacity, replay/rebuild, loss/corruption/retention/retirement and explicitly missing backup/restore. Existing telemetry/core/telemetry-store sourceDependencies cover the sources.

## Exhaustive individual expected sets

The following table is the human summary. `row-verdicts.json` contains full catalogue wording, actual sets, expected inclusion/exclusion sets, scope assessment and primary authorities for each of the 53 rows. `applicability-decisions.json` contains exactly one separately reasoned decision for each of the 636 row/facet pairs; structural assertions do not substitute for semantic source review.

| ID | Mapping verdict | Expected included facets | Expected excluded facets |
| --- | --- | --- | --- |
| SPC-004 | PASS | 05, 06, 08, 09, 11, 12 | 01, 02, 03, 04, 07, 10 |
| SPC-005 | PASS | 05, 06, 07, 08, 09, 11, 12 | 01, 02, 03, 04, 10 |
| SPC-006 | PASS | 05, 06, 07, 08, 09, 11, 12 | 01, 02, 03, 04, 10 |
| SPC-007 | PASS | 01, 05, 08, 09, 11, 12 | 02, 03, 04, 06, 07, 10 |
| SPC-009 | PASS | 01, 05, 08, 09, 11, 12 | 02, 03, 04, 06, 07, 10 |
| SPC-010 | PASS | 01, 05, 06, 08, 09, 11, 12 | 02, 03, 04, 07, 10 |
| COM-001 | PASS | 05, 08, 10, 11, 12 | 01, 02, 03, 04, 06, 07, 09 |
| COM-002 | PASS | 05, 06, 08, 10, 11, 12 | 01, 02, 03, 04, 07, 09 |
| COM-003 | PASS | 05, 06, 08, 10, 11, 12 | 01, 02, 03, 04, 07, 09 |
| COM-004 | FAIL | 05, 06, 08, 09, 11, 12 | 01, 02, 03, 04, 07, 10 |
| COM-005 | FAIL | 05, 06, 07, 08, 11, 12 | 01, 02, 03, 04, 09, 10 |
| COM-006 | PASS | 05, 08, 11, 12 | 01, 02, 03, 04, 06, 07, 09, 10 |
| COM-007 | FAIL | 02, 05, 06, 08, 10, 11, 12 | 01, 03, 04, 07, 09 |
| COM-008 | PASS | 05, 08, 11, 12 | 01, 02, 03, 04, 06, 07, 09, 10 |
| COM-009 | PASS | 02, 05, 08, 10, 11, 12 | 01, 03, 04, 06, 07, 09 |
| COM-010 | PASS | 02, 05, 06, 08, 10, 11, 12 | 01, 03, 04, 07, 09 |
| COM-011 | PASS | 05, 08, 11, 12 | 01, 02, 03, 04, 06, 07, 09, 10 |
| COM-012 | PASS | 05, 10, 11, 12 | 01, 02, 03, 04, 06, 07, 08, 09 |
| DAT-001 | PASS | 06, 08, 10, 11, 12 | 01, 02, 03, 04, 05, 07, 09 |
| DAT-002 | PASS | 06, 11, 12 | 01, 02, 03, 04, 05, 07, 08, 09, 10 |
| DAT-003 | PASS | 06, 11, 12 | 01, 02, 03, 04, 05, 07, 08, 09, 10 |
| DAT-004 | PASS | 06, 08, 11, 12 | 01, 02, 03, 04, 05, 07, 09, 10 |
| DAT-005 | PASS | 02, 06, 10, 11, 12 | 01, 03, 04, 05, 07, 08, 09 |
| DAT-006 | PASS | 02, 03, 05, 06, 08, 10, 11, 12 | 01, 04, 07, 09 |
| DAT-007 | PASS | 02, 05, 06, 10, 11, 12 | 01, 03, 04, 07, 08, 09 |
| DAT-008 | PASS | 06, 08, 11, 12 | 01, 02, 03, 04, 05, 07, 09, 10 |
| DAT-009 | PASS | 02, 06, 10, 11, 12 | 01, 03, 04, 05, 07, 08, 09 |
| TEL-001 | FAIL | 05, 06, 07, 11, 12 | 01, 02, 03, 04, 08, 09, 10 |
| TEL-002 | PASS | 05, 07, 11, 12 | 01, 02, 03, 04, 06, 08, 09, 10 |
| TEL-003 | PASS | 05, 07, 11, 12 | 01, 02, 03, 04, 06, 08, 09, 10 |
| TEL-004 | PASS | 05, 07, 08, 11, 12 | 01, 02, 03, 04, 06, 09, 10 |
| TEL-005 | PASS | 05, 06, 07, 11, 12 | 01, 02, 03, 04, 08, 09, 10 |
| TEL-006 | PASS | 06, 07, 11, 12 | 01, 02, 03, 04, 05, 08, 09, 10 |
| TEL-007 | PASS | 05, 06, 07, 11, 12 | 01, 02, 03, 04, 08, 09, 10 |
| INF-001 | PASS | 01, 11, 12 | 02, 03, 04, 05, 06, 07, 08, 09, 10 |
| INF-002 | PASS | 01, 05, 06, 11, 12 | 02, 03, 04, 07, 08, 09, 10 |
| INF-003 | PASS | 01, 04, 05, 08, 11, 12 | 02, 03, 06, 07, 09, 10 |
| INF-004 | PASS | 01, 04, 05, 08, 11, 12 | 02, 03, 06, 07, 09, 10 |
| INF-005 | PASS | 01, 02, 05, 06, 08, 10, 11, 12 | 03, 04, 07, 09 |
| INF-006 | PASS | 01, 02, 05, 06, 08, 10, 11, 12 | 03, 04, 07, 09 |
| INF-007 | PASS | 01, 02, 05, 06, 08, 10, 11, 12 | 03, 04, 07, 09 |
| INF-008 | PASS | 01, 02, 05, 08, 10, 11, 12 | 03, 04, 06, 07, 09 |
| INF-009 | PASS | 01, 02, 05, 06, 08, 10, 11, 12 | 03, 04, 07, 09 |
| INF-010 | PASS | 01, 04, 05, 06, 07, 08, 11, 12 | 02, 03, 09, 10 |
| INF-011 | PASS | 01, 05, 08, 09, 11, 12 | 02, 03, 04, 06, 07, 10 |
| INF-012 | PASS | 01, 03, 05, 06, 08, 10, 11, 12 | 02, 04, 07, 09 |
| SEC-001 | PASS | 08, 11, 12 | 01, 02, 03, 04, 05, 06, 07, 09, 10 |
| SEC-002 | PASS | 05, 08, 11, 12 | 01, 02, 03, 04, 06, 07, 09, 10 |
| SEC-003 | PASS | 05, 08, 11, 12 | 01, 02, 03, 04, 06, 07, 09, 10 |
| SEC-004 | PASS | 05, 08, 11, 12 | 01, 02, 03, 04, 06, 07, 09, 10 |
| SEC-005 | PASS | 04, 05, 08, 11, 12 | 01, 02, 03, 06, 07, 09, 10 |
| SEC-006 | PASS | 02, 05, 08, 11, 12 | 01, 03, 04, 06, 07, 09, 10 |
| SEC-007 | PASS | 08, 11, 12 | 01, 02, 03, 04, 05, 06, 07, 09, 10 |

## Actual checks and limits

Performed: read the quality standard, acceptance contract, all 53 AP09.7 catalogue entries and their complete mapping records; inspect current primary implementation/configuration/schema/protocol/recovery authorities for scoped duties; evaluate all twelve inclusions/exclusions per row; assert 53 unique row results and 636 unique decision pairs; resolve each cited narrow line interval; compare complete before/after row and catalogue projection, contract hashes and all 66 cited primary hashes. These read-only JSON/hash/line assertions pass. They check structure/freeze, not product behavior or semantic truth by themselves. Evidence helper files only write in this external evidence directory. No repository file, tests, shared generated output, product state, deployment or commit was written by this reviewer.

Not performed: product tests, generator/checker runs, required mutation executions, live/deployment/enforcement tests, clean-checkout execution, independent Reader diagnosis/recovery exercises, full semantic content acceptance of every page/matrix cell, controlled-language or publication/build/route checks, A97 gate/package/global acceptance. All remain pending. No `PASS` here may be recorded as A97-11 full Source/Reader completion or A97-12 mutation proof.

A few exploratory reads used guessed nonexistent paths or overly broad output and were followed by actual discovered paths/focused excerpts. The evidence assembly initially rejected one uncaptured Docker authority and two overlong cited ranges; Docker was then bound to the initial HEAD blob matching inspected bytes, and ranges were corrected to actual file bounds. The final structural/freeze assertions pass. The 1,350-file discovery hash snapshot is not a claim that all those files were read: only the 66 cited authorities form the final needed-authority subset. Its initial hashes were taken after the first focused source reads, so source freeze equality is bounded to that snapshot interval; the row/catalogue/contracts freeze preceded semantic inspection.

Correct the four omitted contributions and their rationale/exclusions, then obtain a new fresh independent full applicability reassessment. This reviewer supplies no author self-acceptance, content approval or package completion claim.
