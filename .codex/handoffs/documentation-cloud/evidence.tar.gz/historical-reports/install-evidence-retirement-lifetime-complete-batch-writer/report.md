# Author correction report

Author: /root/install_evidence_retirement_lifetime_complete_batch_writer. Repository HEAD during final checks: `7647f941d5f6974d937112f309dcdc390d400636`. Exactly two permitted authored pages changed by this author: install.md and maintenance.md. Other dirty files belong to the concurrent root task; no clean-checkout or global acceptance claim is made. No commit or push performed.

Complete assigned pages, quality standard, relevant acceptance contract/fixtures/catalogue/execution requirements, full corrected Source report and full corrected Reader report/fixtures were inspected. Explicit root candidate release preceded edits.

Source F1 / Reader R1: generic retirement now requires platform/storage-owner enforcement for the entire deletion window: namespace recreation, PVC/PV replacement, new claims/provisioning/rebinding, competing administrators/controllers/reconcilers. Original/current namespace/PVC/PV UIDs, bindings, reclaim policy, provider assets and independent data/backup disposition are mandatory. Non-atomic prechecks and name-only re-enumeration/deletion are explicit. Unknown exclusion or identities stop broad teardown and require separately owned exact identity-safe removal. Exclusion remains through final independent verification. All five separately applied recovery-resource decisions, owner commands/read-back, final independent export/integrity/restore and authority/secrets stops remain present.

Reader R2: each snapshot/events/log observation writes a new immutable private attempt with complete output, stderr, actual exit, command, UTC time and decision reason before latest working files change. Whole captures retain their complete or early failed output/status/stderr and working evidence in distinct directories. Guarded recovery and cleanup captures use this same path; PV polling is journaled. Creating namespace UID is never adopted from later observations. Unavailable logs have an explicit status and old logs remain in attempt history. Interrupted or locally incomplete artifacts must be retained and cleanup stops for owner reconciliation.

Local checks: all 41 Bash fences across the two pages pass bash -n. Exact extracted helper synthetic cases pass denied read→success with original output/status/stderr retained, early partial capture, events/log failures and recovery, cleanup/no-log recapture, namespace replacement refusal, repeated PV observation, and local working-copy failure→guarded recovery. Name-only exact product helper synthetic witness reproduces selection of an unapproved new claim; no deletion ran. All 64 two-page product links have valid narrow ranges and pinned complete files equal current complete source files. All 74 local Markdown routes resolve. All 131 table rows retain physical row structure. Task generation --check and task registry validation pass (13 tasks, 14 lifecycle capabilities); diff --check passes. This is author validation, not independent Source/Reader acceptance or live proof.

Not run: cluster reads/writes, installation, trust, key provisioning, real backup/restore, teardown, provider disposal, workflow dispatch, publication/browser rendering, whole docs gates or global acceptance. Fresh independent review remains root-owned. No remaining known author-scope documentation finding; independent reviewers must determine acceptance.

Final page SHA-256:

- `docs/site/use/install.md`: `0a490aa283da337b1e1ee5acca34e746a427408e14a3b41e794b1905929ccafb`
- `docs/site/use/maintenance.md`: `de3b211e41170772178c95c187d778a2af70bea40bca75248e7fb89efa75a945`
