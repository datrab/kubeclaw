# Cluster configuration receiver writer report

Scope: two new documentation automation files only. No product, deployment, common metadata/envelope, discovery, API generator, matrix, commit or push changes.

Read authority: complete documentation quality standard including approved product-scope-and-upstream-references; AP09 A98-10/A98-11 acceptance and configuration fixtures; CFG-009 current incomplete requirement. This report does not close those requirements.

Implemented: 53 source-bound receiver records for ClusterRole, ClusterRoleBinding, IngressClass and CustomResourceDefinition registration. Factory joins exact selected paths (including concrete list indices), delegates shared root metadata/apiVersion/kind and fails unknown selected fields. Ordinary complete typed object semantics are explicitly separate from apply/merge-patch resulting-state construction.

Selected field coverage: 53 produced contexts from the discovery writer's private real rendered field selection; 731 selected body-field joins, zero missing selected contracts. The 53 contexts consist of 22 ClusterRole, 11 ClusterRoleBinding, 2 IngressClass and 18 CRD objects. Producer provenance and selection are retained privately. These numbers do not imply complete profile discovery or semantic API acceptance.

Registration boundary: selected CRD group/names/scope/version name/served/storage, schema registration, status marker and printer-column fields; relevant omitted conversion None and whole-object preserveUnknownFields false. The schema.openAPIV3Schema record deliberately hands the recursive foreign JSONSchemaProps language to pinned upstream authority. Unknown descendants still fail this factory: discovery must explicitly hand off that subtree. Buster's own served instance schema remains independently recursively maintained; the foreign registration boundary does not waive its fields.

Source authority: fresh original bytes from Kubernetes commit 66452049f3d692768c39c797b21b793dce80314e, with retrieval URLs, SHA256, byte counts and private seals. Originals cover typed definitions/defaulting, exact validators/strategies, RBAC escalation/bind/subject matching, naming acceptance, establishment, API serving and deletion finalization. Source range checks pass after correcting two inherited range assumptions against fresh bytes. Bounds alone are not semantic acceptance.

Pinned Tailscale chart SHA256 c2440014df04fdf1b67b53daa4290d7b878584cf4702f9b1b50f51ba64499a6a was verified before reading its original IngressClass template. v1.102.3 annotated tag 9329c3677031109ff6d0b80abee0cddc8f35ff6f resolves to 53a0d659afa51835dd7a9283873cca44261454f8. Original ingress.go and operator.go are retained. This is not a reproducible image provenance proof. The consumer requires explicit class selection and checks controller tailscale.com/ts-ingress; its class-validation error is logged as a warning and provisioning continues. A missing/wrong class or default-class annotation is therefore not falsely documented as terminal admission rejection.

Concrete effects preserved: ClusterRole stores candidate permissions but requires a binding/configured authorizer; policy syntax does not verify resource existence and storage separately checks escalation. ClusterRoleBinding ServiceAccount namespace is required and does not inherit the namespaced-binding fallback; roleRef is ClusterRole-only and immutable. IngressClass controller is immutable. CRD scope/kind become immutable after Established; group/plural are always immutable. Exactly one storage flag, served-vs-storage independence and historical stored-version migration are explicit. status:{} enables the status endpoint, while null/omission does not; enabling does not grant status RBAC. CRD creation and schema registration do not prove controller readiness, live discovery or successful instance writes. CRD deletion can delete instances and is not a harmless schema retry.

Terminal checks:

- PASS: node --test scripts/tests/cluster-configuration-receiver.test.mjs (6/6). Tests check exact-path joins, root delegation, newly selected field rejection, foreign subtree rejection, cluster-vs-namespaced binding semantics, schema/empty/null/served/storage/migration boundaries and truthful consumer limits. They test contract automation and regression expectations, not Kubernetes execution.
- PASS: node --check scripts/docs-kubernetes-cluster-configuration-receiver-contracts.mjs.
- PASS: git diff --check restricted to the two new files.
- PASS: private selected-join and primary-source-bounds check (731 joins; no out-of-range authority).
- FAILED TOOLING: npx eslint on the two files exits 2 because this repository has no eslint.config.* for installed ESLint 10.7.0. No lint PASS is claimed.
- NOT RUN: live API/admission/authorization/persistence/controller tests, upstream executable validation tests, full inventory generation/publication and independent review.

Remaining integration: root must wire the factory into current product-scope selection and generated references, retain registration handoff/digest tracking, and run observed generation/drift checks and independent semantic/depth review. Global production discovery remains failed on the authentic invalid Buster example reported by the discovery writer; no runtime correction or silent suppression was attempted here. A98-10, A98-11 and CFG-009 remain globally incomplete until root integration and acceptance. Fresh source reading is source qualification, not a substitute for those checks.
