# Independent Source review: issuer, approval, platform, and Prism

Reviewed revision: `7e413cf63e82fdc6104184a6be25f35420b15d80`.
Reviewer: `/root/a98_issuer_approval_source_resumed_fresh`, Source role only.
Date: 2026-10-10. Final Source verdict for the combined assigned scope: **FAIL**.

The reviewer began read-only, read the complete three authored pages independently, and read the documentation quality standard, acceptance contract, applicable catalogue records and fixtures. Previous reviewer reports were not used to determine the verdict. A new `git archive` supplied the private source tree; the interrupted reviewer's private archive was not reused. No main repository file was edited, committed, pushed, deployed, or mutated. This report grants no Reader, Quality, publication, live, package-wide, or global AP09 acceptance.

## Page decisions and one required correction

| Frozen authored page | Source verdict | Result |
| --- | --- | --- |
| `docs/site/reference/pipeline-platform.md` | PASS | Complete authored page checked against schema, consumers, discovery, activation, grants, snapshots, TTL, timers, issuer policies and replay. No material source discrepancy found. |
| `docs/site/reference/glossary.md` | PASS | Complete glossary checked within this Source assignment. Approval/publication/resume, SVID/application permission, HMAC/nonce, CSRF, job fence and ARIA definitions agree with their owning sources and express their evidence limits. |
| `docs/site/use/prism-studio.md` | FAIL | One source overstatement about visible corpus references remains. All other reviewed mechanisms and stated product limitations agree with inspected sources in this review. |

**Finding S-01 — visible reference evidence is overstated.** Prism Step 3, page line 870, says: “It shows the direction title, summary, trade-offs, and approved-corpus references.” The UI renders title, summary, trade-offs, and the **number** of approved corpus references. It renders neither their IDs nor their summaries. `skills/prism/studio/app.tsx:615–620` contains the direction card; the only references rendering in the complete file is the count at line 620. The `StudioDirection` type can carry reference IDs/summaries, but the view does not display them. A designer following this instruction cannot inspect the promised reference evidence in the card. Change the sentence to describe the count and explicitly state that individual references are not displayed. No product change is required. Recheck this affected sentence and its nearby source evidence after correction.

Source: [actual direction card](https://github.com/datrab/kubeclaw/blob/7e413cf63e82fdc6104184a6be25f35420b15d80/skills/prism/studio/app.tsx#L615-L620).

## Catalogue findings, separately scoped

| ID | Assigned Source verdict | Whole-ID status | Evidence and boundary |
| --- | --- | --- | --- |
| CFG-002 | PASS | PASS for assigned authored reference Source review | The actual closed platform schema and consumers were read, not inferred from an inventory count. Paths, nested trust maps, open registration configurations and grant envelopes, missing/default/empty values, activation and errors are explained. Deployment readiness is not claimed. |
| CFG-013 | PASS | UNPROVEN outside assigned pages | Platform no-merge/exact-key authority, canonical-file-relative paths, retained runtime subset, Prism chart/release/private overlay/script overrides, Secret references and separate model routes agree with source. The complete canonical `configuration-precedence.md` and all configuration families were not assigned for acceptance. |
| CFG-014 | PASS | UNPROVEN outside assigned pages | Captured runtime values, coordinator TTL, timer limit, storage-root redirection, new-run authority changes, issuer replay and startup/rollout behavior agree with source. The complete canonical `configuration-change-impact.md`, migration/upgrade and other families were not assigned for acceptance. |
| OPR-010 | FAIL | FAIL | Complete authored journey and failure/abort/resume/cleanup limits were reviewed. Finding S-01 prevents Source acceptance of the page. No successful live Studio-to-Nova journey is asserted or proved. |

## Full-page source coverage

Platform: all 15 top-level fields, their required/optional status and closed root; installation/trusted-root array members; both external trust map shapes and their member constraints; provider selections; every dynamic grant/configuration envelope; active-adapter and issuer array members; isolation/cgroup root; storage; timeout and TTL. The frozen generated schema inventory actually contains **33 paths**, including root, array and dynamic-map shapes, preserved in `platform-field-scope.json`. The assignment's “28 fields” was not used as a fixed completeness target or as a reason to omit fields.

The source confirms exact `local:<real package directory>` lookup, sorted path/length/content package digest framing, symlink rejection, built-in trust before both external maps, admission versus execution, unavailable persistent external adapters, bounded external stage/observer wrappers and invocation-time cgroup requirements. All provider map entries are validated; only required providers enable adapters recursively. Enabled registration configuration is validated without inserting defaults, while disabled adapter configuration can remain unchecked. Grants reject missing, unrequested and disabled-registration entries and enforce the capability's closed constraints. Snapshots retain the authored providers/grants/adapters/activeAdapters/observers/isolation subset, separately from effective selected providers; recovery compares that subset and package/graph identities. Timeout, TTL, storage and issuer fields are absent from that configuration subset. Raw configured values are serialized without a redaction layer.

Issuer addition: `engine-admin.ts` compares a recorded decision found by decision ID **or** idempotency key using canonical JSON. Changed content throws `ADMIN_REOPEN_IDEMPOTENCY_CONFLICT`. An exact recorded decision returns from `#authorize` before the authentication callback and current issuer allowlist. Preparation, package/configuration comparison, graph and applicable state checks still execute. Some new-decision-only state restrictions deliberately do not run on a recorded replay; the prose does not claim that replay runs every new-decision check. Removing an issuer does not revoke the recorded replay path. New decisions require callback principal equality and current allowlist membership. Governed wait reconstruction receives the supplied orchestrator issuer. `validateSignal` checks typed envelope, wait/type/issuer match, expiry and issue-time lower bound. Caller-supplied unsigned issuer fields are not authentication. This was also checked through a bounded direct-function probe; full persisted replay remains unproved here because of GNU-flock incompatibility.

Prism: complete deployment prerequisites and release admission; service and agent precedence; conditional runtime settings; Secret creation/rotation distinction; exact SPIFFE mode and peer guards for job claim/status/finish and direction/revision commit; separate Gateway, managed OpenAI OAuth/Codex reasoning and LiteLLM memory-search embeddings; external route ownership and bounded functional proof; deterministic native worker versus managed agent; durable jobs, fence, session serialization and NeedsNova; all eleven journey steps; current client key lifetimes and error-screen limits; child round supersession; typed operation CAS; non-idempotent restore and preference retraction; preview assets/flows/ARIA; evaluation gates; two separate approval/publication writes; original baseline receipt replay; duplicate approval digest; archive assembly and Nova verification/import; interrupted/failed/stale/uncertain outcomes; native/nonce worker diagnostics; migration/artifact boundaries; explicit abort/removal limits; fixed browser path and aggregate stop order; focused check definitions; current capability table; developer routing and final journey evidence checklist.

The reviewed source supports these key distinctions: service readiness is not agent permission or provider completion; embeddings are not directions/revisions; approval alone is not publication; publication is not a Nova signal; signal issuer matching is not human authentication; an old baseline receipt does not renew changed architecture authority; server/helper replay is not automatically an available Studio recovery action. Missing release selection, managed browser path, live identity/provider evidence and native/manual recovery surfaces remain honestly documented product limits.

Metadata and pins: every one of the **264 pinned source links** resolves to a Git blob and an in-bounds line range. Each entire referenced file is byte-identical at its published pin and the reviewed revision; `source-link-audit.json` records both digests. This is stronger than merely finding the same excerpt. The linked Prism implementation also has no changes between historical execution revision `082db288f7bc5e686e47306d60cf4db7d8ba8cfc` and this revision in the inspected Prism/deploy/chart/spike paths. This confirms source continuity, not the independent truth of a historical execution report. Historical runs retain their historical revisions; this review supplies its own distinct current test results.

## Applicable A98 contributions

These are Source-only findings on the assigned pages. `UNPROVEN` means the complete gate requires unassigned material or a different evidence role/class; it is not a contractual PASS-with-reservations or an N/A exemption.

| Gate | Assigned contribution | Complete gate | Reason |
| --- | --- | --- | --- |
| A98-01 | UNPROVEN | UNPROVEN | Prism has one canonical operator-task marker; complete task-inventory ownership was not assigned. |
| A98-02 | PASS | UNPROVEN | Assigned executable paths and unavailable paths name conditions, authority, stop/recovery/evidence boundaries; all operator procedures remain outside this review. |
| A98-03 | PASS | UNPROVEN | Prism stops before deployment without selected release, native/trust/Secret prerequisites; no live installation proof. |
| A98-04 | PASS | UNPROVEN | Source separates health/bootstrap/HMAC-ready/SPIFFE-ready/Control/DB from functional completion. One chart test failed before assertions; no live readiness evidence. |
| A98-05 | PASS | UNPROVEN | Assigned issuer, unsigned signal, canonical decision replay, wait and uncertain resume claims are source-correct. Full lifecycle/cancellation/restart executions are not proved. |
| A98-06 | PASS | UNPROVEN | Assigned diagnostic/recovery boundaries distinguish trust, routes, client retention, worker ownership and nonce database; no full dependency failure matrix. |
| A98-07 | UNPROVEN | UNPROVEN | Prism routes to canonical recovery and states matched data/artifact limitations; full backup/restore procedure is outside scope. |
| A98-08 | UNPROVEN | UNPROVEN | Assigned text correctly denies database rollback from Helm rollback; full version/upgrade procedure is outside scope. |
| A98-09 | UNPROVEN | UNPROVEN | Assigned text preserves authoritative data and routes to decommission; complete retirement procedure is outside scope. |
| A98-10 | PASS | UNPROVEN | Full actual platform schema shape and assigned Prism configuration consumers checked; complete cross-family recursive inventory not accepted here. |
| A98-11 | PASS | UNPROVEN | Assigned precedence, omitted/empty/invalid values, capture and snapshot conditions checked; all-family runtime/conflict tests not proved. |
| A98-12 | FAIL | FAIL contribution | Journey evidence is honestly bounded, but S-01 overstates visible reference evidence. Demo page and live scenario unassigned/unexecuted. |
| A98-13 | FAIL | FAIL contribution | S-01 promises a display unavailable to a fresh operator. This is a Source finding; no Clean-Reader acceptance. |
| A98-14 | UNPROVEN | UNPROVEN | No duplicate full mutation package was run, as instructed. |

## Current execution results and actual endings

Environment: Linux `6.8.0-139-generic`, Node `v24.21.0`, npm `11.19.0`, Helm installed at `/usr/local/bin/helm`, BusyBox `1.37.0`. `/usr/bin/flock` is a BusyBox symlink. Runtime environment-status tool was unavailable in this agent's tool list. No network, credential discovery, provider call or live deployment was performed. The root workspace is concurrently dirty in generated/reference files; it was not represented as clean. The own archive has **5,522 tracked blobs**, all matching immutable Git bytes after checks, zero missing/changed tracked files. All three assigned main authored pages still matched the archive at final verification.

Exact argv, working directory, exit and duration are retained in `test-executions.json`; each run has its own stdout/stderr artifacts.

| Actual invocation | End status and observation |
| --- | --- |
| `npm ci --offline --ignore-scripts --no-audit --no-fund --include=dev` | Exit 0; own root dependencies installed, no main dependency changes. |
| Platform configuration contract | Exit 0, `ok:true`. |
| Registry contract | Exit 0, `ok:true`. |
| Capability-security contract | Exit 1 at fixed `28 !== 24` assertion, before its later semantic checks. This is not a successful grant-security suite. |
| Resume contract | Exit 1 at `FILE_MUTEX_ACQUIRE_FAILED`; BusyBox rejects GNU `--timeout`. Persisted resume assertions not reached. |
| Phase6/admin contract | Exit 1 at the same actual file-mutex boundary. Administrative replay execution not proved. No shim/patch substituted GNU behavior. |
| Initial grouped seven Prism suites | Timeout at reviewer limit 25 seconds; incomplete grouped result is UNPROVEN, not PASS. Subsequent independent reruns below have complete endings. |
| Control configuration | Exit 0; 3 tests passed. |
| Control decisions | Exit 0; 5 tests passed. |
| Design-round client | Exit 0; 2 tests passed. |
| Agent-revision client | Exit 0; 1 test passed. |
| Domain/storage | Exit 0; 1 test passed. |
| Worker readiness | Exit 0; 1 connection-refusal test passed, 1 native PostgreSQL test explicitly skipped for absent isolated migrated database. |
| Worker readiness chart | Exit 1; Helm rejects unbound native node/namespace/policy before probe assertions. The test omits `--namespace default` used by the maintained Helm gate. No successful render implied. |
| `npm run verify:prism:deploy-script` | Exit 0; workflow YAML, deploy-command contract and Bash syntax passed. |
| Runtime release check | Exit 1; `ENOENT releases/runtime-images.json`. Deployment remains unavailable. |
| Prism Nova-stage contract | Exit 0, `ok:true`; local stage fixture, not live handoff. |
| SPIFFE parser/allowlist contract | Exit 0, `ok:true`; no running proxy/identity proof. |
| Own `review-probes.mjs` | Exit 0; authored minimal JSON, canonical symlink base, deep freezing, optional/empty fields, timer-overflow schema acceptance, canonical JSON ordering, unsigned signal matching and wrong-issuer/wait/expiry rejection checked directly. No persisted run/replay or authentication exercised. |

The fixed spike Chromium executable is absent. No browser shim, alternate-build symlink, config edit, browser download, spike verifier, aggregate Prism gate, native worker acceptance, remote embedding/reasoning, cluster journey or live restore was run. No result is extrapolated to these evidence classes. The root separately reports publication controlled-language failures; that publication/style result is distinct from this Source review and is not inherited as this review's verdict.

## Explicit page release

The complete assigned Source review is terminal and its evidence is durable. **All three assigned authored pages are released for lead edits now:** `pipeline-platform.md`, `glossary.md`, and `prism-studio.md`. This releases the edit freeze only. The first two have Source PASS at the frozen revision; Prism has Source FAIL until S-01 is corrected and freshly checked. Subsequent edits require the appropriate new affected-source and independent role reviews. No final package or global acceptance is granted.
