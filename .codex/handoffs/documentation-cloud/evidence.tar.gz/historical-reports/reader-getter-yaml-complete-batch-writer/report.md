# Reader, annotation-getter and wrapped YAML custody correction

Status: complete superseding frozen author candidate; current27-decision receiving and complete63 source tests are observed terminal0. The fdbcb4 candidate is withdrawn. This is correction-author evidence, not independent Source, Reader, Quality, catalogue, package or global approval.

## Problem and ownership

The complete fresh independent report `canonical-entry-reflection-complete-tool-source-fresh/report.md`, SHA256 `73bcb8949a2fcf2c0bfb24338f7d0e025cd16d1318ad13e8b058f3c0c8eb690d`, found five material Source defects. This writer owns S1/S2/S3 only: Python reader/mapping protocols, known annotation-getter custody and executable YAML env-to-shell acquisition. The API author owns S4/S5 and its six files. The full old FAIL remains tied to its old candidate; no old verdict is retroactively changed.

Before editing, the supplied scanner5797 and testf654 freezes were verified. Only `scripts/docs-configuration-inventory.mjs` and `scripts/tests/python-environment-discovery.test.mjs` were edited. Product/runtime/chart source bytes, API files/registry, rendered outputs and unrelated changes were preserved. Charts and bootstrap are modified only in full private receiving copies. No shared whole277 suite, generator, host install, commit, push or target deployment execution occurred.

The full quality07, AP09 acceptance contract and fixtures, relevant catalogue records and gate requirements were read. CFG010/011/013/015/018, REF003/012, A98-10/11/14 and A911-01/02 remain individual Source facets for fresh independent review, not approvals granted by this report.

## Coherent finite correction

S1: `role` retains a known reader’s `__call__`, and known environment `__getitem__`/`setdefault` as reader operations. Finite aliases retain the same roles, keys and actual AST positions. Known user-function/method `__call__` retains its existing callable identity and owning namespace, preserving actual timing before rebinding. Other recognizable environment mapping protocols reject explicitly. General unsupported dunder/namespace acquisition from recognized capability receivers rejects, including getenv `__globals__`; safe scalar `__name__`/`__qualname__`/`__module__`/`__doc__` metadata stays passive. Ordinary foreign objects remain ordinary.

S2: `annotation-reader` is included in the existing transferred-capability and callable-capability predicates. Known getter `__call__` uses the existing direct annotation evaluator, with its exact singleton target exception and namespace/format constraints. Function/class/method evaluated-string annotations reject without evaluating arbitrary strings. Bound reflection, passed/returned/default/container-held getters retain authority or reject at their actual Source boundary. Future function annotations keep their existing finite evaluator; recognizable environment-bearing future class eval_str access is conservatively rejected, preventing an absent deferred-class record from erasing a read. Passive strings and eval_str=False behavior remain unchanged. This does not introduce a Python/string interpreter.

S3: executable YAML applies the already selected finite env/sudo wrapper index to the shell branch. It acquires the actual leading shell `-c` body after admitted simple flags and maps its decoded positions back to original YAML. Shell script operands and later `-c` data stay passive, as do Python module/script operands and descriptive maps. Unknown shell option custody rejects explicitly. The actual command/args ancestry, finite Python argv mode, quoted token handling and stdin custody are retained.

`source-diff.patch` contains the first S1/S2/S3 delta against the prior5797 scanner; `kwargs-source-diff.patch` adds the final bounded missing-key guard. Existing exact subprocess/annotationlib receiver and container diagnostics keep precedence. The earlier helper-argument negative still rejects at that argument boundary before a later unresolved callable alternative. Unknown authority is never made singleton or waived.

## Frozen owning pair

`freeze.json` retains actual shared HEAD/time and owning source snapshots. This is working-tree evidence, not a clean-commit claim.

- Scanner SHA256 `2cfe1e665005be4f4ad0ebb651a2f13409ca4f0d62a52c6a57aeb334d520f969`, 871086 bytes.
- Python tests SHA256 `2484bc3005ab984fa78e80f1a3d035d310b2ee9b3d3c569fbd2eb629d8236092`, 97206 bytes.

## Observed source-only and native proof

Superseding final owning-suite handle80801 was polled to terminal exit0:63/63, zero failure/skip. All prior59 test bytes remain an unchanged prefix. The four new tests cover every S1/S2/S3 report counterexample plus finite aliases, known function/method timing, a container-held getter and a future-class edge; foreign/pure/passive/direct getters, safe metadata, exact namespace/source positions and script/module operand sensitivity are preserved.

`native-results-superseding.json` retains26 current new native observations from the final63 log:22 Python protocol/getter/kwargs cases and4 finite YAML wrapper argv cases. Python witnesses instrument the real environment mapping and record the configured key; they preserve the real getenv.__globals__ namespace instead of substituting a different getter. YAML witnesses execute only synthetic env/sh/Python argv and print the configured value. `full-native-results-superseding.json` retains all125 current owning-unit native observations, including earlier individual value/fallback/acquisition/error distinctions. Discovery never executes inspected product programs.

Preliminary targeted handle95536 exited0 with3 tests. Initial complete-suite handle95016 exited1:61 pass and one prior negative reason-precedence mismatch. The new getter role caused an earlier unresolved-callable rejection; argument-custody diagnostic precedence was restored without weakening the final unknown-authority rejection. `python-tests-initial-failure.log` and `test-receipts.json` preserve this actual failed run. The final62 and superseding63 suites re-executed the first23 native payloads; their rows exactly equal the preliminary targeted native rows. No failure was relabelled PASS or inferred complete from an intended run.

## Coordinated receiving proof

The superseding API author semantically rebound the Source and independent anchor after reading the final missing-key guard/native63 evidence. Current8 source hashes are retained in `coordinated-api-freeze.json`. The original38 historical decisions cover19 Python actual-reader mutations,4 actual readiness-command YAML mutations,3 unsupported acquisition/helper mutations, direct sensitivity, the old dictionary correction,6 foreign/passive/known-getter/snapshot/argv positive controls, and4 complete baseline/restoration gates.

The full private-copy harness checks exact coordinated source hashes, mutates/restores one actual receiver per case and runs only `node scripts/docs-configuration-inventory.mjs --check-environment-coverage-only`. Python cases append to complete `ops/pod/bootstrap.py`. YAML cases replace exactly the actual Codex readiness command in complete `charts/ops-pod/templates/workload.yaml`, with its remaining mount/caller/body context intact. Every negative requires nonzero exit, intended reason/key and real source identity; every positive requires exact436. Baseline failure stops a partition. All live/terminal handles and atomic receipts will be retained; source equality is required after completion.

## Limits and exact reuse

Finite known protocols are supported, while unsupported recognizable mapping/dunder/helper/future-class evaluation paths reject. This deliberately conservative boundary does not certify arbitrary reflection, arbitrary dynamic Python, external helper implementation or every shell option. No path exemption, exact witness-literal patch or blanket unknown-syntax waiver was added.

`prior-input-comparison.json` records exact relevant prior input equality, the unchanged59 test prefix and actual source delta. Earlier native tool facts and narrow unchanged bodies may be reused only with equal inputs and identical artifacts. Old receiving23/113, Root277 and independent PASS rows retain their original scope; none approves this changed candidate. Thousands of unchanged fixtures were not rerun as a proxy for this batch’s new receiving proof.

The final input/artifact manifests and superseding after-freeze receipt are sealed after observed receiving completion. Independent full ToolSource requalification, the API S4/S5 verdict, Root integration/whole suite, generation, rendered page qualification, Reader/Quality and package/global acceptance remain open. No product live result is claimed.

## Withdrawn fdbcb4 proof and final argument-custody correction

The original38 process87021 completed terminal0 at2026-10-12T10:06:40.850896+00:00, all expected outcomes. Two extra future imports had been appended after bootstrap statements: their receipts are parse-only and explicitly excluded from executable semantic receiving proof. `receiving-evidence-classification.json` retains the original36 valid decisions, both illegal-placement full sources/hashes and compile-only failures. Root authorized only two valid-placement supplements; process95036 completed terminal0 with both. Each complete mutated bootstrap compiles legally with its future import first; full source/hash and separate actual synthetic native binding are retained. No inspected product program executed.

Before final seal, an additional same-family real reader gap was found: `os.getenv.__call__(**{'key':'KNOWN_KW_PROTOCOL'})` produced scanner[] but native0/observed on fdbcb4. `known-reader-kwargs-witness.json` preserves this counterevidence. The candidate was withdrawn; `historical-withdrawn-fdbcb4/` preserves every prior frozen/proof artifact before generic paths were updated. The completed Root284 was Root execution only on that old candidate and does not qualify the new source.

The final bounded guard rejects a recognized reader when no explicit positional key or named key keyword is acquired. It does not interpret kwargs dictionaries. Explicit named keys remain supported and foreign kwargs callbacks remain passive. Three new native witnesses prove actual reads for getter protocol kwargs, environment setdefault kwargs and a direct finite reader alias. The new63 suite includes them and all prior62 bytes unchanged. `kwargs-source-diff.patch` records the exact additional argument guard; `kwargs-native-results.json` records the actual payloads. A native test setup initially used the wrong setdefault keyword, default instead of its actual value parameter; its terminal1 log is preserved and the witness was corrected after inspecting the real signature. The final63/125 observations are actually re-executed current evidence.

The superseding27-decision receiving plan replays all required S1/S2/S3 report counterexamples, current kwargs3 and legal future2, direct/old sensitivity, foreign/passive/known-getter/snapshot positives and complete baselines/restorations. Earlier38/future2 stay historical and are not current approval. Sources remain frozen through coherent rebind and observed current receiving; original current handle67902/PID333637 was observed terminal0 at2026-10-12T10:31:57.067866+00:00; all27 decisions pass:7 positive (including4complete/restored436) and20 Source-identity negatives. Atomic actual-output progress and the full terminal aggregate are retained. All21 complete Python mutations compile legally before receiving and their full Source/hash artifacts are retained.

All eight current source byte sequences equal their frozen snapshots after final commands. `after-freeze.json` records this equality and actual terminal outcomes. No further source edits or global tests were made by this writer. Every retained regular artifact is indexed in `manifest.json`, excluding itself, with its separately delivered digest. Current whole-corpus input hashes are final observations excluding Git/dependency directories and symlinks; they are not retroactive claims about every historical starting byte.
