# Independent Source review: FAIL — two material current qualification gaps

Scope: current documentation helper qualification, capability admission/custody, finite module graph and cache, compiled semantic authority and actual callers, and preservation of public discovery/PV patch. This is Source evidence only. It grants no package/global/Reader/Quality/Astra acceptance and does not close A98/AP09. The repository was read-only; all reviewer artifacts and disposable fixtures are private in this directory.

## Exact Source

Current checkout HEAD: `9787e94c12719c30998b6824a249fd88b60c7032`.

Requested and independently observed discovery SHA256: `204c0247771ea81cc757003bc7a25f20b428ddca14c3d40c25690de8738905fe`; registry `c64a6acbf641f2b72696dcc2e7872bd1b03e0dcccb503f30b5737d292327e337`; focused tests `b3e79add1386cbf2b0f7cc36185665636d32e70973c90392f8dc15e556eb201e`; pure helper `e91c3f85ee49f07e79aacabe185919120836979e6f4f5e61f8a62074b8c395c5`. Input manifest and 84 frozen source snapshots bind the inspected inputs. End hashes bind these same current inputs.

Quality basis: docs/blueprint/07-documentation-quality-standard.md:28–80 and :262–312; AP09-acceptance-contract.md:19–43, :47–116, :270, :279, :292. A97-12 and A98-14 require detecting new public surfaces; A98-01 requires task mapping and receives only this bounded Source facet, no whole-gate PASS. Catalogue/fixtures were inspected as applicability inputs, not executed Reader acceptance. A new public consumer cannot retain a docs exclusion merely because today's output is green.

## F1 — unsupported named builtin loader capabilities vanish at admission

FAIL, current Source scripts/docs-api-output-discovery.mjs:174–184, :207–229, :265–290. Named node:module imports record only createRequire, Module and default. Other named exports never acquire a capability, so neither their direct invocation nor their first unsupported transfer can fail closed. `import {_load as load} from 'node:module'; load(absoluteHelper,null,false)` is valid on the actual Node v24.21.0 runtime and reaches all seven helper records. Discovery first qualifies the baseline, then accepts a new tools/public.mjs consumer and returns []. No registry refresh or filename exemption is needed. The container transfer `const o={load};o.load(...)` also vanishes. Alias imports from `module`, unknown env-selected inputs and `_preloadModules` behave the same way.

Node witnesses in new-runtime-witness.json independently execute named _load, _load container, _preloadModules and register; each yields seven records. The register witness uses a private hook module with initialize and a MessageChannel to observe the import in Node's loader thread. Named register/registerHooks admission is currently invisible too. node-module-exports.json records the actual runtime export domain, including _load, _preloadModules, runMain, register, registerHooks, loader caches/extensions and future-sensitive exports.

Necessary correction: intrinsically reject unreviewed loader-bearing or undefined named builtin admissions before aliases/transfers/fingerprints. A blacklist of only _load cannot establish closure. Keep explicit finite custody for createRequire and namespace/default/Module and provide a narrow reviewed treatment for the actual nonloader imports: builtinModules (scripts/plugin-source-closure.mjs:3–6), stripTypeScriptTypes (foundation/packages/install.ts:4, used as a source transform), syncBuiltinESMExports (import-audit-child.mjs:1, :105; a pinned guard synchronizing denied builtin methods). Their roles do not imply general permission for other exports. Unknown future exports must fail closed. No general JS interpreter is required.

The importEquals probe also silently passes, but its .mjs TypeScript import-assignment syntax was not established as a valid default Node execution witness; it is recorded as an admission investigation, not independently used to prove F1. A registerHooks-only source is an admission investigation; the independently executed register witness proves the registration family can load the helper.

## F2 — a canonical finite seed is inventoried under its alias path

FAIL, current Source scripts/docs-api-output-discovery.mjs:121–124, :149–166, :169–173, :130–140. Finite seeds retain original selected paths. Their canonical path is added as alias metadata, but the source body is scanned with the original source path and relative imports resolve from that alias directory. Node resolves a module symlink to its real path and imports siblings from the canonical directory.

Private witness: charts/kubeclaw/files/config/eslint.config.mjs symlinks to charts/actual/eslint.mjs. Actual eslint.mjs exports ./bridge.mjs; actual bridge exports ../../scripts/docs-kubernetes-pv-selected-receiver-contracts.mjs. A benign bridge exists in the original config directory. Qualified discovery returns [] and never scans the actual canonical bridge. Node importing the selected symlink independently receives all seven helper records. This is within a Source-anchored actual ESLint input recipe, not arbitrary added input authority.

The second probe first obtains cached success with a benign canonical bridge, then changes only that actual bridge to import the helper. Discovery remains []. The cache binds alias-side resolution and misses the canonical dependency, so the claim that every selected local bridge mutation invalidates qualification is false. The cache bug is caused by the incomplete initial graph, not by a need to change generic producer or token caches.

Necessary correction: either intrinsically forbid symlinked finite seeds, or inventory and resolve each seed using its canonical module identity from admission onward, binding both the original resolution path and canonical path/bytes. Propagate canonical seeds through the same fixed-point closure and reject repository/vendor escapes before reading unqualified dependencies. Retest safe canonical symlink baseline, actual canonical bridge mutation, alias-side decoy, retargeting, and already-root/shared/cycle closure. Do not treat a path alias record as a source inventory.

## Whole critical claim-group assessment

| Current claim group / gate facet | Source result | Evidence / limit |
| --- | --- | --- |
| Pure finite helper, seven selected receiver rows | PASS | Helper:1–137 has no imports, environment/runtime loader or public emission; checkout fields are unchanged. |
| Exclusion only after qualified docs ancestry; direct/static/public package exposures | PASS for executed finite forms | Discovery:306–354; old probes reject public direct/reexport/aliases/package target/symlink exposure. F1/F2 prevent complete consumer closure. |
| Nested/default/array binding and Promise custody correction | PASS for executed forms | Discovery:207–259; all prior 25 fresh probes pass, including saved awaited aliases/assignments and nested binding rejection. |
| First unsupported loader-bearing transfer across the full builtin domain | FAIL | F1. Named unknown capabilities are lost before custody checks. |
| Finite transitive closure, static/dynamic literal/reexport/cycles/shared roots | PASS for nonsymlink seeds tested | Discovery:143–302; multibridge cycle, extension resolution, already-root shared dependency, missing/unknown bridge reject. |
| Complete canonical seed graph and positive-cache invalidation | FAIL | F2 initial symlink and cached canonical bridge mutation both silently pass. |
| Compiled semantic authority independent of refreshable registry fingerprints | PASS for current 12/27 anchors and executed mutations | Discovery:21–110; recipe-audit and AST operation audit verify all primary/caller/schema hashes, all 27 operation fingerprints, all 12 compiled recipe hashes. Prior source/caller guard mutation and refreshed registry tests reject. This is finite Source authority, not universal runtime publication proof. |
| Fixed guide/config/ESLint inputs are actual finite source classes | PASS class interpretation, FAIL complete graph | Actual guide importSource/call sites, finite ESLint arrays, runtime semantics call sites inspected; F2 affects selected input closure. |
| External Renovate | PASS bounded interpretation | check-renovate.mjs:6–9 uses ENV-selected external root or /usr/local/renovate with three fixed suffixes. External package integrity remains external authority; this is not repository containment or protection against arbitrary external module replacement. |
| Preregistered provider/report/isolation/trusted registration recipes | PASS bounded interpretation | Actual parent protocol/canonical package/digest/trust/schema guards below. Standalone stdin/argv child use is not proven safe, and package guards do not universally prove each imported plugin has no public effect. |
| Generic producer discovery, product scope, output role checks and shlex/token semantics unchanged | PASS preservation | preservation.json compares every byte from documentationEdgeOrder through file end to prior Source snapshot and unchanged compiled anchors/registry. Executed new docs public producer is discovered and unknown writer rejected. |
| Actual public remove-qdrant PATCH preserved | PASS Source/offline discovery only | remove-qdrant.sh:57–77; shell adapter:1937–1953; current checkout sees one PV patch with three tests and add Delete, all seven selected fields. No live request/controller/backend result. |
| Whole Source acceptance | FAIL | F1 and F2 are material; current green existing output does not establish drift completeness. |

## All actual compiled authorities and callers

Recipe-audit.json contains every full input constraint and actual/hash comparison. Operation-audit.json binds each of the 27 actual AST call expressions and owning functions with source line, not author paraphrase. All matched current Source.

| Source | Class | Ops |
| --- | --- | ---: |
| `scripts/check-ap08-effectful-guide.mjs` | fixed-repository-modules | 3 |
| `scripts/check-ap08-minimal-plugin.mjs` | fixed-repository-modules | 2 |
| `scripts/check-core-architecture-guides.mjs` | fixed-repository-modules | 1 |
| `scripts/check-platform-specialist-guides.mjs` | finite-repository-modules | 1 |
| `scripts/docs-configuration-inventory.mjs` | finite-documentation-runtime-semantics | 6 |
| `scripts/docs-lint-policy-reference.mjs` | finite-repository-modules | 2 |
| `scripts/updates/check-renovate.mjs` | external-renovate-fixed-suffixes | 3 |
| `skills/buster/engine/test-gates/provider-child.mjs` | registered-package-protocol-module | 1 |
| `skills/buster/engine/test-gates/report-adapter-child.mjs` | registered-package-protocol-module | 1 |
| `skills/common/plugin-runtime/foundation/isolation/child.mjs` | registered-package-protocol-module | 1 |
| `skills/common/plugin-runtime/foundation/registry/activation.ts` | trusted-package-registration-module | 1 |
| `skills/common/plugin-runtime/foundation/registry/import-audit-child.mjs` | bounded-builtins-and-trusted-registration | 5 |

Actual guards: provider-loader.ts:43–77 canonicalizes and verifies copied package digest; :199–205 sends initialize with modulePath/export. Provider child:50–57 checks initialize and function factory. Report runtime:283–304 verifies original and snapshot digest then canonical module containment; child:17–25 enforces one adapt request/function export. Isolation runner:23–33 canonicalizes package/module and :41–48 bounds filesystem reads; child:78–84 verifies invoke/surface/function export. Registry build.ts:33–60 asserts registration module canonical package containment; discovery.ts:78–102 differentiates trusted builtin roots, digest allowlists and attestations; digest.ts:6–27 rejects symlinks and computes content digest. Activation.ts:28–45 checks integrity, :55–89 branches trusted versus isolated registrations, :121 audits trusted imports. Import-audit parent:27–48 selects registered module/export for child; child:14–100 denies fixed builtin effects and :105 synchronizes exports, then imports selected module and checks function/global state. Current schema and parser hashes are sealed in recipe-audit.json; their authority is source-bound, not renewed by a generic JSON digest. These are parent-authorized protocols; direct arbitrary invocation is outside the claimed proof.

## Executed checks, individual probe table and limits

All 55 old and 25 prior fresh independent Source probes were copied privately and executed by this reviewer: 80 PASS, zero failures. New independent probes: 16 capability admission cases (8 PASS, 8 nonrejections, with witness qualification distinguished above), plus 7 closure/cache cases (5 PASS, 2 FAIL). Focused suite: 16 PASS, zero SKIP. The first private relocation accidentally left three relative source URLs pointing into the evidence directory, producing ENOENT and 13/3; focused-tests.log preserves that reviewer harness error. Relocated paths were corrected, not product code, and focused-tests-corrected.log is terminal 16/0.

Actual checkout discovery completed exit0: 36 script outputs, 111 shell outputs, no false PV helper output, one actual PV PATCH and seven fields. checkout-probe.json and log preserve the results and YAML warnings. Old six Node witnesses reproduced seven records each; five new Node witnesses also show seven each. Root integrated full API verification is root-owned and was not duplicated or inferred as Source acceptance. No full config generation, package/global checks, product runtime, deployments, cluster/provider/media/SQL/real Secret use, commits/pushes or installations were performed.

| Harness / case | Observed |
| --- | --- |
| old-probes.json / namespace | PASS |
| old-probes.json / default | PASS |
| old-probes.json / namedAlias | PASS |
| old-probes.json / computed | PASS |
| old-probes.json / destructured | PASS |
| old-probes.json / cjs | PASS |
| old-probes.json / awaitNamespace | PASS |
| old-probes.json / call | PASS |
| old-probes.json / apply | PASS |
| old-probes.json / bind | PASS |
| old-probes.json / reflect | PASS |
| old-probes.json / dynamicCall | PASS |
| old-probes.json / dynamicApply | PASS |
| old-probes.json / dynamicReflect | PASS |
| old-probes.json / pass | PASS |
| old-probes.json / returnLoader | PASS |
| old-probes.json / returnFactory | PASS |
| old-probes.json / returnNamespace | PASS |
| old-probes.json / objectShorthand | PASS |
| old-probes.json / objectProperty | PASS |
| old-probes.json / objectAssignment | PASS |
| old-probes.json / arrayTransfer | PASS |
| old-probes.json / exportLoader | PASS |
| old-probes.json / exportDefaultLoader | PASS |
| old-probes.json / factoryObject | PASS |
| old-probes.json / namespaceSpread | PASS |
| old-probes.json / conditionalLoader | PASS |
| old-probes.json / reassignment | PASS |
| old-probes.json / plainRequireProperty | PASS |
| old-probes.json / plainRequireReturn | PASS |
| old-probes.json / dynamicBuiltin | PASS |
| old-probes.json / nohintUnknown | PASS |
| old-probes.json / publicDirect | PASS |
| old-probes.json / publicTransitive | PASS |
| old-probes.json / publicReexport | PASS |
| old-probes.json / packageAlias | PASS |
| old-probes.json / packageConditionalAlias | PASS |
| old-probes.json / bin | PASS |
| old-probes.json / main | PASS |
| old-probes.json / exports | PASS |
| old-probes.json / nonDocsInvocation | PASS |
| old-probes.json / fileSymlink | PASS |
| old-probes.json / directorySymlink | PASS |
| old-probes.json / sourceDeleted | PASS |
| old-probes.json / sourceRenamed | PASS |
| old-probes.json / edgeChanged | PASS |
| old-probes.json / edgeDeleted | PASS |
| old-probes.json / docInvocationChanged | PASS |
| old-probes.json / docInvocationRenamed | PASS |
| old-probes.json / digestRefreshed: console.log(JSON.stringify({apiVersion:"v1",kind:"ConfigMap"})); | PASS |
| old-probes.json / digestRefreshed: process.stdout.write(process.argv[2]); | PASS |
| old-probes.json / digestRefreshed: export const extra=1; | PASS |
| old-probes.json / docsNamedPublicEmitter | PASS |
| old-probes.json / docsNamedUnknownPublisher | PASS |
| old-probes.json / publicDynamicRegistryRefresh | PASS |
| new-probes.json / nestedNamespace | PASS |
| new-probes.json / nestedDefault | PASS |
| new-probes.json / nestedAwait | PASS |
| new-probes.json / nestedRequire | PASS |
| new-probes.json / nestedDynamic | PASS |
| new-probes.json / exportNested | PASS |
| new-probes.json / arrayDestructure | PASS |
| new-probes.json / arrowReturn | PASS |
| new-probes.json / getterReturn | PASS |
| new-probes.json / asyncReturn | PASS |
| new-probes.json / logicalFactory | PASS |
| new-probes.json / optionalCall | PASS |
| new-probes.json / templatePath | PASS |
| new-probes.json / namespaceRest | PASS |
| new-probes.json / asyncPromise | PASS |
| new-probes.json / finiteOutsideTransitive:static | PASS |
| new-probes.json / finiteOutsideTransitive:reexport | PASS |
| new-probes.json / finiteOutsideTransitive:dynamic | PASS |
| new-probes.json / finiteOutsideTransitive:bridge-cache | PASS |
| new-probes.json / runtimeAuthority:skills/buster/engine/test-gates/provider-loader.ts:refresh=false | PASS |
| new-probes.json / runtimeAuthority:skills/buster/engine/test-gates/provider-loader.ts:refresh=true | PASS |
| new-probes.json / runtimeAuthority:skills/common/plugin-runtime/contracts/plugin-system/v2/plugin-system-v2.schema.json:refresh=false | PASS |
| new-probes.json / runtimeAuthority:skills/common/plugin-runtime/contracts/plugin-system/v2/plugin-system-v2.schema.json:refresh=true | PASS |
| new-probes.json / runtimeAuthority:skills/common/plugin-runtime/foundation/registry/digest.ts:refresh=false | PASS |
| new-probes.json / runtimeAuthority:skills/common/plugin-runtime/foundation/registry/digest.ts:refresh=true | PASS |
| additional-probes.json / namedPreload | FAIL: expected rejection, discovery accepted |
| additional-probes.json / namedPrivateLoad | FAIL: expected rejection, discovery accepted |
| additional-probes.json / namedPrivateLoadDefault | FAIL: expected rejection, discovery accepted |
| additional-probes.json / namedPrivateLoaderEscape | FAIL: expected rejection, discovery accepted |
| additional-probes.json / namedPrivateLoadDynamic | FAIL: expected rejection, discovery accepted |
| additional-probes.json / importEquals | FAIL: expected rejection, discovery accepted |
| additional-probes.json / namedRegister | FAIL: expected rejection, discovery accepted |
| additional-probes.json / registerHooks | FAIL: expected rejection, discovery accepted |
| additional-probes.json / moduleConstructor | PASS |
| additional-probes.json / namespacePrivate | PASS |
| additional-probes.json / nestedPromiseDefault | PASS |
| additional-probes.json / promiseAssignment | PASS |
| additional-probes.json / forwardingRequire | PASS |
| additional-probes.json / privateBuiltinReexport | PASS |
| additional-probes.json / builtinNamespacePrototype | PASS |
| additional-probes.json / deferredPromise | PASS |
| closure-probes.json / finiteOutsideTransitive:selected-symlink | FAIL: expected rejection, discovery accepted |
| closure-probes.json / finiteOutsideTransitive:selected-symlink-cache | FAIL: expected rejection, discovery accepted |
| closure-probes.json / finiteOutsideTransitive:multibridge-cycle | PASS |
| closure-probes.json / finiteOutsideTransitive:shared-root | PASS |
| closure-probes.json / finiteOutsideTransitive:extension-resolution | PASS |
| closure-probes.json / finiteOutsideTransitive:missing-after-cache | PASS |
| closure-probes.json / finiteOutsideTransitive:unknown-bridge | PASS |

Executed cases establish only their finite forms. No universal JavaScript evaluator, every future Node export, arbitrary runtime package/module input, served Kubernetes behavior, Reader task completion or upstream PV semantic acceptance is claimed. Correction requires a new full fresh Source review; rerunning only these two failures is insufficient.
