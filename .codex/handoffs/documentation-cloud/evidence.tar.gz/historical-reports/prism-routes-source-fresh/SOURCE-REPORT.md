# Independent SOURCE review: frozen Prism journey and glossary

Reviewer: `/root/a98_prism_routes_source_fresh`; completed 2026-10-10 UTC.
Scope: SOURCE OPR-010 and Prism contributions to A98-02/04/06/12/13 only. This is not a Reader, Quality, Astra, whole-platform, live-delivery, or global acceptance verdict.

## Reviewed immutable inputs

Full original source: `733b7417992c1bafaf5848d421c80ff76b73a9e4`, archived from `/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04` into private `archive/`, also retained as `source-archive.tar`. No main or product-source edits, cluster mutation, network install, downloads, commits, or pushes were performed. Candidate copies preserve the frozen main bytes, including edits not in the source archive:

- `prism-studio.candidate.md`: 2350 lines; SHA256 `041a849890eb72f65e58f729ee0b7860b646b4794c27fae165153113752a0dcb`.
- `glossary.candidate.md`: 274 lines; SHA256 `25aa9f129ccaaa67badedc48cf73c3aa7693b0af851d03a3ea193d43115bc1db`.

The full two pages were read. Quality standard 07 and the complete AP09 acceptance contract were read; OPR-010 catalogue authority and relevant acceptance fixtures were inspected. Prior author/reviewer summaries were not used to prove semantics. A later broad catalogue search incidentally returned historical review records; none supplies this report's findings or verdicts.

`source-pins.json` independently validates all 221 pinned page links, covering 72 distinct files. Each target is a full 40-character revision, a tracked regular file of mode 100644/100755, with existing in-range line anchors. Every entire pinned file equals the corresponding current source file at 733b7417. The Prism evidence revision ec2a42ed and historical execution revision 082db288 remain distinct; byte equality does not retest the old execution or establish a current live result.

## SOURCE verdicts

| Assigned ID | Verdict within assigned SOURCE partition | Reason |
| --- | --- | --- |
| OPR-010 | FAIL | The complete canonical journey and its recovery boundaries are accurate, but the required shared glossary contradicts the journey's approval authority boundary (F1). |
| A98-02 | FAIL | F1 prevents a consistent authority definition. Separately, frozen Prism metadata omits mandatory `Last verified` (F2); historical execution text does not replace it. |
| A98-04 | PASS | Process, bootstrap, DB dependency, native host, capacity/stopping state, and business readiness are accurately separated. |
| A98-06 | PASS | Diagnosis distinguishes mandatory prerequisites, modes, uncertain responses, bounded retry, and safe recovery/cleanup STOPs. |
| A98-12 | PASS | The actual Prism setup-to-human-approval-to-separate-publication-to-Nova journey and its failure/interruption/resume/cleanup limitations are represented truthfully. No synthetic or unavailable step is promoted to live delivery. This is the Prism SOURCE contribution only. |
| A98-13 | FAIL | A fresh technical reader receives an incorrect universal shared definition of Approval (F1); required verification metadata also needs correction (F2). |

PASS means the documentation accurately describes the inspected source and its limits. It does not mean the execution checks all passed, a browser journey worked, or full cross-page gates passed.

## Material findings and concrete corrections

### F1 — Shared Approval definition conflates stored Prism approval with Nova resume signal

Frozen `docs/site/reference/glossary.md:22` says: “An authorized signal that answers a stored wait.” It declares one shared plain meaning (L12–16). That is false for the stored human approval created by Prism Control. The Prism candidate explicitly distinguishes human approval, publication, and Nova signaling (L106–115).

Current original authorities:

- `skills/prism/server/control-server.ts:521–565`: POST `/v1/approvals` checks project/document ownership, quality and warning acknowledgment, active design request, and inserts a distinct `prism.approval` record with the session actor. It returns an approval ID; it does not resolve a Nova wait.
- Same file L567–643: publication is another route, checks the current revision/digest and selected current direction, and can reuse the already published receipt. Approval is not publication.
- `skills/nova/plugins/prism-design/src/stage.ts:8–34`: a separate guidance payload binds configured operator issuer, approval ID, architecture digest and bundle digest; the unapproved stage creates/publishes a signal wait. It does not turn the Prism approval POST into an authorized resume signal.
- `skills/nova/core/execution/engine-run.ts:81–120`: the separate resume path checks recoverable run, active wait and signal before recording resolution. An issuer field matching configuration is not proof of the CLI caller's identity.

Concrete correction: define Approval as the relevant human authorization record/decision; explicitly state that Prism's stored approval, publication receipt, and Nova resume signal are separate. Link the Prism approval and Nova signal meanings to these narrow current source ranges. Retain the statement that lifecycle state is changed only through the owning runtime's allowed transition. Do not imply that a submitted issuer string authenticates a caller.

Independent bounded execution: `approval-boundary-fixture-v2.mts` uses original Control HTTP and original migrations/repository with embedded PGlite and pgvector. With a minted local signed session (not real ingress identity), approval returns 201 and stores one row; exact repeat returns 422 uniqueness; publication without selected direction returns 422 and stores no baseline. Listener and DB close in `finally`; no worker/artifact/provider call occurs. This proves route separation within that fixture only.

The first fixture version's failure is preserved: it hashed the pre-storage JSON object, but JSONB-normalized persisted content gave a different digest; publication correctly rejected `stale approval digest` before the fixture's expected selected-direction check. Version 2 reads the persisted document before hashing. No product code was changed and no first error was erased.

### F2 — Missing required verification metadata (separate required gate defect)

Frozen Prism candidate L1–9 contains `Historical executed checks` but no `Last verified` field. This absence was independently inspected. Parent reported that coherent documentation generation succeeded, then the original `docs:governance:generate` required gate failed because this field was absent. That command's result is parent-observed, not independently executed by this SOURCE reviewer, and is not proof of a route semantic mismatch.

Concrete correction: add honest `Last verified` metadata for the present bounded source/pin review, retaining separate original historical execution date/revision and exact execution limitations. Do not rename old executions as current, or weaken the required metadata rule. This review executed selected original tests at 733b7417, with the failures and skips below; it did not execute the complete documented journey.

## Source findings that support the accurate portions

- Common Gateway chart and Prism agent overlay select managed OpenAI/Codex reasoning with specified allowlisted fallbacks. Protected persistent OAuth state is separate from LiteLLM's memory embedding model and API credential. LiteLLM is not the managed reasoning login route; neither config nor a readiness response establishes successful managed reasoning.
- Control's agent claim/status/outcome and design-set/revision commit routes require SPIFFE and the configured Prism agent identity. Healthy HMAC worker HTTP can coexist with an unusable agent journey. Agent bridge/plugin and async job fence bind the original job, generation/revision, caller and current unexpired lease; exact committed-result replay differs from a fresh write under an expired lease.
- Deployment checks SPIRE CSI registration unconditionally at the deploy-script boundary. Native mode additionally requires selected namespace/node/policy and host obligations. Health does not prove these prerequisites, and adding environment secrets does not supply the trust or host policy.
- Control `/health` is process-only; `/ready` executes `SELECT 1`. Worker bootstrap checks native host readiness without waiting for HMAC nonce storage; full HMAC readiness requires the actual nonce table query. SPIFFE readiness omits that HMAC-only dependency. Lifecycle capacity/stopping may refuse readiness. Direct HMAC/SPIFFE/native fixture substitutes are declared below.
- Native lifecycle counters are event-time snapshots: duration is recorded/rounded at emission, active includes the operation until its final release, open/pending come from the pool's current total/waiting counts; idle timer refresh and operation bounds are not a historical saturation metric. Default/native config bounds and owner-specific readiness STOPs match source.
- Studio's component/session storage receipt behavior, round/revision job recovery, uncertain submission state, stale base checks, direction exact-key replay, fresh preference/retraction events, history restore revision increment, approval uncertainty, and separate publication receipt reuse are accurately differentiated. A reload is not permission to create another job/round or repeat non-idempotent restore/approval. UI-local receipt loss remains an honest product limit.
- Nova payload/run/wait validation happens before duplicate recording; the signal format is not independently authenticated human approval. Immutable bundle archive verification, checksum/entry restrictions and artifact storage are distinct from receipt IDs. Screenshot/ARIA and selected-direction publication checks are source-backed; no local browser success is claimed.
- Bounded backup gathers a matching snapshot group and checksum evidence; it is not an arbitrary named historical group selector. Cleanup skips pending objects and does not authorize raw DB-row deletion or account-wide resource removal. Pending writes, unresolved attempt cleanup and unavailable readiness force the documented STOP and ownership escalation.
- Fixed spike configs require `/ms-playwright/chromium_headless_shell-1228/chrome-headless-shell-linux64/chrome-headless-shell`; both spike locks pin Playwright 1.55.0, while the root lock pins @playwright/test, playwright and playwright-core 1.62.1; the offline-cache-installed root playwright-core browser registry selects Chromium and Chromium headless shell revision 1234. The fixed 1228 path is absent here. Studio's optional managed browser path/fallback differs from the fixed spikes. No browser download, spike run, browser recovery or live route was invented.
- Deploy source selects materialized Runtime Release values; current `releases/runtime-images.json` and required selection are unavailable. Original materialization fails with ENOENT, retained below. No rollout command was attempted.

## Actual execution and first errors

Environment: Node v24.21.0, npm 11.19.0, Helm v3.22.0+g144ca65; `/usr/bin/flock` is BusyBox v1.37.0. Runtime skill read; no network/proxy/container operation was required.

Private `npm ci --offline --ignore-scripts --include=dev` succeeded from the pre-existing cache (478 packages added; audited 545). This is offline cache dependency reuse, not a clean install, a dependency isolation proof, or live provider evidence. `dependency-install.log/.exit` retain the result. No dependency or native/trust substitute was installed into the original source.

| Check/artifact | Actual result and limits |
| --- | --- |
| `original-tests.log/.exit` | Original 16-file bounded Node test command: 52 tests, 50 passed, 1 failed, 1 skipped, 0 cancelled; exit 1. Includes Control config/clients/decisions/rounds/storage, agent job/HTTP/auth, worker service/readiness/chart/capacity/shutdown, quality and artifact durability. |
| First original failure | `worker-readiness-chart.test.mts:6`: actual `helm template prism charts/prism -f charts/prism/ci-values.yaml` lacks explicit namespace; native guard at workloads L6 rejects selected namespace/node/digest. This failure is retained and not converted to PASS. |
| Original skip | Real PostgreSQL readiness/cancel test requires `KUBECLAW_PRISM_READINESS_TEST_DATABASE`; not provided. Embedded/refusal fixtures do not replace it. |
| `focused-helm.log/.exit` | Original prescribed `npm run verify:prism:helm` includes `--namespace default`; lint and render pass, exit 0. Separate check, not a relabeling of the failed test. |
| `deploy-script.log/.exit` | Original `npm run verify:prism:deploy-script` passes, exit 0. Shell/deploy fixture validation only; no cluster operation. |
| `worker-trust-contract.log/.exit` | Original `node tests/verification/contracts/check-worker-trust-spiffe.mts` passes. Static source contract only. Full trust aggregate/live suite not run. |
| `nova-prism-wait.log/.exit` | Original `node --test tests/verification/integration/prism-wait.test.mts` fails before wait assertions: `OBSERVABILITY_STORE_LOCK_FAILED` because `/usr/bin/flock` does not accept `--timeout`. No executable replacement or fixture-only shim converted this to PASS. Owned temporary directory absent after cleanup. |
| `runtime-materialize.log/.exit` | Original `node scripts/updates/materialize-release.mjs --family=runtime --check` fails with ENOENT for `releases/runtime-images.json`. No release files created or cluster mutated. |
| `explicit-source-fixture.mts/.log/.exit` | Exit 0; actual original Control HTTP rejects mandatory agent claim/commit routes in HMAC mode before body/DB access. Original worker HTTP uses declared native-readiness and nonce-store substitutes: bootstrap skips nonce query, HMAC ready executes it and rejects its deliberate failure, native failure precedes DB query, SPIFFE ready succeeds without nonce DB. No live SPIFFE handshake/native host/production DB is proven. All listeners closed. |
| `approval-boundary-fixture.mts/.log/.exit` | First private fixture exit 1; JSONB digest mismatch causes `stale approval digest`, retained. Cleanup completed. |
| `approval-boundary-fixture-v2.mts/.log/.exit` | Exit 0; corrected fixture reads persisted document; original Control approval/publication boundaries verified as described under F1. Embedded DB and local minted session only. |
| `browser-preflight.json` | File existence only; fixed 1228 absent, cached Chromium 1187 present. No browser launched. |

The original bounded suite uses its declared embedded SQL, deterministic provider/native substitutes, actual loopback HTTP and local filesystem/process fixtures. Artifact tests cover corruption, pending cleanup, concurrent writers and process interruption without asserting live cloud storage. Passing tests do not establish cluster/cgroup ownership, real ingress identity, production PostgreSQL, managed reasoning, remote embeddings or browser acceptance.

All review-owned commands terminated, fixture listeners/databases closed, native attempts were not started, and the original Nova test temporary directory is gone. Other agents' processes were not terminated.

## Actual read scope

Complete reading of both candidates, quality standard 07 and AP09 acceptance contract. Catalogue OPR-010 record and relevant READER-QUALITY/EXEC-PRISM fixture records read; catalogue is classification, not operational proof.

Full source files read in the relevant Prism paths: Control server/config; worker/config/readiness/service; Studio config; agent job routes/runner/bridge/attempt; OpenClaw plugin; agent jobs/admission; design generations/direction decisions; native operation/store/execution/host; lifecycle; Studio app, design-round/revision clients, preview/assets/flows; storage index/artifacts and migration 001; preferences/product decisions; domain index; evaluation; render operation; baseline archive; pipeline adapter. Common/Nova: Prism stage/archive/config schema, Nova CLI and engine run, worker trust. Full Prism chart values/workloads/services, agent overlay, worker Dockerfile, SPIRE values, backup job/script and bootstrap script were read. The selected original client/config/decision/round/storage, worker-service/readiness/internal-auth, agent-job-HTTP, chart and Nova wait test source files were read; the other files in the 16-file suite were executed and relevant output checked, without claiming an exhaustive line-by-line test-source review.

Bounded sections inspected rather than entire unrelated files: Common chart values L16–220; Common Deployment L442–530,1315–1355,1399–1430,1627–1648; Prism architecture verifier pinned ranges; Prism trust template relevant generated proxy/CSI ranges; values schema L59–108,510–531; deploy script L100–103,962–984,1590–1820; worker native ownership L179–199,244–281; recovery page L369–504; maintenance references found by search; root package/lock and spike browser configs/locks for the named gates. This is not a full schema/platform/recovery-page review. `source-pins.json` supplies exact pinned authority ranges and full file byte hashes.

Unexecuted: complete `verify:prism:local`/aggregate checks; fixed browser spikes, Studio browser journey and approval/render browser acceptance; real PostgreSQL readiness cancellation; live managed OpenAI/Codex reasoning and LiteLLM memory embeddings; SPIFFE live handshake/CSI rollout; native systemd/cgroup containment; native live interruption/cleanup, cloud backup/restore; production readiness or rollout; Nova end-to-end pipeline resume after approval; full worker trust aggregate/live suite; EXEC-PRISM-JOURNEY; READER-OPERATOR01–04 live operator routes. AP09 explicitly treats truthful unavailable product/live-delivery boundaries and those deferred checks as nonblocking for documentation, so none is manufactured as execution evidence or automatically used to fail accurate SOURCE content.

Relevant fixture registration mentions `docs/site/use/workflows/examples/prism-studio-flow.json`, which is absent in the immutable source archive. This is reported as a separate registration/scope observation, not a SOURCE journey semantic failure or whole-platform acceptance verdict.

## Durable evidence and release

`archive-manifest.json` inventories all tracked immutable source blobs and verifies every extracted archive byte after the checks. `manifest.json` inventories report, candidate copies, scripts, checks, logs, exit records, full source tar and source-pin/artifact manifests with SHA256. Neither node_modules nor main worktree changes are hidden as product source. Both frozen candidate pages are released after final report/manifest completion; later edits require their own recheck and hashes.

## Report fact correction (2026-10-10)

The first report incorrectly assigned Playwright 1.55.1 / Chromium 1187 to the root lock. Parent identified that reviewer error. Direct rereading of immutable revision 733b7417 confirms all three root Playwright packages are 1.62.1; both spike locks are 1.55.0. The installed root 1.62.1 browser registry selects Chromium/headless-shell 1234. `browser-fact-correction.json` preserves exact source-file equality, versions and registry hash. The old report and manifest are retained as `SOURCE-REPORT.first-inaccurate.md` and `manifest.first-inaccurate.json` with their original hashes. This correction does not change source archive, candidate verdicts, execution results or the already released pages. No main edit or new review was performed. The separate browser-preflight 1187 entry describes an existing cached file; it must not be attributed to the root lock.
