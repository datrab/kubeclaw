# Core API receiver writer candidate

The sole repository output is `scripts/docs-kubernetes-core-receiver-contracts.mjs`. It exports 272 authored receiver records: ConfigMap 42, Namespace 49, PersistentVolumeClaim 89 and Service 92. The inventory is re-enumerated through the sole schema authority helper. No schema description is used as receiving behavior evidence.

Kubernetes source revision is `66452049f3d692768c39c797b21b793dce80314e`. The private primary directory contains 35 source files. Each raw file has its byte count and SHA-256 recorded in primary-manifest.json; verify-primary.py separately compared its computed Git blob ID with GitHub's content metadata at the full pinned revision. verified-primary-manifest.json records all 35 matches. These are source checks, not API/controller/driver execution.

The authored scope includes every envelope, metadata, spec, status, collection, scalar item and exact map entry exposed by these four pinned schemas. The Go declaration table is separately extracted from primary core/meta type declarations. The module throws on an un-authored path or absent Go declaration. Scalar null list items retain scalar zero/empty values; exact map keys retain their decoded zero entry. Pointer and ordinary struct paths remain distinct. Quantity, IntOrString, Time and FieldsV1 custom decoder routes are explicit. Empty Time strings fail RFC3339 parsing; null Time value resets zero and null optional pointer remains nil.

Resource evidence includes typed REST constructors, preparation, defaults, validation and update branches. Namespace uses status and finalize ownership and its concrete content deletion/finalizer sequence. ConfigMap uses exact key/overlap/decoded-size/immutable checks and its namespace-local volume payload/publishing/error route. PVC uses field gating/data-source compatibility/normalization, immutable update/expansion-recovery constraints, matching/binding/provisioning and kubelet Bound/PV UID lookup. Service uses type-dependent defaults, traffic feature branches, IP/port allocation and status-address validation. None of these sources establish a target cluster's external storage or network behavior.

Executed checks

- node --check completed for the candidate module.
- check.mjs executed the full schema/export boundary bijection, uniqueness and required member/case shape checks.
- Every one of 284 unique evidence URL ranges resolves to retained primary bytes and lies within the corresponding file. source-range-excerpts.json contains those exact source lines; record-source-case-mappings.json links each record/case to its evidence and outstanding documentation gaps.
- Export was produced twice during development and deterministic hashes were compared by the executed checks; the final export hash is `e0f4a9efe5066d469531cf05e04ceba86f3af9913e0831826ab02204fcfeaa22` and module hash is `9c30639ea6a9a2db61ab79bea7c49126c44d51d9c5d460adf17bbb14ec9a30f4`.

No Go decoder tests were executed by this writer. Root's separately scoped decoder evidence must be evaluated independently. No API request, live cluster write, controller convergence, installed plugin acceptance, external provisioner operation, mount, dataplane probe, ownership conflict or publication reader exercise was executed here.

Remaining proof obligations

remaining-proof-obligations.json enumerates all current available-source documentation gaps and their affected boundaries. Major groups are downstream garbage-collection/owner-reference permission handling; full managed-fields normalization/conflict/field-set interpretation; generic deletion-grace lifecycle; complete condition producers; ConfigMap manager/environment/subPath consumers; selected storage driver/populator/resize/ReferenceGrant consumers; and Service EndpointSlice/proxy/DNS/load-balancer consumers. These are documentation obligations. They must not be reclassified as product limits or closed through these qualification strings. The authored export is a concrete candidate for full fresh independent semantic review; this report does not self-accept it.

The quality standard and AP09 A98-10/A98-11 were read. The source/case ledgers distinguish omitted, null, empty, invalid, cross-field, update and recovery cases. The qualified source results need comparison with the original CFG-009 fixtures and effective Helm/GitOps path by the root integrator. This writer does not claim a global A98/CFG PASS.

Ownership is released for integration and independent review. No other repository file was edited, and no commit, push or deletion was performed.
