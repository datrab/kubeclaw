# Capacity controls complete author correction

Role: documentation author `/root/capacity_controls_complete_correction_writer`, not an independent Source, Reader or Quality reviewer. This bundle provides an authored correction and bounded local checks. It grants no Source/Reader/Quality, registered gate, AP98, AP09, global, publication, runtime or CLI-execution acceptance. Parent coordination owns commits and subsequent independent reviews.

Repository: `/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04`; sole repository write: `docs/site/use/capacity.md`. Initial HEAD and source-link authority: `ad312e3e4f15223809fadef90bd90e1f689ce941`. Concurrent parent work advanced HEAD to `b8ffca0f637aa4e426281e58fded2afeb88c16f6` before sealing. The final seal reconfirmed all 77 guarded inputs and the authored page unchanged; source links remain byte-current at their original committed authority. This author performed no commit or push. Other tracked modifications pre-existed this task and are preserved in the guard status records. The configured assignment identifies Sol medium fresh context; no backend-routing certificate is available or asserted.

## Inputs and preservation

The complete independent Source report was read from `capacity-complete-current-source-fresh/report.md`; copied as `review-report.md`, SHA-256 `9c57486cf477ef5d01d160a9f1656f66fcabac72d96c9c62d793f1c5bda85482`. Its whole-page FAIL and separate measured-budget facet PASS were treated separately. All S1/S2 correction families were considered together; no subset is offered as a complete acceptance.

Original page is `before-capacity.md`: 13925 bytes, 236 lines, SHA-256 `39aae50f9105bf0f6ce8d4704dc098cc551d063a3af146403e5e5432769d1e06`. It was saved before any author edit. `preserved-budget.md` is the exact uninterrupted original complete service-budget subsection, including the unpopulated record, service coverage, growth math, warning/stop/owner response and stop conditions. The final local check proves this full byte span remains in the corrected page. `unaffected-portions.json` records every unchanged matching line span with both positions and exact hash; `complete-delta.patch` contains the complete before/after delta, and `after-capacity.md` preserves the complete resulting page.

The complete quality standard 07, acceptance contract, fixtures and execution plan were inspected, with the OPR-009 catalogue entry and A98-02/04/06/07/09/13 facets. Reads that initially exceeded output limits were followed with smaller sections. Canonical inspection included shared tool/version rules, install binding and read/host access, store/projection and Redis profile boundaries, LiteLLM retention acquisition and its unknown-runtime stop, Prism runtime/native limits, configuration precedence, backup/restore, diagnosis and maintenance retention/collection boundaries. A local link to the generated Helm reference identifies its location, not semantic currency or runtime proof; this author did not accept generated facts or run the changing generator tools.

## Primary evidence and actual operative inspection

Read the actual operative implementations, not only the independent report summaries: full ingestion service, full RAM execution cache, Worker configuration/lifecycle/native execution loaders, native supervisor/pool-policy readers, node policy/reservation/capacity/preflight, direct/GitOps Redis values and Redis adapter, Prometheus/Loki values, full Prism and LiteLLM backup scripts, Prism backup/ingestion/claim values/templates, each of the six local retirement/compaction entry points, full connected planner, full causal dispatch and operator helpers, full run inspector, full original Nova run-evidence reader, full attempt projection reader, the complete operative durable-record retirement and durable-attempt retirement methods, and Buster completed-job compaction and retained-source/artifact validators. Relevant acquisition, cache, ingress and backup test bodies were read; none was executed. Whole operative delegation bodies were inspected to check retained-source, original-consumer and writer-fence claims.

`primary-sources/` retains exact complete files for the final page's 45 pinned references. The pin check validates regular Git modes, existing objects, full-file byte equality to the working file, ascending in-bounds line ranges no longer than 60 lines, and the recorded full commit. Every final source citation uses `ad312e3e4f15223809fadef90bd90e1f689ce941`. Current full-file equality is distinct from semantic independent review.

Initial necessary-input guard was captured after the initial source/canonical discovery and before the first author edit, with 61 inputs. The extended final guard includes 77 inputs and records its actual later timestamp and newly discovered paths. It excludes only the intentionally authored page from initial-input change comparison. Every previously guarded non-authored input remained byte-identical, and every final cited product file matches its committed Git object. This guard does not certify all repository files or the concurrent source-filter correction. No dirty tool implementation was cited as committed product authority.

## Complete correction mapping

| Finding | Authored correction and explicit limit |
| --- | --- |
| S1 selected service control map | Existing measured-budget contract retained; adjacent map connects all listed service families to effective profile/configuration authority, actual pressure/cost, named owner, safe stop, retry and retain/cleanup boundary. Additional discovery remains mandatory. Owner-native methods and exact permission/selector/version are required before their execution, never inferred. |
| S1 Prism acquisition | Exact 4 GiB temporary volume, one-hour TTL clamped one minute–one day, reaper cadence, request/acquired-byte ceilings and authenticated exact-digest DELETE separated from durable logs, artifacts, reports and Control replay. Actual Control cleanup after failed processing is included. No credential or manual API procedure is invented. |
| S1 Prism RAM cache | In-flight/count/byte defaults, excess-work rejection and reconstructible completed-entry eviction distinguished from durable replay/artifacts, with inspected test status. |
| S1 Worker/native pressure | Separate ingress/probe/connection/body/time fences, `503` meanings, CPU/memory/Linux-task budgets, root-owned aggregate pool authority, node/boot/runtime reservations and journal/liability limits; Pod CPU alone does not prove host capacity. |
| S1 Redis profiles | Direct AOF/no-eviction/maxmemory/20 GiB profile separated from GitOps 2 GiB/256 MiB Pod values and omitted direct policy. Effective loaded policy and independent stream/dedup bounds required. |
| S1 backup headroom | Independent live data, completed groups, failed staging and off-node destination budgets; Prism 80/90/100 GiB and 1 MiB subtraction separated from LiteLLM 64/90/100 GiB and 64 MiB subtraction. No automatic expiry, failed-stage deletion command or application restore claim. |
| S1 actual telemetry horizons | 15-day/20 GiB Prometheus and 720-hour/20 GiB Loki, 721-hour query bound, actual coverage/growth measurement and capacity-not-guaranteed limit; canonical product evidence remains separate. |
| S1 implemented narrow local controls | Individual telemetry/admission/attempt/dispatch/operator/Buster rows identify actual local caller, eligible copy, owners, original authority and writer fences, retained readers/source/receipts. Actor/owner JSON, age, globs and terminal status grant no permission. No local mutation is represented as executed. |
| S1 blocked connected deletion | Planner `executable:false`, zero release and four completeness/release blockers; full run/evidence deletion unavailable. Exact blocked scope-construction/application step, responsible owners, safe retain/add-capacity/stop choice and qualification/implementation/isolated-proof closure stated. |
| S1 navigation and diagnosis | Canonical stores, telemetry, runtime/native configuration, generated-reference location, acquisition/version, diagnosis, recovery and maintenance reachable beside records. Distinct permission, missing metrics, admission, backup allowance, Redis, quarantine, horizon and projection failures lead to safe checks/stop/recovery. |
| S2 actual tool acceptance | Shared accepted actual client/server/product/storage-tool pair rule applied before measurement; build and Ops selections distinguished without invented compatibility range. |
| S2 read prerequisites | Resource/non-resource/metrics rights, named namespace UIDs and exact scopes; owner-native query permissions and permission-denied stop. Added bound read-only namespace UID capture and independent identity comparison. Existing frozen dedicated kubeconfig and no-default-cluster rules retained. |

## Individual applicable author coverage facets

These rows describe where author coverage now resides. They are not PASS verdicts, participant results or an independent acceptance of any requirement.

| Facet | Author coverage |
| --- | --- |
| OPR-009 measurement, warning, stop, growth, owner and response | Exact original completed-record contract preserved; no production numbers or approved thresholds supplied. |
| OPR-009 complete selected capacity/retention controls | Service map, temporary/native/Redis/backup/projection subsections and supported-response boundary. |
| A98-02 purpose and starting location | Existing cluster, independent administration, product-owning query surface and sole canonical procedure. |
| A98-02 authority and cluster binding | Existing read-only frozen dedicated kubeconfig plus explicit accepted versions/read rights and independent namespace UID comparison. |
| A98-02 prerequisites and ordered actions | Placeholders frozen/replaced, private evidence outside workloads, inventory then real per-resource measurement then owned response and final verification. |
| A98-02 operational impact and methods | Effective loaded profile/control, actual pressure/cost, exact method/selector/permission required before execution; no guessed tool. |
| A98-02 stop, repeat, recovery and cleanup | Missing readings/authority stops mutation; read repetition stays bound; uncertain effect is reconciled before retry; access released through issuer; only identified local disposable files cleaned. |
| A98-04 inventory versus function | PVC Bound/top/HTTP probes remain insufficient for free capacity, actual host reservations or original readers. |
| A98-04 exact service pressure | Admission code/reserved probes, native liability, caches and distinct store bounds reachable beside budgets. |
| A98-06 unavailable metrics versus zero | Original unavailable/missing/undefined rules retained; diagnostic table differentiates API/access unavailability from measured pressure. |
| A98-06 cause/stop/recovery mapping | Per-service map and eight observation/check/safe-boundary diagnostic rows; canonical symptom route linked. |
| A98-07 backup scope and headroom | Separate allowances/ceilings, failed staging retained, canonical group integrity/external copy/encryption/credential/original-reader requirements linked. |
| A98-07 honest restore status | No isolated application/full-platform restore established; canonical recovery boundaries remain explicit. |
| A98-09 retention versus environment removal | Local eligible copies distinguished from full history/evidence deletion; canonical decommission remains the separate authority. |
| A98-09 retained evidence and uncertain mutation | Individual retained readers/receipts/source boundaries plus before/after evidence and no repeat deletion on uncertainty. |
| A98-13 truthful unexecuted template | No live readings, owner approvals, product queries or mutation successes invented; live exercises remain unexecuted product validation. |
| A98-13 self-contained reader path | Navigable controls, exact missing-method/unsupported-mutation stops and owner closure conditions added; fresh Reader work still required independently. |
| Source evidence currency/ranges/callouts | 45 current full-SHA references; explicit claim/implementation/setting/test-status/revision/limit callouts and independent source/procedure distinctions. |
| Applicable upstream scope | Actual selected controls explained; no general Kubernetes course, unused alternatives or exhaustive foreign-field reproduction. |
| Units, forecasts and reasons | Original positive-growth/free-space math preserved; temporary/native resource terms and headroom explained; historical reason unknown with labelled inference, costs and reassessment owner/trigger. |

## Actual checks and limitations

Executed locally: `git rev-parse HEAD`, `git status --short`, hashes and complete before/after capture; `git show`/`git ls-tree` byte and regular-mode checks for all 45 pinned references; 43 local path/heading checks; `bash -n` on all four complete Bash blocks; exact original budget-span proof; full unaffected-line-span and delta proof; initial/final necessary-input comparison; `git diff --check -- docs/site/use/capacity.md` (exit zero). `local-checks.json`, `terminal-checks.json`, private check script and block files preserve actual checks and tool versions.

The first bounded pin check detected six out-of-bounds line ends inherited from report leads. Actual current line numbers were inspected and corrected. `initial-local-checks-with-corrected-pin-findings.json` retains that initial failure; final checks have no failures. Parsing, link resolution and object equality do not prove operational execution or complete independent semantic acceptance.

Not executed: any cluster command or product-native query, live reading, backup/restore/copy, projection/retention/deletion, credential qualification, host installation/preflight, provider/secret/network action, runtime test, build/generator, mutation/global gate, rendering/browser/publication, participant exercise, independent Source/Reader/Quality review, commit or push. No source-filter tooling was edited or tested. No other repository document, navigator or registry was edited. Full independent reviews and parent-owned registration/commit work remain separate.
