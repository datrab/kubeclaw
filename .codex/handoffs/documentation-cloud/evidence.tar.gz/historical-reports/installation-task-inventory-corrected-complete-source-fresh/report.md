# Independent fresh-context Source review — FAIL

Reviewed revision: `2a3fe02c93c9aa996d6e84feae7cd862d319ec22` on `docs/documentation-overhaul`.
Role: Source only, independent fresh-context read-only repository review. No inherited author report was used as evidence. This is neither Reader nor Quality acceptance and establishes no live result.
Repository: `/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04`.
Evidence directory: this directory, outside repository. Node v24.21.0; Linux environment recorded in before.json. No repository changes were made. Concurrent changes outside the assigned files existed before and after; this is not a clean-worktree/global acceptance claim. HEAD and all retained scope hashes were identical before/after.

## Material findings

F1 — Missing negative-proof limitation permits a false Worker Trust acceptance.
Documentation: `docs/site/use/worker-trust.md:263-269` and its pre-execution requirements at `:236-259`; installation final trust proof at `docs/site/use/install.md:1210-1230`.
Source: `tests/verification/live/worker-trust-cluster-e2e.sh:145` and `:175` (wrong-SVID verifier commands), `:38-52` (direct TLS rejection), `:190-199` (unconditional success declaration after probes).
The wrong-SVID commands set accepted=false, swallow fetch errors, and reject only response.ok. An unreachable proxy, TCP failure or HTTP 503 therefore satisfies the same probe as an authenticated authorization denial. Direct TLS tests also accept timeout/network errors as rejection. Earlier valid-identity probes do not identify the cause of a later negative probe: their caller/endpoint and timing differ. The page correctly separates cleanup and unit receipts, but supplies no corresponding limit for denial proof and no requirement for an independently captured TLS/allowlist rejection before treating paired denials as complete. Once lifecycle owners resolve the stated capture boundary, the current instructions still permit use of a success JSON that does not establish the negative security result.
Actual proof: `denial-probe.mjs` executes both exact extracted production command strings with only fetch stubbed. Both accept ECONNREFUSED and HTTP 503 and HTTP 403; both reject HTTP 200. This is synthetic unit evidence, not a cluster result.
Required documentation fix: describe these current verifier semantics, classify unavailable/timeout/5xx results as inconclusive, and require a maintained owner procedure to capture the actual negative peer/authorization observation paired with reachable positive control for each tested route. Until that is qualified, keep the installation/operational approval pre-mutation stop in force. No product-code change is authorized by this review.

F2 — `teardown` retained-state table contradicts installed recovery resources.
Documentation: `docs/site/use/maintenance.md:1203` says Keeps “Namespace and Secrets only”; `:1258-1272` asks for retained objects to match that column.
Source: `scripts/deploy.sh:1161` applies independently rendered PostgreSQL recovery resources. `scripts/render-postgresql-recovery.mjs:61-81,90-96,116-120` creates CronJob `litellm-postgresql-backup`, ConfigMaps `litellm-postgresql-backup-settings` and `litellm-postgresql-backup-script`, two CiliumNetworkPolicies `litellm-postgresql-backup` and `litellm-postgresql-backup-database`, and the backup PVC. `scripts/deploy.sh:2749-2825` removes Helm infrastructure and listed manifests, then deletes remaining PVCs, but never removes these separately applied CronJob/ConfigMaps/policies. Neither PostgreSQL Helm uninstall nor deleting its backup PVC removes those independently applied resources. Pre-suspending scheduled work does not erase its resource.
Actual proof: `extracted-teardown-fixture.sh` invokes exact extracted teardown helpers with logging-only kubectl/Helm stubs. It issues deletion of the backup PVC and no deletion of those recovery resources. Static source confirms their separate ownership. This establishes issued-call scope, not actual Kubernetes garbage collection or a live retirement result.
Required documentation fix: correct the table and callout to identify the actual remaining resource classes and selected exact recovery resources; add an owner-approved inventory/removal/verification boundary for these objects or explicitly record retention. Ensure final inventory includes ConfigMaps and CiliumNetworkPolicies. Preserve final backup/export proof before PVC deletion and prohibit blind repetition.

F3 — Full-file currentness failure in the linked canonical operation authority.
Documentation: `docs/site/use/operate.md:166` pins `package.json:42` to `1c30980c132e3ff0b45dc8eeaf4b46a37d6d77de`, but candidate HEAD has different complete package.json bytes. The command line itself remains unchanged; this finding does not allege a changed dispatcher or incorrect npm invocation. The explicit acceptance rule rejects relevant files changed since a narrow old pin, and the parent assignment requires full-file currentness. `package-pin-diff.txt` retains the complete committed difference.
Required fix: refresh this relevant pin/callout to a verified revision containing the current full file; retain historical executed test revisions separately.

## Individual assigned gate facets

These are Source-facet verdicts only. They do not award complete multi-role gate acceptance.

| Requirement | Source verdict | Evidence and limit |
| --- | --- | --- |
| A98-01 — canonical machine-readable task mapping | PASS | Authored/generated inventory maps installation/preflight, readiness, observation, control boundary, diagnosis, recovery, upgrade/rollback and retirement uniquely. Independent generation --check and semantic checker passed 13 tasks/14 required capabilities. No execution acceptance inferred. |
| A98-02 — complete procedure contracts | FAIL | F1 and F2 omit/conflate material verification and retained-state consequences; F3 violates linked evidence currentness. Supported start states, version limits and external authorities are otherwise explicit. |
| A98-03 — safe actual installation/preflight | FAIL | Existing-cluster start, absent runtime-selection stop, render/access/ownership gates, provider reconciliation before disposable writes, and separate full/reduced profile stops are accurate. However F1 leaves the mandatory live proof prerequisite incomplete after the stated lifecycle prerequisite is resolved; safe operational approval cannot be established by this verifier alone. |
| A98-04 — named readiness distinctions | PASS | Canonical operate section distinguishes rollout/Pod state, Service/ready EndpointSlice, smoke/dependency health, and terminal functional exercise/audit/receipts. Install defers comprehensive status until selected workloads are installed. This is source correspondence, not evidence any readiness level ran in a cluster. |
| A98-13 — self-contained authority/observation/stop/recovery boundaries | FAIL | F1/F2 affect the observations and unsupported capabilities a fresh reader must identify. No fresh-reader live exercise was performed by this Source reviewer. |

## Individual assigned catalogue requirements

| Catalogue ID | Source verdict | Reason |
| --- | --- | --- |
| OPR-001 — logical operator lifecycle | PASS | use/README.md leads from install to governed operation, diagnosis/recovery, maintenance and retirement; machine task map identifies one canonical authority per task. This navigation/lifecycle-source result does not certify the defective retirement claim. |
| OPR-002 — prerequisites, versions, preflight, topology | PASS | Existing Kubernetes and independent access start, no broad compatibility matrix, selected source-bound release, external storage/registry/host authorities and explicit unsupported boundaries are stated. |
| OPR-003 — Helm installation, GitOps handover, first verification | FAIL | Registry/client and release-selection steps are now canonical Site links and mixed ownership stops are accurate; F1 leaves final trust proof incomplete. Linked currentness defect F3 also remains. |

## Checked correspondence and positive scope

Read complete install.md (1292 lines), maintenance.md (1293 lines), worker-trust.md (426 lines), documentation quality standard (312 lines) and acceptance contract (489 lines); inspected acceptance fixtures and individual OPR-001/002/003 records. Inspected authored/generated task entries and canonical use index. Reviewed linked readiness section, Prism deployment/profile/agent trust and stop/retention boundaries, actual deploy setup/infra/role render/install/smoke/status/receipt/trust/teardown/main selection paths, complete live verifier and production receipt module, complete release materializer/deployment release/configuration verification/manual and automatic promotion sources, registry generator, Qdrant retirement source, Worker Core trust and Nova source-key/transport checks, Control dispatch/durable request/design-round/agent admission and agent runner behavior, and related configuration/test sources. The Source role did not perform the unrelated full Nova Reader/Quality audit or a complete Prism guide acceptance.

Receipt authority: fixed trusted-public-key path, external key realpath containment, Ed25519 SPKI fingerprint and matching pair qualification agree with the signer. Nova pipeline source-attestation keypair is distinct from the production operator receipt authority. The wrapper runs live design admission before unit transaction/signing; owner qualification must precede effects. Unit receipt cleanup booleans concern runner cleanup and deliberately do not establish cluster/durable design cleanup. Fixed-path receipt overwrite and uncertain effects are documented.

Full/reduced profile: boolish selection and guarded Prism function agree with source. False does not uninstall Prism, and the verifier always requires Nova/Buster/Prism Control/Worker. The page correctly stops completed installation before probe/workload mutation when required profile proof is unavailable.

Durable effects: accepted Control dispatch persists project/request and starts a design round/agent job; original request keys/responses are discarded by the live script; temporary asynchronous cleanup suppresses outcomes. Owner capture and reconciliation before effects, no inventing lost keys or resuming via new identities, independent UID/resource observation, provider effect retention and qualified follow-up conditions are documented accurately. F1 is an additional verification limitation.

Probe: present/absent/denied snapshots are separated, Pending allocation requires external-owner reconciliation, cleanup clearance is identity-bound, raw namespace DELETE uses a UID precondition, and provider absence remains separately required. No live CSI/provisioner proof was performed.

Release acquisition: source run/attempt/main/event authority, GitHub App dispatch/PR/merge boundary, generated values/configuration equality, code/image source commit distinction and documentation-only successors correspond to source. No selection exists in this candidate; no promotion/network verification ran.

Narrow source pins: source-pin-audit.json contains every 81 narrow link occurrences across assigned three pages, 43 distinct revision/file pairs, with valid ranges and complete file equality to candidate HEAD. linked-source-pin-audit.json extends this to all narrow links in canonical operate.md and prism-studio.md (19 and 82 distinct pairs respectively). Prism pins are current; operate package.json is F3. No external upstream browse/live verification was performed; product source and pinned-client source expectations remain bounded.

## Actual checks and exclusions

Executed, all exit zero: registry generator --check (read-only); operator-task semantic check; production receipt attestation contract; bash -n deploy and live verifier; bash -n all 44 top-level Bash fences across assigned pages. These prove inventory parity/structure, local receipt semantics and syntax, not procedures in a cluster. Each command/output/exit is retained as JSON. Two exact-source synthetic fixtures executed with side effects stubbed, as described in F1/F2.

Not executed: npm install/ci, mutation generators, release workflow dispatch, GitHub receipt network verification, render with a selected runtime receipt (none exists), cluster probes, setup/deployment, Worker Trust live, production signing authority provisioning, unit production execution, provider calls, readiness/functional live exercise, backup/restore/upgrade/rotation/retirement or external erasure. No fabricated PASS for those runs. No global gate acceptance, publication, language review or Reader result is claimed.

All report findings concern this candidate. They require correction and a fresh independent review of affected paths. An inventory check passing does not close them.
