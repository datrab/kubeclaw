# Independent complete Source review

**Verdict: FAIL.** Three material findings remain in the frozen procedure and its seven composed receiver records. This is Source review only; no Reader or Quality role, author self-acceptance, full publication, live retirement, or package acceptance is claimed.

HEAD `bcf1d131242913f98427dcb7e01050a7529139a2`. Frozen maintenance SHA-256 `8a009bedc8c7dbe17265f3b1ea04d34ae789d2aeaa0b485a7cc0fa524bdd8a06`; module `e91c3f85ee49f07e79aacabe185919120836979e6f4f5e61f8a62074b8c395c5`. The writer report was a locator only. Old review conclusions were not reused. Sixteen cached primary authority files were independently hashed and tag v1.35.0 resolved to commit66452049f3d692768c39c797b21b793dce80314e; three additional pinned kubectl primary files were fetched independently.

## Material findings

F1 — `docs/site/use/maintenance.md:151,429` and `scripts/remove-qdrant.sh:53–55`. The guide says the Cilium policy is deleted if its API is served. The script actually deletes only if its discovery pipeline succeeds and matches. A failed/Forbidden discovery runs inside an `if`, so Bash errexit does not abort it. Own exact-script fixture produced Forbidden, later PV patches/PVC deletes, no Cilium deletion, and exit0. The earlier guide discovery cannot guarantee later discovery success. Qualify the claim, explain this suppressed failure/zero-exit path and full-state reconciliation, and make clear that the operator sees redirected output after invocation; prose must not promise an immediate automatic stop. Product behavior need not be changed for an honest documented limit. `synthetic-results.json` retains exact calls/output.

F2 — `docs/site/use/maintenance.md:146–153`. Named access omits PV list/watch and PVC watch needed by deletion waits. Pinned primary `staging/src/k8s.io/kubectl/pkg/cmd/wait/delete.go:78–89` uses List/Watch after Get for positive-timeout waits; PVC deletion wait invokes it through `.../cmd/delete/delete.go:460–470`. StatefulSet deletion also waits. Add explicit wait observation privileges at appropriate namespace/cluster scopes and explain read-back after a denial following accepted deletion. Own installed kubectl v1.34.11 exact PV wait command (`--timeout=180s`) requested a PV collection list, received synthetic403, and was deliberately stopped by reviewer after2seconds; this is not a completed180second wait or live Kubernetes result. Evidence: `default-wait-results.json`; newly fetched primary hashes in `additional-primary.json`.

F3 — `scripts/docs-kubernetes-pv-selected-receiver-contracts.mjs:135`, `scripts/docs-api-reference.mjs:57–62`, `scripts/docs-generate.mjs:341–346`. All seven receiver records emit `maintenance.md#retire-the-former-qdrant-installation` unchanged when composed into `docs/site/reference/helm-values.md`. It resolves to nonexistent `docs/site/reference/maintenance.md`. Independent evaluation of the exact production renderer confirms seven wrong targets. Its whitelist rejects the correct `../use/maintenance.md#...` alternative. Fix target and safe renderer path validation together, check actual output target/anchor, and rerun current publication. This finding concerns composition, not a claim that stale root publication was rebuilt. Evidence: `navigation-results.json`.

## Complete claim assessment

| Claim | Scope lines | Source facet | Reason |
| --- | --- | --- | --- |
| task/scope | 127–140 | PASS | Fixed former qdrant/kubeclaw operation and independent source/admin location match producer6–18. No current Qdrant dependency invented. |
| tools/version | 139–145; README110–121 | PASS | Bash/Python/Helm/kubectl boundary is explicit; actual versions and external acceptance required. Upstream1.35 source expectations do not become compatibility claims. |
| access/wait | 146–153 | FAIL | F2: producer PVC delete --wait and PV wait require additional list/watch routes omitted from named privileges. |
| named resource sequence | 149–151;346–354 | FAIL | Sequence matches producer46–77 except F1: Cilium removal is conditional on successful discovery, and failed discovery is suppressed. |
| decommission prerequisites | 111–125;160–167;Controlled Retirement | PASS | Admission/exposure/uncertain-work reconciliation and independently retained final backup/restore/ownership precede destruction. Unknown owner/shared/incomplete restore stop is explicit. |
| external exclusion | 169–188 | PASS | External owner-maintained exclusion includes replacement/rebinding/policy competition. Text expressly says script has no fence. It does not represent suspension of storage deletion controllers as safe. |
| exact selector | 252–256 | PASS | Own exact published capture selects known names OR instance/name labels; legacy app fallback only if name key absent. Empty/null/different name labels excluded. |
| sanitized private capture | 192–250 | PASS | Fresh private absolute directory and standard-library field selection exclude arbitrary annotations and CSI credential reference. Own fixtures confirm sanitization. Storage handle retained privately. |
| source version capture | 204–206 | PASS | Source commit and actual client/server/tool outputs retained. Bound shell supplies fail-fast set-euo-pipefail from install181–218. |
| PV identity/driver/source | 262–279 | PASS | UID/version/reference/policy presence/value/class/CSI handle captured. NonCSI/migrated authority must be resolved by owner; no default class substitution allowed. |
| unbound/empty selection | 274–282 | PASS | No PV patch/wait for missing volumeName; PVC name delete persists. Owner must exclude pending provisioning; empty selection alone is no erasure proof. |
| original/current comparison | 284–299 | PASS | Captured row sets and fields compared, version changes reviewed, policy absent/null/different not silently accepted; observations explicitly non-atomic. |
| patch guards | 178–188;295–297 | PASS | Actual three tests check claimRef only, no PV UID/resourceVersion/prior-policy test; actual add replaces existing or adds missing policy. Name-only PVC delete explicitly distinguished. |
| destructive invocation | 329–344 | PASS | Single invocation redirects output and captures actual status via if, avoiding pipeline loss. Exclusion and unchanged owner-approved inventory are preconditions. |
| partial/uncertain result | 346–354;421–444 | FAIL | Most partial/uncertain outcomes correctly separated; F1 missing suppressed discovery path can leave later destructive effects despite diagnostic and zero status. |
| original-row observation | 356–377 | PASS | Queries use original names and UIDs, distinguish replacement/absence/API error. Own actual default kubectl accepts exact commands against read-only local API fixture. |
| events UID | 370–386 | PASS | PVC and PV original UID field selectors sent correctly by default kubectl. Event absence is expressly no success proof. |
| attachment/class/driver | 379–405 | PASS | Cluster attachment rows keyed original PV name with UID separately checked; class provisioning policy distinct from stored PV; missing attachment not erasure. |
| controller backend | 401–416 | PASS | Exact externally discovered controller namespace/kind/container queried; logs inspected privately and sanitized; non-Kubernetes equivalents owner supplied; absent driver-specific lookup is stop. |
| 422/admission/NotFound | 430 | PASS | Pinned patch handler403–417 distinguishes decoding/application422; server admission/update validation can reject after guards; earlier removals preserved. |
| response loss | 431 | PASS | No response cannot prove no write; original identities/policy/deleting state and owner handle reconciliation precede retry. |
| PVC failure/replacement | 432 | PASS | Absence, original terminating UID, replacement UID distinguished. No name re-delete prescribed. |
| PV timeout/finalizer/inuse | 433–435 | PASS | Released/controller/attachment/backend/finalizer outcomes separated; retry governed by owners; no force-finalizer workaround. |
| reconciliation/storage responsibility | moduleconditions;guide354,401–444 | PASS | Primary PV controller576–689,1178–1215,1321–1437,1495–1540 support nil/empty/matching-reference paths, migration/external responsibility, retries and backend-before-finalizer uncertainty. |
| rollback/recovery | 437–444 | PASS | Controller retries can continue while script stops. General partial-resume absent; policy restoration cannot recover erased data; verified retained media and owner restore required. |
| completion verification | 448–461 | PASS | Successful reads/no replacement plus separate owner disposal/retention receipts required; unexpected selected claims stop, do not widen scope. |
| retention/cleanup | 463–471 | PASS | External private evidence/backup/approvals/versions/status/original identities retained. Script temp inventory trap is not audit evidence. Exclusion release only after reconciliation. |
| reason/current citations | 473–491 | PASS | Producer comment is evidence for retention issue; current inferred motivation labelled, historical incomplete guards unknown, reassessment owner/conditions explicit. Pinned cited product bytes agree with current producer/module. |
| shared bindings/links | 18–26;install181–233 | PASS | Fail-fast restricted shell exports readonly kubeconfig/context/namespace, binding checks target identity and recovery does not use default config. Guide local prerequisite links resolve. |
| reference link composition | module135;reference57–62;generate341–346 | FAIL | F3: exact renderer emits seven bare maintenance.md targets under reference/helm-values.md. Relative resolution misses use/maintenance.md; safe relative alternative rejected. |
| registry/schema join | productscope762–800;coverage14–63 | PASS | Own actual registry/schema join yields all seven selected PV boundaries with matching authored records. Mechanical join is explicitly not semantic/live acceptance. |
| publication/current package status | generator/reference boundaries | FAIL | Current root publication remains stale; no full publication or package acceptance demonstrated. This is an explicit unexecuted boundary, not an additional prose defect. |

## Seven receiver rows

| Field | Semantics and six cases | Primary evidence | Composed navigation | Source row |
| --- | --- | --- | --- | --- |
| `$` | PASS | PASS | FAIL F3 | FAIL |
| `$.spec` | PASS | PASS | FAIL F3 | FAIL |
| `$.spec.claimRef` | PASS | PASS | FAIL F3 | FAIL |
| `$.spec.claimRef.name` | PASS | PASS | FAIL F3 | FAIL |
| `$.spec.claimRef.namespace` | PASS | PASS | FAIL F3 | FAIL |
| `$.spec.claimRef.uid` | PASS | PASS | FAIL F3 | FAIL |
| `$.spec.persistentVolumeReclaimPolicy` | PASS | PASS | FAIL F3 | FAIL |

The semantics were checked independently against API typed encoding/decoding, complete-PV update validation, bundled JSON Patch ordered guards/add behavior and PV controller paths. Root is a partial PATCH against an existing PV, not CREATE; spec/claimRef are traversed, leaf guards compare JSON strings without coercion, and policy add replaces or creates only that member. Nil/missing/empty/invalid cases do not claim malformed objects can be stored. All rows preserve uncertain-effect recovery and backend limits. Correct semantic facets do not erase their navigation failure.

## Executed checks and limits

Executed: nine exact published Bash blocks parsed with actual Bash; exact published private capture with real Bash/Python and synthetic kubectl/Helm; selector absent/empty/null/different legacy-label cases; captured identity/driver/handle sanitization; binding refusal before clients; actual script initial-precheck mismatch, patch rejection, lost-response simulation, PVC denial and PV timeout command-order checks; actual script suppressed-discovery failure; seven actual registry/schema joins; exact production navigation-function checks; actual installed kubectl observation commands against a localhost synthetic read-only API including original UID event selectors; actual installed kubectl PV wait collection request with explicit bounded reviewer interruption. No real cluster, Secrets, product mutations, backend operation, dependency installation, or commit was performed.

The synthetic API initially lacked resource shortNames and controller Pod responses. Those fixture defects were corrected before the successful default-client runs; they are not documentation findings. The initial test-script tracebacks were visible in tool output. Recorded successful results use corrected fixtures.

Go was not available, so the bundled patch library was source-inspected rather than executed. Full publication, true server authorization/admission, reconciliation, driver operations, data erasure, and restore were not executed. `EXEC-DECOMMISSION` remains unexecuted live/product evidence. OPR001 (operator lifecycle) and OPR008 (maintenance/retirement) were read as scope/catalogue requirements; this bounded review cannot award whole-ID or package acceptance. A98-06/09/13 Source facets fail on F1/F2; A98-10/11 selected seven semantic facets pass but composition fails F3; A911/A913 full aggregate acceptance is not established.

Initial/end scoped-input changes: ['scripts/docs-api-output-discovery.mjs']. Maintenance and receiver module stayed at their requested hashes. Supplementary sources discovered later have separate hashes; no claim of an initial hash for them is invented. Repository was already dirty with authorized external work, so this is frozen-input Source evidence, not clean-checkout final package evidence. All files in this evidence directory are included in the final artifact manifest; report and manifest are sealed by SHA-256.
