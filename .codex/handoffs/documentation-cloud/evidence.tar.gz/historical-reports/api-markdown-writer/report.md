# Generator literal Markdown correction — author evidence

Source baseline: `93ca75a4694084e5bc216f9aa9c7d52c13b965c6`.
Assigned source: `scripts/docs-generate.mjs` only. No main generated outputs,
source lock, inventory authorities, schemas, product behavior, checker, lint
rules or table core were edited by this author. No commit or push was made.

Release source SHA-256: `c079e493d1f8cee4e472f50ba999f734bab7c0663ed88bb3dafff91764b49979`.
Assigned patch SHA-256: `926cad22702a7033700c11fe830bfdf2881e0fed9f9a818dfb6e582b15a49603`.
Canonical private Helm output: 16,248,655 bytes,
SHA-256 `fabf5e28caa96c15017c1372d58d642fe65fa894e89d50413114acd06e87e900`.
Canonical private plugin output:
SHA-256 `0825434de1a254d810d66b1d696a70a0be4c6500ddc2d998134045731e06a061`.

Read requirements: documentation quality standard 07 in full; acceptance
contract (especially A98-10/A98-11, truthful evidence classes, navigation and
rendered anchors); CFG-009 source catalogue row; publication tooling contract
06; actual generator, table escaping and shared Markdown parser. Scope is the
literal rendering defect, not complete CFG-009/A98 acceptance or live evidence.

## Root causes demonstrated

The baseline archive generator with disclosed root-current inventory copies
reproduced 12 bogus regex links and 392 unresolved API links. It contained
170 literal API HTML ids; only 10 were visible to the actual shared parser,
and only 412 API links remained visible (`baseline-parser.json`). Baseline
output hash and inputs are pinned in the evidence manifest.

An initial correction confined to schema table descriptions/JSON and selected
values still failed. The actual parser paired the two-backtick opener in field
meaning `exact field ``.` at byte 12,402,434 with the empty-path heading
`ValidatingAdmissionPolicy: `` ` at byte 15,660,303, swallowing intervening API
anchors. This is independent of the single-backtick JSON issue. Nested JSON
schema descriptions also contain real backticks, so a single delimiter is not
safe. Failed first and second candidate evidence has been preserved.

Raw receiving conditions exposed Helm regexes such as
`[a-z0-9]([-a-z0-9]*[a-z0-9])` as Markdown links. Remaining raw field constraints
contained schema JSON regexes that produced five more false links after the
anchor correction. These were output defects; the checker was unchanged.

## Result

A shared literal encoder now shields HTML and Markdown characters, including
backticks, brackets, backslashes and pipes, before the existing table escape.
Schema descriptions and field meanings remain literal data; JSON constraints,
keywords and reference chains use encoded HTML code elements. The original
schema descriptions retain their line breaks. Selected values use encoded code
elements, and an empty string reads `"" (empty string)`. Empty API paths have
the descriptive heading `API object root`. Receiving template conditions and
raw field limits are literal output. Appended evidence and API contract links
remain real links.

Actual shared parser: **170/170 API ids, 913 API links, zero unresolved API
links, zero regex false links**. See `candidate-parser.json`.

Independent generated-data decoding uses installed `parse5`, not the generator
helpers. It verifies exact descriptions and recursively parses JSON data against
the unchanged inventory. It checks 2,158 schema nodes, 2,110 descriptions,
407 references, 4,723 JSON records, 3,813 Helm selected values (96 empty strings),
3,813 complete field meanings, 3,738 receiving conditions, 9,255 field limits,
1,467 payload values, 855 plugin defaults, 1,372 plugin constraints, and 15
compact swarm values. See `fidelity.mjs`, `fidelity.json`, and `fidelity.log`.
The first fidelity harness failure accidentally included later payload tables
in the final API section; that bounded extraction failure was corrected and
preserved as `fidelity-harness-first-failure.log`.

## Executed commands and status

All generation commands ran from MAIN with original invocation semantics:

```
KUBECLAW_DOCS_ISOLATED_MUTATION=1 node scripts/docs-generate.mjs --root /home/node/Documents/Codex/a98-evidence/api-markdown-writer/candidate --revision 93ca75a4694084e5bc216f9aa9c7d52c13b965c6 --allow-detached-source-root
KUBECLAW_DOCS_ISOLATED_MUTATION=1 node scripts/docs-generate.mjs --root /home/node/Documents/Codex/a98-evidence/api-markdown-writer/candidate --revision 93ca75a4694084e5bc216f9aa9c7d52c13b965c6 --allow-detached-source-root --check
node /home/node/Documents/Codex/a98-evidence/api-markdown-writer/probe.mjs
node /home/node/Documents/Codex/a98-evidence/api-markdown-writer/fidelity.mjs
node /home/node/Documents/Codex/a98-evidence/api-markdown-writer/candidate/scripts/docs-check-refs.mjs
node --test scripts/tests/docs-markdown-anchors.test.mjs
node --check scripts/docs-generate.mjs
git diff --check -- scripts/docs-generate.mjs
```

The unchanged baseline generator was invoked from MAIN through
`archive/scripts/docs-generate.mjs` with the corresponding `--root baseline`,
full revision and detached-source opt-in; its archived original script hash
is in `inputs.json`.

Generator `--check`: exit 0, byte-exact output current. Parser tests: exit 0,
6 passed, 0 failures. Fidelity checks: exit 0. Syntax and whitespace: exit 0.
Baseline, first/second candidates and final full reference check are **FAIL**
(exit 1), with their diagnostics preserved. The final checker has no Helm or
plugin output errors; it retains only three archive limitations:

- AP03 progress cites `docs/operations/`.
- AP01 baseline cites `docs/reference/`.
- Generated reference index cites `docs/reference/`.

Those directories exist as empty, untracked directories in MAIN and are absent
from Git archive. They were not recreated to turn this private gate green.
The root agent must run the actual final MAIN gate after independent review
and the authorized source/generated commit separation.

## Limits and review release

Actual published Markdown/HTML rendering is **UNPROVEN / NOT EXECUTED**.
The publication build copies Markdown, and this checkout has no installed
MkDocs, Python-Markdown or CommonMark renderer. No renderer was downloaded or
invented. HTML literal decoding and the actual repository parser are bounded
proofs, not a published-site render or reader acceptance.

The fixture uses an immutable 93ca Git archive plus root-current generated
inventory copies. `inputs.json` lists every copied inventory file's actual
byte count and SHA-256, including metadata. The candidate adds only the owned
source overlay. External node_modules and Git object availability use read-only
fixture symlinks. The author does not grant independent acceptance.

The assigned file is released for a fresh read-only independent reviewer.
Root owns MAIN regeneration, source commit and subsequent generated commit.
