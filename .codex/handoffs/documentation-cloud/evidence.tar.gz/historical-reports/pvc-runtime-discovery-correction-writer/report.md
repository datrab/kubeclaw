# PVC runtime discovery correction author report

Author only; not independent acceptance. Exclusive owned files were configuration-change-impact.md and diagnose.md. No other repository file was edited by this author. No commits, push, runtime edits or live operations.

R1 correction: added a concrete read-only discovery path from recorded claim/PV driver and workload node to CSI registration, candidate controller/node Pods, named containers, shared sockets, imageIDs, command/args, owner references, restart state and timestamped current/previous logs. Unknown installed digest, wrapper, identity, access or controller selection stops the procedure. Configured bootstrap intent is separate from installed-driver observation.

Added effective handle policy, flag/default/member distinction, archive-removal option, deletion-reference annotation precedence, StorageClass operation/default pair rules, invalid/empty/conflicting pairs and fallback token-resolution boundaries, and stored nodeStageSecretRef distinction. Existing bound-claim and ConfigMap explanations are preserved.

Important original-source finding: v1.20.0 accepts and passes DefaultOnDeletePolicy but does not assign it to the internal defaultOnDeletePolicy member. Full archived repository Go search found only the main flag declaration and pass, struct field declarations, and reads; no setter or constructor assignment. The empty member therefore selects the non-Retain/non-Archive removal branch when secrets exist. Creation validates supported values; direct deletion parses an existing handle without that validation. Documentation changed; runtime did not.

Worker/staging boundary: no invented host command. Required external read-only node/storage owner procedure and inputs are named, with a hard stop before retry/restart/unmount/deletion until exact staging target, mount namespace/current mount, worker state, server original/archive observations and conflict-free owner determination exist. Missing logs and missing API objects are explicitly insufficient proof.

R2 correction: canonical symptom index now routes PVC Lost/ClaimLost/ClaimMisbound, Released/reclaim uncertainty and FailedMount/timeout to distinguishing identity/driver checks and safe stops. Actual driver selection precedes SMB assumptions.

Scope: selected KubeClaw optional SMB chart branch and affected A98-02/06/10/11/13 reader slice. Read full quality standard, acceptance contract, independent fresh-reader FAIL report, operator reader fixtures and AP09.8 catalogue entries (notably OPR-002/006 and CFG-009/011/013/014). No applicable AGENTS.md at repository or direct ancestor paths. No upstream alternative catalogue or whole-package acceptance.

Sources: original public raw files and full fixed-SHA codeload archive for kubernetes-csi/csi-driver-smb 1bd5463f965be7b173ff1e7fc3c9a3c29972539c. Available earlier original-primary-blob-ledger provides Git blob identities; overlapping full archive files were verified byte-for-byte and Git blob SHA-1 against that ledger. New main/chart artifacts were compared byte-for-byte with the same archive and Git blob hashes retained. External-provisioner original source from core-current-storage-correction-writer at 986812da302189f395030a72c3099dc7302b4899 was read for precedence and token rules. KubeClaw bootstrap/values read from fixed Git blobs f0e3759e867eb9ac224a047b710f9397c16af22b and current checkout; selected content agrees.

Checks performed: local source inspection, full SMB policy symbol search, source range existence/bounds, local anchor existence, original byte/blob comparisons and git diff --check (exit 0). Commands were reviewed for kubectl shape and explained placeholders; not executed. Source evidence does not prove running images, credentials delivery, mount completion, erasure or restored application. Renderer, independent Source/Reader/Quality reviews, drift mutations and live operator tasks were not run. No acceptance verdict is granted.

Controlled-language author review: direct conditions/actions, component names and explicit stop boundaries; technical vocabulary includes PVC/PV, CSI, reclaim, volume handle, imageID, staging target and mount namespace. No formal ASD-STE100 certification claim.

Ownership released for both authored files after sealing this snapshot. Parent may now integrate and request independent affected-route review.
