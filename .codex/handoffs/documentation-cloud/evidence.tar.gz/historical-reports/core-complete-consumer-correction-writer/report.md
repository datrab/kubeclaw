# Core receiver consumer corrections — author report

This is an author candidate, not a Source, Reader, Quality, Astra, CFG-009, A98-10/A98-11 or global acceptance. The complete 272-record recursive core scope was retained and joined against the actual authority: ConfigMap 42, Namespace 49, PersistentVolumeClaim 89 and Service 92. All original record identities and all 1437 original case names remain. Thirty bounded cases were added, giving 1467 total cases. Existing Namespace discovery/finalization/status and ConfigMap cache/environment/subPath cases were preserved.

The sole repository change is `scripts/docs-kubernetes-core-receiver-contracts.mjs`. No product code, generation, commit, push, deployment or message to an external application was performed. Sibling authors' working-tree changes were left untouched. The branch observed during final checks was `docs/documentation-overhaul`, HEAD `39db3d80be95cf08e130e0452f630f05a4c2ecdc`; the authored candidate is an uncommitted file and its exact SHA is recorded in checks.json. No optional reader page was created. Existing ConfigMap reader references remain linked to configuration-change-impact.md#configmap-consumption. The common metadata mechanism export is reused as the single authority, with independently qualified core strategies, scope, reset/DELETE overrides and consumers.

## Source authorities and bounded results

The original pinned Kubernetes tree and full source archive were fetched independently from `66452049f3d692768c39c797b21b793dce80314e`. Previously authored reports and retained reviewer findings were navigation, not proof. Final source checks validate every one of 454 unique evidence URL ranges against retained original bytes, file length, regular Git mode and original tree Git blob SHA-1. Ninety-four distinct cited files are covered; each has byte count/SHA-256/Git identity in verified-original-sources.json. The exact excerpts are in source-ranges.json. This proves provenance and bounds; it does not itself prove every caption semantically.

Additional selected conditional authorities are:

- SMB chart/driver v1.20.0: `kubernetes-csi/csi-driver-smb` commit `1bd5463f965be7b173ff1e7fc3c9a3c29972539c`. The chart defaults select external-provisioner v6.0.0 and external-resizer v2.0.0. Overrides or another StorageClass select another authority; deployment is not inferred.
- External-provisioner v6.0.0: `986812da302189f395030a72c3099dc7302b4899`.
- External-resizer v2.0.0: `665104f4a4eb88b48edd185d2b5544a5c850ac17`.
- The pinned Kubernetes DNS addon selects CoreDNS v1.13.1; its Kubernetes-plugin authority is `coredns/coredns` commit `1db4568df6aaacda6ebbce87717156bd855f8103`. Actual DNS selection is not inferred from this addon source.

GC/admission now distinguishes syntactic reference validity, same-name/different-UID ownership, dependent scope, solid/dangling owners, graph-known blocking dependents, and exact update-on-owner-finalizers authorization. Root managedFields now distinguishes fresh typed null/omission, nonnil []/[{}] reset, existing-UID skip-wrapper behavior, create tracking probability, later before-first-apply initialization, subresource live ownership and Apply conflict/last-applied differences. False direct-wrapper outcomes were replaced, rather than left beside contradictory additions. Namespace cluster scope clears authored namespace before validation. Lifecycle fields distinguish typed decoder errors, create wiping, replacement preservation and actual DELETE. Namespace DELETE separately checks UID/version, first stores Terminating/deletionTimestamp, returns pending and requires both finalizer-list conditions before final removal.

ConfigMap adds manager selection/TTL/reference lifetime/immutable watch stop, projected-volume payload, optional fetch/key boundaries and preserves cache, atomic publication, environment creation and Linux subPath limits. The canonical existing reader page was inspected. No fixed refresh deadline or process environment reread is asserted.

PVC adds selected CSI provisioning selector rejection, local/cross-namespace source precedence, exact ReferenceGrant matching, clone/snapshot checks, populator handoff, SMB Block/snapshot restrictions, resize admission, external-resizer allocation/status progress and partial-write behavior, core and external condition-merge differences, CSI attach/stage/publish boundaries and PVC protection. SMB controller resize returns requested bytes without changing quota; Bound/capacity/mount is not data-integrity or recovery proof. New operation cases live at the applicable parent fields instead of being duplicated on every descendant. The exact resource request-map entry explicitly distinguishes the storage key from other keys.

Service adds nil-versus-retained-empty selector behavior, namespace Pod selection, named targetPort resolution including restartable init containers, endpoint Ready/Serving/Terminating, topology-annotation precedence, distribution fallback, family/VIP selection, iptables/IPVS/nftables affinity, local policy, health response, source-range versus NodePort distinction, conditional CoreDNS address/alias/error paths and default cloud-controller finalizer/provider/status/retry sequence. Proxy mode ingress is excluded from kube-proxy VIP rules. Default cloud status updates LoadBalancer only; it does not produce status.conditions transitions.

## Individual gap dispositions and remaining work

individual-gap-dispositions.json maps each of the nine original gap strings to every affected record and its current disposition. individual-record-dispositions.json contains all 272 identities, original/new case names, current cases, operation applicability, evidence and remaining gaps. The original blanket PVC/Service gap claims were narrowed where actual source qualification now exists. Available-source markers were not removed for unspecified later implementations.

The following source obligations remain explicitly open:

1. A selected custom populator, snapshot-controller/non-SMB driver or application recovery implementation needs its own complete pinned receiving contract. The qualified provisioner handoff does not prove that implementation exists or succeeds. The SMB unsupported snapshot route is a concrete source-backed restriction, not a waiver for other drivers.
2. The selected load-balancer provider or class controller needs its own address-announcement, external-filtering, port-error and status-condition producer contract. The default cloud-controller/provider interface does not prove those effects. Another dataplane/DNS implementation needs its selected authority too.

These residual gaps prevent an author claim of whole-scope source-proof closure. No missing source proof was reclassified as a product limitation. Actual component/image selection, authorization, admission, kernel/driver state, controller convergence, storage data and application recovery remain separate runtime evidence even for the source-qualified paths.

## Executed verification

- `node --check scripts/docs-kubernetes-core-receiver-contracts.mjs`: exit 0.
- Private check.mjs: exit 0. Actual apiReceiverCoverage/assertApiReceiverCoverage joins cover every recursive core path, not a summary or sample. Identity/order preservation, every prior case name, unique case names, required record members and focused corrected outcomes pass. Removing an exact-map-entry record for each of the four kinds produces the expected missing-contract failure. These are private negative checks, not a preregistered fixture acceptance.
- `node --test scripts/tests/api-receiver-coverage.test.mjs scripts/tests/api-reference.test.mjs`: exit 0, 12 tests passed, 0 failed/skipped. focused-tests.txt retains the output.
- Private source-check.py: final exit 0; all 454 URL ranges and 94 file/tree identities verified. An initial range check failed for two newly authored upper bounds (external-provisioner util.go 58 versus actual 55; EndpointSlice utils.go 410 versus actual 409). Both were corrected to the actual source extent before final checks.

The full quality standard, relevant acceptance contract A98-10/A98-11, CFG-009 catalogue finding, fixtures structure and documentation handoff requirements were inspected. No original CFG-009 Helm/GitOps fixture run, generator/publication run, clean Reader exercise, controlled-language independent review, API request, ownership conflict, DELETE, GC/controller, mount, DNS/network probe, storage operation or restore was executed by this author. Historical rationale is not inferred from source. The author does not grant any acceptance verdict.

The exact candidate module, imported mechanism module, patch, reports, exports, checks, excerpts and retained original source bytes are SHA-sealed in artifact-manifest.json. Repository file ownership is released with the candidate module SHA recorded in checks.json.
