# Independent fresh-context Deployment receiver Source review

Verdict: **FAIL**. Recursive path scope: **PASS**. This is Source-only component review, with no Reader, Quality, Astra, publication, global-gate, target-image, cluster or live acceptance.

Freeze: archive of `728a977ec4db75b0239092a1ad872b6242d9c16e` plus only `scripts/docs-kubernetes-apps-receiver-contracts.mjs`, SHA256 `edb2843af2c4b3c083b5b17ea401428abe042e5f8a01feda3249e276c8dc608a`. Kubernetes implementation and independently fetched OpenAPI revision: `66452049f3d692768c39c797b21b793dce80314e`. The module remains byte-identical. Other working-tree changes appeared during concurrent work; they are excluded by the archived baseline and private module snapshot. This reviewer made no repo edit, commit, push, cluster mutation or Secret read.

The full quality07 standard and AP09 acceptance contract were read, together with CFG-009 catalogue binding and relevant acceptance-fixture config families. A98-10 requires recursive fields/defaults/domains/owners/consumers. A98-11 requires full effective-value precedence and empty/conflict/Secret/invalid cases. These requirements are applied to this component's authored Source claims, without claiming AP09 gate completion or adding Go/live execution requirements.

The official OpenAPI was independently traversed through references, objects, list items and typed map values. All ObjectMeta branches at every depth belong to the separate metadata owner. The exact nonmetadata authored spec scope is1267paths plus `$`:1268records, with no missing, extra or unresolved boundary. All1268 records and6340 cases have individual binary dispositions. All347 original named workitems,201 distinct projected boundaries and36 contexts are reconciled from the original Source ledger as scope only. Prior verdicts and authorPASS were not inherited. The author report/manifests were used to locate source, then actual pinned code was read.

Record dispositions:1037FAIL and231PASS. The231PASS records are children of retained ephemeral-container items; the actual Pod-template validator categorically rejects a nonempty ephemeralContainers list, so these children never reach Deployment-created Pods. The ephemeral list/item boundaries still need actual decode proof. The1037FAIL records all have an unclosed actual decoder citation for explicit null, and many also have wrong semantics, ranges, missing domains or unproved downstream routes. Case outcome dispositions are separate from complete record acceptance:5103PASS and1237FAIL. A case PASS means its stated outcome agrees with the read family under its stated conditions; it does not override failed cross-field, qualification or record proof. All347 original workitems fail full Source closure.

Every selected cited range was read as implementation, including decoder, default setter, conversion, template validator, Deployment strategy/controller, kubelet/runtime and volume payload routes where present. `range-claim-dispositions.json` contains221distinct ranges and363individual evidence claims. Shared implementation families preserve each record/case/workitem verdict; they are not count/string-presence substitutes. No validator simulation was used as behavioral evidence.

## S01 — FAIL

Module: `20-28; generic constructors and alternative item/map constructors`. Null behavior is supported with decoder documentation L87–90, not the actual scalar/struct/pointer dispatch, custom UnmarshalJSON, list iteration and map writeback. This task explicitly requires those implementation contexts. Quantities cite their decoder but map/pointer context still matters.

Required correction: Bind each shape to actual dispatch and writeback; explain fresh zero-value semantics. No Go or live probe is mandated.

- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/vendor/sigs.k8s.io/json/internal/golang/encoding/json/decode.go#L453-L525)
- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/vendor/sigs.k8s.io/json/internal/golang/encoding/json/decode.go#L528-L620)
- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/vendor/sigs.k8s.io/json/internal/golang/encoding/json/decode.go#L754-L780)
- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/vendor/sigs.k8s.io/json/internal/golang/encoding/json/decode.go#L831-L850)
- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/vendor/sigs.k8s.io/json/internal/golang/encoding/json/decode.go#L884-L896)
- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/vendor/sigs.k8s.io/json/internal/golang/encoding/json/decode.go#L950-L1004)
- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apimachinery/pkg/api/resource/quantity.go#L731-L752)
- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apimachinery/pkg/util/intstr/intstr.go#L87-L95)

## S02 — FAIL

Module: `scripts/docs-kubernetes-apps-receiver-contracts.mjs:44;188-189;288-291`. Generic null outcome treats a string-map entry as absent. Decoder retains the key with an empty string; MatchLabels adds an equality-to-empty requirement. NodeSelector likewise retains a constraint.

Required correction: State null map entry remains key:""; distinguish absent key and empty map; correct null cases and matching/default consequences.

- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/vendor/sigs.k8s.io/json/internal/golang/encoding/json/decode.go#L754-L780)
- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/vendor/sigs.k8s.io/json/internal/golang/encoding/json/decode.go#L884-L896)
- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/vendor/sigs.k8s.io/json/internal/golang/encoding/json/decode.go#L991-L1004)
- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apimachinery/pkg/apis/meta/v1/helpers.go#L36-L73)

## S03 — FAIL

Module: `215; copied regular/init securityContext and Pod securityContext`. localhostProfile omission says nil pointer is required only for Localhost. The validator requires nonnil for Localhost and forbids nonnil for other types.

Required correction: Invert omitted/null prose: nil fails Localhost, nil is required for RuntimeDefault/Unconfined. Preserve present empty path behavior separately.

- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L5243-L5266)

## S04 — FAIL

Module: `638-645`. Projected Secret/ConfigMap branch omitted/null outcomes inherit direct Volume source text claiming emptyDir default. A missing VolumeProjection branch does not create emptyDir.

Required correction: Replace inherited branch omission/null cases with no source payload; retain at-most-one source rule and name/item/path checks.

- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L1159-L1367)
- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/volume/projected/projected.go#L259-L429)

## S05 — FAIL

Module: `649-653`. All four projected serviceAccountToken records point at core validation 1233–1248 (clusterTrustBundle selection), not token duration/path code.

Required correction: Cite token branch 1218–1230 for 600..4294967296, required path and conditional path validator; audience absence is established by plugin.

- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L1218-L1230)
- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/volume/projected/projected.go#L320-L354)

## S06 — FAIL

Module: `646`. Projected downwardAPI citation 1215–1232 omits downward item loop/collision insertion at1204–1217.

Required correction: Cite the actual downward projection item iteration and path-set writeback.

- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L1204-L1217)

## S07 — FAIL

Module: `scripts/docs-kubernetes-apps-receiver-contracts.mjs:653-659`. Trust name/signer pointer exclusivity and exactly-one claims cite1249–1295, excluding pointer presence/combination checks1232–1248.

Required correction: Include actual pointer presence/combination code while preserving selected name/signer/path validation citations.

- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L1232-L1295)

## S08 — FAIL

Module: `scripts/docs-kubernetes-apps-receiver-contracts.mjs:188-204;285;465`. Several narrow core-validation ranges are unrelated adjacent branches: nodeSelector4655–4659, runtimeClass4722–4724, overhead4729–4733, OS4736–4750, Pod resources4759–4788, Pod claims4774–4778, workloadRef4752–4754.

Required correction: Cite actual field dispatch and its helpers: label validation4652, RuntimeClass4704–4705, overhead4712–4713, OS4716–4725, resources4736–4758, workloadRef4728–4729. Establish gate/drop options rather than blanket unknown.

- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L4649-L4654)
- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L4704-L4713)
- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L4716-L4758)

## S09 — FAIL

Module: `scripts/docs-kubernetes-apps-receiver-contracts.mjs:41`. Specific minReadySeconds evidence664–672 omits its nonnegative validation at660.

Required correction: Cite actual minReadySeconds call and nonnegative helper.

- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/apps/validation/validation.go#L658-L662)

## S10 — FAIL

Module: `scripts/docs-kubernetes-apps-receiver-contracts.mjs:344; copied init container constructor380-400`. Exact environment field literals require the complete declared set2784–2794. Specific2793–2805 misses most of the set; general2761–2790 misses hostIPs/podIP. Resource exact divisors and enum constants similarly need declared literals rather than only helper invocation.

Required correction: Bind declared literal set, converter, validation and extractor separately; include exact unit lists for divisor claims.

- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L2784-L2794)
- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L2982-L3017)

## S11 — FAIL

Module: `scripts/docs-kubernetes-apps-receiver-contracts.mjs:98-105;465`. Milli precision literal is outside44–54 at43. Resource limits cite dispatch loop while quantity/name/hugepage semantic claims depend on uncited helpers.

Required correction: Cite default loop39–48 including literal -3 and helper implementations for negative/integer/hugepage/nonovercommittable/name semantics.

- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/v1/defaults.go#L39-L48)
- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L8113-L8122)
- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L7955-L7985)

## S12 — FAIL

Module: `scripts/docs-kubernetes-apps-receiver-contracts.mjs:200-230;271-285;366-375; affinity policy/key constructors288-340`. Some domains are described as supported values or ID validator without actual domains; exact named values/ranges cite helper calls rather than implementation/declarations. Examples procMount, labelKeys, inclusion policies, Windows bounds, restart-rule sets and group/SELinux policies.

Required correction: Name exact accepted enum values and numeric/string ranges with declaration plus selected actual validation path; retain conditional gate/old-object rules.

- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L8728-L8740)
- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L8849-L8861)
- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L8944-L8960)
- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L8424-L8427)
- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L3662-L3681)

## S13 — FAIL

Module: `scripts/docs-kubernetes-apps-receiver-contracts.mjs:19; qualificationLimits throughout34-699`. Explicit missing-source clauses and stale “children still need authoring” clauses cannot close A98-10/11. Scheduler fallback/selector merging/GtLt, security inheritance/imageUSER, restart rules, service-account/Priority/RuntimeClass admission, resource extractors, volume managers and storage consumers remain proof work.

Required correction: Replace each missing-proof clause with pinned actual consumer/precedence code and exact outcomes, or an actual documented product limit with Source, blocked step, safe action, owner and measurable follow-up. External image/backend/live state stays bounded honestly. No blanket unknown waiver or live execution mandate.


## S14 — FAIL

Module: `scripts/docs-kubernetes-apps-receiver-contracts.mjs:34`. Root claims status endpoint preserves spec and labels, but status strategy range is not provided; normal endpoint109–135 does not prove status endpoint.

Required correction: Add actual status strategy169–177 for this root claim. Report status child scope separately rather than silently approving it.

- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/registry/apps/deployment/strategy.go#L169-L177)

## S15 — FAIL

Module: `scripts/docs-kubernetes-apps-receiver-contracts.mjs:62;152-155;169-174`. Several exact defaults cite setter constant names while selected constant declarations are absent. File modes, grace30, default-scheduler and termination defaults must be backed by actual literal declarations.

Required correction: Link selected type constant declarations alongside actual setter route; retain existing correct downward/projected0644 declaration citations.

- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/v1/defaults.go#L211-L232)
- [Pinned implementation](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/v1/defaults.go#L66-L81)

## Qualification boundaries

The61distinct qualifications each have an individual classification and field-path list in `qualification-dispositions.json`. A statement that runtime image/backend/permissions/reachability/live results are unproved is an evidence boundary, not an asserted product success. By contrast, an explicit “requires source”, unknown scheduler fallback, absent security inheritance, admission precedence, missing manager semantics or stale “children still need authoring” clause is missing documentation/Source work. Kubernetes has implementations for those behaviors; lack of this review module's proof is not a documented product limitation. No blanket unknown waiver is used. A real product limit would need the actual implementation boundary, blocked action, safe action, owner and measurable follow-up. API acceptance remains distinct from runtime success.

## Adjacent status proof gap

Deployment status is outside this module's author scope, but its17recursive boundaries remain a visible adjacent **FAIL** proof gap in `adjacent-status-gap.json`. This is neither a request to add them to the spec owner nor an approval to hide them. The root status endpoint claim independently needs its actual status strategy citation(S14).

## Saved proof and actual checks

`record-case-dispositions.json` preserves all1268individual rows and6340cases with findings, conditions, qualifications, schema shape and actual source families. `original-workitem-dispositions.json` preserves all347names and required contracts; `original-boundary-dispositions.json` and `original-context-dispositions.json` preserve original mappings. `scope-check.json`, `independent-spec-paths.json`, pinned source manifest, archive/module/standard snapshots, exact range claim ledger and read excerpts retain reproducibility. `executed-and-nonchecks.json` records actual checks and skipped classes. Node syntax/import, source hashes and independent scope reconciliation passed; they do not prove semantics. Source corrections require fresh independent re-review of affected routes. No rendering, global gate, full mutation duplication or live execution was done or claimed.
