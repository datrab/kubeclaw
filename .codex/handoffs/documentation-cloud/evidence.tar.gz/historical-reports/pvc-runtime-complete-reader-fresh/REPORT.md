# Independent PVC/SMB reader review

Terminal result: PASS for the bounded reader/documentation criteria below at be78787633d774e9fd2a2ff401311499a555156d. This is one READER identity only, not Source, Quality, whole gate, catalogue or global acceptance. No author writes occurred.

Reviewer: /root/pvc_runtime_complete_reader_fresh. Fresh task context; no previous authoring contribution or author evidence used. Product tree has unrelated dirty generator drafts; all reading used immutable Git blobs exported to snapshot, never those drafts. Upstream bytes were fetched directly from pinned raw GitHub URLs into private upstream; manuscript author check claims were not treated as execution evidence.

## Contract and scope

Read full 07-documentation-quality-standard, full AP09-acceptance-contract (including 2026-10-10 product scope and live operator deferral), full AP09-acceptance-fixtures. Inspected generated catalogue AP09.8 records, especially OPR-001/002/006/007/008, CFG-001/009/011/013/014. These are context bindings, not full individual requirement acceptance. A98-02/06/10/11/13 are gate IDs, not catalogue IDs.

Read entire configuration-change-impact (753 lines), canonical diagnose front matter/authority/order/evidence/symptom routes (1-225), connected operator entry/version/binding/install independent-access, operate readiness authority, reference entry, store/retention ownership, maintenance decommission/controlled retirement, recovery preconditions/nonnegotiable/group/node-loss/independent-access boundaries. Unrelated dependency fault exercises and other chapters do not become accepted by this bounded review.

Published reader route means immutable docs/site reader content and links. No review directory, package README or chat answer was used to solve any reader decision. Home diagnosis entry leads directly to Observe and Diagnose; Symptom Index makes Lost, Released and FailedMount concrete. Reference entry also reaches change impact directly. The route does not depend on search.

## Individual bounded criteria

### A98-02: PASS (bounded reader aspect only)

Prerequisites/authority/version/place, explained placeholders, ordered reads, expected fields, hard stops, evidence and no cleanup requirement are available. Version mismatch selects owner contract, never guessed defaults.

Evidence: docs/site/reference/configuration-change-impact.md:651-753; docs/site/use/install.md:156-233; docs/site/use/README.md:134-150. Fix: none. Executed: independent reading and supplemental synthetic decisions. Unexecuted: deployed procedure, full registered fixture, full gate run.

### A98-06: PASS (bounded reader aspect only)

Observable Lost/Released/FailedMount routes reach distinguishing binding/driver checks and safe next action; failure diagnosis does not start with assumed SMB or restart.

Evidence: docs/site/use/diagnose.md:14-70,193-206; docs/site/reference/configuration-change-impact.md:499-753. Fix: none. Executed: independent reading and supplemental synthetic decisions. Unexecuted: deployed procedure, full registered fixture, full gate run.

### A98-10: PASS (bounded reader aspect only)

Within this PVC/SMB subset the significant omission/default, claim/PV/class/driver distinction, relevant controller flag, handle and secret references are visible. No full recursive inventory or generator acceptance is granted.

Evidence: docs/site/reference/configuration-change-impact.md:423-655. Fix: none. Executed: independent reading and supplemental synthetic decisions. Unexecuted: deployed procedure, full registered fixture, full gate run.

### A98-11: PASS (bounded reader aspect only)

Reader can independently select chart versus API empty, stored handle policy versus current SC, constructor effective member versus flag, deletion annotation versus SC/default pair and node staging refs. Supplemental manual conflict/empty/invalid cases completed; no execution of driver/API/credential paths claimed.

Evidence: docs/site/reference/configuration-change-impact.md:423-451,602-655. Fix: none. Executed: independent reading and supplemental synthetic decisions. Unexecuted: deployed procedure, full registered fixture, full gate run.

### A98-13: PASS (bounded reader aspect only)

Fresh-context reader reaches concrete readonly actions, exact unsupported proof and owner input/stop/resumption conditions without authors. Meaningful safe action remains at host inspection boundary; missing supported host capability is truthfully declared.

Evidence: docs/site/reference/configuration-change-impact.md:651-753. Fix: none. Executed: independent reading and supplemental synthetic decisions. Unexecuted: deployed procedure, full registered fixture, full gate run.

## Supplemental independent Find / Understand / Act exercises

These manual synthetic cases were newly constructed for this review and are explicitly supplemental. They are not READER-OPERATOR-01 through -04 and not a registered product execution. Every case has a separate PASS/FAIL entry in reader-exercises.json.

- S01 PASS — Empty chart storageClass versus API empty. Chart storageClass="" omits storageClassName; stored claim may receive cluster default. API storageClassName="" instead selects no class. Actual stored claim/class/PV driver must be read; optional SMB declaration cannot substitute. Evidence: docs/site/reference/configuration-change-impact.md:423-451. Fix: none.
- S02 PASS — Multiple/default-absent classes. Exact true annotations select candidates, newest timestamp then ascending name. No default is unresolved; later assignment possible. Stop class lookup for empty stored class; do not invent SMB. Evidence: docs/site/reference/configuration-change-impact.md:441-451. Fix: none.
- S03 PASS — Bound claim volumeName missing. ClaimLost/Lost is a binding observation. Stop PV commands if name empty, retain UID and earlier record, request owner data observation before replacement. Evidence: docs/site/reference/configuration-change-impact.md:499-511; docs/site/reference/configuration-change-impact.md:657-670. Fix: none.
- S04 PASS — Named PV absent. Missing cache/PV yields ClaimLost; NotFound and Lost do not prove erased data. Stop replacement and preserve retained PVC/PV identities. Evidence: docs/site/reference/configuration-change-impact.md:499-511. Fix: none.
- S05 PASS — PV claimRef UID differs. Same namespace/name with a different UID is another lifetime. ClaimMisbound/Lost warrants stop before claimRef edits or replacement; storage owner inspects data. Evidence: docs/site/reference/configuration-change-impact.md:503-511; docs/site/use/diagnose.md:204. Fix: none.
- S06 PASS — Missing claimRef. Controller can repair binding with a later retry after write error; reader is not authorized to repair by manual claimRef edit. Evidence: docs/site/reference/configuration-change-impact.md:504-511. Fix: none.
- S07 PASS — Ordinary release removal. Role/artifact retention annotations preserve claims under release removal; database Argo retention differs from Helm keep. Explicit broad teardown deletes retained PVCs, requiring backup/ownership/destruction approval. Evidence: docs/site/reference/configuration-change-impact.md:453-467; docs/site/use/maintenance.md:687-717. Fix: none.
- S08 PASS — PV Released Retain versus Delete. PV Retain prevents reclaim; Delete hands to actual external provisioner, independently of SMB onDelete. Finalizer/attachment/error evidence precedes any proposed cleanup. Evidence: docs/site/reference/configuration-change-impact.md:469-497; docs/site/reference/configuration-change-impact.md:521-550. Fix: none.
- S09 PASS — SMB no secrets/Retain. A driver success may preserve directory and cache handle; absent PV does not prove erasure or recoverability. Record reference separately from actual successful credential lookup. Evidence: docs/site/reference/configuration-change-impact.md:548-566. Fix: none.
- S10 PASS — SMB Archive. Existing archive can be removed before failed rename if flag true. Preserve original/archive observations and stop automatic replay; directory on same share is not independent backup. Evidence: docs/site/reference/configuration-change-impact.md:554-569; docs/site/reference/configuration-change-impact.md:722-753. Fix: none.
- S11 PASS — SMB empty policy/default flag. Fourth nonempty handle segment wins. Current StorageClass cannot replace stored policy. Empty policy uses empty internal member because constructor does not copy DefaultOnDeletePolicy; with secrets it enters removal even when flag says Retain. Evidence: docs/site/reference/configuration-change-impact.md:602-620. Fix: none.
- S12 PASS — Deletion credential precedence. Both annotations present select references/no secrets; one empty does not fall back. Missing annotation key consults SC. Specific pair wins over default; incomplete/duplicate/empty/unresolved token is stop. Name tokens differ from namespace; deletion fallback has no PVC annotations. Evidence: docs/site/reference/configuration-change-impact.md:623-646. Fix: none.
- S13 PASS — Node credential reference. PVC route uses stored nodeStageSecretRef, independently of deletion references; inline ephemeral volume-context lookup is not PVC fallback. Evidence: docs/site/reference/configuration-change-impact.md:647-655. Fix: none.
- S14 PASS — Runtime discovery. Starting from actual PV smb driver and workload claim Pod/node, read CSINode driver and candidate Pods. Inspect UID/owner/node, named smb and csi-provisioner/registrar, socket args/env/shared volume, image and imageID, command/args, restartCount/current and previous logs. Registrar is not mount worker. Unknown identity, wrapper, ambiguity, absent log evidence means stop/owner deployment record. Evidence: docs/site/reference/configuration-change-impact.md:594-600; docs/site/reference/configuration-change-impact.md:671-718. Fix: none.
- S15 PASS — Mount timeout uncertainty. 110s wait does not cancel mount worker; lock releases. Read-only API/log discovery narrows incident but cannot prove host stage or worker stopped. Stop retry/restart/unmount/deletion; obtain approved owner inspection with exact request-correlated staging path, correct mount namespace/source/target/options and process state. Evidence: docs/site/reference/configuration-change-impact.md:571-590; docs/site/reference/configuration-change-impact.md:722-742. Fix: none.
- S16 PASS — Safe meaningful completion at product boundary. Available action is collect non-secret identities, policies, logs, refs, preserve backups and give exact owner request. Platform operations owns missing host procedure, storage owns share checks. Resume only on timestamped observations/no conflicting work/data-preserving determination; cutover stops without isolated application recovery. Evidence: docs/site/reference/configuration-change-impact.md:722-753; docs/site/use/recovery.md:77-92; docs/site/use/recovery.md:523-545. Fix: none.

## Verification and limits

Executed: immutable Git export and per-blob SHA-256 manifest; direct pinned upstream downloads (14 unique files/53 narrow links); manual source reading needed to understand selected defaults/branches; 16 independent supplemental manual synthetic decisions; static affected-route local link/anchor check: 215 checked, zero unresolved. Linux; Python 3.14.8; Git 2.54.0. All successful shell checks exited zero; initial wrong guessed contract filename exited 128 and was corrected via immutable tree discovery before review.

Unexecuted: browser/server or rendered-output publication check; layout/accessibility/search; Helm render, Kubernetes reconciliation, any cluster command, Secret fetch/value inspection, host mount/process inspection, live SMB/CSI operation, injected timeout, deletion, erasure, backup/restore/cutover/retirement. READER-OPERATOR-01..04 remain deferred product validation under immutable contract; no result is asserted for them. Generator mutation/full semantic Source approval and language/architecture Quality approval are outside this identity.

Source understanding was independently obtained from pinned Kubernetes binding/default classes, SMB DeleteVolume/handle/NewDriver/flags/NodeStage/timeout and original controller/node chart containers/socket, and external-provisioner credential selection. Download coverage alone is not Source approval; only the explicitly inspected branches inform reader decisions.

No material bounded reader failure remains. The unsupported host inspection capability is an explicit product boundary with named owners, exact missing proof, useful safe evidence collection and a hard stop; it is not repaired by invented host commands. Earlier failure reports were not consumed as acceptance evidence. Full reference and all affected diagnostic/storage routes were considered afresh.

Terminal release: review work complete; private evidence sealed by SEAL.json and SHA256SUMS. No requested bounded work remains; no global acceptance is granted.
