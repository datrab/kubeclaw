# Independent bounded source review — frozen cluster metadata and fixture candidate

Decision: FAIL. This is an incomplete semantic review with an explicit unreviewed set, not a complete source acceptance, Reader/Quality review, publication acceptance, CFG-009 completion or package acceptance.

Frozen revision: bc55a98da5897ed97ffdc0fdf9703fb9f04cd14b. Private Git archive was reconstructed from that exact commit, then private Git initialized/fetched/reset to permit revision-bound link checks. Shared product tree was never edited, committed or deployed. No applicable AGENTS.md was found in the repository or ancestor paths by discovery. Source role remained independent of authors and other reviewer roles.

## Actual reviewed scope

The complete new 124-line fixture workflow was read, together with changed use README navigation, controller storage/fixture backlink passages and the fixture AP08 catalogue operationNote. Its direct provider, storage-policy/counting, caller preflight, basic readiness wait, output and uncertain apply/cleanup claims were compared with independently downloaded originals pinned at 28e4f1b6a2e736dc936b48847cf422dcc0a25da2. The complete linked Buster suite/controller/runtime task contents and their full original entrypoint/grant/controller chains have NOT been independently source-verified; downloading/reading a subsection does not constitute that verification.

The approved product/upstream boundary in 07-documentation-quality-standard.md and the binding contract rules were read. This review preserves the distinction between selected typed CRD registration, KubeClaw-owned Buster instance schema and unused foreign-instance alternatives. No blanket upstream exclusion is approved by this report. AP09 fixture JSON was parsed and its categories inspected; the entire fixture catalogue was not independently executed or fully reviewed.

Exactly 197 requested records are enumerated in semantic-ledger.json: cluster configuration 53, selected metadata 136, selected typed envelope 8. Eight envelope records are PASS for their bounded typed identity semantic claims after reading raw upstream meta/json serializers, REST create/update handlers, literal null decoding and CRD typed storage construction. Four retained-null item records are FAIL (F2). The other 185 remain explicitly UNREVIEWED for complete semantic acceptance, although selected shared defaulting/validation/strategy/status/delete mechanisms were inspected. unreviewed-set.json lists each unresolved record individually. Pending is 185, not zero. No completeness is inferred from the six structural tests or a source URL resolving.

Primary retrieval: 62/62 immutable GitHub originals downloaded independently into primary/. primary-provenance.json records URL, path, byte length and SHA256 for each file. Kubernetes revision is 66452049f3d692768c39c797b21b793dce80314e; Tailscale ingress consumer revision is 53a0d659afa51835dd7a9283873cca44261454f8. A fetched primary file is not automatically a reviewed file.

## Material findings at the frozen revision

F1 — Catalogue cleanup claim omits retain branch. docs/blueprint/AP08-catalogue-guidance.json:197 unconditionally states “Cleanup calls release and requires a successful response.” Original provider.js:134-144 at 28e4f1b6a2e736dc936b48847cf422dcc0a25da2 returns without invoke when retentionMode is retain (line 136). This conflicts with the newly authored fixture guide, which correctly distinguishes delete and retain. Fix the note to state that delete invokes release and checks ok:true, while retain performs no provider release and remains governed by expiry/controller policy. Root reported a later correction; no later revision was reviewed here and the frozen FAIL remains.

F2 — Retained-null list objects inherit removal outcomes. scripts/docs-kubernetes-cluster-configuration-receiver-contracts.mjs:36 supplies generic nullValue and line 43 propagates it into the null case. The rules[] (line 49), subjects[] (line 64), CRD versions[] (line 84) and printer-column[] (line 90) records append their omission/removal wording instead of their actual zero-item rejection. The same records already describe retained null as rejection under emptyValue, producing contradictory dimension evidence. Original decode.go:988-1004 retains ordinary value structs at zero under null. Original RBAC validation.go:103-125 requires verbs/groups/resources; :217-255 requires subject name/kind. Original apiextensions validation.go:405-463 validates versions and exactly one storage flag; :821-845 requires column name/type/jsonPath. Fix each retained-item nullValue explicitly: null preserves a zero list item and applicable required-field validation rejects it. Root-null $ wording also needs separation from absent request body. Root reported a later correction; it is not accepted by this frozen report.

F3 — Three genuine reader anchors remain missing. docs/site/understand/buster-namespace-controller.md:67 links api-field-2d7090db945e3299f8e7; :72 links api-field-e5b8003a74b771aad5b3; :158 links api-field-446072fe13a4ef01e5dc, all in ../reference/helm-values.md. The independently run repository reference checker rejects all three at the frozen commit. Fix generation/discovery or links to the correct canonical published authority and recheck the frozen replacement revision. Do not repair their history by retroactive PASS.

Repository archive observations (separate from F3): AP03-progress.md:150 references docs/operations/; blueprint/ap01-baseline/README.md:54 and generated/reference/README.md:8 reference docs/reference/. Neither directory has a frozen tracked Git entry. The shared tree contains empty directories that Git archives do not preserve. These additional reference-check diagnostics are archive/history effects, not additional published reader findings.

## Bounded acceptance points

A98-02 FAIL: complete linked task/authority source verification remains pending.
A98-03 FAIL: full selected runtime/caller/controller/storage prerequisite chain remains pending.
A98-04 FAIL: direct basic wait and output distinctions inspected, but full controller observation contracts remain pending.
A98-06 FAIL: source-verified complete failure/recovery path pending; F3 breaks required linked reference authority.
A98-09 FAIL: F1 falsely describes retain cleanup; cleanup/retained-volume distinction otherwise appears in the new guide.
A98-10 FAIL: 185 requested semantic records and conditional discovery applicability remain pending; eight envelope PASS records do not close the inventory.
A98-11 FAIL: F2 contradicts null versus omitted receiving semantics; complete precedence/consumer coverage pending.
A98-13 FAIL: complete supported task source trace remains pending and F3 is unresolved. This is Source review, not a fresh Reader execution.
CFG-009 FAIL: full selected configuration semantics, discovery and complete authored procedure authority have not been independently established.
Other A98 gates were not assessed; no N/A approval or full-gate PASS is issued.

## Checks and limits

check-results.json records exact final commands, exit codes, tool versions and dependency method. Cluster focused tests and workload focused tests each pass six tests. check-buster-guides.mjs passes its static gate. docs-check-refs.mjs exits nonzero with F3 and the separately classified archive-directory diagnostics. Earlier missing-dependency/no-Git check logs are preserved and are not counted as successful reproduction. Dependency files were copied privately from the preinstalled shared node_modules; no clean npm-ci reproduction is claimed. No live API request, cluster create/update/status/delete, controller reconciliation, volume provision/mount/reclaim, Buster production run, deployment, reader exercise, full publication build or mutation suite was performed.

The report and listed evidence are hashed by SHA256SUMS. These hashes seal this report revision for comparison; they do not turn pending semantic work into PASS. The next review must finish each unreviewed record and the entire linked Buster entrypoint/authority/consumer/task chain against originals, then independently inspect the corrected revision and rerun affected checks.
