# Helm collection semantics source repair

This is an implementation report, not independent Source, Reader, Quality or acceptance approval. Root owns integration, source commit, main documentation regeneration and the subsequent fresh reviews. No main documentation outputs, navigation, publication inventory, matrix, contracts, mutation runner, commit or push were changed by this writer.

The six authorized source files in the repository now exactly match the isolated checked files recorded in `source-provenance.json`. `source.patch` contains only those six changes. The isolated input tree is a clean `git archive` of product revision `ec2a42ed215a2fa7dbd3172ef70ef446084963a9`, with the source repairs overlaid and a dependency-directory symlink. Root's later status-only revision `601205ab14d2de927be52c75f5445e9432800639` does not change the product charts used here.

## Implemented behavior

The canonical Helm renderer publishes every nonroot scalar, list and map. Discovery assigns a collection an exact local template/receiver contract, pinned API envelope, pinned upstream template contract, exact source-only loader contract, or a nonempty structural grouping with its actual nested consumers. Empty unqualified collections fail closed. Groups name their child paths and retain their complete child contracts; they do not claim arbitrary extra keys or independent runtime switches. The renderer preserves receiving conditions and default-selection proofs. Selected collection values show size/empty state without copying access lists or credential bytes.

Collection precedence is recorded separately from receiving meaning. A later Helm list replaces the earlier list; `[]` removes earlier items. Maps merge recursively, so `{}` retains previous keys. Null requests removal before chart validation and template evaluation. No assertion that a chart accepts null, empty values or arbitrary variants follows merely from those merge rules. Named local collection contracts retain chart guards and exact chart schemas; Pod variants retain exact pinned Kubernetes API schemas. Prism collections retain `minItems`, `uniqueItems`, maximum counts and enabled-mode constraints. API manifests and source loaders do not inherit Helm semantics.

Local discovery now follows serialized parent collections and their descendants, helper collection items, and exact range-variable boundaries. This fixes both missing parents and the Prism resources/requests/limits discovery omissions while avoiding `$provider` matching `$providerId` or `$route` matching `$routes`. Local receiver equality still checks the complete actual Helm consumer set; source loaders/producers remain separate runtime consumers. Unknown authorities, exact source hashes, schema/type contracts, ownership, original scalar evidence gates and all existing consumer checks remain enforced.

Exact scalar repairs apply to defaults and overlays through their owning chart:

- GitOps revision requires exactly 40 lower-case hexadecimal characters before Argo CD receives it.
- Empty ESLint, Semgrep and swarm JSON overrides select the bundled `.Files.Get` document. Existing lint files are preserved unless `swarmConfig.overrideOnRestart` selects overwrite; swarm JSON is copied unconditionally on init startup.
- Empty gateway URL falls back to `http://127.0.0.1:<gateway.port>` for `OPENCLAW_GATEWAY_URL`.
- The four Prism image policies allow `IfNotPresent` and `Never`; `Always`, an empty string and explicit null fail their owning image schema. Envoy's separate enum remains separate.

Two SPIRE selector maps have exact collection contracts pinned to the already vendored SPIRE chart 0.30.0 archive and its actual controller-manager selector template. Empty `{}` retains the non-raw template's `NotIn` exclusions; it does not become an unrestricted/disabled selector. The archive/member hashes and token checks remain enforced independently of the original external scalar snapshot gate.

K3s `configs` and `mirrors` are bounded to their actual tracked node-configuration generator and source inspector. The repository has no proved deployment path for this file. Empty/omitted/null input gives the inspector no entries, while generated operator node configuration is a separate source. The inventory explicitly marks these source-only values as unused by a checked-in deployment; it makes no unproved containerd version, default-endpoint or uncached-CRI claim.

Argo CD whitelist semantics use chart 10.8.0's deployed application version 3.5.2 and the official controller evaluator at immutable commit `e258ee23c3e52266d407572f4bcdfe7d9ed36cb5`, `pkg/apis/application/v1alpha1/app_project_types.go:367-385`. Explicit empty namespace whitelist denies namespaced kinds; omitted/null namespace whitelist permits them subject to blacklist/destination rules. Empty/absent cluster whitelist grants no cluster kinds. Official source evidence is saved as `argocd-tag.json` and `argocd-app-project-types.go` (SHA256 `88020a2125baee5551050dc0dc7ecb199a8fc8512ab414bf26754000a0ca42f3`).

## Complete collection accounting

`collection-accounting.json` and `.tsv` identify every source/document/path. The publication harness compares this exact set against the independent reviewer discovery set, verifies every source section's complete field-row count and all 1,613 collection rows, and checks that all 410 structural groups have children and consumer traces. It evaluates the actual `renderHelmValues` function without running the main generator. `helm-values-preview.md` is an isolated review artifact only.

There are 67 source files, 100 YAML documents, 2,200 scalar leaves, 1,613 nonroot collections, 35 empty collections and 3,813 published nonroot field rows. All active/collection blockers are zero under strict inventory generation, an implementation gate result rather than semantic acceptance.

Final inventory statuses: 286 local Helm collection authorities; 410 nested structural containers; 849 typed API structural envelopes; 64 API operational collections; 2 SPIRE external collection authorities; 2 source-only K3s loader collections. The 35 empty collections are 26 local Helm, 5 operational API, 2 SPIRE and 2 K3s collections. Role accounting is 332 bound collection contracts, 20 receiver-bound qualified groups, 410 nested structural groups, 849 typed API envelopes and 2 source-only loader collections. These roles are also recorded per path in `publication-results.json`; neither structural/API envelopes nor receiver-bound grouping maps are presented as independently configurable product switches.

Registry 1,091 entries = 805 original scalar contracts + 286 collection contracts (212 maps, 74 lists). There are 170 exact chart/path collection keys, or 139 unique chart/path keys with array indices normalized to wildcard notation. A previously quoted 137 was an intermediate counter without a retained definition and is superseded by these explicit durable definitions. The retained 1,077 stage artifact contains 805 scalar + 272 collection entries and 133 normalized chart/path keys. Its 14 missing entries are the 12 Prism control/studio/worker request/limit maps across defaults/overlay plus the two codex-ops `networkPolicy.apiServerCIDRs` and `rbac.namespaces` arrays. `source-provenance.json` lists those exact additions. Counts establish accounting only, not independent semantic acceptance.

## Clean canonical observer inputs

The configuration source inventory now owns the seven tracked files under `contracts/agent-observability/v1/src` and the tracked observer `sync-contract.mjs` producer. Each canonical source records the exact ignored runtime import path and byte-for-byte materialization relationship. Generated observer copies are not source authorities. Actual runtime scanning canonicalizes and deduplicates these paths; a present copy must match the tracked source bytes, and a missing canonical source or corrupt copy remains a hard diagnostic.

`observer-repro-results.json` proves full three-inventory byte identity between the clean archive with no ignored observer copies and the same tree after executing the tracked producer. It records all seven canonical hashes, runtime copy paths, producer provenance and inventory hashes. A deliberately corrupted isolated copy fails with `CONFIG_MATERIALIZED_SOURCE_DRIFT`; the fixture was restored. Runtime import tests run after sync, as required by the package build boundary.

## Terminal verification

All checks below completed successfully on the isolated repaired source tree:

- Real authority generation: `node scripts/generate-local-helm-authorities.mjs`; check: same command with `--check`, exactly 1,091 authorities.
- Complete inventory generation: `node scripts/docs-configuration-inventory.mjs --out-dir ../final-inventory`; full strict `--check` against that output after observer sync, including offline external chart authority verification.
- Actual schema semantic checks: `--check-schema-semantics-only` (recursive rules, registry defaults, approval/direct-command collections and new Secret authority).
- Actual runtime consumer semantic checks: `--check-runtime-consumer-semantics-only` (Prism, observer, Redis, Ops origins, dispatch/trust identifiers and OpenAPI bodies; no live/network calls).
- Existing local Helm boolean check: 93 actual boolean contracts/guards.
- 20 isolated Helm render assertions (`render-results.json`, `collection-precedence-results.json`): GitOps groups/revisions, collection rendering, overlay empty/null precedence, Prism pull-secret minimum, each `Always`/empty policy rejection, bundled config and gateway URL fallback.
- Eight additional policy shape assertions: each Prism `Never` policy actually renders (ingestion explicitly enabled/sized for its positive case); each explicit null fails schema (`prism-policy-shapes-results.json`).
- Actual renderer path/row/structural-consumer accounting and canonical observer absent/present/corrupt-copy proof.
- Syntax checks for all five modules and scoped `git diff --check`.

ENV and Secret semantic gaps are now discovered together before their combined fail-closed rejection. This preserves both complete authority requirements and all exact source lines/Secret identities instead of allowing an unknown ENV producer to hide the same unknown Secret binding. `env-secret-diagnostics.mjs` reproduces the root's exact failing Helm Secret fixture through the real isolated runtime inventory. Both missing contracts are present in the error; a separate ENV-only fixture also remains rejected. Results/logs are durable. The mutation runner and its regex assertions were not changed.

Intermediate failures were resolved, not counted as passing checks: early maintenance discovery exposed the Prism resource descendants/codex-ops arrays; their exact bindings were fixed. An initial runtime consumer check in the clean archive failed because ignored observer import copies had not yet been materialized; the final runtime check after tracked sync passes. An initial positive ingestion policy test omitted ingestion enablement and therefore could not assert a rendered policy; the final positive test explicitly enables/sizes ingestion and passes. An overlapping isolated mutation/regeneration attempt was stopped and rerun sequentially before any final outputs were accepted.

## Integration and remaining boundaries

The permanent authority JSON is an input, not a documentation output. It pins values-source bytes, chart templates, exact schema contracts and receiver/default/condition proofs; it has no documentation source-revision lock or generator commit SHA. GitOps revision values inside it are selected product configuration data, not the documentation provenance revision. `source-provenance.json` captures all generation source hashes. Commit the six repaired source/input files first, then regenerate revision-bound main documentation at that new source commit in root's separate generation step.

No full mutation suite or main documentation generation was run by this writer. Root's immutable old full suite terminated at the now-reproduced ENV-preemption/Secret-diagnostic case; the new source still needs root's fresh full mutation suite and independent Source/Reader/Quality reviews. No live cluster, uncached CRI or production rollback/restart was exercised. The evidence is bounded to checked-in pinned authority and meaningful isolated renders/runtime checks. These limitations do not represent a claim of completed acceptance.
