# Authored operator safety correction

Author role only. No Source, Reader, Quality, INF-012, OPR, AP09, or global acceptance is granted by this report. Fresh independent reviews must inspect the whole affected memory journey. Repository HEAD during this work: a629fcae2c6567e48f50c592c5c9455b4c853461, branch docs/documentation-overhaul. The shared working tree has unrelated concurrent changes and is not a clean acceptance checkout.

Exclusive repository write: docs/site/use/diagnose.md. No product/runtime file, commit, push, deployment, provider call, Secret access, host/app image change, full generator or mutable broad suite was performed. All harness fixtures and evidence are private to this directory.

Frozen page SHA-256: 45c1b0c2300d7b3306b4ccdb5e4c286b233a95c3809227b557b4ef3769768870. Frozen exact bytes: diagnose-frozen.md. Focused patch: authored-scope.diff. Source/input hashes: scoped-input-hashes.json. Final check records: checks.json. Artifact manifest: artifacts.json. No change to diagnose.md is authorized by this author after this freeze without a new correction/review cycle.

## Corrections

F1: Every shown cluster-binding block now explicitly exits on assertion failure. Every reusable helper that sends cluster commands explicitly returns 126 before its first command when binding fails, including restoration traps outside the memory fault. The memory and policy helpers do not depend on errexit; policy removal and policy-absence reads explicitly preserve failure. A binding failure is not classified as a provider or memory error.

F2: The operator selects and records the actual consumer Pod/container and controller owner chain. The entire affected memory/LiteLLM exercise uses that exact Pod name and container, not Deployment exec. The frozen snapshot records Pod UID, owners, image reference, image ID, container ID, restart count, mounts and volume sources. Every owned exec checks the frozen identity before and after. Actual CLI status selects the workspace and SQLite database path; source identity freezes workspace/source roots, database path, parent filesystem identity and configuration digest. Note creation/deletion uses the recorded actual workspace and an exclusive receipt with its exact path and content. Path/source checks surround every later memory call and note operation. Unknown or replacement identity creates a persistent stop file. Database inode is deliberately not treated as fixed because the derived index can be replaced.

The page requires a stable disposable consumer controlled by its workload owner. It explicitly states that kubectl exec has no atomic Pod UID precondition; before/after comparison cannot prevent a replacement between check and API request. If stable controlled ownership cannot be established, stop before baseline. A mismatch invalidates the operation instead of accepting another consumer. Observed imageID is not source/image attestation.

F3: The mandatory symptom index now routes observable memory indexing, empty/stale recall and embedding-timeout symptoms to the actual memory CLI consumer path. A separate readiness/model row distinguishes LiteLLM readiness, the embedding route, and managed reasoning. Consumer credentials, authenticated gateway SecretRef resolution, gateway/database, Vertex/model/quota, vectors and freshness remain distinct.

F4: The observer polls its own spawned negative process-group ID with signal 0. Direct-child close clears the CLI deadline only; it does not cancel group observation or escalation. Remaining members get SIGTERM, SIGKILL after five seconds, and a final bounded observation after ten seconds. The receipt explicitly records group ID, child close, code/signal, deadline, and quiescent true/false. Unknown membership exits 125. A persistent local stop file is removed only after a final valid quiescence receipt and unchanged Pod identity. Missing receipt, exec loss, interruption, remaining group, changed source or Pod identity block every following stateful memory call, note deletion and reindex. Route policy restoration remains a narrow independent administration action; post-disconnect group reattachment is unsupported because numeric PID reuse cannot prove ownership. Independently detached descendants are outside this group check and require owner proof before the task. No broad kill, production restart, remote abort, or fake receipt is supplied.

Defined SecretRef, builtin backend, semantic-vector result and quiescence in ordinary words. Preserved OpenClaw v2026.9.4 commands and source semantics, managed provider/model/SecretRef selection, deadlines, retry bounds, fault classification, source-versus-SQLite distinction, end-consumer recovery and narrow cleanup.

## Authority read

Read the full documentation quality standard and acceptance contract, catalogue INF-012 and OPR rows, and immutable EXEC-FAIL-LITELLM fixture. Read the actual sealed Quality report and its extracted primary failed-binding reproduction. Read the current chart initialization, managed-memory sync, selected config/workspace PVC versus emptyDir branch and memory settings; route model config and Cilium policy; primary pinned OpenClaw CLI manager acquisition/close and SecretRef handling, status, index/search and SQLite/cache selection; query retry policy and wrapper. Primary source files and hashes are recorded separately. The older authors' reports establish navigation only, not independent acceptance.

Read official Node 24 process/group and detached-child API documentation and the kubectl exec contract. Published links accompany these mechanism claims. The docs explain a missing atomic UID precondition rather than inventing one.

## Executed offline checks

Executed check.py against final page bytes. Node v24.21.0; GNU Bash 5.3.9, Linux x86_64, Alpine/musl environment.

- All 29 page Bash blocks passed bash -n. All 24 extracted inline Node modules passed node --check. These are syntax checks, not target-image execution.
- Extracted published helper functions stopped before mock kubectl for failed assertion under set +e in plain, conditional and command-substitution calls. Each helper's status was individually required to be 126. No real kubectl was called.
- The extracted owned-exec/Pod guard received a replacement UID snapshot and stopped with 126 before mock exec. It retained the stop file.
- A missing remote observer receipt returned 125, retained memory-stop, and prevented a second call from reaching the mock exec.
- The exact published observer module was extracted to observer-extracted.mjs. For real local process probes, only /app/openclaw.mjs was replaced with a private fixture path. It was invoked with the same node --input-type=module -e argument semantics. No OpenClaw behavior is asserted by these substitutions.
- Normal fixture exit returned 0 with direct-child close and quiescent true.
- A one-second deadline fixture ignored SIGTERM. The observer escalated to SIGKILL after five seconds and returned 124 with quiescent true and child signal SIGKILL.
- A direct child spawned a group descendant with ignored stdio/SIGTERM, then closed. The observer retained escalation after close, killed the descendant, and returned 125/quiescent false because the killed descendant remained a zombie pending harness reaping. The fixture confirmed no running descendant remained. The page requires a safe stop for this conservative unsupported result; it does not claim direct-child close means quiescence. The private Python harness acted as a Linux subreaper and reaped only its own orphan fixture.
- git diff --check scoped to diagnose.md passed. Eleven applicable local references resolved to repository paths/anchors; no built-route proof is inferred.

Harness extraction development initially exposed an extraction regex and file-mode argv mismatch in the private harness; these were corrected. Final checks execute the unchanged published observer apart from the explicitly recorded fixture path substitution. Final logs and checks.json are authoritative for the scoped results.

## Remaining limits

No target-image CLI or source/image attestation, live cluster/Cilium, provider delay, retry-count observation, semantic query, remote cancellation, consumer recovery/cleanup, publication renderer, broad gate, mutation catalogue, clean-reader live run, or final acceptance was executed. EXEC-FAIL-LITELLM remains unexecuted. A fast network rejection still cannot satisfy its registered timeout scenario. The actual image may lack the CLI or gateway resolution; the page names those blocked steps and the platform/OpenClaw maintainers' required follow-up.

The PID/group observer proves absence only in its controlled container namespace and group scope. It cannot recover a lost observer safely, identify escaped independent work, prove Vertex abort, or guarantee atomic Pod UID selection. Those limits have explicit stops, retained evidence and owner follow-up. Independent Source, Reader and Quality reviewers must decide whether the corrected complete memory journey meets the applicable documentation requirements.
