# Network receiver correction 4

Author: root. Independent review of prior candidate9d164f remains FAIL; this release is not acceptance.

NF01: Added actual token dispatch, pointer traversal, Boolean/object/array/string target rejection and saved-error return, preserving existing numeric/null proof. Exact receiver declarations were read directly for the21 affected selector/TLS/status records; the Protocol named string declaration is included. Array/list element dispatch and map element reset/writeback are attached as actual mechanism proof.
NF02: IPBlock update caption now cites actual strategy86–90, where normal/update error lists are combined.
NF03: Ingress class create-only registration now cites actual constructor61–65 with Create at63.

All122 record identities, all707 cases and every non-evidence property equal the frozen previous candidate.94 unique attached immutable ranges were bounded and checked against verified primary SHA-256 files. Mechanical coverage checks reject extra paths and validate every evidence/case shape; missing shared metadata remains explicitly named. Nine focused helper tests passed before the final additional map/list evidence; final complete exports and mechanical joins then passed. No generator/publication or Go/API/CEL/live acceptance was executed.

New complete Fresh-Context Source review is required; Source correctness does not replace Reader/Quality/Astra acceptance.
