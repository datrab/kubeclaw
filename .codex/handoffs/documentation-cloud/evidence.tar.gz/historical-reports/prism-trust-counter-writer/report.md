# Prism trust and counter correction — author handoff

Date: 2026-10-10. Identity: `/root/a98_prism_trust_counter_writer`. Role: AUTHOR only. This report grants no independent Source, Reader, Quality, package, or live acceptance.

## Ownership and candidate

Exclusive writes were limited to `docs/site/use/prism-studio.md` and `docs/site/reference/glossary.md`. Existing dirty corrections were preserved. No product, gate, schema, register, generated output, dependency installation, commit, push, cluster, or deployment was changed by this author. Private scripts and evidence are under this directory. The shared tree was dirty at assignment; it is not presented as a clean accepted commit.

Assignment HEAD was `9d085bb20af0cc70201cc41801011b63c626301c` on `docs/documentation-overhaul`; HEAD at final checks was `1c2265bef1c2f5d1fb5f4dd376af2c4f378b3a01` following separately owned root commits. Product source pin remains `ec2a42ed215a2fa7dbd3172ef70ef446084963a9`. All pinned authorities used by these two pages equal final HEAD and current worktree bytes. Historical execution pin/date statements remain unchanged; byte correspondence does not establish a historical test execution.

| File | Frozen before SHA-256 | Released candidate SHA-256 | Lines |
| --- | --- | --- | --- |
| `docs/site/use/prism-studio.md` | `3b774234c53c2b4c846987958932692614a6c402399ae09439d3c37424b17f95` | `a4738017edbbb039cb12767e95daff922a686815cd36ebbe834d1e167b44dbaf` | 2272 |
| `docs/site/reference/glossary.md` | `1e9892cc26de4a66b1cf5f5c8d32a68a61348376927c15607ed1579243e49eeb` | `25aa9f129ccaaa67badedc48cf73c3aa7693b0af851d03a3ea193d43115bc1db` | 274 |

`before/`, `candidate/`, `candidate-manifest.json`, and `author-change.patch` retain the exact overlays and this author's delta. No other author edits were copied over or reverted.

## Required reads and correction scope

Read the full quality standard, full acceptance contract (including targeted read of the middle section when a combined output truncated), all 2111 original Prism lines in contiguous chunks, all 274 glossary lines, the complete independent fresh Source report, and the root boundary log. Read the OPR-010 catalogue object and full relevant fixtures: post-documentation product-validation classification; READER-OPERATOR-01–04; READER-QUALITY-01; EXEC-PRISM-JOURNEY; EXEC-FAIL-POSTGRESQL. Demo is outside this ownership scope. Source reads include the full nonce producer, full agent job routes and runner, full Control configuration, exact Control commit guards, chart mode/identity producer, defaults/agent overlay, original health/lifecycle sources and readiness test, and contextual agent-route documentation.

- S1: Added adjacent definitions for `durationMs`, `active`, `open`, and `pending`. Duration is nonnegative rounded elapsed operation time, with idle timing starting at error handling. Active counts admitted nonce dependency operations at event creation before failure decrement; capacity is four and rejection does not increment. Open is total pool clients including idle and checked-out clients; pending is pool acquisitions waiting for a client. Explained event-time scope, missing versus zero, log bounds, repeated health comparison, and lack of leak/current-health/native-job proof. Narrow producer links and the worker callout claim match this explanation.
- S2: Added a canonical SPIFFE admission prerequisite and source callout before submission. It requires SPIFFE-enabled Control, matched agent path, exact selected trusted Agent identity, delivery/proxy checks, and separately established claim plus both commit permissions. Service defaults disabled and agent overlay enabled remain distinct from a matched release. CSI registration remains an unconditional, separate prerequisite. Applied this boundary to the canonical journey start, Before You Start, selected-values/trust settings, agent configuration, render inspection, health interpretation, status map, initial dispatch, initial directions, child rounds, natural-language revisions, capabilities, and completion checklist.
- S2 diagnosis/recovery: Added `Agent work blocked by trust`, exact disabled-mode errors, identity-error distinction, selected-mode/error correlation, release/trust/Prism ownership, blocked step, measurable closure, retained original identities, and no replay/trust-mode flip to clear active errors. Connected all three pending-agent symptoms to that path. Unknown durable outcomes still stop for Prism reconciliation; health does not resolve them.
- Root reader-boundary findings: Replaced glossary CSRF/job-fence/ARIA internal source-inspection bookkeeping with reader-useful execution scope. Adjacent source pins and all required evidence fields remain intact. Browser/private ingress, running agent completion/commit, and capture/publication remain unverified rather than hidden.

| Assigned ID | Changed/preserved scope; author result only |
| --- | --- |
| OPR-010 | Corrected full initial/child/revision governed agent path through prerequisites, status, diagnosis, stop/recovery, completion. All thirteen original interruption distinctions remain byte-identical. |
| A98-02 | Added explicit agent trust/permission prerequisites and meaningful retained-counter interpretation. Preserved supported-version link, bound execution location, permission/UID/mode/bounds/secret filtering, retention and cleanup. |
| A98-04 | Kept HMAC health independently valid, separated it from agent admission, and kept process/native/nonce/functional signal distinctions. Added event-time scope instead of treating counters as current health. |
| A98-06 | Corrected pending direction/child/revision diagnosis and exact trust errors; added counter meanings next to nonce phase/code owner diagnosis. Preserved revision-conflict and Nova-rejection uncertainty rules. |
| A98-12 | Made unavailable agent claim/commit step and owner closure explicit throughout the journey. Preserved separate human approval, publication, Nova import, abort limitations and cleanup. |
| A98-13 | Made prerequisites and retained diagnostic fields understandable without hidden knowledge; no invented operator repair command or live result. Independent fresh Reader recheck remains required. |

Language method: project controlled-language drafting under the full quality standard and ASD-STE100 Issue 9 principles; direct component subjects, conditions before actions, explicit scopes, defined workload identity/pool counters, one canonical trust recovery section, links at each affected action. This is an author language check, not formal ASD certification or independent Quality acceptance. Technical terms retained include SPIFFE, CSI, workload identity, job fence, nonce, pool client, checked-out client, idempotency key, revision, and result commit. Existing definitions and narrow authority links remain available.

## Executed checks

Environment: Linux container, Node.js `v24.21.0`, GNU Bash `5.3.9` on x86_64 Alpine/musl, Python 3. Cloud runtime skill read; no `environment_status` tool exposed. No network/remote infrastructure used. Exact scripts/logs below are retained.

| Check | Command and exit | Observation and limit |
| --- | --- | --- |
| Initial full boundary | `node scripts/check-site-reader-boundary.mjs`, exit 1 | `before/boundary.log`: glossary196/224/248 plus status-source704 failure. Root separately corrected status-source prose. Parent's original three-line log retained as `before/root-boundary.log`. Failure is not erased. |
| Source pin/current bytes and shell syntax | `python3 harness/verify.py`, exit 0, final log `verify-final.log` | 209 source links, 70 unique pin/file authorities, regular Git files, in-bounds ranges, equal final HEAD/worktree bytes; all 14 exact Bash blocks pass `bash -n`. `source-links.json`/`shell-syntax.json` retain details. Syntax is not kubectl execution. |
| Local links/anchors | `node harness/anchors.mjs`, exit 0 | 89 local links/anchors resolve, `local-anchors.json` and `anchors-final.log`. Uses repository Markdown parser; no rendered/public-route proof. |
| Original counter/agent guards | `node --test harness/controls.test.mjs`, exit 0 | Three bounded controls passed: counter snapshots/admission limit/pre-decrement reporting/idle elapsed time; disabled mode rejects internal claim/read/finish before body/auth work; exact configured identity handed to permission check before claim. `controls.log`. Pinned original source copied; only imports redirected to explicit stub pool/auth/job dependencies. Seeded pool counters prove field binding, not real pg pool behavior. Authorization stub is not certificate/proxy proof. |
| Original health and exact safe filter | `node harness/health-filter.mjs`, exit 0 | Healthy HMAC, native-unready, nonce-failure, healthy SPIFFE/skipped nonce query, and safe-log filter controls passed. `health-filter.log` and `fixture-results.json`. Original pinned health/lifecycle/config modules used; contract/trust/native attempts and nonce result are explicit stubs. Exact documentation probe uses wrapper mapping fixed loopback8080 to a private ephemeral port; no claim of selected-image8080 or installed exec. Original filter retains counters and excludes injected secret fields/unknown native messages. |
| Preparation assertion failure retained | `python3 harness/prepare-health.py`, initial exit 1, later exit 0 | Initial comparison to prior probe fixture differed only by trailing newline; `prepare-health-initial.log` retains assertion failure. Final comparison disregards terminal newlines; fresh extracted probe/filter bytes remain in harness. `prepare-health-final.log`. This was harness comparison failure, not a product/health failure. |
| Final full boundary | `node scripts/check-site-reader-boundary.mjs`, exit 0 | `boundary-final.log`: Reader-site boundary check passed. This is a full shared-tree outcome at that moment, not an independent semantic verdict. No own-file findings remain in this output. |
| Whitespace | `git diff --check -- docs/site/use/prism-studio.md docs/site/reference/glossary.md`, exit 0 | No whitespace errors in owned pages. |
| Preservation and release snapshot | `python3 harness/preserve.py`, exit 0 | `preservation.log`: all 14 Bash blocks, all 13 interruption table rows, and entire fixed-build1228 stop section are byte-identical to the supplied candidate; exact final hashes copied to candidate. |

Additional navigation/tool failures were not behavioral checks: guessed `configmap-control-trust.yaml` and `scripts/docs-markdown-anchors.mjs` did not exist; actual `configmap-worker-trust.yaml`/`scripts/lib/docs-markdown-anchors.mjs` and workload identity producer supplied authority. One patch application failed its final context match and made no edits; the corrected patch was applied afterward. Initial diagnostic `rg` used an absent glob. None was recorded as source success.

## Unexecuted evidence and remaining obligations

Not executed: selected runtime materialization/deployment/render, cluster binding/RBAC/JSONPath/custom columns/UID races, actual installed exec/log collection, real nonce SQL/replay or pg pool behavior, agent certificate/proxy delivery and actual claim/direction/revision commit permissions, model completion, external launch reconciliation, native attempt/journal/ownership/repair/cleanup, post-repair functional check, browser install/capture/recovery/publication, full local Prism aggregates, full mutation package, rendered publication routes, live Studio-to-Nova, or independent Source/Reader/Quality acceptance. All live permission and journey boundaries remain explicit in reader prose. Historical checks retain their original dates/revisions; they are not rerun claims.

No further material documentation finding was discovered by this author correction. S1, S2, and glossary boundary changes are corrected candidates, not self-closed acceptance findings. Parent must obtain fresh independent Source, Reader, and Quality rechecks of these immutable bytes. No package PASS or live PASS is claimed.

## Explicit file release

Author work is complete for these hashes. Both `docs/site/use/prism-studio.md` and `docs/site/reference/glossary.md` are explicitly released for the parent to freeze and for fresh Source/Reader/Quality reviewers. This author will make no further changes unless the parent issues another correction assignment. Commit/push and any generated ownership remain with the parent.
