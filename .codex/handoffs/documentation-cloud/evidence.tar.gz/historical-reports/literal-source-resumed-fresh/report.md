# Fresh independent bounded Source review

Revision: `7e413cf63e82fdc6104184a6be25f35420b15d80`.
Reviewed repository: `/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04`.
Reviewer: `/root/a98_literal_source_resumed_fresh`.
Completed scope: the complete affected generator source, literal encoder and its actual table/parser consumers; complete API-schema authority module and lock inputs; actual fresh generated-output literal fidelity, API navigation, and authority corruption diagnostic reproduction. This is a Source review of the two corrections, not complete recursive operational interpretation of all 170 API boundaries or Reader/Quality acceptance.

**Bounded Source verdict: PASS.** No defect found in the assigned literal correction or authority diagnostic correction. Published Markdown-to-HTML rendering remains **UNPROVEN**. The complete reference checker remains **FAIL** because the private archive lacks three legacy directory references; it reports no error in either affected generated page.

## Inputs and review method

Read quality standard 07 in full; publication/tooling contract 06 in full; acceptance A98-10/A98-11/A98-14; CFG-009 catalogue and completion-matrix row; complete `scripts/docs-generate.mjs` and `scripts/docs-api-schema-authorities.mjs`; the actual `table` implementation in `docs-generate-core.mjs`; actual shared parser `scripts/lib/docs-markdown-anchors.mjs`; unchanged reference checker and authority lock files; publication `build()` implementation. No applicable AGENTS.md was found in the repository, task workspace, or their ancestor directories.

The author report and diagnostic log were leads. Results below came from freshly executed commands on an independent fixture. The fidelity harness was inspected, copied, re-rooted to this fixture and tightened: absent-description sentinel, complete limit sequence, complete condition sequence, and complete plugin constraint sequence are checked, rather than only membership. JSON records use recursive deep equality; HTML literal text uses installed parse5 decoding. No generator helper is used to obtain expected fidelity text. Supplemental boundary checks extract and execute the actual immutable helpers, with the unchanged actual table, and decode independently.

`immutable.tar` is a Git archive of the stated revision (SHA-256 `36e180e8b3a50d94b2833cb30344dba0a3f454d506a077dd2944f2ce2d48d718`). `archive/` contains that archive plus 15 disclosed copies of actual current `docs/generated/inventory/*.json`, followed by private generated outputs. Every copied input has byte count and SHA-256 in `inputs.json`; they are not presented as immutable-commit generated data. Source revision is explicitly passed as the reviewed 7e413 commit. The actual generation command runs from the original MAIN invocation root with both isolated-mutation environment opt-in and `--allow-detached-source-root`. Read-only links provide node_modules and Git-object availability. MAIN source, inventories, schemas, checkers and generated outputs were never written by this reviewer. No commit, push, network access, refresh or full suite execution occurred.

Source hashes:

- `scripts/docs-generate.mjs`: `c079e493d1f8cee4e472f50ba999f734bab7c0663ed88bb3dafff91764b49979`.
- `scripts/docs-api-schema-authorities.mjs`: `dd10b7fcfb3b1cdc33782e690adca368d25665ac01dbc6e420299139c95809e4`.

## Reproduced findings

The literal encoder at generator lines 113–127 encodes HTML metacharacters and Markdown punctuation before the unchanged table processing. Real newlines become `<br>`, then the independent decoder reconstructs the original newline. Recursive API descriptions and JSON fragments at lines 377–381 receive this encoding. Selected values/defaults, payload values and compact swarm values use literal code; an empty string is explicit `"" (empty string)`. API root headings avoid empty backtick spans. Helm field meanings, limits and receiving conditions preserve literal data while separately appended evidence and API links remain actual links.

Fresh actual output has **170 raw API ids, 170 parsed ids, 170 unique ids, 913 API links, zero unresolved API links, zero false regex links**. The plugin output also has zero false links. Both inline and reference-link consumers were used. The unchanged shared-parser test file passes all six tests.

Fresh recursive fidelity passes:

| Data boundary | Checks |
| --- | ---: |
| API sections | 170 |
| Recursive schema nodes / descriptions | 2,158 / 2,110 |
| Recursive reference targets / JSON records | 407 / 4,723 |
| Helm selected values / explicit empty strings | 3,813 / 96 |
| Helm field meanings / receiving conditions / complete limits | 3,813 / 3,738 / 9,255 |
| Payload selected values | 1,467 |
| Plugin defaults / complete constraints | 855 / 1,372 |
| Compact swarm values | 15 |

The real corpus exercises 513 multiline descriptions and seven multiline selected values; 44 descriptions and 911 limits contain backticks; bracket/regex cases occur in descriptions, selected values, receiving conditions and limits; pipes occur in six descriptions, 58 conditions and 25 limits. Selected values in this corpus contain no backticks or pipes, so those particular selected-value combinations are supplementary helper proof, not claims about existing selected inputs. Eleven supplemental actual-helper/table cases cover newline, one/two-backtick runs, regex, Markdown-looking links, brackets, pipe, backslash, HTML metacharacters, literal entity-like strings, empty string and mixed characters. All decode exactly.

The authority-module diff against author baseline `93ca75a4694084e5bc216f9aa9c7d52c13b965c6` changes assertion messages and adds precise identity text. Its byte-count and SHA comparison operands/operators remain unchanged. Iterating CRD entries additionally supplies the kind for the message. `unchanged-contracts.diff` is empty for table, shared parser, reference checker, API lock/checksum, archive manifest and vendor authority/archive bytes. There is no ignored-checking or schema/lock change to make the correction pass.

Authentic fresh Kubernetes ConfigMap, Argo Application and CiliumNetworkPolicy calls pass, including their expected content identities. A fresh process for each case prevents cached custom schemas from hiding archive drift. A single XOR byte at midpoint preserves Cilium archive size **212,159 bytes**, changes SHA to `7f2f49c722e385fe8a5f0652337b1e8e246205e79f073e10d3f8d02cc6edd414`, and exits 1 with:

```
CONFIG_YAML_AUTHORITY_DRIFT: cilium cilium@1.20.1 (scripts/vendor/external-helm-charts/06210eef7c23d15f7699c79e2fe3a1ec9c389024c5c5c006ea04022d322449a2.tgz): chart archive bytes changed
```

The diagnostic contains actual and expected SHA values. A separate extra-byte mutation exits 1 with the same identity and `chart archive byte count changed`. Original bytes are restored in a finally path, SHA returns to `06210eef7c23d15f7699c79e2fe3a1ec9c389024c5c5c006ea04022d322449a2`, and restored authentic calls pass. The private archive is byte-exactly restored.

## Executed checks and limits

Generation command, run from MAIN:

```
KUBECLAW_DOCS_ISOLATED_MUTATION=1 node /home/node/Documents/Codex/a98-evidence/literal-source-resumed-fresh/archive/scripts/docs-generate.mjs --root /home/node/Documents/Codex/a98-evidence/literal-source-resumed-fresh/archive --revision 7e413cf63e82fdc6104184a6be25f35420b15d80 --allow-detached-source-root
```

Generation and the same command with `--check`: exit 0. `node fidelity.mjs`, `node parser.mjs`, `node helper-boundaries.mjs`: exit 0. Actual authority baseline/mutation/restore results are in `authority-results.json` and `authority.log`. Generator/module syntax and source whitespace checks: exit 0. Parser tests: six pass, zero fail. Unchanged full `node scripts/docs-check-refs.mjs`: exit 1 with exactly three errors: AP03 progress references `docs/operations/`; AP01 baseline README and generated reference README reference `docs/reference/`. These absent archive directories were not invented to turn the checker green. The global reference gate is not claimed PASS.

No installed MkDocs, Python-Markdown, CommonMark, pandoc, cmark, markdown-it, marked or remark renderer was found (`renderer-availability.json`). Installed parse5 is an HTML parser, not a Markdown renderer. Publication `build()` copies/transforms Markdown; it does not render these tables to site HTML. No renderer was installed. Real published HTML, table formatting, narrow-layout usability and Reader/Quality acceptance remain **UNPROVEN**. The output is larger than the author's earlier output because revision/actual input snapshots differ; `output-hashes.json` pins this review's actual bytes, not the author's hash.

## Acceptance IDs

| ID | Assigned bounded Source result | Complete ID result |
| --- | --- | --- |
| A98-10 | PASS: generated schema descriptions/recursive JSON, selected values/defaults and tested literal boundaries preserve this input snapshot; no source authority/schema change. | UNPROVEN: this review does not establish every inventory source, owner, consumer or complete operational field semantics. |
| A98-11 | PASS: exact selected/empty values and receiving condition literals survive generation; schema descriptions are not rewritten into invented runtime defaults. | UNPROVEN: all runtime precedence/conflict/secret/invalid branches were not independently executed here. |
| A98-14 | PASS: unchanged size/SHA comparisons detect authentic same-size and byte-count archive corruption with precise authority diagnostics. | UNPROVEN: archive corruption does not prove the required new-field mutations for Helm, Environment, Secret, Scriptflag and swarm. |
| CFG-009 | PASS: assigned literal/navigation and authority-diagnostic corrections are reproduced on actual fresh output. | UNPROVEN: full Helm/GitOps/infrastructure partition and operational recursive semantics are outside this bounded review. |

Source corrections may proceed to the root agent's MAIN regeneration and actual gates. This report grants no global A98/CFG-009, Reader, Quality or publication-render acceptance.
