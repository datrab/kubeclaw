# Independent complete fresh Source review: creating identity, trust and retirement

Verdict: **FAIL** for this finite assigned Source contribution. No Reader, Quality, Astra, package, global-gate, deployment or live approval.

Reviewer identity: `/root/install_creating_identity_corrected_complete_source_fresh`. Fresh initial read-only reviewer distinct from the authors. Repository `/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04`, branch `docs/documentation-overhaul`, candidate **4ed48fa6ce17a4813ed3bcf4593ff010911fd974**. No repository edit, commit, npm install, generator mutation, key-file read, workflow dispatch or real cluster write. The worktree contains unrelated concurrent changes; no clean-checkout/global qualification is claimed.

## Exact reviewed scope

Read the complete handoff, quality standard, acceptance contract, execution plan and acceptance fixtures; derived applicability from OPR-003 (installation, release/render, client preparation, GitOps ownership transfer and first verification), OPR-008 (upgrade, rollback, rotation and retirement), and the assigned A98-02/03/09/13 facets. Read all three complete assigned pages: install 1433 lines, Worker Trust 492 lines, maintenance 1404 lines. Their exact hashes are:

- install: `55b325b6bbafc708c498007967581355759b3dd38913474b71d325a032c1fca7`
- Worker Trust: `3812bb3f04367bc82c027d1cbe5ce8c196a7d73a48193d118abaf42001dc1799`
- maintenance: `de3b211e41170772178c95c187d778a2af70bea40bca75248e7fb89efa75a945`

Read every linked product-source range (90 references, 34 distinct pinned product files), verified whole-file equality against the complete pinned Git blobs and range bounds, and read the critical complete live trust script, receipt verifier, Qdrant remover, registry generator and release verification/configuration mechanisms beyond snippets. Checked actual deployment/setup/infra/role/Prism/trust/teardown dispatch, release workflow authority and generated values, source-signing inputs, identity parser and allowlists, loopback transport guards, receipt key/fingerprint/revision/cleanup contracts, Prism persisted dispatch/admission and destructive retirement/recovery consequences. Inspected pinned upstream raw-delete, JSON Patch, deletion waits and volume controller sources and official DeleteOptions/auth documentation. Retained source excerpts and complete pinned upstream files separately.

Mandatory adjacent canonical dependencies were checked directly: use index/tool/placeholders, locked dependency setup, operation raw-preservation helper, diagnosis durable inspection, pipeline-state recovery and actual FileJournal/audit. These dependencies now require writer ownership, original identities, verified raw preservation and strict parsing before audit/recovery/resume. Previous F4 is not carried forward as an open finding.

The guarded closure is 56 immutable source/task inputs (`before.json`). Unrelated mutable Buster workflow, scanner/plugin-generator, global configuration discovery and completion-matrix scopes are excluded. No result here approves those scopes. A source hash or valid range does not substitute for semantic review. The old failing report was read as finding history, not approval. All 9757 author artifacts were independently rehashed with zero mismatches; all 44 author source inputs currently match their manifest. Root trust/operator gate terminal receipts were separately inspected; no author summary was promoted to approval.

## Findings

### F1 — sealed observation permissions prevent ordinary GNU-cp working-copy refresh

**Material command-family defect.** `docs/site/use/install.md:727–730` removes write permission from observation files, then copies them using `cp -T` to the latest working files. Under umask 077, a newly created working file inherits mode 0400. The next observation of the same logical file attempts to overwrite that file. This occurs on repaired reads, cleanup's required recapture, and repeated PV-after polling.

Current native tests use BusyBox 1.37.0 `cp`, which replaces the destination and therefore pass. They do not prove GNU-cp behavior. The documented Ubuntu operator starting environment uses the ordinary GNU behavior: an existing destination is opened with `O_WRONLY|O_TRUNC`; unlink after a failed open is disabled unless explicitly selected. Authoritative retained GNU coreutils v9.4 source: [copy.c lines 1285–1315](https://github.com/coreutils/coreutils/blob/v9.4/src/copy.c#L1285-L1315), [new destination mode lines 1450–1457](https://github.com/coreutils/coreutils/blob/v9.4/src/copy.c#L1450-L1457), [cp.c default at 829 and force option at 1050](https://github.com/coreutils/coreutils/blob/v9.4/src/cp.c#L824-L830). The source is byte-bound in the artifact manifest. This is source-qualified GNU behavior; no native GNU-cp binary was available or installed here.

Own exact-helper execution produces an actual mode-0400 working file under uid 1000. Opening that file with GNU's exact documented write/truncate flags returns EACCES 13 (`gnu-open-boundary.json`). A clearly labelled GNU-open **model**, invoking the unchanged published observer twice, confirms the second command exits 0 but local retention fails and the wrapper returns 1 (`gnu-open-model.*`). It is a model, not a GNU-cp executable run. BusyBox native denial/recovery results remain true within their actual environment.

This fails safely rather than falsely permitting deletion, but prevents the published normal cleanup/repaired-read route on ordinary GNU tools. Correct all three working-copy writes so the working files can refresh while sealed historical receipts remain immutable. Guard each local change/copy/rename and preserve the directory-target rejection. One possible design explicitly creates writable working copies, or replaces exact regular working paths through guarded new-file publication. Recheck successful recapture, nine denied/repaired paths, copy/open failures, replacement/unknown identity stops and repeated PV polling with both the actual declared GNU and BusyBox tool paths. Do not solve it by weakening historical modes or dropping retention-failure stops.

### F2 — TLS timeout source link ends before timeout handling

`docs/site/use/worker-trust.md:320–322` says its linked direct-TLS implementation proves network-error and timeout acceptance, but `#L38-L52` ends at `request.on("error",...)`; the actual `request.on("timeout",...)` is line 53. The claim itself is true and the wrong-SVID links now correctly select lines 146 and 182. Correct the direct-TLS link to the complete relevant function, e.g. `#L43-L55`, preserving the pinned unchanged revision. This is a concrete narrow-evidence correction; it does not create a new live-denial result or a runtime safety defect.

No additional material semantic defect was found after completing the assigned domains. The remaining unavailable runtime selection, absent full signing-owner provisioning, live identity capture/denial procedure, upgrade pair, node preparation and provider cleanup are honestly documented product limits with safe stops and owners; they are not treated as new documentation failures.

## Individual requirement contributions

| Requirement/facet | Verdict | Complete assigned result and boundary |
|---|---|---|
| OPR-003 installation/release/render/authority/client/GitOps/first-verification contribution | FAIL | Release acquisition and receipt/source/configuration checks, all selected render/ownership/authority gates and first verification agree with source. F1 prevents ordinary working-copy recapture and cleanup completion on GNU tools. |
| OPR-008 maintenance, upgrade/rollback/rotation and retirement contribution | PASS | No supported upgrade pair is invented; irreversible data boundaries, external rotation authorities, GitOps transfer stop, registry/node preparation limits, lifetime exclusion and broad/fixed retirement scopes agree with sources. This is Source qualification, not live maintenance. |
| A98-02 exact complete command/observation/recovery/evidence contract in assigned pages | FAIL | F1 is a reproducibility defect in a mandatory command family; F2 requires a narrow source-callout correction. Named authorities, versions, execution location, placeholders and remaining contract dimensions were checked. |
| A98-03 supported starting state and pre-mutation prerequisite/authority gates | PASS | Existing cluster and independent recovery, reviewed runtime selection, read-only/render/GitOps/scoped grants, StorageClass/provider/lifetime ownership, receipt keys and mandatory live lifecycle/denial proof are explicit pre-mutation gates. Missing runtime selection actually refuses locally. F1 remains a separate post-create observation/cleanup defect. |
| A98-09 disposable installation probe cleanup contribution | FAIL | Single-object CREATE provenance and immutable original namespace/PVC/Pod identities, original PV/provider reconciliation, authenticated clearance and UID-precondition deletion are correct; F1 blocks mandatory recapture on GNU tools. It fails closed; no safe cleanup completion is proved there. |
| A98-09 broad decommission/retained recovery objects/former Qdrant contribution | PASS | Dedicated inventory and complete externally enforced lifetime window through final API/backend disposition; original/current identities, non-atomic name mutations, Pending allocation, final independent export/integrity/restore, revoked/retained readers, all five separately applied recovery objects and their Jobs/Pods, fixed Qdrant selectors/policy/partial failures and backend receipts are explicit and source-correct. |
| A98-13 fresh-context task-route Source sufficiency, within assigned family | FAIL | F1 requires correcting the runnable route and its tool coverage. Missing implementation paths are accurately explained; no author/live proxy approval is accepted. |
| Worker Trust identity/key/signing/source-attestation/no-false-denial contribution to A98-02/03/13 | PASS | Independent source boundaries are correct: fixed external Ed25519 receipt authority, source Secret distinct, pre-effect qualification, actual peer/application rejection plus reachable contemporaneous controls, inconclusive timeout/5xx, original durable identities/reconciliation, receipt overwrite/unit cleanup versus live cleanup and no unsupported universal removal. F2 is separately recorded in evidence fidelity. |
| A98-04 installation/trust readiness slice (ancillary, not full gate) | PASS | Process, Service/dependency and functional proof remain distinct; Pod Running/source/smoke/live JSON cannot replace live trust. |
| A98-08 unsupported-pair/irreversible upgrade slice (ancillary, not full gate) | PASS | Empty pair matrix stops upgrades before mutation; image rollback cannot undo incompatible data or accepted external effects. |

No whole A98 gate or grouped catalogue-ID approval follows from these finite rows. No acceptance of unassigned configuration, complete operation/control, publication, language, architecture, reader exercises or scenario gates is implied.

## Actual independent bounded executions

All own subprocesses reached terminal status; command/exit/raw stdout/stderr artifacts are retained.

- 90 pinned product links: complete Git-file byte equality and all range bounds passed.
- 44 exact Bash fences across all three pages: `bash -n` exit 0.
- Fresh extraction of the entire published observer/parser/capture helper equals the author's final tested helper byte for byte. Reconstructed current namespace CREATE and full PVC/Pod/run block executed in 13 shell-only mock cases: positive, ordinary output, Lists, denied/partial responses and replacement identities for all three kinds. All driver assertions exit 0.
- 33 independently constructed strict CREATE controls (three kinds × positive/empty/malformed/partial/List/missing or numeric UID/wrong name/kind/version/deleting): all actual accepts/rejects match expectations.
- Ten local capture-write/index/date/printf/mkdir/copy/chmod/terminal-output/log-status/log-removal controls preserve nonzero failure and failed capture.
- Output-open failure prevents command invocation (`not-run`); exit-write and unexpected working-directory controls retain actual command exit 37 separately from failed retention.
- Nine denial routes plus nine repaired reads retain original stdout/stderr/exits and historical hashes; 18 observations remain sealed. Observer-history/copy-failure control also passes. These are native BusyBox-tool shell fixtures, not Kubernetes denials.
- Positive exact cleanup block issues only original-UID Namespace DELETE body and independently observes simulated absence. Three replacement-identity and three unknown-original-identity controls actually exit 1; own inspection confirms no DELETE call. Synthetic clearance shape does not authenticate a real owner or prove provider disposition.
- Actual kubectl v1.34.11 executed three single-object CREATE commands against a private loopback HTTP fixture, retaining server-supplied UIDs/kind/name/namespace. PVC/Pod fixture uses `--validate=false` because the private server has no OpenAPI service; the published commands retain default validation. No actual API authentication/authorization/admission, provisioner or storage succeeded.
- Actual local `selectedRelease(...,'runtime')` refuses the absent selection with nonzero exit and the expected diagnostic.
- Actual uid-1000 write/truncate open of a generated 0400 working file fails EACCES; clearly labelled source-based GNU-open model confirms repeated observer failure. Native GNU-cp run remains unexecuted.
- Independent rehash of all 9757 author artifacts and all 44 author input files passes. Root `root-complete-operator-correction-gates/result.json` records actual trust and operator checks both exit 0 and sources unchanged; retained logs and source contracts were inspected. These are root's gate executions, not my own native/live executions and not semantic approval.

Environment: uid 1000 node, Node v24.21.0, GNU Bash 5.3.9, BusyBox 1.37.0 cp, Python 3, kubectl v1.34.11. Private fixture writes only. Source/artifact SHA closure and final unchanged guard are in `manifest.json`.

## Explicit unexecuted checks and unsupported claims

No real cluster write/read/Secret/key access, runtime release publication/promotion/merge, upstream chart staging/render with a selected release, live installation, image pull, actual StorageClass binding/provider disposition, authenticated cleanup-owner clearance, externally enforced lifetime exclusion, live trust/paired receiver denial, actual operator authority provisioning, production receipt, real upgrade/rollback/rotation/decommission, restore/application-reader proof, browser/publication, Reader/Quality/Astra, global generator/scanner or complete configuration mutations ran here. The native private HTTP fixture is not a real apiserver, admission or provisioning result.

EXEC-UPGRADE, EXEC-ROLLBACK and EXEC-DECOMMISSION remain unproved here. The adjacent EXEC-WAIT-RESUME/CANCELLATION/RESTART-RECOVERY deployment scenarios are not approved by raw-preservation source inspection. Recommended operator/Prism/Demo product exercises are likewise not converted to PASS. Green root trust/task structure gates and artifact integrity cannot qualify GNU portability, live effects or provider removal.

Required next step: correct the complete working-copy refresh family and TLS range, retain both native tool implementations' exact results, then obtain a new complete fresh Source review at the new page hashes. Existing older failures remain tied to their own revisions; this review does not rewrite that history.
