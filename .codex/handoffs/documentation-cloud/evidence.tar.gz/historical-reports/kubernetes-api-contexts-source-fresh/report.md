# Kubernetes API contexts — independent fresh Source review

The assigned Source partition fails complete semantic acceptance at `f68a7294abf0928c1aabf290c6a7e486c651a808`. All 93 contexts and 252 instances were assessed: 42 contexts contain identified semantic failures and 51 remain UNPROVEN for complete receiver/variant acceptance. The schema-copy and Source Markdown projection checks pass for the entire assignment. These results are deliberately distinct.

Scope is Deployment36, NetworkPolicy15, ValidatingAdmissionPolicy15, Ingress8, PersistentVolumeClaim6, Service6, ValidatingAdmissionPolicyBinding3, ConfigMap2, Namespace2. Cilium49, Argo28, retained805/286 Helm, Reader/Quality, actual HTML rendering and live operations are excluded. Shared ObjectMeta was checked for each assigned kind. No repository sources were edited, no commits or pushes made, and no full mutation run duplicated.

The quality07 contract, AP09 acceptance contract, CFG-009 catalogue entry and A98-10/11 require recursive semantics and authored-to-effective precedence. A copied description/default keyword alone cannot satisfy that requirement. Therefore this report does not close CFG-009 or either whole A98 gate.

## Evidence and reproducible checks

- [semantic-context-ledger.json](semantic-context-ledger.json) names all93 contexts and1142 exposed field/item/map/child/item-child/parent boundaries, with separate schema-copy and semantic case verdicts. The402 PASS boundary entries approve bounded source-family claims; they do not approve complete recursive receiver acceptance. Forty boundary entries FAIL. The148 explicitly rendered absent item/map contract boundaries are included as PASS statements of schema absence only. Seven hundred entries have individually named field-specific UNPROVEN work items.
- [findings.json](findings.json) has21 findings,16 FAIL and5 UNPROVEN, exact affected contexts/ancestor contexts, generator lines, reader Markdown lines and primary source lines.
- [assigned-contexts.json](assigned-contexts.json), [assigned-rows.json](assigned-rows.json), [assigned-scalar-rows.json](assigned-scalar-rows.json) retain full assigned raw rows. All110 normalized API scalar contexts/281 scalar instances were read, together with collection prose and exposed contracts. Machine schema facts are approved by exhaustive comparison; this does not claim manual runtime verification of every unselected OpenAPI variant.
- [exact-authority-comparisons.json](exact-authority-comparisons.json) records1764 deep comparisons for every instance's field, children, item, item children, map value, parent and parent chain. The independent resolver does not import the inventory or authority helper. It resolves pinned references and sibling attributes, then compares all JSON keys/values recursively. Removing an exposed child and replacing peer description are rejected negative controls. Required membership and description hashes are also asserted.
- [source-projection.json](source-projection.json) records1394 checks of exact literal schema text and field meaning in generated Markdown for all93 contexts. The named `api-collection` section and every exposed source table boundary are checked. This is not actual rendered HTML evidence.
- [executed-checks.json](executed-checks.json) verifies static snapshot sources byte-for-byte against the reviewed immutable commit; raw/generated output is independently captured f68 generation output with explicit source lock. [primary-sources/manifest.json](primary-sources/manifest.json) records independently fetched primary URLs/hashes. [manifest.json](manifest.json) hashes durable artifacts, including the read-only full snapshot archive.

The Kubernetes runtime sources are pinned to v1.35.0 commit `66452049f3d692768c39c797b21b793dce80314e`. Argo operational documentation is pinned to3.5.2 commit `e258ee23c3e52266d407572f4bcdfe7d9ed36cb5`; actual client version/synchronization state is unproved. Distribution3.0.0 resolves to immutable commit `9ed95e7365224025ee89365e12cf128e1f1bf965`; all five fetched source files match that immutable commit's bytes. Source-derived expected outcomes below have not been executed against a live API or controller.

## Concrete findings

- **K01 FAIL — NetworkPolicy empty peer item is rejected.** A retained peer item {} has zero selectors/IPBlock and validation rejects it. Empty/missing from list matches all; {podSelector:{}} is a valid same-namespace Pod peer, not equivalent to {}. Generator: `scripts/docs-configuration-inventory.mjs:2038`. Evidence: `primary-sources/network-validation.go:107-132`.
- **K02 FAIL — Empty namespace string is filled from request namespace.** Empty ObjectMeta.Namespace is accepted at the receiving REST create boundary and assigned the request namespace before validation; cluster-scoped empty namespace is preserved. Actual client request namespace and live permissions remain separate. Generator: `scripts/docs-configuration-inventory.mjs:2214`. Evidence: `primary-sources/namespace-request.go:45-63`, `primary-sources/rest-create.go:110-123`.
- **K03 FAIL — Empty Deployment strategy type defaults RollingUpdate.** SetDefaults_Deployment treats Type=="" as RollingUpdate and creates the rollingUpdate defaults. Recreate plus rollingUpdate is rejected. Generator: `scripts/docs-configuration-inventory.mjs:2261`. Evidence: `primary-sources/apps-defaults.go:38-63`, `primary-sources/apps-validation.go:608-627`.
- **K04 FAIL — Empty image pull policy is defaulted.** SetDefaults_Container treats an empty string as absent and derives Always for latest, otherwise IfNotPresent. Deployment generated defaulter invokes SetDefaults_Container; this effective runtime default is not an OpenAPI default keyword. Generator: `scripts/docs-configuration-inventory.mjs:2265`. Evidence: `primary-sources/core-defaults.go:82-101`, `primary-sources/apps-generated-defaults.go:538-542`.
- **K05 FAIL — Protocol enums and defaults are not supplied by schema keywords.** These selected OpenAPI nodes have no enum/default keyword. Container and Service string "" default TCP; NetworkPolicy nil pointer defaults TCP, explicit "" is invalid. Accepted runtime values TCP/UDP/SCTP require receiver validation, not a nonexistent schema enum. Generator: `scripts/docs-configuration-inventory.mjs:2268`. Evidence: `primary-sources/apps-generated-defaults.go:538-548`, `primary-sources/core-defaults.go:106-111`, `primary-sources/network-defaults.go:30-35`, `primary-sources/network-validation.go:78-104`, `primary-sources/core-validation.go:2722-2755,6780-6810`.
- **K06 FAIL — Empty Service type defaults ClusterIP.** SetDefaults_Service assigns ClusterIP for empty Type before validation. Generator: `scripts/docs-configuration-inventory.mjs:2269`. Evidence: `primary-sources/core-defaults.go:123-125`.
- **K07 FAIL — Optional port names accept empty and use different grammars.** Empty container port names are skipped by IANA validation. A single-port Service can have empty name; multiple-port Services require names. Service names use DNS1123Label, unlike Pod IANA_SVC_NAME. Generator: `scripts/docs-configuration-inventory.mjs:2263`. Evidence: `primary-sources/core-validation.go:2722-2755,6620-6640,6780-6810`.
- **K08 FAIL — Service targetPort zero or empty string defaults to port.** Service defaulting assigns Port to TargetPort when integer zero or string ""; schema keyword has no default, while copied description documents this behavior. API scalar prose conflicts with copied child contract. Generator: `scripts/docs-configuration-inventory.mjs:2267`. Evidence: `primary-sources/core-defaults.go:136-140`.
- **K09 FAIL — Container requests omission requires created-Pod boundary.** At created Pod defaulting, missing requests inherit present limits per key. SetDefaults_Pod applies this, not SetDefaults_PodSpec for the Deployment template. Explain authored template versus resulting replacement Pod, and additional namespace admission constraints. Generator: `scripts/docs-configuration-inventory.mjs:2266`. Evidence: `primary-sources/core-defaults.go:164-196`, `primary-sources/apps-generated-defaults.go:373-380,536-553`.
- **K10 FAIL — Empty HTTPGet path defaults slash.** HTTPGetAction.Path=="" defaults to /; Scheme=="" defaults HTTP. Generated Deployment defaults wire all probe variants. Empty numeric strings have different decoding, null/default behavior must be named by type. Generator: `scripts/docs-configuration-inventory.mjs:2276`. Evidence: `primary-sources/core-defaults.go:316-324`, `primary-sources/apps-generated-defaults.go:564-603`.
- **K11 FAIL — Empty API group item selects legacy core group.** apiGroups contains empty string for legacy core API group; both authored policies use it. apiVersions, operations, resources have different nonempty rules; do not share an unconditional empty-invalid rule. Generator: `scripts/docs-configuration-inventory.mjs:2246`. Evidence: `primary-sources/admission-validation.go:140-163`.
- **K12 FAIL — False admission validation follows binding actions.** False is enforced through binding validationActions: Deny denies, Warn warns, Audit audits; Warn/Audit alone allow. Authored Deny baseline is narrower than reader-exposed binding variants. Generator: `scripts/docs-configuration-inventory.mjs:2251`. Evidence: `primary-sources/admission-types.go:493-532`.
- **K13 FAIL — Empty validation message uses runtime fallback.** Pinned validator permits literal "" for a single-line expression. Nonempty whitespace-only is rejected. API type documents multiline-expression message requirement, but actual validation contains a different condition: do not turn the documented condition into a proven implemented rejection. Runtime uses valid messageExpression then nonempty custom Message then failed-expression fallback. Generator: `scripts/docs-configuration-inventory.mjs:2252`. Evidence: `primary-sources/admission-validation.go:1034-1060`, `primary-sources/admission-types.go:352-366`, `primary-sources/validating-policy-validator.go:156-188`.
- **K14 FAIL — Variables are unavailable to match conditions.** Variables are unavailable in matchConditions; conditions run before variable evaluation. Later variables, validations, messageExpression and audit expressions can reference them under declaration order/compilation constraints. Generator: `scripts/docs-configuration-inventory.mjs:2250`. Evidence: `primary-sources/admission-types.go:280-291`, `primary-sources/validating-policy-validator.go:80-109`.
- **K15 FAIL — Pod Security namespace labels are handled as generic metadata.** The generic metadata.labels handler shadows exact PSA handling. These labels have privileged/baseline/restricted values, mode-specific default delegation and admission consequences. With PSA admission enabled, invalid labels are rejected on Namespace create; update rejects changed invalid labels but may retain unchanged old invalid labels. Actual installed PSA configuration/exemptions are not proven by Source. Generator: `scripts/docs-configuration-inventory.mjs:2215`. Evidence: `primary-sources/pod-security-policy.go:99-105,181-224`, `primary-sources/psa-namespace-admission.go:245-280,327-388,625-626`.
- **K16 UNPROVEN — Numeric port bounds cannot come from absent schema keywords.** Selected pinned schemas omit minimum/maximum keywords. Name receiver constraints explicitly: listener/policy ports 1..65535; nodePort=0/omission allocates for the service type, nonzero allocation uses configured server range. Generic copied schema cannot prove complete boundary/default/conflict cases. Generator: `scripts/docs-configuration-inventory.mjs:2267`. Evidence: `primary-sources/core-validation.go:2722-2755,6780-6810`, `primary-sources/network-validation.go:78-104`, `primary-sources/core-defaults.go:106-143`, `primary-sources/util-validation.go:270-276,314-340`, `primary-sources/service-alloc.go:498-566,973-980`, `primary-sources/util-validation.go:270-276,314-340`, `primary-sources/service-alloc.go:498-566,973-980`.
- **K17 UNPROVEN — Deployment label empty-value claim needs exact equality qualification.** Empty label values are legal if selector and template match. Independently removing/changing one can cause mismatch; demonstrate both sides empty versus one side changed. Current wording does not clearly qualify this variant. Generator: `scripts/docs-configuration-inventory.mjs:2260`. Evidence: `primary-sources/apps-validation.go:638-656,833-845`, `primary-sources/meta-validation.go:113-120`.
- **K18 FAIL — Fail admission errors also follow binding actions.** failurePolicy=Fail makes errors enforced by binding validationActions; Warn/Audit alone do not deny. Ignore skips such errors. Match-condition errors have a distinct skip/failure route and should be described with binding enforcement boundary. Generator: `scripts/docs-configuration-inventory.mjs:2245`. Evidence: `primary-sources/admission-types.go:233-249,493-500`, `primary-sources/validating-policy-validator.go:80-122`.
- **K19 UNPROVEN — Registry PVC effective storage values come from renderer input.** This template intentionally contains required placeholders. config JSON validated by renderRegistryLocal overwrites storageClassName and requests.storage; existing PVC is validated against same winner. Deployment mode overwrites replicas and changes workload set in gc modes. Actual deploy picks serve. Inventory does not name these winners/conditions. Generator: `scripts/docs-configuration-inventory.mjs:1804`. Evidence: `snapshot/scripts/render-registry-local.mjs:10-16,32-67`, `snapshot/scripts/deploy.sh:1193-1217`.
- **K20 UNPROVEN — LiteLLM Service ports are patched after apply.** deploy.sh renders/configures LiteLLM then merge-patches Service ports from validated LITELLM_NODE_PORT. The current source row does not identify this later writer as winner. Existing field ownership/client apply changes require route-specific distinction. Generator: `scripts/docs-configuration-inventory.mjs:1804`. Evidence: `snapshot/scripts/render-litellm-deployment.mjs:10-22`, `snapshot/scripts/deploy.sh:1168-1183`.
- **K21 UNPROVEN — Registry ConfigMap payload empty behavior lacks exact parser outcome.** Mounted config.yml bytes reach Distribution3.0.0 serve config argument. CLI arg beats REGISTRY_CONFIGURATION_PATH; empty bytes lack version and reject unsupported version before env overrides. With version0.1, environment overrides precede conversion; no storage configuration then errors. Reader should name these outcomes and immutable parser source. Generator: `scripts/docs-configuration-inventory.mjs:2186`. Evidence: `primary-sources/distribution-registry.go:103-120,473-500`, `primary-sources/distribution-parser.go:114-152`, `primary-sources/distribution-configuration.go:790-838`.

## Actual receiving routes and remaining work

Registry-local authoring is a template: storage config JSON overwrites storage class/capacity, existing Deployment/PVC checks reject incompatible storage, serve mode selects one replica, and deployment applies rendered output in the request namespace. LiteLLM rendering derives ConfigMap bytes and rollout annotation from one input snapshot; a later merge patch overrides Service ports using the validated NodePort environment value. Registry mirror uses direct optional kubectl apply. The stateful network-policy renderer rewrites only Cilium objects, leaving the assigned Kubernetes NetworkPolicy unchanged. GitOps Applications select specific directories, a moving `main` revision and kubeclaw destination namespace; declared selection is Source evidence, not proof of a performed sync. The admission baseline file has no independently established active direct apply path; current deploy says the broker Helm release owns its fence. The namespace example is illustrative. Every instance names its own conditional route and source proof in the ledger.

OpenAPI descriptions of direct children and their reference chains are copied exactly, but deeper alternatives require named receiving contracts. Examples include Deployment PodSpec affinity/securityContext, Container lifecycle/securityContext/resize variants, Volume projected/CSI/image sources, Service sessionAffinityConfig, Ingress rules/resource backend, admission paramKind/auditAnnotations, binding paramRef/matchResources and system-maintained ObjectMeta children. The ledger names every exposed unproved boundary, exact copied contract, required omitted/null/empty/invalid/change cases and references. These are concrete unproved work items, not an approval inferred from a shared family branch.

UNPROVEN is also retained for operation-specific three-way ownership/conflict cases, changing cluster policy/default class/driver settings, exact external controller version/receiver outcomes, image default behavior not established by an immutable image contract, and complete schema-versus-runtime implementation discrepancies. Source checks do not establish live enforcement, scheduling, endpoint readiness, storage expansion or reload. No actual HTML renderer artifact was available, so Render remains UNPROVEN.

## Full context assessment

| Context | Source semantic acceptance | Direct collection-family prose | Exposed boundaries | Source schema / Markdown |
| --- | --- | --- | --- | --- |
| `Namespace $.metadata` | FAIL | UNPROVEN | 18 | PASS / PASS |
| `Namespace $.metadata.labels` | FAIL | PASS | 4 | PASS / PASS |
| `Deployment $.metadata` | FAIL | UNPROVEN | 18 | PASS / PASS |
| `Deployment $.metadata.labels` | UNPROVEN | PASS | 4 | PASS / PASS |
| `Deployment $.spec` | FAIL | UNPROVEN | 12 | PASS / PASS |
| `Deployment $.spec.selector` | UNPROVEN | PASS | 7 | PASS / PASS |
| `Deployment $.spec.selector.matchLabels` | UNPROVEN | PASS | 6 | PASS / PASS |
| `Deployment $.spec.strategy` | FAIL | PASS | 7 | PASS / PASS |
| `Deployment $.spec.template` | FAIL | UNPROVEN | 7 | PASS / PASS |
| `Deployment $.spec.template.metadata` | UNPROVEN | UNPROVEN | 21 | PASS / PASS |
| `Deployment $.spec.template.metadata.labels` | UNPROVEN | PASS | 7 | PASS / PASS |
| `Deployment $.spec.template.spec` | FAIL | UNPROVEN | 48 | PASS / PASS |
| `Deployment $.spec.template.spec.containers` | FAIL | PASS | 32 | PASS / PASS |
| `Deployment $.spec.template.spec.containers[]` | FAIL | PASS | 33 | PASS / PASS |
| `Deployment $.spec.template.spec.containers[].args` | UNPROVEN | PASS | 9 | PASS / PASS |
| `Deployment $.spec.template.spec.containers[].env` | UNPROVEN | PASS | 12 | PASS / PASS |
| `Deployment $.spec.template.spec.containers[].env[]` | UNPROVEN | PASS | 13 | PASS / PASS |
| `Deployment $.spec.template.spec.containers[].envFrom` | UNPROVEN | PASS | 12 | PASS / PASS |
| `Deployment $.spec.template.spec.containers[].envFrom[]` | UNPROVEN | PASS | 13 | PASS / PASS |
| `Deployment $.spec.template.spec.containers[].envFrom[].secretRef` | UNPROVEN | PASS | 13 | PASS / PASS |
| `Deployment $.spec.template.spec.containers[].ports` | FAIL | PASS | 14 | PASS / PASS |
| `Deployment $.spec.template.spec.containers[].ports[]` | FAIL | PASS | 15 | PASS / PASS |
| `Deployment $.spec.template.spec.containers[].resources` | FAIL | PASS | 12 | PASS / PASS |
| `Deployment $.spec.template.spec.containers[].resources.limits` | UNPROVEN | PASS | 10 | PASS / PASS |
| `Deployment $.spec.template.spec.containers[].resources.requests` | FAIL | PASS | 10 | PASS / PASS |
| `Deployment $.spec.template.spec.containers[].volumeMounts` | UNPROVEN | PASS | 16 | PASS / PASS |
| `Deployment $.spec.template.spec.containers[].volumeMounts[]` | UNPROVEN | PASS | 17 | PASS / PASS |
| `Deployment $.spec.template.spec.volumes` | UNPROVEN | PASS | 38 | PASS / PASS |
| `Deployment $.spec.template.spec.volumes[]` | UNPROVEN | PASS | 39 | PASS / PASS |
| `Deployment $.spec.template.spec.volumes[].configMap` | UNPROVEN | PASS | 13 | PASS / PASS |
| `Deployment $.spec.template.spec.volumes[].secret` | UNPROVEN | PASS | 13 | PASS / PASS |
| `Service $.metadata` | FAIL | UNPROVEN | 18 | PASS / PASS |
| `Service $.metadata.labels` | UNPROVEN | PASS | 4 | PASS / PASS |
| `Service $.spec` | FAIL | UNPROVEN | 24 | PASS / PASS |
| `Service $.spec.ports` | FAIL | PASS | 11 | PASS / PASS |
| `Service $.spec.ports[]` | FAIL | PASS | 12 | PASS / PASS |
| `Service $.spec.selector` | UNPROVEN | PASS | 5 | PASS / PASS |
| `Ingress $.metadata` | FAIL | UNPROVEN | 18 | PASS / PASS |
| `Ingress $.spec` | UNPROVEN | UNPROVEN | 8 | PASS / PASS |
| `Ingress $.spec.defaultBackend` | UNPROVEN | PASS | 7 | PASS / PASS |
| `Ingress $.spec.defaultBackend.service` | UNPROVEN | PASS | 8 | PASS / PASS |
| `Ingress $.spec.defaultBackend.service.port` | UNPROVEN | PASS | 9 | PASS / PASS |
| `Ingress $.spec.tls` | UNPROVEN | PASS | 7 | PASS / PASS |
| `Ingress $.spec.tls[]` | UNPROVEN | PASS | 8 | PASS / PASS |
| `Ingress $.spec.tls[].hosts` | UNPROVEN | PASS | 7 | PASS / PASS |
| `ValidatingAdmissionPolicy $.metadata` | UNPROVEN | UNPROVEN | 18 | PASS / PASS |
| `ValidatingAdmissionPolicy $.spec` | FAIL | UNPROVEN | 11 | PASS / PASS |
| `ValidatingAdmissionPolicy $.spec.matchConditions` | FAIL | FAIL | 7 | PASS / PASS |
| `ValidatingAdmissionPolicy $.spec.matchConditions[]` | FAIL | FAIL | 8 | PASS / PASS |
| `ValidatingAdmissionPolicy $.spec.matchConstraints` | FAIL | PASS | 10 | PASS / PASS |
| `ValidatingAdmissionPolicy $.spec.matchConstraints.resourceRules` | FAIL | PASS | 12 | PASS / PASS |
| `ValidatingAdmissionPolicy $.spec.matchConstraints.resourceRules[]` | FAIL | PASS | 13 | PASS / PASS |
| `ValidatingAdmissionPolicy $.spec.matchConstraints.resourceRules[].apiGroups` | FAIL | PASS | 8 | PASS / PASS |
| `ValidatingAdmissionPolicy $.spec.matchConstraints.resourceRules[].apiVersions` | UNPROVEN | PASS | 8 | PASS / PASS |
| `ValidatingAdmissionPolicy $.spec.matchConstraints.resourceRules[].operations` | UNPROVEN | PASS | 8 | PASS / PASS |
| `ValidatingAdmissionPolicy $.spec.matchConstraints.resourceRules[].resources` | UNPROVEN | PASS | 8 | PASS / PASS |
| `ValidatingAdmissionPolicy $.spec.validations` | FAIL | PASS | 9 | PASS / PASS |
| `ValidatingAdmissionPolicy $.spec.validations[]` | FAIL | PASS | 10 | PASS / PASS |
| `ValidatingAdmissionPolicyBinding $.metadata` | UNPROVEN | UNPROVEN | 18 | PASS / PASS |
| `ValidatingAdmissionPolicyBinding $.spec` | UNPROVEN | UNPROVEN | 8 | PASS / PASS |
| `ValidatingAdmissionPolicyBinding $.spec.validationActions` | UNPROVEN | PASS | 5 | PASS / PASS |
| `ValidatingAdmissionPolicy $.spec.variables` | FAIL | PASS | 7 | PASS / PASS |
| `ValidatingAdmissionPolicy $.spec.variables[]` | FAIL | PASS | 8 | PASS / PASS |
| `Deployment $.spec.template.spec.containers[].livenessProbe` | FAIL | PASS | 19 | PASS / PASS |
| `Deployment $.spec.template.spec.containers[].livenessProbe.httpGet` | FAIL | PASS | 15 | PASS / PASS |
| `Deployment $.spec.template.spec.containers[].readinessProbe` | FAIL | PASS | 19 | PASS / PASS |
| `Deployment $.spec.template.spec.containers[].readinessProbe.httpGet` | FAIL | PASS | 15 | PASS / PASS |
| `Deployment $.spec.template.spec.containers[].startupProbe` | FAIL | PASS | 19 | PASS / PASS |
| `Deployment $.spec.template.spec.containers[].startupProbe.httpGet` | FAIL | PASS | 15 | PASS / PASS |
| `NetworkPolicy $.metadata` | UNPROVEN | UNPROVEN | 18 | PASS / PASS |
| `NetworkPolicy $.spec` | FAIL | UNPROVEN | 8 | PASS / PASS |
| `NetworkPolicy $.spec.ingress` | FAIL | PASS | 7 | PASS / PASS |
| `NetworkPolicy $.spec.ingress[]` | FAIL | PASS | 8 | PASS / PASS |
| `NetworkPolicy $.spec.ingress[].from` | FAIL | PASS | 10 | PASS / PASS |
| `NetworkPolicy $.spec.ingress[].from[]` | FAIL | FAIL | 11 | PASS / PASS |
| `NetworkPolicy $.spec.ingress[].from[].podSelector` | UNPROVEN | PASS | 11 | PASS / PASS |
| `NetworkPolicy $.spec.ingress[].ports` | FAIL | PASS | 10 | PASS / PASS |
| `NetworkPolicy $.spec.ingress[].ports[]` | FAIL | PASS | 11 | PASS / PASS |
| `NetworkPolicy $.spec.podSelector` | UNPROVEN | PASS | 7 | PASS / PASS |
| `NetworkPolicy $.spec.podSelector.matchExpressions` | UNPROVEN | PASS | 9 | PASS / PASS |
| `NetworkPolicy $.spec.podSelector.matchExpressions[]` | UNPROVEN | PASS | 10 | PASS / PASS |
| `NetworkPolicy $.spec.podSelector.matchExpressions[].values` | UNPROVEN | PASS | 8 | PASS / PASS |
| `NetworkPolicy $.spec.podSelector.matchLabels` | UNPROVEN | PASS | 6 | PASS / PASS |
| `NetworkPolicy $.spec.policyTypes` | UNPROVEN | PASS | 5 | PASS / PASS |
| `PersistentVolumeClaim $.metadata` | UNPROVEN | UNPROVEN | 18 | PASS / PASS |
| `PersistentVolumeClaim $.spec` | UNPROVEN | UNPROVEN | 13 | PASS / PASS |
| `PersistentVolumeClaim $.spec.accessModes` | UNPROVEN | PASS | 5 | PASS / PASS |
| `PersistentVolumeClaim $.spec.resources` | UNPROVEN | PASS | 7 | PASS / PASS |
| `PersistentVolumeClaim $.spec.resources.requests` | UNPROVEN | PASS | 6 | PASS / PASS |
| `ConfigMap $.data` | UNPROVEN | PASS | 4 | PASS / PASS |
| `ConfigMap $.metadata` | UNPROVEN | UNPROVEN | 18 | PASS / PASS |
| `Deployment $.spec.template.spec.volumes[].persistentVolumeClaim` | UNPROVEN | PASS | 11 | PASS / PASS |
| `PersistentVolumeClaim $.metadata.labels` | UNPROVEN | PASS | 4 | PASS / PASS |

All93 assigned contexts are assessed. This report releases the frozen f68 findings for correction and a new independent Source review; it does not approve subsequent mutable generation output.
