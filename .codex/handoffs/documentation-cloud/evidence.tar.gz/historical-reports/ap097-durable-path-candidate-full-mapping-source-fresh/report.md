# Independent private candidate Source mapping review

**PASS for private candidate mapping applicability: 53/53 row PASS and 636/636 decision PASS.**

Reviewer: `/root/ap097_durable_path_candidate_full_mapping_source_fresh`, fresh independent Source role, repository read-only throughout. Reviewed HEAD: `b6e4a0d774434b8c39b2575322436e3fba708914`. Exact input: `/home/node/Documents/Codex/a98-evidence/ap097-durable-path-correction-candidate/candidate-matrix.json`, SHA-256 `09d844fc2056a5ac0b8f6735f885248c01da9839224197045ac2863936285320`. Candidate bytes and all 53 complete row objects were frozen before semantic reassessment.

This PASS applies only to applicability of the exact private candidate. Canonical currently differs on COM-004, COM-005, COM-007 and TEL-001. This report does not claim canonical is corrected or accepted. Integration may carry this mapping result only after a future check proves equality of the complete canonical AP09.7 53-row projection with `rows-before.json` AND unchanged bytes/SHA-256 of every relied-on authority (including supplementary schemas). Any discrepancy requires reassessment. Candidate root metadata and unrelated generated reader/output changes are outside this applicability scope. No content, package, global, live or A97 gate acceptance is granted.

## Method and authority

Read the complete quality standard and acceptance contract, all 53 catalogue duties and complete candidate mapping records. Reassessed all twelve assigned/excluded facets for every row against actual scoped implementation/configuration/protocol/schema paths. The previous failed report supplied leads and its data-layout helper was reused for evidence assembly; its verdicts were not treated as authority. The expected sets were independently retained after the source/duty reassessment. `source-reading-plan.txt` and `inspected-primary-excerpts.json` identify narrow sources; this is not a claim that every file in the repository was read.

The 71 primary/contract/catalogue authority files captured before focused source reassessment remain byte-identical. Two supplementary schemas were inspected later and matched the original/final HEAD blobs; they have an explicit separate timing/binding record. Complete candidate bytes remain unchanged. Structural assertions resolve every cited line range and assert 53 unique results and 636 unique pairs; those assertions do not themselves prove semantics.

Scope follows quality-standard lines 20–75: all KubeClaw functions/interfaces, supported optional branches, selected manifests/charts/clients, default omissions and actual data lifetime/security boundaries remain applicable. General unused upstream alternatives are outside scope. No upstream operational claim is verified by file existence or a live test assumption. Planned Git mirror is not an implemented store; the current Git-origin failure boundary still participates. A read-only consumer, incomplete writer or absent implemented restore does not erase an existing physical state duty.

## Coherence decisions across comparable rows

Durable authority/recovery is a store contribution where the catalogue owns result import, stored outcomes, state/removal, replay, authority or lifetime. This consistently includes SPC-004/005/006/010, COM-002/003/004/005/007/010, TEL-001/005/006/007 and actual data/infrastructure store rows. Plain per-connection persistence annotation (COM-001), endpoint method/path listing (COM-008), framed channel data (COM-006), bounded event type/schema (TEL-002), and subscriber-to-sink association (TEL-003) do not each become the complete physical retention/restore authority contract. Their applicable wire semantics remain under 05; complete store duties remain on owning rows.

COM-007 owns the RESP client path: passwordSecret resolution through secrets.read and AUTH are actual trust boundaries, so 08 applies. COM-001/004/005/008/009/010/011 and selected infrastructure identity boundaries also include 08. DAT-007 owns stream/key/dedup/MAXLEN/AOF/replay/deletion data, while COM-007/INF-009/SEC-004 own credential resolution/rotation policy; no second independent Secret matrix is created just because DAT-007 uses Redis. DAT-005 is schema/matched-backup/migration scope; DAT-006 explicitly adds credentials and connection pool and therefore adds 05/08. Local journal hash/record identity consistency (DAT-002/003) does not alone define external credential or supply-chain policy. DAT-004 signing and DAT-008 digest/visibility/artifact identity do.

TEL-001 owns canonical-event versus projection authority and sink/query/replay; persistent telemetry projection and checkpoint journals require 06. TEL-003 associates subscribers and sinks without owning their full retention/restore lifecycle. TEL-004 explicitly owns sensitive-field/redaction duties and therefore includes trust 08. Incidental logs/health observations in infrastructure do not all become a telemetry architecture; INF-010 explicitly does and has selected storage, auth absence and privileged log access.

Runtime dependency census 01, six named dependency operating contracts 02, LiteLLM gateway 03, optional platform fallback 04 and named specialist products 09 remain scoped to actual catalogue duties. An adjacent deployment PVC does not make the read-only Ops troubleshooting caller (SPC-007) a workspace-store owner. Archviewer (SPC-010) explicitly reads the persisted design tree and publication/lifecycle inputs, so its store contribution is real. A core invocation local recovery duty is not automatically the package-wide named-dependency fault journey 10.

A97-11 remains included on all 53 rows and retains BOTH full requirements: fresh Reader diagnosis and safe recovery for EVERY dependency, and separate full Source comparison of ALL applicable matrices against current authorities. This review performs applicability reassessment, not those complete content/Reader executions. A97-12 remains included on every row: real discovery must reject undocumented additions; quality-standard lines 68–75 and contract maintenance requirements preserve change, removal and rename detection. Fixed counts, pinned links, pending checks and manual mapping cannot replace genuine mutation evidence. No row exclusion waives package-wide gates.

## Four corrected duties

| Candidate row | Accepted scoped correction | Narrow implementation authority |
| --- | --- | --- |
| COM-004 (candidate line 3361) | 06: durable OpenClaw result import/publish before Git cleanup, with authority/loss/corruption/remaining-data and honest restore limits | runtime-dispatch/src/openclaw.ts:279–298; src/openclaw-result.ts:63–115; src/result-persistence.ts:44–95; schemas/openclaw-config.schema.json:14–62 |
| COM-005 (candidate line 3439) | 06: effects/event/checkpoint/delivery journal authority and restart repeat/stop consistency | skills/nova/core/execution/engine-runtime.ts:75–94; execution/effect-recovery.ts:14–28; telemetry/observers.ts:43–67; telemetry/observer-recovery.ts:33–81 |
| COM-007 (candidate line 3593) | 08: passwordSecret authority/resolution and AUTH on Redis/rediss client path, with actual negative access and honest rotation limits | skills/common/plugins/redis-transport/src/adapter.ts:23–43,62–84; src/exchange.ts:7–35 |
| TEL-001 (candidate line 4777) | 06: durable telemetry projection writer/reader/capacity/replay/lifetime plus canonical journal/recovery authority; added engine-runtime.ts dependency is present | skills/common/plugins/telemetry-store/src/adapter.ts:5–41; skills/nova/core/execution/engine-runtime.ts:75–94; telemetry/observer-recovery.ts:14–30 |

No additional material applicability omission or unjustified inclusion was found in this whole-set reassessment. Old FAIL remains tied to the old canonical revision/scope; it was not relabelled as a historical PASS.

## Every row and expected facet set

Numbers below mean A97-xx. Each row is individually assessed; `applicability-decisions.json` has every one of the 636 include/exclude reasons with catalogue and primary source authority.

| Row | Verdict | Expected included | Expected excluded |
| --- | --- | --- | --- |
| SPC-004 | PASS | 05, 06, 08, 09, 11, 12 | 01, 02, 03, 04, 07, 10 |
| SPC-005 | PASS | 05, 06, 07, 08, 09, 11, 12 | 01, 02, 03, 04, 10 |
| SPC-006 | PASS | 05, 06, 07, 08, 09, 11, 12 | 01, 02, 03, 04, 10 |
| SPC-007 | PASS | 01, 05, 08, 09, 11, 12 | 02, 03, 04, 06, 07, 10 |
| SPC-009 | PASS | 01, 05, 08, 09, 11, 12 | 02, 03, 04, 06, 07, 10 |
| SPC-010 | PASS | 01, 05, 06, 08, 09, 11, 12 | 02, 03, 04, 07, 10 |
| COM-001 | PASS | 05, 08, 10, 11, 12 | 01, 02, 03, 04, 06, 07, 09 |
| COM-002 | PASS | 05, 06, 08, 10, 11, 12 | 01, 02, 03, 04, 07, 09 |
| COM-003 | PASS | 05, 06, 08, 10, 11, 12 | 01, 02, 03, 04, 07, 09 |
| COM-004 | PASS | 05, 06, 08, 09, 11, 12 | 01, 02, 03, 04, 07, 10 |
| COM-005 | PASS | 05, 06, 07, 08, 11, 12 | 01, 02, 03, 04, 09, 10 |
| COM-006 | PASS | 05, 08, 11, 12 | 01, 02, 03, 04, 06, 07, 09, 10 |
| COM-007 | PASS | 02, 05, 06, 08, 10, 11, 12 | 01, 03, 04, 07, 09 |
| COM-008 | PASS | 05, 08, 11, 12 | 01, 02, 03, 04, 06, 07, 09, 10 |
| COM-009 | PASS | 02, 05, 08, 10, 11, 12 | 01, 03, 04, 06, 07, 09 |
| COM-010 | PASS | 02, 05, 06, 08, 10, 11, 12 | 01, 03, 04, 07, 09 |
| COM-011 | PASS | 05, 08, 11, 12 | 01, 02, 03, 04, 06, 07, 09, 10 |
| COM-012 | PASS | 05, 10, 11, 12 | 01, 02, 03, 04, 06, 07, 08, 09 |
| DAT-001 | PASS | 06, 08, 10, 11, 12 | 01, 02, 03, 04, 05, 07, 09 |
| DAT-002 | PASS | 06, 11, 12 | 01, 02, 03, 04, 05, 07, 08, 09, 10 |
| DAT-003 | PASS | 06, 11, 12 | 01, 02, 03, 04, 05, 07, 08, 09, 10 |
| DAT-004 | PASS | 06, 08, 11, 12 | 01, 02, 03, 04, 05, 07, 09, 10 |
| DAT-005 | PASS | 02, 06, 10, 11, 12 | 01, 03, 04, 05, 07, 08, 09 |
| DAT-006 | PASS | 02, 03, 05, 06, 08, 10, 11, 12 | 01, 04, 07, 09 |
| DAT-007 | PASS | 02, 05, 06, 10, 11, 12 | 01, 03, 04, 07, 08, 09 |
| DAT-008 | PASS | 06, 08, 11, 12 | 01, 02, 03, 04, 05, 07, 09, 10 |
| DAT-009 | PASS | 02, 06, 10, 11, 12 | 01, 03, 04, 05, 07, 08, 09 |
| TEL-001 | PASS | 05, 06, 07, 11, 12 | 01, 02, 03, 04, 08, 09, 10 |
| TEL-002 | PASS | 05, 07, 11, 12 | 01, 02, 03, 04, 06, 08, 09, 10 |
| TEL-003 | PASS | 05, 07, 11, 12 | 01, 02, 03, 04, 06, 08, 09, 10 |
| TEL-004 | PASS | 05, 07, 08, 11, 12 | 01, 02, 03, 04, 06, 09, 10 |
| TEL-005 | PASS | 05, 06, 07, 11, 12 | 01, 02, 03, 04, 08, 09, 10 |
| TEL-006 | PASS | 06, 07, 11, 12 | 01, 02, 03, 04, 05, 08, 09, 10 |
| TEL-007 | PASS | 05, 06, 07, 11, 12 | 01, 02, 03, 04, 08, 09, 10 |
| INF-001 | PASS | 01, 11, 12 | 02, 03, 04, 05, 06, 07, 08, 09, 10 |
| INF-002 | PASS | 01, 05, 06, 11, 12 | 02, 03, 04, 07, 08, 09, 10 |
| INF-003 | PASS | 01, 04, 05, 08, 11, 12 | 02, 03, 06, 07, 09, 10 |
| INF-004 | PASS | 01, 04, 05, 08, 11, 12 | 02, 03, 06, 07, 09, 10 |
| INF-005 | PASS | 01, 02, 05, 06, 08, 10, 11, 12 | 03, 04, 07, 09 |
| INF-006 | PASS | 01, 02, 05, 06, 08, 10, 11, 12 | 03, 04, 07, 09 |
| INF-007 | PASS | 01, 02, 05, 06, 08, 10, 11, 12 | 03, 04, 07, 09 |
| INF-008 | PASS | 01, 02, 05, 08, 10, 11, 12 | 03, 04, 06, 07, 09 |
| INF-009 | PASS | 01, 02, 05, 06, 08, 10, 11, 12 | 03, 04, 07, 09 |
| INF-010 | PASS | 01, 04, 05, 06, 07, 08, 11, 12 | 02, 03, 09, 10 |
| INF-011 | PASS | 01, 05, 08, 09, 11, 12 | 02, 03, 04, 06, 07, 10 |
| INF-012 | PASS | 01, 03, 05, 06, 08, 10, 11, 12 | 02, 04, 07, 09 |
| SEC-001 | PASS | 08, 11, 12 | 01, 02, 03, 04, 05, 06, 07, 09, 10 |
| SEC-002 | PASS | 05, 08, 11, 12 | 01, 02, 03, 04, 06, 07, 09, 10 |
| SEC-003 | PASS | 05, 08, 11, 12 | 01, 02, 03, 04, 06, 07, 09, 10 |
| SEC-004 | PASS | 05, 08, 11, 12 | 01, 02, 03, 04, 06, 07, 09, 10 |
| SEC-005 | PASS | 04, 05, 08, 11, 12 | 01, 02, 03, 06, 07, 09, 10 |
| SEC-006 | PASS | 02, 05, 08, 11, 12 | 01, 03, 04, 06, 07, 09, 10 |
| SEC-007 | PASS | 08, 11, 12 | 01, 02, 03, 04, 05, 06, 07, 09, 10 |

## Actual checks and limits

Performed: read-only source/configuration/schema/protocol inspection, catalogue/mapping comparison, all 636 applicability decisions, SHA-256/byte freezes, line-range resolution and unique-pair assertions. Evidence assembly command: `python /home/node/Documents/Codex/a98-evidence/ap097-durable-path-candidate-full-mapping-source-fresh/build-evidence.py` exited 0: 53 rows PASS, 636 decisions PASS, unchanged exact candidate and 71 unchanged primary authorities. Final HEAD remained the stated commit. The repository was shared and dirty; no clean-checkout acceptance is claimed. Some broad exploratory outputs were truncated and were followed with focused reads; two guessed SDK directories did not exist and actual contract paths were then discovered. These are search results, not product test failures.

Not performed: repository edits, generated-output writes, product tests, generator/checker runs, add/change/remove/rename mutation executions, content completeness review of every page/matrix cell, independent Reader diagnosis/recovery exercise, controlled-language acceptance, renderer/routes/publication tests, deployments/live enforcement, commits, or any A97 package/global acceptance. All remain pending. Evidence helpers write only this external evidence directory.

Private mapping acceptance remains conditional on future canonical projection equality and unchanged needed authorities as stated above.
