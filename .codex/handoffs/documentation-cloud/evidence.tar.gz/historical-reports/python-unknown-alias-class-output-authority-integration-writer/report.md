# Unknown-key, alias, class-annotation and shell custody authority integration

Author integration evidence only. Historical complete Source FAIL S1–S5 remains attached to the original b8cb884c-qualified candidate and is not converted into PASS. No independent Source, Reader, Quality, package/global, publication or live acceptance is claimed. Shared HEAD is 2a8558d795054d25aa4b72dbdc296c9321ba38f6 with pre-existing dirty changes.

Root explicitly held provisional 43b52dc and then released only superseding final scanner b27e386731f0416daaf899d2640e2cdae67e4181d676b88d48d79f92d160d578 (831920 bytes) and test 2bb4b67525de7b3c8dc392d2c2480cc7bd01f07416346348b223197af046a382 (34490 bytes). Both final identities were verified before mutation. No interim candidate was qualified. The private before scanner is explicitly an interim ea3f1223 input, not the prior qualified Source. Prior complete qualified scanner b8cb884c85e364ccf99c46d1ca8044a94b6e0532b657cccab7bffdffe30855f4 was preserved separately and the complete final scanner diff was examined against it.

## Exact frozen author delta

Exclusive edited files: scripts/docs-api-output-discovery.mjs and scripts/docs-api-producer-adapter-authorities.json. Registry updates only the existing scanner sourceSha256 from b8cb884c85e364ccf99c46d1ca8044a94b6e0532b657cccab7bffdffe30855f4 to b27e386731f0416daaf899d2640e2cdae67e4181d676b88d48d79f92d160d578. Discovery updates only its exact complete Source recipe anchor from 0cebf713ab9c242fd68a9e76643c022be9d67dabe95c4b4690ce59f386277ab1 to 2805546006609fee0f9bdc779c414eb0ffc1902f5b750d9b156888949d6c59db.

Final discovery SHA256 3a5b001a7df705e2203ac0e569e54e7d3ab178982340180e27673099fd3f00a8, 341826 bytes. Final registry SHA256 95e4745c223f759da145946499acedb9faf60abd05fe732275606ee9551a7d4a, 2699859 bytes. Both are frozen. Exact single substitutions reproduce both files; every other owned byte remains identical. No scanner/test/product/docs/matrix/generated edit, commit, push or generation was performed by this integrator.

## Complete semantic and dependency examination

S1: key acquisition now carries None as an explicit unresolved/non-string alternative through names, simple bindings and joins. Missing branch bindings retain unknown alternatives. A known key cannot erase the unresolved member; add rejects empty or unknown-bearing domains with the actual source and line. Finite known literal branches remain supported. This is fail-closed static acquisition rather than execution of arbitrary helpers.

S2: selected function identity is registered separately and propagated through finite role/alias expressions, including known method selections. Calls select registered bodies against current lexical/global state; later rebinding no longer postpones the alias call to final pending analysis. An active-function set bounds recursion. Arbitrary dispatch/reflection and all possible callable object forms remain outside this finite model.

S3: lazy class annotations retain their owning class, actual class-bound names and namespace. Explicit __annotations__ or recognized annotationlib.get_annotations accesses combine that namespace with evaluation-time globals; older eager annotations retain their path. Future/local passive distinctions remain. The superseding fix passes eval_str into class evaluation and retains explicit nonfuture evaluated-string rejection with annotation line/source. Final potential class evaluation remains conservative; this does not assert that every annotation is executed at declaration or at runtime. No inspected expression is evaluated by the scanner.

S4: >, >> and finite descriptor duplication acquire their descriptors and operands as redirections, not Python positional argv. stdout/stderr no longer suppress selected stdin heredoc code. fd0 winning-input custody remains. Combined or unresolved redirection/operator forms reject where supported custody cannot be established. No runtime output is produced by the scanner to model these forms.

S5: delimiter quoting and escaping are retained. Quoted bodies preserve literal syntax. A selected unquoted body with unresolved dollar/backtick/backslash expansion rejects rather than silently parsing the unexpanded body. Plain unquoted finite code stays supported; passive nonselected heredoc bodies are not promoted. This fixes acquisition custody without claiming that the earlier independent receiving gate was GREEN for every S5 fixture.

No module loader, selected Node module path, caller/schema authority or native launcher changed. Before mutation every actual dynamic import was extracted from final TypeScript AST: six expressions and complete containing-operation hashes match the existing recipe exactly. Actual full graph audits retain 12 recipes / 27 unresolved operations / six scanner imports / 15 selected modules. No broader inventory or schema update was justified or made; root received this assessment before final test evidence.

The actual ops/pod/test-image.sh:26 stdin dependency remains ops/pod/test/app_server_smoke.py SHA256 a283df5cd2bf4208cf762d25c293207d39862f475f82e1ad46cdccae5e137361. Its finite winning-fd0/interpreter-mode, exact dirname/BASH_SOURCE or absolute path, repository containment, regular-file and realpath checks are unchanged. Current target is parsed and has no keyed environment readers. New external readers reject with target path/name/line rather than a fabricated shell offset. There is no new filesystem acquisition or helper exemption in this batch.

Native AST transport remains fixed literal python3 -I -c, stdin-only inspected text, UTF-8, 10-second timeout and 8-MiB output bound. It uses ast.parse and finite literal/AST inspection; inspected programs are never imported, evaled or executed. Corpus/capture full test Source/package/command/dependency roles, pure metadata helper qualification and public/canonical/capability guards are unchanged byte-for-byte. All 61 unrelated captured baseline inputs remain identical. All 65 complete final captured input hashes match at end.

## Actual terminal checks

Focused production api-output-publication.test.mjs: exit 0, 25 PASS / 0 FAIL / 0 SKIP. Source/digest/operation repair, helper/public/canonical/capability custody, finite bridges/cache and precise native corpus/capture roles remain covered by the unchanged suite.

Production new-custody test selection: exit 0, five PASS / zero FAIL / zero SKIP: unknown alternatives; function/method aliases with passive shadows; lazy class annotation namespace/timing and eval_str string rejection; output-redirection argv custody; quoted/expanded heredoc distinction. These tests invoke current extracted scanner and actual receiving gates with synthetic fixtures. This integrator did not run the writer's separate native execution witnesses or whole 33-test file. The writer's six native witnesses, 33/33 and actual 436-name coverage are external owner evidence, not counted here.

Actual operation-owner audit exit 0 verifies 27/27; complete Source/caller/canonical recipe audit exit 0 verifies 12/12. Actual full protected graph assertion exit 0 verifies 12/27. Five actual current-function operation-only/source-only/caller-only/selected-input-extension/unsupported-custody repair probes reject.

Private actual scanner authority controls: exit 0, 9/9. Final full source/six operations accept. Changed Source, JSON-only Source refresh, new expression, changed containing operation, unsupported capability, missing selected module and canonical retarget to qualified PV metadata reject. Changed selected bytes alter the authority cache key; that control does not independently prove semantic rejection of every selected-byte mutation. Private actual provider-child caller controls: exit 0, 4/4; baseline accepts while caller byte drift, JSON-only refresh and canonical retarget reject.

Actual checkout discovery exit 0: 36 script outputs, 111 shell outputs, zero false PV helper outputs, one real selected PersistentVolume PATCH and seven receiver fields. YAML collection-key warnings retained. Counts are observed facts, not completeness bounds.

Quality standard, AP09 contract, CFG-011/013/015 and A98-10/11/14 remain applicable. Actual newly selected input detection cannot be replaced by fixed counts. No full root suite, global generators, all 84 registered mutations, product programs, cluster/kubectl, credentials against services, corpus PostgreSQL or native capture runtime, publication, Reader/Quality/live acceptance ran here. No earlier independent FAIL was relabeled. Fresh whole Source review and root stable suite remain necessary.

## Evidence custody

Private before/interim snapshot, prior complete qualified scanner, complete final diff, actual operation/recipe audits, production extraction harnesses, final terminal logs/run ledger, 65 final complete inputs, exact single-substitution proof and frozen owned files are retained. Manifest binds every artifact except itself/seal; seal binds exact report and manifest hashes/bytes. Earlier sealed evidence is untouched.
