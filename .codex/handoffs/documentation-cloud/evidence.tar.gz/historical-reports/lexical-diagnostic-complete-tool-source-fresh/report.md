# Independent Tool SOURCE review — lexical custody and diagnostic qualification

**Verdict: FAIL.** Independent reviewer `/root/lexical_diagnostic_complete_tool_source_fresh`, fresh context, read-only in the reviewed repository throughout. Initial HEAD `79816e114a3db5b38260ddb814d5e1ae66c43c66`; final observed HEAD `b63f36b0f563c70abb8901d4bd5c75d5115f9d46`. This is a frozen-working-tree Tool Source review, not clean-commit acceptance. The four assigned frozen authorities matched their supplied SHA-256 values initially and finally. No SourceDoc, ReaderDoc, Quality, Astra, package/global AP09, publication, deployment or live verdict is granted.

Repository: `/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04`. Evidence: this directory. Product/source edits, generation, installation, cluster access, commit and push were not performed by this reviewer. Private synthetic fixture files and read-only filesystem overlays were used for negative checks.

## Material findings

### S1 — F6: known `os` reflection silently loses reader authority

`pythonEnvironmentReads`, `scripts/docs-configuration-inventory.mjs:5477` (`Readers.role`), `:5809` (`visit_Attribute`), `:6141` (`visit_Call`). The reflection guard at :6149 recognizes `getattr`, while the attribute reflection guard at :5811 covers annotationlib/subprocess receiver mutation. Neither covers a known `os` module's dictionary or bound attribute accessor.

Both executable finite witnesses return an empty reader inventory without an unsupported diagnostic:

```python
import os
os.__dict__['getenv']('FRESH_DICT_REFLECTION')
```

```python
import os
os.__getattribute__('getenv')('FRESH_ATTRIBUTE_REFLECTION')
```

Native Python executes both, records the requested key through a synthetic instrumented getenv, and exits zero. Separate full receiving-source overlays append corresponding new reads to actual `ops/pod/bootstrap.py`. Both coverage gates exit zero with the unchanged 436-name inventory. The baseline also exits zero; a direct new getenv key exits one with `CONFIG_SEMANTIC_GAP`, so the overlay is sensitive to the intended source and gate.

Evidence: `witness-results.json`, `receiving-gate-results.json`, `dictionary-receiving-gate.log`, `attribute-receiving-gate.log`, `direct-receiving-gate.log`, and the overlay source. Required correction: preserve or explicitly reject these recognizable reflected module/capability acquisitions at their actual receiving source. No arbitrary reflection interpreter or universal Python certificate is required.

### S2 — F1/F3: bound reflected annotation access loses evaluation-time custody

Same owning scanner, `Readers.role` at :5477 and `visit_Attribute` at :5809. Direct annotation access, aliases and known annotationlib calls retain identity. A bound `.__getattribute__('__annotations__')` access on a known function/method does not. The final annotation pass then uses the rebound global namespace and silently misses the earlier actual evaluation:

```python
import os
def fresh(x: os.getenv('FRESH_BOUND_FUNCTION')): pass
fresh.__getattribute__('__annotations__')
os = None
```

```python
import os
class Fresh:
    def method(x: os.getenv('FRESH_BOUND_METHOD')): pass
Fresh.method.__getattribute__('__annotations__')
os = None
```

Each native Python witness records the key and exits zero; each scanner returns `[]`. Each full bootstrap receiving overlay exits zero with 436 names. The class control `type.__getattribute__(C, '__annotations__')` rejects through transferred class custody, showing that supported explicit rejection already exists for the adjacent finite capability path.

Evidence: `witness-results.json`, `annotation-reflection-gate-results.json`, `functionAnnotation-receiving-gate.log`, `methodAnnotation-receiving-gate.log`. Required correction: recognize or explicitly reject bound reflective metadata access on known function/method identities whose annotation evaluation can acquire environment authority. Retain defining-module globals and access-time/active lexical closure semantics. Add full receiving-source negatives and native witnesses for both identities.

### S3 — ordinary public checkout: module closure discovery depends on a documentation exemption

`scripts/docs-api-output-discovery.mjs:405` returns from `assertDocumentationToolQualifications` when there are no qualification records. This skips `documentationModuleGraph`. At :446, `nodeOutputExecutableSources` then uses `nodeProductExecutableSources`, which enumerates root executable filenames but not transferred CommonJS fallback modules. The closure is consequently absent from the actual scanner at :955 and from output-role classifications at :1230.

An ordinary private checkout has `package.json`, public `tools/gateway.cjs`, and `tools/producer.yaml`, with no documentation-authority registry or static-source exemption. Gateway code:

```javascript
require('./producer.yaml');
```

The transferred file first prints a literal core/v1 Secret JSON, then is changed to `process.stdout.write(process.argv[2])`. Actual Node CommonJS executes the YAML-suffixed module in both cases and emits Secret JSON with exit zero. `discoverScriptApiOutputs` returns `[]` for both variants, without rejecting unknown publication. Direct docs-named `.mjs` producers in that same checkout are discovered on Add and Change, and removed on Remove, so the problem is specifically transferred executable closure custody.

Evidence: `public-producer-results.json`, `commonjs-native-results.json`, and their private fixture sources. Required correction: build and validate the complete canonical executable module closure independently of whether documentation metadata exemptions exist. Apply qualification-specific guards conditionally, while keeping ordinary transferred modules, CommonJS fallback formats, unknown publication and cache invalidation in discovery. Do not make the presence of a PV metadata exemption a prerequisite for complete public discovery.

## Individual F1–F10 decisions

These are complete-family decisions in the finite assigned scope, not retroactive changes to the prior FAIL report.

| Family | Verdict | Source and evidence |
| --- | --- | --- |
| F1 function annotation identity/timing | FAIL | Original chained/conditional alias and caller-shadow cases are corrected. S2 leaves recognizable bound reflected access GREEN at the full receiver. |
| F2 class annotations and class-owned namespace | PASS | Known class identity, aliases, class-local snapshot/current globals, future/passive strings and actual annotationlib target custody are retained. Unknown class bases, metaclass authority and mutation reject explicitly. Independent semantic controls and current native tests cover these cases. |
| F3 method annotation identity/timing | FAIL | Direct `C.f.__annotations__`, method aliases, class-owned annotation keys and caller-shadow controls pass. Bound reflected access fails S2. |
| F4 Python argv mode | PASS | Shared finite mode parser consumes admitted flags and only selects the first real mode. Script/module operands after the mode remain passive; unknown flags reject. Independent shell/YAML module/script controls pass. |
| F5 executable YAML wrappers | PASS | Actual command/args nodes acquire admitted env/sudo wrappers, `-c` programs and decoded source positions; passive description maps and operands are not promoted. Unknown wrappers/nonliteral argv fail with source identity. |
| F6 recognizable reflection/acquisition | FAIL | getattr/builtins aliases, star/helper paths reject, but known os dictionary/bound reflection silently escapes: S1. |
| F7 os star import | PASS | Finite unsupported os star import explicitly rejects at the exact receiver; native execution establishes its capability. |
| F8 helper returned/passed capabilities | PASS | Functions/classes/methods/lambdas, nested literal containers, aliases, parameter/default/return/iteration/write/unpack/Boolean/comprehension custody are retained or explicitly rejected. Passive None, ordinary data and pure callbacks remain admitted. Owning lexical namespace and snapshot forwarding controls are separately addressed below. |
| F9 mutable registry cannot reauthorize static receiving Source | PASS | `staticReceiverSourceAuthorities` at discovery :399 and check :416 bind the actual complete PV static module independently of mutable SHA/operationRecipe. Missing qualification, digest-only repair and digest+recipe repair reject. The actual module has fixed descriptions and no runtime-input/output capability. Protected semantic input recipes and caller/canonical-input guards are preserved. |
| F10 exact captured Codex bearer receiving authority | PASS | Discovery :1514–1560 binds the complete shell body, unique Codex container/mount, exact bearer volume/Secret projection and bootstrap producer. Actual deploy shell caller and Docker COPY are also checked in `shellDynamicOperationProof`. Unrelated Ops MCP mount, changed selected mount, mode/items/Secret/volume ambiguity and additional output reject in current receiving tests. |

## Assigned facet decisions

| Facet | Verdict | Individual acceptance basis |
| --- | --- | --- |
| Syntax-only Python acquisition; passive comments/docstrings/literals | PASS | Parser uses `python3 -I` and never imports/executes inspected text. Passive None and raised synthetic programs are parsed; native execution is a separate synthetic witness. |
| Direct imports/aliases/static keys/finite joins | PASS | Actual role/key binding and unknown alternatives examined; finite if/else, walrus, tuple loops, empty loops and shadows have current controls. |
| Callable/class/method containers and parameter/return custody | PASS | Marker propagation and rejection paths read in the actual scanner; 39 independent supplemental semantic witnesses pass, including nested/Boolean containers, defaults, iteration and write receivers. |
| Owning module globals and active closure namespace | PASS | `analyze_function`, `annotation_globals`, definition states, lexical ownership and function stack are reviewed. Caller local os/subprocess shadows cannot replace the callee module. Active closure imports work; escaped unresolved closure authority rejects. |
| Annotation access and reflected metadata | FAIL | Explicit normal access and mutation controls pass; bound reflective access fails S2. |
| Exact subprocess env snapshot receiving proof | PASS | `exact_subprocess_receiver` and `snapshot_forwarding_parameter` bind unconditional owning imports/aliases, exclude parameter/local/global/nonlocal writes, module escape, decorated/bound method argument ambiguity and foreign receivers. Only copied snapshots in the exact env slot/closed helper forwarding are exempted. Unwritten/deleted/conditional/mixed keys and opaque helper reads reject. |
| Shell executable Python, stdin and native argv | PASS | Finite quoting, wrapper, substitutions, redirects, winning fd0, quoted heredoc and mode logic read. External stdin is canonical repository file custody; readers there reject with target path/key/line instead of a fabricated caller line. Native current tests and independent winning-fd0/fd3/script/module controls pass. |
| Executable YAML Python | PASS | Node ancestry restricts real container/exec command and args; decoded offset mapping and wrapper/mode rules checked. No blanket YAML or filepath exemption. |
| Actual OPS bootstrap consumers | PASS | Entire owning bootstrap and current OPS test read. Exact selector/value precedence, empty selectors, path whitespace, strip/default decoding, content failure, missing/unreadable/directory/invalid encoding, order and partial effects match actual code. Current 9 tests execute unchanged functions against synthetic subprocess/files only. |
| OPS supervisor and auth shell consumer | PASS | Whole supervisor, shell, deploy caller, Docker source and selected workload read. Supervisor copies os.environ then strips mounted token text and forwards env to exact subprocess Popen; auth shell exports unstripped command-substitution token after length guard. kubectl exec does not inherit supervisor env. No live authentication claim. |
| Secret copy versus grant versus volume admission | PASS | Fixture provider/runtime payload, both allowlists, lease `secretsToCopy`, controller `copySecrets`/`sanitizeSecret`/`createOrPatch`/kube transport and actual callers inspected. Copying an approved Secret object is separate from access grants and checked manifest projections. The changed schema purpose accurately distinguishes those operations. |
| Static Source qualification and protected recipe/caller anchors | PASS | Immutable static module SHA, finite semantic input recipes, full unresolved operation inventory, canonical closure and public exposure guards inspected. Current publication cases cover registry repair, caller/module drift, extensions, symlink retargeting, missing/escape and cache reuse. |
| Synthetic native corpus/capture exclusions | PASS | Complete two actual native test sources and owning package commands read; complete Source/caller/contracts are pinned, and public imports/symlinks/package targets invalidate synthetic classification. There is no generic test-directory acceptance for those roots. Real PostgreSQL/browser tests themselves were not run. |
| Diagnostic checker Source qualification | PASS | Full checker read. Native Source anchor :876–886 protects complete collection/producers, independently of a mutable line/operation receipt. Current checker hash is `79469dc8ac99a7d111c93d5d22c6f3cdbe1a3834822a7ec275da3ac3eaec7715`. Exact three sinks are 212/213/217; :213 uses the renewed exact receipt. |
| Diagnostic API/sink mutations | PASS | Independent const/producer-push/sink mutations were classified and executed only in private synthetic checkouts. Narrow sink facts alone can retain a producer-push role, but the actual public receiving discovery rejects every changed checker at `API_PRODUCT_DIAGNOSTIC_SOURCE_ROLE_UNQUALIFIED`. No diagnostic label overrides actual API identity. |
| Full API output discovery dispatch and qualification | FAIL | Helm branch witnesses/rejections, script syntax/constructors/final mutation ordering, native Python/Go, raw shell receiving channels, patches, transformed renderers, infrastructure/external archives and caching were inspected. S3 leaves an actual new/changed public executable transfer undetected in ordinary checkout. A green qualified fixture cannot approve the default domain. |
| Root module/seed/canonical/dependency closure | FAIL | Qualified metadata fixtures preserve loader capability custody and closure. Ordinary no-record checkout skips that same closure: S3. |
| Current corpus retained | PASS | Independent exact receiving baseline exits zero/436, current focused 94 tests pass. This proves retention only; S1/S2 negate future completeness. |
| All recognizable new inputs must reject/discover | FAIL | Four new full receiving-source mutations stay GREEN; S1/S2. |

## Catalogue and gate facets

Catalogue entries were read in `docs/blueprint/generated/ap09-catalogue.json`, together with the quality standard, acceptance contract, execution plan and preregistered fixtures. There is no `API-*` namespace in this catalogue: API tool facets map to CFG/REF IDs. The following decisions are confined to assigned tooling Source facets and are not page/content verdicts.

| ID / facet | Verdict | Reason |
| --- | --- | --- |
| CFG-010 host/Codex/OPS receiving Source facet | FAIL | Actual selected OPS behavior is source-correct locally, but future reflected environment/annotation consumers can be invisible. |
| CFG-011 environment/Secret discovery | FAIL | S1/S2 violate exhaustive receiving-source discovery. Exact current OPS selectors and Secret bindings pass locally. |
| CFG-013 effective-value Source authority | FAIL | Actual globals can be read at an earlier explicit evaluation that final-state discovery silently misses. |
| CFG-015 fail-closed configuration discovery diagnostics | FAIL | Recognizable reflected custody is neither discovered nor explicitly rejected. |
| CFG-018 supported configuration/consumer discovery facet | FAIL | New consumers and public transferred executable outputs are hidden by S1/S2/S3. |
| OPR-003 selected OPS bootstrap/deploy Source facet | PASS | Actual discovery, credential preparation, pre-render order and exact source/caller mapping inspected; no installation/live outcome approved. |
| OPR-006 checker/diagnostic Source facet | PASS | Exact checker collection/sink/Source qualification and independent receiving negatives pass. This is not diagnosis guide acceptance. |
| OPR-008 selected OPS credential update/partial-effects Source facet | PASS | Files are applied on each nonempty selector, previous bearer/pull retained, later failure does not roll back earlier changes; actual error boundary suppresses submitted-object stderr. |
| REF-003 configuration discovery facet | FAIL | S1/S2. |
| REF-004 selected API output/schema-input discovery facet | FAIL | S3 can omit an actual serialized API source before schema/receiving inventory is built. |
| REF-012 exact environment/Secret Source completeness facet | FAIL | S1/S2; copied Secret semantics are otherwise inspected separately from projections/grants. |
| A98-10 assigned environment/API-output completeness | FAIL | Real recognizable inputs and public output source transfers vanish. Other general configuration families are outside this tooling verdict. |
| A98-11 assigned effective namespace/receiver authority | FAIL | Bound reflected annotation evaluation is not retained. Current OPS/envcopy/captured mount boundaries pass individually. |
| A98-14 assigned new environment discovery mutation facet | FAIL | Full new input receiving mutations remain GREEN. The full preregistered Helm/Secret/script/swarm mutation package was not run here. |
| A911-01 assigned output discovery search-space/parser facet | FAIL | S3 means declared public execution roots do not consistently include their real transferred executable closure. |
| A911-02 assigned recursive Source retention facet | FAIL | Hidden callable annotation/environment custody and actual executable transfer are incomplete. |
| A911-08 assigned read-only evidence facet | PASS | Exact coverage mode exits before generation. All repository captured sources stay byte-identical; private fixtures receive writes. No general generator determinism acceptance is claimed. |
| A911-12 assigned independent Source scope facet | FAIL | Independent review finds S1/S2/S3. No clean-checkout maintainer/global reproduction verdict is granted. |
| A912-01 assigned diagnostic internal-reader boundary tooling facet | PASS | Full checker/Source anchor and Source-bound output role examined, with no filepath or diagnostic-label exemption. Publication output/Reader route checks remain separate. |

## Executed checks, reuse, and limits

Independently executed:

- `node --test scripts/tests/python-environment-discovery.test.mjs scripts/tests/ops-bootstrap-environment-contracts.test.mjs scripts/tests/api-output-publication.test.mjs`: terminal exit 0, 94 pass, zero fail/skip. Both complete changed test files and the OPS test were read.
- Exact `--check-environment-coverage-only`, with baseline, direct negative sensitivity and four reflected custody mutations: baseline/direct behave correctly; four reflected mutations return GREEN/436. Native reflection witnesses separately prove the reads.
- `semantic-family-witnesses.mjs`: 39 supplemental independently selected supported/rejection controls, all matching their expected result. These are not a universal Python proof.
- `diagnostic-witness.mjs` and `diagnostic-gate.mjs`: original three sinks plus three producer/sink variants; actual Source guard rejects all changed variants.
- `public-producer-witness.mjs` and `commonjs-native-witness.mjs`: direct Add/Change/Remove, public transferred literal output and changed unknown publication; transferred cases fail S3. Only synthetic private programs execute.
- `authority-validation.mjs`: reconstructed 264 current operation/Source receipts across all stored producer, nonAPI, command, native writer, static qualification and semantic-input groups. 263 match. One stale nonAPI operation receipt for `check-operator-task-registry-mutations.mjs` is unused: actual line76 derives `actual-for-of-tuple-bindings`; complete actual current sink roles are all nonAPI. This receipt mismatch is reported, not presented as a material false-GREEN or as a 264-PASS certificate. Digest equality alone is not semantic approval.

The supplied Root 11-suite receipt was read as an observed external record: terminal exit 0, 268 pass/0 fail/0 skip, with current frozen tool hashes. It was not relabelled as this reviewer's own execution, and does not override these independent failures. Author artifact counts and author PASS statements were not adopted as Source approval. The prior independent report defined F1–F10; its old FAIL remains tied to its original bytes. `prior-input-comparison.json` actually compares 2,068 prior inputs: eight differ; unchanged authority comparison is recorded without retroactive approval or mechanical rerun of thousands of unchanged controls.

Both complete native Go adapters (2,566 lines) and the complete native Python output adapter were read as AST/offline acquisition boundaries. Original product Go binaries, live native corpus/capture tests, full generators, publication, served routes, upstream deployment, full preregistered AP09 mutations, Reader exercises and Quality checks were NOT RUN by this reviewer. The standalone Go command only reports version. General unrelated schema/Helm/configuration prose and all product claims in the 261-item catalogue are not approved by this assigned Tool Source review. Source snapshots and mechanical recipe comparisons are not asserted to certify all possible Python, JavaScript, Go, shell or upstream capability behavior.

The whole assigned Tool Source verdict is FAIL: S1/S2/S3 require a correction batch and a new independent review. The passing family/facet rows do not offset them, and do not grant clean-commit, Reader, Quality, package or global acceptance.

## Read-only input and evidence seal

Initial manifest captured 966 scripts/OPS/blueprint and other source files before tests. An explicitly later extended input manifest captured broader roots before final qualification/consumer witnesses. The combined final guard covers 2,669 authorities: **zero byte changes**, including every frozen assigned file. Initial/final Git status and HEAD are separate artifacts; concurrent Root documentation commit advancement is not disguised as one reviewed clean commit.

| Frozen source | SHA-256 |
| --- | --- |
| scripts/docs-configuration-inventory.mjs | 4263f0e834ca8dd71e2be1cc3276306d0121f19c81fec9ceb06eb2fdee51c3db |
| scripts/tests/python-environment-discovery.test.mjs | 478f3ff5b7c5199c2d4d1bc3980cb81f836244011f983f75d2a510c59d7ac9d7 |
| scripts/docs-api-output-discovery.mjs | f9badd6b691cf495cdf1d5e059919aa2d03b6e9bd1140caf53c1b6600546531a |
| scripts/docs-api-producer-adapter-authorities.json | cae72d663464d1858f29187163ae83f56fc1d1e351b459150c11f23a208d3e09 |

Environment: Linux x86_64 managed workspace; Node v24.21.0, Python 3.14.8, Bash 5.3.9; private existing Go 1.26.3. No dependency install. `evidence-manifest.json` records each private artifact's path, byte size and SHA-256; all private evidence files are sealed read-only after this report. No repository source permission or content was changed by sealing.
