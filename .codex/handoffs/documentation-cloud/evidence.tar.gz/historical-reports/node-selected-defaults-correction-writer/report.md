# Node selected default author correction

Scope: exactly `scripts/docs-kubernetes-node-workloads-receiver-contracts.mjs` and `scripts/tests/node-workloads-receiver.test.mjs`. No runtime, generator, shared metadata, envelope, inventory, or publication edit; no commit or push.

Read the full documentation quality standard, including the 2026-10-10 product boundary, and AP09 acceptance clauses A98-02/06/10/11/13. This work supplies narrow authored receiving contracts for the configuration coverage work; it does not establish whole CFG009 or A98 acceptance.

Three missing defaults were selected by actual product discovery: DaemonSet template schedulerName, DaemonSet Secret volume defaultMode, and CSIDriver seLinuxMount. Direct DaemonSet/CSIDriver records avoid importing Deployment operation-specific examples. Present-parent, null, empty/zero, invalid decode/validation, update, gate and actual consumer conditions are explicit. CSI false does not relax SPIFFE read-only/ephemeral requirements or promise permissions, driver installation, mount eligibility, or successful live mounts.

All 272 prior emitted records retain byte equality as JSON records in the preservation ledger; exactly three records were added, giving 275. No old correction exception was needed.

Evidence: immutable Kubernetes 66452049f3d692768c39c797b21b793dce80314e originals were fetched fresh for the added mechanisms. Additional existing preparation originals were copied only after validating their recorded SHA256. Provenance identifies fresh URL/path/hash and copied-original method. Source-proof resolves 33 narrow references for the three additions with pinned original hash and private excerpt. It is author evidence, not an independent review.

Tests exercise every current discovered external Helm node output context through source selection and receiver resolution, including source-qualified omitted defaults. Removing a receiver does not hide the default selected by source; a coverage check then fails. New/renamed fields fail the actual selector, and typed/default/consumer distinctions are asserted. One intermediate mutation test incorrectly expected removal of a receiver to remove authoritative source selection; its failing output is retained. It was corrected to require selection remain visible and coverage fail.

Final command outcomes are in command-outcomes.json and tests.log. No live execution, independent review, global gate, stable global generation, or final documentation acceptance is claimed. Root owns integration/source commit and independent acceptance. Author releases exactly the two files listed in seal.json and will not edit them further without a follow-up.
