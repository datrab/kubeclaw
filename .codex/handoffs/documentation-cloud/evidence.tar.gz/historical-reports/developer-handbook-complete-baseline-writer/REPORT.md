# Developer handbook author delivery

Role: documentation author, not SourceDoc, CoreReader, quality reviewer, or acceptance participant.
Source revision: 671234b056bf5f5f503e51e8db30f843e781ba6e.
Branch: docs/documentation-overhaul.
Repository: /home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04.
Delivery date: 2026-10-12.

Only the two assigned repository paths were written:

- docs/site/extend/developer-handbook.md
- docs/site/extend/examples/platform-change-nova-lifecycle.json

No product implementation, contract, test, tool, navigation, classification, shared registry, generated inventory, commit, push, host installation, or absolute lock executable was changed by this writer. Parallel unrelated work existed before writing and remains owned by its authors. Whole-tree tooling/mutation/generation/publication checks remain reserved to root. The existing approved source/reader pages were linked, not edited.

## Inputs and currency

Read the documentation quality standard, full acceptance contract, full registered fixture file, execution plan, all nine DEV records in docs/blueprint/generated/ap09-catalogue.json, and relevant HANDOFF. Applicable ancestor and repository AGENTS search found no applicable AGENTS.md in this repository or ancestor chain. Read the managed-cloud runtime skill; no container build/run, credential inspection, deployment or executor-network action was performed. The upstream Kubernetes API reference was opened on 2026-10-12 only for the general upstream-reference link; no exhaustive upstream schema was copied.

Product claims and command routing were inspected against current root/workspace packages, source entrypoints/configuration, owner checks, schema generation, TypeScript rules, lifecycle recorder/reducer/recovery, native and compatibility fixtures, workflow trust/trigger/dependencies, central versions, receipts/promotion/rollback, and existing canonical reader task owners. Earlier README text was not accepted as evidence of unverified behavior. FileMutex/journal implementation corroborates Linux GNU lock/append/fsync requirements. Archviewer implementation/native fixture corroborates static reads; the unsupported publisher boundary stays explicit.

input-manifest.json records exact input SHA-256, committed comparison, and role. HANDOFF is an uncommitted scope input and explicitly has no committed product-evidence status. sourceguard.json records every published source link, full revision, Git file mode, line bounds, committed/current SHA-256, and byte equality. All 107 links to 60 distinct committed files are current at delivery and use valid ascending ranges of no more than 60 lines. Counts describe structural inspection scope and do not establish content acceptance. No dirty source/tool was linked as committed evidence.

## Requirement coverage supplied for independent review

Each record below is author coverage, not a PASS finding. Its canonical page is docs/site/extend/developer-handbook.md.

| Requirement | Concrete authored reader result | Main section |
| --- | --- | --- |
| DEV-001 | Central developer route selects owner by behavior, links extension choice and canonical component/task guides, and separates platform/Core/UI/contracts/data/deployment/release | Opening; repository ownership; ten component change routes |
| DEV-002 | Clean checkout, full revision, root workdir, Node/npm/lockfile setup, GNU /usr/bin/flock, compiler/shell/archive prerequisites, explicit C build, baseline, distinct Go modules/Helm versions, separate npm locks, browser/services/credential/trust setup boundaries | Prepare a clean checkout; Add tools and credentials |
| DEV-003 | Entry/build/start/debug/log/test/cleanup paths for Nova, Worker library, Buster, Prism services/Studio, registries, SDK, telemetry, deployment and Ops MCP/UI; unsupported generic starts remain explicit | Component routes; Prism service table; Ops local startup |
| DEV-004 | Evidence classes and six-part smallest-complete selection; concrete Nova unit/contract/journal/replay/recovery/historical-compatibility/docs chain; boundaries that add adjacent tests | Select the smallest complete check chain; Nova route/exercise |
| DEV-005 | All 13 current workflows: actual triggers, path filters/conditions, jobs/timeouts where declared, matrix behavior, write trust, secrets/vars, artifacts, cancellation/concurrency and release effect; server branch protection unknown | CI triggers, authority, and failure handling |
| DEV-006 | ESM/erasable TypeScript, explicit extensions/import type, exports, no compiler-only aliases, owner dependency directions, generated output order, closed-schema evolution, result identity and durable replay rules | Repository ownership; Generate/build; SDK and lifecycle routes |
| DEV-007 | Authority/threat questions and real negative/isolation/provider checks; safe fixtures; journal benchmark load/ceiling/environment/baseline interpretation; real browser/scanner/retention budget prerequisites and evidence limits | Security and performance; Worker/UI/Lint routes |
| DEV-008 | Distinct version identities and central source, synchronization/tool locks, changed executable checks, supported schema/data pairs and historical fixtures, release-note obligations, receipts and bundle source, manual/automatic promotion, deployment-commit rollback and irreversible data limit | Versions and release selection; CI; Charts/GitOps |
| DEV-009 | Existing generated metadata/page-map authority, source-owner routing for all changed families, separate authored/generated changes, exact mapped docs commands, valid/current source citations, add/change/remove and redirect obligations | Route each source change to its documentation owner |

Assigned gate facets, independently separable:

- A910-01: developer setup/baseline prerequisites and safe failure paths authored. A full clean-checkout participant execution is not supplied.
- A910-02: source/role/package ownership, dependency rules, generated source/build order authored and source-checked. Root must register page/navigation/classification and refresh generated map.
- A910-03: concrete build/test/lint/version/release/compatibility commands and their prerequisites/exit/stop/retained evidence authored. Environment-dependent chains remain unexecuted; no meta-script is presented as universal proof.
- A910-11: all ten required routes (Nova, Worker, Buster, Prism, Registry, SDK, telemetry, Charts/GitOps, Ops MCP, UI) authored. Nova includes the complete local chain and a newly registered desired-behavior fixture. The independent registered platform reader has not run.

This delivery does not claim full SDK API, package discovery/classification/deepguide completion, README parity, all 27 developer requirements, A910-04 through -10/-12 through -14, pipeline/global acceptance, deletion permission, or Source/Reader/Quality approval.

## Registered task fixture

The exact canonical path docs/site/extend/examples/platform-change-nova-lifecycle.json supplies READER-PLATFORM-02 input. It asks an independent participant to add the bounded internal diagnostic administrative_retry_suppressed for an administrative retry that would otherwise request nonterminal work. It preserves ordinary/other administrative actions, result reason, status/budgets, schema/event/type/graph/digest identities and generated output. It includes baseline, neighboring unchanged cases, pending-state invalid-transition rejection, process termination after durable blocked commit before terminal projection, restart preservation, removal, and retained external evidence.

No implementation source path or test command is present in the fixture. It carries executionStatus not-executed and no observed/fabricated success. Only the participant's isolated scratch checkout may receive the temporary implementation/test change. Product runtime remains unchanged. The recovered state has no invented reason field; the fixture separately checks durable event reason and recovered blocked state/counters. Its new-condition assertions and crash point must be implemented/executed by the independent participant, not inferred from existing test names.

## Actual terminal checks

Environment: Node v24.21.0; npm 11.19.0; Linux x64; existing root dependencies. Absolute /usr/bin/flock is BusyBox v1.37.0 and rejects --timeout. cc, bash, tar, Go, Helm, kubectl, Docker were not available through current PATH. Root dependencies were not reinstalled in the shared checkout. Ops MCP's separate dependency tree was absent. See environment.json and executions.json for exact environment/commands/status; logs preserve actual output.

| Actual command | Exit | Actual observation and class |
| --- | --- | --- |
| node tests/verification/contracts/check-plugin-system-v2-lifecycle.mjs | 0 | Lifecycle contract script reports ok; bounded contract evidence |
| node tests/verification/contracts/check-plugin-system-v2-registry.mjs | 0 | Registry contract script reports ok; bounded contract evidence |
| node skills/common/plugin-runtime/sdk/tests/values.test.ts | 0 | SDK JSON domain/accepted-byte helper regressions passed; unit evidence |
| node --test tests/verification/reliability/source-snapshot-version.test.mjs | 0 | Three current/historical snapshot and codec compatibility tests passed; no skips |
| node node_modules/typescript/bin/tsc --noEmit -p skills/nova/tsconfig.json | 0 | Targeted Nova compilation; no runtime evidence |
| node --test tests/verification/reliability/lifecycle.test.mts tests/verification/reliability/decisions-and-snapshots.test.mts tests/verification/reliability/project-recovery-version.test.mjs | 1 | Six tests, four passed (decision/snapshot-process-death and current/legacy compiler recovery), two failed at FILE_MUTEX_ACQUIRE_FAILED because BusyBox lacks GNU --timeout; overall FAIL |
| node tests/verification/contracts/check-nova-journal-scale.mts | 1 | GNU-lock prerequisite failure before measurement; no benchmark result |
| node --test tests/verification/reliability/sdk-json-contract.test.mts tests/verification/reliability/sdk-json-portable.test.mts | 1 | Both failed at OBSERVABILITY_STORE_LOCK_FAILED for unavailable GNU lock contract; no portable-consumer PASS |
| node --test tools/ops-mcp/test/local.test.mjs | 1 | Child startup exit 1; no listener/read proof |
| node tools/ops-mcp/src/server.mjs (bounded startup diagnostic) | 1 | Exact missing @modelcontextprotocol/server separate dependency; ERR_MODULE_NOT_FOUND; no credentials or cluster call |
| node private/check-authored-scope.mjs | 0 | Only assigned files: source mode/SHA/byte currency/ranges, local links/anchors, one H1, fixture ID/shape/no hints, package-script/Node path authorities; not semantic or independent acceptance |
| git diff --check -- assigned-two-paths | 0 | Whitespace only |

command-block-inventory.json retains 21 exact published shell blocks; source-to-command-inventory.json maps 98 selected npm/Node command occurrences to reviewed authority. Commands that were inspected but not executed remain unexecuted. Failed logs are not renamed passed. No timeout sleep, native process substitution, lock shim, PATH trick, kernel/cgroup mock, host install, or external credential was used to manufacture higher-class evidence.

## Remaining facts, owners, and closure

- Developer environment owner: provide a qualified Linux filesystem and real GNU util-linux at hardcoded /usr/bin/flock, C/Bash/GNU archive/native toolchains, and rerun exact failed journal/SDK/scale checks. Do not treat a private PATH flock as equivalent.
- Ops/environment owner: install the independently locked MCP package on an isolated prepared checkout, then repeat local auth/tool/failed-read fixture. A successful package test still does not close target-image/live RBAC proof.
- Native/platform/component owners: provide browser/database/Redis/Distribution/scanner/cgroup/test-cluster/trust prerequisites for the selected native/image/deployment/live routes. No such higher-class PASS is supplied.
- Repository maintainer: current branch-protection required-check setting is outside source and unknown here. Confirm it separately; workflow existence is not required-check proof.
- Contract/store owners: declare a supported old/new version pair, migration/rollback/retained-reader behavior for any newly incompatible change; no universal global private-package SemVer/changelog/migration command is invented.
- Nova/Archviewer owners: static serving is implemented; a production publishing producer is not supplied by this route. Closure needs writer identity/atomic/content/retention contract plus authenticated end-to-end producer/read proof. Current 404 stops before unsupported manual publication.
- Platform/store owners: complete isolated application/platform restore remains bounded by existing recovery guidance. Component checks cannot establish cross-service restore; no cutover or restore was attempted.
- Root integrator: register/classify/navigate the new page/fixture through existing authorities, refresh source-to-page/generation/publication after both toolwriters stabilize, then commission independent SourceDoc/CoreReader/Quality and exact READER-PLATFORM-02 execution. Check catalogue/gate results individually. No bulk parity/deletion or global acceptance is authorized by this report.

## Evidence boundary

The sourceguard is current at the stated source revision and saved working bytes. This author's shared checkout is not a clean reviewed documentation commit. No independent reader or reviewer was impersonated. The fixture, handbook, structural validator and passing targeted tests are not ReaderPASS or final source/quality acceptance. Product code, native host, deployed platform, release state, unrelated parallel files and prior frozen approved pages remain untouched by this writer.
