# Selected PV receiver documentation correction

Author work only. No independent acceptance or formal ASD-STE100 certification is asserted.

Base repository HEAD: `4a381a370e4ca90bdae53f27bfee759704f1300c`, with the starting working-tree citation corrections retained. Only `scripts/docs-kubernetes-pv-selected-receiver-contracts.mjs` was edited in the repository. Frozen module SHA-256: `27c46abc1d156ffb4827a98bcbd672ab944e1e63297d7dba116325f8350c1d4a`.

Read the entire documentation quality standard and applicable A98-02/06/09/10/11/13, evidence-class and independent Source/Reader/Quality requirements. Read the complete original module, the canonical retirement procedure, the renderer, schema/structure join, and exact pinned producer and cited upstream spans from the preceding Source review's downloaded source files. No fresh network download occurred: `inherited-download-provenance.json` records their original download provenance; the focused harness verifies every cited source-file hash against it. This author independently read the source contents. The evidence is not a new independent Source review.

The correction addresses F1 across all seven records through connected task explanations. PV, PVC, claim reference and UID are introduced in the operation description. JSON Patch guards, conversion from an existing typed PV to JSON, possible omission of empty fields, conversion back to declared PV types, and admission rules are explained at the time they occur. No claim is made that malformed current JSON can be stored or that patch input uses PV-creation defaults. The conditions define reconciliation, controller nil/no-reference state, finalizers, storage driver, migration of deletion responsibility, provisioner and backend. Unnecessary implementation labels such as reclaim consumer, in-tree operation and typed update strategy are replaced by named component actions. Exact API, event and field identifiers remain intact.

F2 is corrected by explicitly saying that the script uninstalls the Qdrant Helm release and removes named resources before patching, then deletes the PVC. Release of the bound volume and storage deletion are separate PV-controller work, with no storage-deletion guarantee. The module keeps all seven behavior cases, exact string guard failures, null/empty/absent distinctions, unchanged binding, complete update checks, lack of broader concurrency preconditions, irreversible deletion, uncertain-response stop, evidence retention and storage-owner inspection. No unselected provisioning choices were added.

PV-CORRECTED-SOURCE-01 is corrected with two separate callouts: validation.go 2015–2025 supports the nonempty membership check; 1942–1945 supports Delete membership in that set. Both keep the same exact Kubernetes commit. The existing pinned producer and other source ranges remain unchanged.

## Observed checks

- Module syntax: `node --check scripts/docs-kubernetes-pv-selected-receiver-contracts.mjs`, exit 0.
- Existing publication-language tests: `node --test scripts/tests/api-reference-reader-language.test.mjs`, exit 0, both tests pass. This verifies the publication language guard, not practical reader understanding.
- Focused author harness: `node /home/node/Documents/Codex/a98-evidence/pv-selected-receiver-plain-english-writer/check.mjs`, final exit 0. Exactly seven selected schema/structure joins, 42 cases, 36 unique source spans, exact commit pins, valid bounded line ranges, source hashes matching inherited download provenance, and separate Delete declaration/validator callouts.
- The exact private receiver-prose renderer and text helper were extracted from the actual renderer to produce `rendered-selected-reference.md`. This exercises published prose selection only. It is not a full-resource inventory validation, HTML publication build or fresh-reader exercise.

Two initial optional harness failures remain recorded: the full-resource renderer expected 245 rows because selection metadata was absent (`failed-full-resource-render.txt`); the revised private-helper harness had an invalid regular-expression escape (`failed-harness-escaping.stderr`). The final harness uses the renderer's exact escaping helper and passes. These author harness failures are not hidden or counted as passing runs.

Unexecuted: broad API/configuration generation or tests, site build, live API/RBAC/admission/controller/driver/storage effects, retirement/erasure/recovery, independent fresh Source/Quality/Reader acceptance and global A98 acceptance. Parent coordinates fresh reviews against the frozen module. No commits or runtime product changes.

Artifacts: frozen module and consulted repository inputs, before/after diff, scoped working diff, input hashes, inherited upstream download provenance and source bytes, span audit with excerpts/hashes, expanded records, selected schema-joined rows, exact extracted prose renderer, rendered prose, focused check source/log, existing language test log, and retained failure evidence.
