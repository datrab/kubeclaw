# Independent source review — bounded FAIL

Reviewed revision: `7d0ad00b82839b977d232e3463240dd21a4d96ef`.
Reviewer: `/root/buster_complete_source_corrected_fresh`; fresh source role, no author edits, no product changes. Private Git archive used; shared working tree was not modified. Owner-approved product/upstream boundary applies. This is not global AP09 closure and does not claim exhaustive acceptance of every retained upstream assertion.

## Individual results

| Gate | Result | Exact scope and reason |
| --- | --- | --- |
| A98-02 | FAIL | Deployment Success Exercise `docs/site/use/workflows/buster-suite.md:459` requires fixture output `credentials`; actual manifest `skills/buster/plugins/kubernetes-fixture/plugin.json:32` and provider `src/provider.js:125` declare/emit `demo-credentials`. The mandatory linked-chain check rejects the correct executable chain. |
| A98-06 | FAIL | Fixture RBAC-denial symptom: `docs/site/reference/buster-error-codes.md:271` says policy does not permit RBAC and advises selecting an allowed value/changing owning policy. Actual caller `kubernetes-fixture-runtime.ts:703–706` runs `kubectl auth can-i create/get/delete busternamespaceleases.<group> -n <controller namespace>` and rejects a result other than `yes`, with the missing verb appended. Missing Kubernetes identity/RBAC privilege, wrong group/namespace/context and product allowlist rejection are distinct boundaries. The entry supplies no distinguishing identity/access check. |
| A98-10 | FAIL | Full requested 150-field independent acceptance is not established. The recursive schema comparison passed, but that structural test does not independently verify every field's authored consumer/default/error prose or retained Kubernetes-source assertions. No full-scope PASS may be inferred from the bounded source findings below. |
| A98-11 | FAIL | Full requested per-field precedence and conflict/null/empty/invalid/Secret execution proof is not established. The observed 12-test run verifies selected source slices and structural constraints, not all 150 consumer behaviors. |
| A98-13 | FAIL | Same exact executable chain check mismatch as A98-02: a fresh reader following the published validator cannot accept the correct fixture-to-auth credential link. |

Required correction for A98-02/13: provide one canonical site procedure for the actually supported fixture path, including supported version/location, caller grant and cluster identity, configured group/namespace/subjects, complete input/manifest prerequisites, activation/invocation, expected namespace/workload observations, uncertain-apply and suppressed-cleanup inspection, explicit-release result and retained volume limit, final proof and evidence. If a reader-ready invocation is unavailable, identify the exact blocked step, owner, safe stop and measurable completion condition instead of saying the linked page provides prepare/release tasks.

Immediate correction for the proved chain defect: use fixture output `demo-credentials` and auth input `credentials` in the validator, then execute the affected validator with a source-resolved valid chain and a wrong-output negative case. `independent-chain-check.log` records an independent Node assertion against the actual fixture manifest; exit 0 proves the manifest/published-predicate mismatch, not the complete live exercise.

The broader procedure search did find `use/workflows/buster-suite.md`, including production compile/start/audit/recover, fixture example and deployment success exercise. Therefore this report does not assert that all fixture entrypoints are absent. The controller page's linked package-catalogue page still contains no focused prepare/release task, but that navigation/completeness issue needs the full cross-page fresh-reader review before an absence finding can be treated as exhaustive.

Required correction for A98-06: explain the actual `auth can-i` verb result and identity/group/namespace checks; distinguish client authorization from controller allowedAccess policy; stop before apply when authorization fails and correct the identity or reviewed RBAC authority before repeating preflight.

Required correction for A98-10/11 evidence gaps: complete independent per-field source/consumer review, including read retained upstream sources and full operation-specific null/admission semantics; store exact source and actual execution limits. These two FAILs identify missing acceptance evidence, not a newly proved product bug.

## Independently checked corrected claims

* Spec runId/project producer is fixture lines 692–700; `ownerLabels` is main.go 1765–1781 and does not use them. Digest main.go 1624–1635 removes only purpose/exposure. Readiness validation/construction demo-readiness.go 66–79/250–256 supplies and persists separate request RunID. Corrected trace explanation agrees.
* createdAt main.go 674–680 parses lease creationTimestamp as RFC3339, returns UTC and falls back to current UTC on error; provisioning lines 636–646 publishes it. Caller 721–726 validates it and uses requested retention for fallback expiry. Corrected explanation agrees.
* Fixture apply is 709, before protected try at 711. Failed protected preparation catches at 733–735, suppresses cleanup rejection, and rethrows original error. Separate timer/signal helper 616–625; explicit release 739–744 propagates deletion error. Corrected page 425–445 agrees.
* Owned exposure.path schema 176–179 rejects empty string; controller 1222–1227 defensively defaults empty to slash and rejects malformed nonempty paths. Corrected distinction agrees; controller additionally rejects NUL.
* Actual access bindings main.go 964–990 use namespaceRoleBinding default ClusterRole 1043–1070, while dedicated credential paths explicitly select Role. Deployed chart lines 24–67 allow deployer Secret get/list and tester read/Job lifecycle. The unused namespaceRole helper is different. Corrected text agrees.
* Ready phase consumer is basic fixture wait 525–540, with no UID/generation return fence; stronger provenance/readiness paths are separate. Separate NamespaceReady/AccessReady/SecretsReady/CredentialsReady/ExposureReady publication is main.go 662–672. Corrected text agrees.
* Readiness source verification independently read in demo-readiness.go and demo-readiness-sources.go: current lease, expiry, receipt/replay, owner/generation, live namespace, exact ingress and generated Secret proof are separate from schema validity. v1/v2 retention source in demo-retention.go agrees with corrected version distinction.

## Actual execution

Node v24.21.0. Initial receiver test failed before execution because the private archive lacked `yaml`. Copied existing yaml and TypeScript package directories into private node_modules, then ran `node --test scripts/tests/buster-lease-receiver.test.mjs`: exit 0, 12 tests passed, none skipped. Log: `receiver-tests.log`. This includes an executed VM/transpiled slice of original failure/release methods; it does not execute full fixture preparation, Go or Kubernetes. `command -v go` returned no executable. Go controller tests, live admission, deployment, DNS, TLS delivery, Secret copying, namespace deletion/restart, full fresh-reader task and publication renderer were not executed.

Full requested surface is preserved in originals. Human inspection was bounded to receiver declarations, relevant controller/caller slices, readiness sources, controller site page, fixture site page/package README, demo-delivery page and quality/acceptance requirements. The archive is broader than the independently verified human-read scope. A structural all-150 check is not labelled full semantic inspection.

Additional canonical discovery: all site pages matching `kubernetes-fixture` or `kubernetes.fixture` were enumerated; the Buster suite workflow, runtime Kubernetes-fixture configuration table, suite reference and shared Buster extension path were inspected for alternate task routes. Full huge generated reference tables and all retained upstream originals were not semantically accepted. This review remains terminal FAIL with incomplete full-scope evidence, not a completed exhaustive PASS review.
