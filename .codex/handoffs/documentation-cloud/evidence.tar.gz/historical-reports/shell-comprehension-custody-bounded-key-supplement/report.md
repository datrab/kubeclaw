# AUTHOR superseding bounded-depth and key-custody supplement

The two owning corrections are complete at the exact a3b2/19ae pair below. **Actual full receiving gates remain NOT RUN** pending Root-coordinated API qualification. No independent Source, Reader, Quality, package or global acceptance is awarded.

Author `/root/shell_comprehension_custody_complete_batch_writer`, same explicitly assigned gpt-6.1-sol/medium/fresh-none configuration; no backend certification. Repository `/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04`, branch docs/documentation-overhaul, observed HEAD30824cc555fa2623142752646f26dcc43072b5f7. This is dirty working-tree evidence, not clean-commit evidence. Only scripts/docs-configuration-inventory.mjs and scripts/tests/python-environment-discovery.test.mjs were edited. Root owns integration/commits/pushes. Product/API/generated/docs/nav/library/classification/matrix bytes were not edited by this author.

The original54-artifact author report SHAae039ffc6589a821d0969c17be8bb4243ee4afac6213db16c770dea8296e737f and manifest SHA38109d0b62777becc095b400b00b12853ddadf3afee6b468ac81ac7623b8c2bd remain immutable. `prior-immutable-seal-guard.json` verifies all54 with zero mismatch. Original67/150 evidence is legitimate historical evidence at56949279/earlier tests, not retroactively current complete acceptance. Independent COMPLETE FAIL3 and earlier COMPLETE FAIL2 remain historical failures.

## Concrete correction authorities

Root explicitly assigned two related pre-rebind findings. API owner's depth-shadow-results.json/log shows a legal20-dollar-substitution synthetic native process exit0 reading DEPTH_GUARD_NATIVE while scanner569 discovers the key rather than honoring its advertised finite nesting limit. Root's probe.json/probe.cjs shows a comprehension assignment replacing ROOT_PRIOR_KEY with ROOT_CURRENT_KEY: native exit0 prints current-observed, while scanner569 reports the stale prior key. Adjacent global-key-probe.json correctly rejects the ordinary global write. These are production source-only observations, not independent complete Source or qualified full receiving verdicts. No API rebind had occurred before the corrections.

Quality07, the AP09 contract/fixtures/execution plan and individual catalogue/Source findings remain governing authorities from the original assignment. Green unit totals cannot offset the concrete findings or substitute for the later independent review.

## Coherent bounded implementation

The dollar-substitution delimiter counter is now named delimiterDepth. The recursive call retains the function's actual depth+1 rather than the settled local delimiter counter0+1. Dollar/backtick/literal shell recursion still uses the shared finite limit16. Native-supported within-bound0/2/15 and legal out-of-bound16/20 witnesses distinguish acquisition from explicit rejection; direct/backtick acquisition, passive quoted recipes and source offsets remain controlled. No shell evaluator or generic feature was added.

The comprehension NamedExpr guard now covers both the recognized transferred value and an existing environment-relevant target name: environment_authority_names, subprocess_names, environment_key_names. It rejects before temporary-state restoration can issue a stale prior-key claim. The existing scope/AST ownership boundary, first iterable and independent function/lambda distinction remain unchanged. Shared list/set/dict/generator handling covers the legal containing-scope key witnesses.

An initial targeted failure exposed that the existing attribute key-name scan accepted any foreign getenv/get member name. Applying that broad name set to the new escape guard would reject ordinary foreign controls. The scan now uses its existing acquisition predicate to establish recognized os custody. Imported/direct reader aliases, os.environ.get alias and mapping subscript retain key sensitivity. Unused pure writes and foreign getter values remain passive; direct local finite-key NamedExpr reports CURRENT_KEY_NEW. The adjacent ordinary global-key write retains its existing explicit unsupported outcome. This uses the existing finite name/custody machinery; no general comprehension execution, dependency evaluator or interprocedural mutation interpreter is introduced.

Complete source delta is `before-scanner.mjs.patch`. Actual TypeScript whole top-level function-body comparison gives128 functions,126 unchanged; only pythonShellPrograms/pythonEnvironmentReads changed. All previous67 tests are an unchanged byte prefix (`existing67-prefix-guard.json`). Prior R1/R2/R3 tests and native meanings remain retained.

## Stable owning pair

- scripts/docs-configuration-inventory.mjs: SHAa3b2fd2a7fcf887eef999b34389db78ae8d1d0e912a2e2c177c6843d975e3ee2,873868 bytes.
- scripts/tests/python-environment-discovery.test.mjs: SHA19ae422bc5b781633aa3d10279203fdf657f569e5f0aaec886cf5069c99eac57,111696 bytes.

`freeze.json`, complete frozen sources and `after-freeze.json` bind these bytes. At preparation time the prior952-input manifest had950 unchanged inputs and only the two owning files changed (`dependency-guard.json`). This is narrow exact dependency/body reuse evidence. It is not a current API qualification; Root's subsequent API rebind is separate and may legitimately change its owned authorities.

## Actual terminal source/unit/native results

Initial targeted original22026 was observed terminal1: the newly applied broad existing key-name scan rejected a foreign-control witness. The source acquisition narrowing corrected that substantive false-rejection risk; the initial log remains retained.

Stable targeted original83797 was observed terminal0,2 PASS/zero fail, command `node --test --test-name-pattern='literal substitution nesting enforces|comprehension walrus writes to recognized' scripts/tests/python-environment-discovery.test.mjs`. Stable full owning suite was run once: original7080 observed terminal0,69 PASS/zero fail/skip,38.84s; command `node --test scripts/tests/python-environment-discovery.test.mjs`. `test-receipts.json`, targeted-final.log and owning-full.log retain these actual outcomes. No live or terminal test was restarted after a temporary capacity interruption.

`full-native-results.json` retains159 actual suite-native records, previous150 plus9 new. Existing deliberate native-failure/fallback cases keep their expected meanings. New9 are five depth witnesses and four comprehension key variants; all execute native exit0 with the configured synthetic observed value. These are separate synthetic programs, never inspected product bootstrap execution.

`current-probe.cjs` completed terminal0. It reacquires all eight prior complete-source witnesses and the nine new complete-source mutations using frozen production declarations. Depth15 discovers the real unqualified key; depth16/20 reject with actual workload identity/reason; four key variants reject with actual bootstrap identity; direct key sensitivity discovers CURRENT_KEY_NEW; unused pure key control remains passive. The prior four getter/reader comprehension cases and two substitution stdin cases reject, direct nested stdin retains useful identity, direct NamedExpr sensitivity discovers its key. `current-complete-source-probe.json` and `supplement-complete-source-probe.json` retain actual results. A real uncaught child-process error exits1 and emits workload source identity plus unresolved nested stdin reason (`rendered-error.log`/receipt). These are source-only declaration checks, not the full qualified receiver CLI.

## Prepared complete receiving supplement — NOT RUN

All prior25 cases are retained unchanged, and nine new cases bring the preparation to34 cases plus two baseline and two restored decisions:38 total. `receiving-cases.json`, `supplement-cases.json` and all complete prepared Sources are retained. Every complete Python Source legally compiles; no complete product bootstrap runs. New key mutations start from existing public KUBE_CONTEXT, so a stale prior-field claim cannot satisfy the eventual receiving test. Exact actual readiness-command replacement tests within-bound key sensitivity and out-of-bound useful rejection. Every negative requires nonzero exit, intended key/reason and actual receiving identity. Positives require exact436.

`prepared-receiving-status.json` remains **NOT RUN**. The prepared receiving-gates.py requires a later coordinated-api-freeze.json; none is fabricated by this author. Root should execute a separate receiving supplement after coherent semantic API binding. This immutable source/unit/native seal must not be overwritten to claim that later execution. There is no circular wait: stable owning pair and terminal unit/native evidence are available for API rebind now.

Remaining work is coordinated API qualification, actual38 receiving checks, Root integration checks, fresh complete independent Tool Source and separate Reader/Quality/global acceptance. No Root whole11 suite, full generation, global mutation package, API hash repair, deployment/provider/cluster/credentials/host installation or complete product bootstrap was run by this author. Source-only/Unit/native/compile evidence cannot certify live behavior, arbitrary shell/Python interpretation or whole documentation completeness.
