# Prism diagnosis and terminology author report

Role: documentation author only. This report does not accept Source, Reader,
Quality, OPR-010, any A98 gate, or the complete documentation package. The prior
Reader PASS and partial Quality PASS are historical scoped results. Fresh
independent reviews must assess the integrated candidate.

Start checkout: `afc2d38e5aa988e8ec344b4e77b8aa9a390e4c73`, branch
`docs/documentation-overhaul`. Product/source pin:
`ec2a42ed215a2fa7dbd3172ef70ef446084963a9`. Root and another author changed the
shared checkout during this work; release HEAD was
`ab4a6ef31c3187c6daebb2d5f36482d1aa0b2e1b`. This was not a clean-checkout
acceptance run. `release-working-tree.txt` records that limit. I created no
commit and performed no push.

## Authorized authored scope

Only these main-checkout files were changed by this author:

- `docs/site/use/prism-studio.md`
- `docs/site/reference/glossary.md`

The focused patch is `authored.patch`; exact released copies and file identities
are in `release.json`. Generators, generated inventories, matrix, register,
navigation, other pages, commits, and push remained outside this author scope.

## Inputs inspected

Read the complete documentation quality standard, full AP09 acceptance
contract, the entire original 1,759-line Prism page, the shared glossary, and
`/home/node/Documents/Codex/a98-evidence/prism-quality-current-fresh/report.md`.
Read OPR-010 and contextual SPC-002/SPC-003/CDV-009 catalogue records, fixture
metadata/post-documentation exclusions, READER-OPERATOR-01 through -04,
READER-QUALITY-01, EXEC-PRISM-JOURNEY and EXEC-FAIL-POSTGRESQL. No catalogue,
fixture, gate, or prior result was modified by this author.

Independently inspected worker-service, worker-readiness, worker config/startup,
worker lifecycle, native execution/journal startup, native ownership supervision
and recovery, actual chart workload names/labels/container/port/affinity/policy
and probes, service ports, worker Dockerfile, maintained deploy smoke command,
internal HMAC authentication, agent job/result fences, Studio session handling,
browser render capture, the original wait/run code, and canonical install/use
version/authority binding. New source links were checked against the pinned Git
objects and current source bytes, not inferred from file existence. The shared
pin's inspected product files are unchanged at release HEAD.

For PostgreSQL code names, inspected the primary PostgreSQL 17 error-code
reference at https://www.postgresql.org/docs/17/errcodes-appendix.html on
2026-10-10: `28P01` invalid password, `42P01` undefined table, `42501` insufficient
privilege, `57014` query cancelled. The authored table cites that primary source.
This lookup does not establish a deployed PostgreSQL version or error occurrence.

## Changes and full-page consistency assessment

Q1: The revision-conflict diagnosis row now carries the original-outcome stop and
links both detailed procedures. It permits a new operation only after history
and current content resolve the uncertainty. The Nova rejection row and detailed
interruption path audit the unchanged original run/wait first, separate active
wait input errors from missing/expired/resolved/terminal outcomes, and preserve
all original identities. They give no general instruction to correct or replace
a rejected signal. Issuer matching remains distinct from authentication.

Q2: HMAC, nonce, CSRF, job fence, and ARIA snapshot are explained in ordinary words
at their first operational uses and linked to new shared glossary sections.
Definitions retain exact API/header/key names. Authentication, permission,
replay protection, concurrency authority, human approval, and retained evidence
remain separate. The glossary descriptions have narrow source callouts.

Q3: Replaced the worker checklist with a complete diagnosis path: prerequisites,
execution location/version limits, permissions, selected mode, one selected Pod
and UID, non-secret metadata, three sequential bounded GET requests, HTTP status
and sanitized JSON, exact current/previous log commands with filtering/bounds,
expected healthy bodies, native/nonce/lifecycle errors, dependency phase/code
and counter interpretation, repair owner and unsupported step, repeat health and
smoke checks, separate original-attempt reconciliation and authenticated
functional check, retained evidence, and cleanup. No port-forward, Secret read,
process-environment dump, database mutation, native repair, or attempt submission
was added. Transport uncertainty is retained rather than treated as remote
process cleanup proof.

Reviewed the final complete page for consistent status, request/run/wait identity,
revision/approval/publication uncertainty, mode/readiness distinctions, private
access, product boundaries, and cleanup. The unconditional registered CSI
prerequisite remains intact. The fixed 1228 browser-path STOP, Playwright
1.55.0/1187 versus 1.62.1/1234 distinctions, 12 mobile plus 3 preview failures,
product issue/owner/closure conditions, and unavailable aggregates remain intact.
Package preparation, isolated database/client work, source inspection, and
available focused checks are never promoted to aggregate, native, or live PASS.

## Actual author checks

Environment: Node.js `v24.21.0`, npm `11.19.0`, Bash `5.3.9`, local kubectl client
`v1.34.11`, Helm `v3.22.0+g144ca65`, Linux amd64. These are inspection tools, not a
compatibility acceptance statement. No cluster version was queried.

1. `python3 check-authored.py` — exit 0. All 14 Bash blocks pass `bash -n`; all
   194 source links have regular Git targets, ascending valid line ranges, and
   bytes identical to current source; all 72 local paths/anchors resolve.
   `static-checks.json` records each target/range and source hash. This is syntax
   and reference verification only, not semantic or rendered-output acceptance.
2. `git diff --check -- docs/site/use/prism-studio.md docs/site/reference/glossary.md`
   — exit 0. No whitespace errors in the two authored files.
3. `node local-probe-check.mjs` — final exit 0. The unchanged extracted probe body
   ran against the original `createWorkerServer` HTTP implementation, with explicit
   test doubles for native execution readiness and database check. Healthy HMAC
   gave 200/200/200 and one database check; closed native admission gave
   200/503/503 and no database check; failed HMAC dependency gave 200/200/503;
   SPIFFE mode gave 200/200/200 and skipped that database check. No attempt was
   submitted. Separate localhost response fixtures checked exclusion of secret
   fields, unknown errors, oversized responses, and safe capacity errors. The
   unchanged log filter kept safe phase/code/counters and discarded unstructured,
   unknown, and credential-bearing content. `local-probe-results.json` retains
   outputs and expected probe exit statuses. These are local fixture results.
4. Initial `node local-probe-check.mjs` — exit 1, `EADDRINUSE` before starting any
   probe child. The occupied 8080 listener was not contacted, stopped, or edited.
   The private fixture was changed to dynamic local ports with an explicit fetch
   transport wrapper before the unchanged extracted probe. This substitution
   and limitation are recorded in the script/results and
   `initial-local-probe-port-conflict.txt`. It is not proof that the fixed deployed
   loopback port was tested here.
5. `node kubectl-format-check.mjs` — exit 0. Actual kubectl parsed all 9 unchanged
   JSONPath/custom-column expressions against a private localhost HTTP API
   fixture and a dedicated disposable kubeconfig/cache. Policy annotation,
   image/status metadata, Pod UID, and non-secret trust flag selected correctly.
   No real cluster request, resource creation, or authenticated Kubernetes action
   occurred. `kubectl-format-results.json` preserves output. Owned temporary
   kubeconfig/cache were removed and fixture listeners closed.
6. `python3 shell-stub-check.py` — exit 0. The three authored diagnosis Bash
   blocks executed with the documented `hmac` substitution and private bound-tool
   stubs. Healthy collection returned 0; failed readiness saved status 1 and
   STOP while continuing diagnosis collection; denied permission, multiple Pods,
   mode mismatch, and changed UID stopped as expected. Changed UID caused no exec
   call. The Node log filter actually ran. No real cluster tool action occurred.
   `shell-stub-results.json` records commands, outcomes, and output files. Owned
   stub temporary directories were removed.

All checks use private files in this evidence directory; extracted Bash blocks
are preserved for reproduction. Results never stand in for the independent
Source/Reader/Quality roles or live installed execution.

## Controlled-language author method

Applied the repository's declared ASD-STE100 Issue 9 project principles manually
to the full affected page and glossary: direct named actors; prerequisites before
actions; explicit conditions; consistent terms; ordinary definitions at first use;
exact identifiers preserved; commands separated from explanations; uncertain
outcomes before retry; no simplification that removes a technical boundary.
Necessary vocabulary includes HMAC, nonce, CSRF, job fence, ARIA snapshot,
idempotency, reconciliation, active wait, native ownership, and diagnostic
phase/code. Q1/Q2 shortcut/vocabulary findings were addressed in author text.
The full licensed dictionary was unavailable. This is an author controlled-language
check, not certified ASD-STE100 compliance or independent Quality acceptance.

## Unexecuted limits and integration handoff

No live selected release, Pod, service reachability, installed database, SPIFFE
identity/permission, authenticated attempt, native cgroup execution/repair,
provider completion, browser capture, browser download, complete Prism aggregate,
mutation package, or Studio-to-Nova journey was executed. Native/database repair
remains an explicitly unsupported operator surface with stop, owner, and closure
conditions. Existing product failures and prior skipped real-PostgreSQL work
remain truthful historical scope.

Root must refresh generated embedded-example inventory and applicable source
dependencies, integrate the two files, and launch NEW fresh independent full
affected Source, Reader, and Quality reviews. The author release adds 3 diagnosis
Bash blocks (14 page Bash blocks total), new glossary anchors, and narrowly cited
worker lifecycle/nonce/native ownership, chart, image, internal-auth, agent-fence,
and ARIA sources. No author acceptance is supplied.
