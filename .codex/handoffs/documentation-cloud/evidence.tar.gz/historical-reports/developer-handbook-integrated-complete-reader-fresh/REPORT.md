# Independent Reader review of the integrated Developer handbook

Date: 2026-10-12 UTC
Reviewer identity: `/root/developer_handbook_integrated_complete_reader_fresh`
Role: Reader only; distinct from authors and Source/Quality reviewers.
Configured spawn metadata supplied with the assignment: `gpt-6.1-sol`, `medium`, `fork_turns=none`. This records configured identity, not a backend model certificate.
Repository: `/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04`
Branch: `docs/documentation-overhaul` (assigned branch; this report does not change it).
Observed HEAD before and after the guard interval: `e65738b302f0ad028e564f8f6f556fe26d3e144c`.
Product baseline cited by the candidate: `671234b056bf5f5f503e51e8db30f843e781ba6e`.

**Decision: PASS for the complete candidate's assigned static Reader facets and the new source navigation. No material Reader correction was identified.** This is not acceptance of a formal exercise, rendered publication, exhaustive reference generator, hosted CI run, clean-checkout execution, or global documentation gate. Those outcomes remain unawarded. No Source or Quality verdict is adopted as this review's own result.

## Exact candidate and review boundary

- `docs/site/extend/developer-handbook.md`: 97,248 bytes; SHA-256 `ccebdd16f6aee7445784433e9fa298669e2f47dc2516dd4cf19e3d1bc438f36e`; all 1,342 lines read.
- `docs/site/extend/examples/platform-change-nova-lifecycle.json`: 5,763 bytes; SHA-256 `2a1d752198305331536e73a771fb0e2096eb501266f43612f6286ca786e406fc`; complete task input read and parsed.
- `docs/site/extend/README.md`: current SHA-256 `99ca254b59faddd4f5bc8151632025f163a369327db0469bbc9021938eab5a34`; original choice-guide prose plus new descriptive routes read. Independently reconstructed original SHA-256 `470b9a50df07d53fe19d48ece4e39e87c671473ad6bb5b4dde05eb07eb15449e` by removing exactly one recorded insertion. New navigation is this review's own finding; the previous Source/Quality evidence for the earlier README remains historical.

The working tree is shared and dirty. Candidate bodies are untracked. This is a file-hash-bound read-only review, not the acceptance contract's clean committed evidence ledger. The 112-file guard includes both candidates, README, direct linked canonical contexts, and directly cited source authorities. `guard-before.json`, `guard-after.json`, and `guard-result.json` show no guarded-file change. The guard was first captured after initial candidate-body reads; assigned candidate hashes and the subsequent guard agree. It does not retrospectively prove immutability before capture, or whole-checkout immutability. No administrative HEAD advance occurred during the recorded interval.

The assignment was clarified to require full candidate bodies plus the canonical sections necessary for the declared Reader tasks. It does not ask this reviewer to approve the entire transitive site. Large linked documents were read at the operative sections used below; merely checking their existence is not presented as semantic review of their complete content.

## Method and allowed input

Read the complete quality standard, acceptance contract, fixtures, DEV-001 through DEV-009 and QUA-001 through QUA-010 catalogue records, and relevant execution-plan reader/Developer/integrated-acceptance clauses. The contract distinguishes reviewer from registered execution participant. This reviewer is not a participant in `READER-PLATFORM-02` and received no authorization to implement, crash, recover, or remove the temporary change.

Reader tasks used `docs/site` and the source links it supplies. Blueprint requirements define scoring, not solutions. No package README, historical review folder, prior chat, or maintainer explanation supplied a procedural solution. The private navigation-delta record was used only to bind the exact new insertion, after assessing the descriptive routes themselves.

Operative canonical contexts read include the site entry and request-to-result routing page; complete Developer handbook, choice-guide body, platform/Buster guide, platform/Prism guide, Archviewer page and documentation-governance page; Nova lifecycle/state/replay/administrative-reopen sections; Operate's command-form/compile/start sections; Diagnose's health/logs and durable-inspection sections; Buster workflow's prerequisite, production submit/observe, local proof, result, diagnosis, and cleanup sections; Maintenance's canonical upgrade/rollback stop, version authorities and rollback decision; Prism's full local-development/browser-selection/fixed-path/focused-check section; Ops MCP authentication/configuration/authorization/failure/change-boundary sections; Worker Core's responsibility and two-layer explanation. Other linked material is navigation/context, not wholesale site acceptance.

Read operative source authorities for reducer, decision recorder and recovery-state behavior; journal's absolute lock contract; SDK/schema and launcher/plugin generators; package scripts/exports; Prism config/start entrypoints and generation hooks; Ops config/authentication/policy/local test; absolute observability Go fixture; Registry native retention fixture; lifecycle/snapshot recovery fixture source; TypeScript source rules; governance routing; and selected workflow authorities. Read `docs-checks.yaml`, `build-ops-mcp.yaml`, and `role-images.yaml` as complete source. Workflow rows beyond those are assessed for reader comprehension and explicit source routing, not independently certified as fully semantically correct here.

## Declared Reader tasks and observed results

| Task | Individual static decision | Reader result and concrete locations | Source authority and limit |
| --- | --- | --- | --- |
| R1: From the site entry, find platform/Core development and its bounded practice input. | PASS | Site `README.md` Start With Your Task -> `extend/README.md` Purpose -> Developer handbook. Exercise is directly named beside that route and also at handbook line 476. The route needs two meaningful choices for handbook and at most three for exercise. | New README insertion is exact and independently read. `navigation-independent.json` verifies preservation of original bytes. This is repository/source navigation, not rendered or search proof. |
| R2: Determine setup requirements and stop safely when this host is unsuitable. | PASS | Handbook lines 25-205 states Linux, qualified filesystem, absolute GNU util-linux flock, C11 cc, Bash/GNU tar/Git, Node 24/npm/root lock, isolated install, launcher build, and baseline order. Additional routes name distinct Go modules, absolute Go/tar, independent npm/Python installs, browser/service/native/cluster authority. | `file-mutex.ts` uses `/usr/bin/flock` with timeout/conflict options. Actual read-only preflight finds BusyBox, absent absolute tar/Go and Python yaml/MCP dependencies. The prescribed stop is actionable. Installation/baseline execution is not claimed. |
| R3: Locate the correct owner and minimal complete checks for all ten component changes. | PASS | Handbook component map lines 206-264; check ladder lines 306-361; component sections enumerated below. Each chain explains adjacent boundaries and additional environment classes. | Root/package script bodies were read or resolved in `source-navigation-checks.json`. Selection/readability is assessed; no chain was executed. |
| R4: Plan the lifecycle diagnostic exercise, identify invariants, negative input, retained-record recovery and removal. | PASS | Handbook lines 408-498 and full JSON: Nova owns policy; reducer's running-only guard; recorder administrative stop; one consumed attempt; preserve original result/reason and neighboring administrative cases; unchanged public identities/schema/types; crash only after durable blocked event; compare baseline/generated outputs and retain evidence externally. | `applyStageResult`, `DecisionRecorder.record/#administrativeBlocked`, and recovery-state were actually read. Replay has no new reason projection field requirement. Existing process-death fixture is clearly insufficient to cover the new assertion automatically. This task is planning/understanding, not `READER-PLATFORM-02` execution. |
| R5: Locate start/debug/log/cleanup routes without treating libraries as daemons. | PASS | Nova lines 461-474 -> Operate/Diagnose; Worker lines 499-553 is a hosted library and names native admission/evidence boundaries; Buster lines 554-642 -> workflow source; Prism start table lines 663-691, local UI lines 1043-1093; Ops lines 932-1042. Registry's fixture start/GC/restart/cleanup is explained at 695-744. Shared SDK/telemetry/chart work uses focused commands and owned outputs rather than fictional starts. | Prism start/config source, Ops auth/config/local fixture, Registry real-binary fixture and operative Buster/Operate/Diagnose sections were read. Candidate states loopback debug limits, process vs service readiness and evidence retention. No running service, debugger, log collection or cleanup was performed. |
| R6: Interpret test/CI results, cancellation/skips, credentials and release effect. | PASS | Evidence ladder lines 330-361; CI table lines 1154-1203; separate secrets, fail-fast, concurrency, required-check server-setting uncertainty and retention. Ops CI Node22 is distinguished from root Node24. Missing artifact/cancelled/skipped execution remains missing proof. | Selected workflow sources read as above; package script mapping. Branch protection, credentials and hosted jobs remain unverified. |
| R7: Plan versions/compatibility/promotion/rollback and find the safe stop for missing pair proof. | PASS | Handbook lines 1204-1273 distinguishes lock/schema/package/source/image/bundle/deployment identities, old/new pair obligations, historical fixtures, write workflow authority and irreversible data boundaries. Canonical Maintenance lines 28-64 explicitly records empty supported-pair matrix and stop before mutation. | Version/release commands resolve to their sources. Reader can avoid substituting a source SHA for rollback's deployment commit and avoid promising data restoration. No version sync, release, promotion or rollback occurred. |
| R8: Route a source change to documentation ownership and interpret the maintenance proof limit. | PASS | Handbook lines 1274-1325 -> governance/map; add/change/remove/rename, canonical owners, generation before check, no duplicate authored/generated authority; absence of correct map owner means assign/register before closure. | Governance canonical text and generator routing actually read. Current map/publication generation is pending integration; no mutation/drift or exhaustive mapping PASS is awarded. |
| R9: Interpret failure and remaining evidence without converting a prerequisite failure into product proof. | PASS | Handbook line 1326 to end, plus specific tool/route stops throughout. Owner and repeat/closure condition are visible. Recovery/portable SDK/scale/Ops local failures are preserved as failures, not success. Exercise `executionStatus` is `not-executed`. | Fresh read-only tool observations corroborate prerequisite limits. Historic local results in candidate remain attributed text, not this reviewer's reruns or substituted evidence. |

## All ten component routes

| Component | Candidate location | Static Reader assessment |
| --- | --- | --- |
| Nova | 408-498 | Ownership, reducer/recorder/replay invariants, full check chain, CLI/debug/log delegation, recovery stops and temporary change removal found. |
| Worker | 499-553 | Generic attempt vs native host, separate native/trust proof, authority and retained ownership/spool/journal boundary found. |
| Buster | 554-642 | Plan/provider/report/import owners, tests and remote fixture prerequisites, absolute GNU tar, workflow start/observation, retained result and cleanup found. |
| Prism | 643-694 | Component tests, contract hooks, real PostgreSQL/native/image classes, service start/config/access/log/shutdown found; local-development canonical context explains unavailable spike aggregates. |
| Registry | 695-744 | Plugin registry and OCI registry are distinguished; inert discovery, absolute Distribution binary, restart/offline GC, digest retention and owned cleanup found. |
| SDK | 745-787 | Public/testing entrypoints, schema-first generation, compatibility fixtures, closed-schema optional-field caveat and retained digest encoding found. |
| Telemetry | 788-874 | Authoritative event vs projection, PATH Go/gofmt vs absolute Go/module lock/cache/download contract, durability/reconciliation/reader checks and evidence-retaining cleanup found. |
| Charts/GitOps | 875-931 | Exact render/local-selection checks, conditional profiles/default omission, immutable identities, live boundary and retained-data rollback limit found. |
| Ops MCP | 932-1042 | Independent npm locks, isolated pinned PyYAML setup/test/cleanup, local authenticated loopback route, image/live separation and read-only tool changes found. |
| UI | 1043-1093 | Studio typed operation/revision authority, focused build/browser checks, development Vite distinction; Archviewer real nginx/OpenSSL and missing publisher/404 stop found. |

These are individual static route assessments. They do not certify every linked component's full documentation or execute its chain.

## Individual catalogue decisions

The following PASS decisions apply only to each ID's Reader-facing contribution supplied by this candidate. They do not change the catalogue status or award the entire requirement at the formal gate.

| ID | Assigned static Reader decision | Reason and location | Unawarded remainder |
| --- | --- | --- | --- |
| DEV-001 | PASS | R1; site/choice/handbook/exercise route and owner are readable. | Rendered navigation/search, global reader-tree acceptance. |
| DEV-002 | PASS | R2; handbook 25-205, exact setup sequence and distinct tools/credentials are visible before work. | Clean-checkout installation and baseline run. |
| DEV-003 | PASS | R3/R5; ten explicit components, maintained commands, service vs library, debug/log/cleanup and delegated operative contexts above. | Actual build/start/debug/log/cleanup execution; whole component-documentation acceptance. |
| DEV-004 | PASS | R3; six check-selection questions, evidence classes and per-change chains, no universal shortcut. | Executed complete changed-boundary chains. |
| DEV-005 | PASS | R6; triggers, environments, credentials, timeout/retry distinctions, artifacts and merge/release consequences explained. | Hosted workflow/branch protection verification and full Source-role semantic audit. |
| DEV-006 | PASS | R3/R4; ownership/import direction, TS source extensions/erasability, generated authorities, strict compatibility and distinct authority namespaces. | Full language/API/concurrency semantic Source audit and changed-code evidence. |
| DEV-007 | PASS | R9; 1094-1153 names authority threat review, real scanner/database requirements, isolated fixtures, predeclared retention budget and comparable performance baseline. | Any security/benchmark/load measurement. |
| DEV-008 | PASS | R7; version authorities, schema/data pair stop, release-note obligations, receipts/promotion/rollback and irreversible boundary. | Release execution, supported pair or migration proof. |
| DEV-009 | PASS | R8; 1274-1325 gives canonical page/owner/check routing, generated map lookup, unknown dependency handling and add/change/remove/rename obligations. | Generator integration, complete source-map and negative mutation proof. |

| QUA ID | Reader-facing static decision | Basis | Formal requirement remains |
| --- | --- | --- | --- |
| QUA-001 | PASS | Complete handbook explains workspace/role/contract/projection/digest/fixture and difficult fsync/inode/lock/identity distinctions in connected English. R2-R9 require no unexplained chat shorthand. | Global site quality/technical-depth acceptance outside this candidate. |
| QUA-002 | UNAWARDED | Controlled-language certification/editorial method belongs to Quality; this Reader does not assume that role. | Separate project controlled-language review; no certification asserted. |
| QUA-003 | PASS | R3/R7 show current reasons/costs/reconsideration or clearly unknown history/inference (ownership section 241-253). | Global and Source/Quality decision-evidence review. |
| QUA-004 | PASS | Reader can follow adjacent callouts to precise pinned implementation/contract/test/revision/limit; structural checks below resolve current bytes. | Semantic Source-role verification, global exhaustive evidence mapping and rendered callouts. |
| QUA-005 | PASS | R9; complete candidate distinguishes source/local/failed/unexecuted/native/image/deployment/live/release/restore and never claims a successful exercise. | Global truthful-status review. |
| QUA-006 | PASS | R1-R9 are meaningful find/understand tasks from the reader tree, complete candidate assessed. | Global end-to-end fresh reader exercise across all personas. |
| QUA-007 | UNAWARDED | No operator execution task assigned or performed. | Operator procedures and their independent validation. |
| QUA-008 | UNAWARDED | No new extension creation/activation/replacement/removal performed. | Registered extension participant tasks and discovery coverage. |
| QUA-009 | PASS | Static platform/Core comprehension and exercise-planning facets R3/R4 pass. | `READER-PLATFORM-02` implementation, negative/recovery run and baseline-restoring removal NOT EXECUTED. |
| QUA-010 | PASS | Static maintenance/owner/drift-routing task R8 passes. | Actual mutation trials NOT EXECUTED. |

`UNAWARDED` marks a facet outside this reviewer assignment, not a third gate verdict and not a performed failed exercise. The contract's full gates remain for the Root's acceptance matrix.

## Assigned gate Reader facets

| Gate | Static Reader facet decision | Scope and location | Gate proof not awarded |
| --- | --- | --- | --- |
| A910-01 | PASS | R2: setup tools, separate packages/services/credentials, expected baseline and safe stop. | Clean-checkout reproducibility/execution. |
| A910-02 | PASS | R3: handbook ownership/build/generation boundaries 206-305 and package authority. | Wider Source audit if claimed. |
| A910-03 | PASS | R2/R3/R5/R7: ordered exact commands, prerequisite/outcome/limit and focused check choice. | Complete executable-example runs. |
| A910-11 | PASS | R3 plus ten-component table and R4: smallest complete changed-boundary chain selected from candidate, without hidden README knowledge. | Formal `READER-PLATFORM-02` practice execution. |
| A912-02 | PASS | R1 repository route, descriptive handbook and exercise navigation within three decisions. | Real renderer/browser route/navigation output. |
| A912-09 | PASS | Source path/range/direct Markdown anchor facet below. | Actual built output/assets/routes/anchors. |
| A913-03 | PASS | This is a separate fresh-context initially read-only Reader report with exact candidate hashes. | Separate Source/Quality reports and full integrated acceptance. |
| A913-04 | UNAWARDED | Reader reviewer is not registered execution participant. | All persona tasks including implementation/recovery/removal. |
| A913-05 | UNAWARDED | No practical workflow/fault/change-removal execution. | Required individual scenario runs. |
| A913-09 | UNAWARDED | Dirty shared tree and untracked candidate; private evidence/guards recorded honestly. | Contract's clean committed full evidence bundle. |
| A913-12 | PASS | Report names precise successes and every unexecuted higher evidence class below. | Entire final global report/gates. |

## Executed checks and actual outcomes

1. Complete candidate and required relevant contextual/source reads: completed; no material documentation defect identified in the assigned static tasks.
2. Python JSON parse of full public exercise: PASS; structure only.
3. `bash -n` through stdin on all 25 `sh`/`bash` handbook blocks: 25 exits zero; `syntax-checks.json`. No shell block was executed.
4. Source navigation checker: 175 direct handbook links, including 117 pinned GitHub source links. All 117 resolve through local Git, have valid cited ranges, and equal current file bytes. All direct local targets exist; referenced Markdown fragments pass a source-heading/explicit-ID heuristic. One general Kubernetes API link is external and was not fetched; no general upstream behavior was adjudicated. All named npm-run scripts resolve to a root or named package script authority. `source-navigation-checks.json` is structural/read-source evidence, not semantic Source approval or rendered-anchor proof.
5. Independent new README insertion/before-byte reconstruction: PASS; one insertion, current and reconstructed original hashes match. `navigation-independent.json`.
6. Read-only environment observations: Node `v24.21.0` exit 0; npm `11.19.0` exit 0; Python `3.14.8` exit 0. `/usr/bin/flock --version` exit 1 identifies BusyBox (GNU tool contract unsatisfied). `/usr/bin/tar` and `/usr/local/go/bin/go` are missing, so invocation is unavailable, not a fabricated numeric process exit. Python `yaml` module and independent MCP server dependency path are absent. `environment-readonly.json`.
7. Before/after guarded-file checks: 112 files unchanged; HEAD unchanged. `guard-result.json`.

No dependencies installed; no product script/test/generator/build/server/cluster/provider command run; no credential inspected or used; no source/repository edit, commit, push or product action. Writes were only this private evidence bundle.

## Findings, required corrections, and exact limits

Material Reader findings in the declared static tasks: **none**. Required candidate prose/navigation corrections: **none identified**. There was an initial checker classification mistake treating the general Kubernetes URL as a local path; the checker artifact was corrected before adjudication. It is not a documentation finding.

The missing host/dependency observations are prerequisite failures, not new documentation defects: candidate supplies absolute paths, safe stops, preparation owner and repeat/closure condition. They do not prove journal recovery, remote archives, cross-language execution, policy assertions or MCP startup. Do not replace tools with wrappers/symlinks or weaken the test/authentication to manufacture proof.

Formal lifecycle implementation, invalid-input execution, crash-after-durable-block recovery, compatibility/generated-output comparison, and removal/rerun are **NOT EXECUTED**, not performed FAILs. A registered independent participant on the declared prepared host must supply them. No clean-checkout, complete chain, native, host, cluster, browser, image, deployment, live dependency, release, restore or benchmark result is claimed by this report.

Publication classification/input selection is a separate Root integration boundary. The assignment reports two explicit classified candidate records, static allowance and 153-page/16-asset selection plus 12 publication tests. Those reported results establish selectability only; they are not this reviewer's execution evidence and do not prove render, search, generator freshness or public browser behavior. This Reader did not run the publication build. Render/search/generator integration remains pending, and no full Publication/global gate is approved here.

This report completes the assigned candidate-static Reader assessment at the guarded hashes. A whole reader-tree review and global documentation acceptance remain separate later work. No average, page count, code parse, link resolution or pre-existing verdict replaces those missing proofs.
