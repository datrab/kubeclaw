# Canonical run-control preservation and retention correction

Author contribution, 2026-10-12 UTC. Repository:
`/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04`.
Branch `docs/documentation-overhaul`; source/starting revision
`2025f36306636b2e0c2c426447bf137d0574e11f` (matrix-only successor to documentation
revision `37920d4f92dd95764c7df2c20748a5a0f59fb829`). Writer:
`/root/raw_audit_entry_complete_family_writer`.

Exclusive repository edits: `docs/site/use/operate.md` only. Guard was released
by root before edits. recovery.md, diagnose.md, plugins.md and
workflows/buster-suite.md remain byte-identical to the released frozen baseline.
Their before/after hashes are retained. No commit, push, product/runtime change,
generator output write, test-tool change or dependency installation was made.
Concurrent unrelated work is recorded in git-status.txt.

## Findings corrected

The complete fresh independent Source report at
`/home/node/Documents/Codex/a98-evidence/raw-audit-entry-complete-corrected-source-fresh/report.md`
remains its original FAIL. This author correction addresses S01–S04; it does
not retroactively replace the independent verdict.

* S01: direct resume entry now requires original platform/run/project-or-graph,
  package/storage/configuration identities, exited owner, stopped run/adapter
  writers, new verified raw run and owning-adapter copies, strict copied-journal
  parsing, and known effect outcomes before **each** submission, including
  repeat/replay/wrong-signal attempts. Both command forms call the existing
  canonical helper immediately before the CLI and capture stdout/stderr/actual
  exit. Each result/rejection/lost response requires stopped-writer ownership,
  new run and adapter captures, strict inspection, then audit. Earlier captures
  are retained, never reused as proof of later bytes. Signal authority remains
  unsigned/self-asserted; the same bytes/key rule is preserved.
* S02: each recovery form calls that helper and records actual outputs/status.
  After every recovery attempt, the numbered procedure requires an exited owner,
  stopped run/adapter writers, original identities, new owned adapter copies,
  another verified raw capture and successful copied-journal parse before the
  final audit. Failed, blocked, rejected, or lost responses use the same ordering.
  Missing outputs or exit status remain `not observed`. A later audit cannot use
  the pre-recovery preservation receipt. Further retries repeat all prerequisites.
* S03: closed-envelope validation is stated before the accepted signal and
  durable `wait.resolved` transition, separately from earlier mutation ownership
  and journal constructors. Current narrow engine-run/run-mutation pins explain
  why invalid/stale/terminal rejection does not establish unchanged files.
  Recovery's pre-return journal opening and observer reconciliation are also
  linked narrowly. Original raw bytes must precede any later authorized repair.
* S04: raw observations require an incident audit owner's existing private durable
  evidence root, access/capacity/retention qualification and final-disposition
  authority. The helper fails when this root is absent; it no longer silently
  chooses the default temporary directory for retained raw bytes. Ordinary
  cleanup cannot delete observation directories after recording a digest.
  Complete raw run/adapter bytes, manifests, rejected tails, original signal
  bytes, command records and actual repair changes remain retained. Only named
  disposable working candidate/signal copies may be removed after their own
  prescribed retention, documented owner disposition and retained-original proof.

The new `RUN_CONTROL_EVIDENCE_ROOT` placeholder means an existing private durable
location selected by the incident audit owner, outside run/adapter stores and
protected from automatic temporary cleanup. This input is defined in canonical
Inspect a Run, which the frozen entry pages already require before defining
and calling the helper. No second large preservation helper or generic adapter
backup command was added. Owning-store backup, stopped writers and incident
retention remain explicit operator prerequisites; missing authority stops work.

Retry table and cancellation diagnosis now route through the same fresh-capture
contract. Active run observation does not use live audit. Containment is not
terminal completion or external-effect reconciliation. Readiness, platform
configuration, release/tool controls, original package/graph checks, failure
outcome tables, no-cancel CLI boundary and demo/Prism product limits remain.
Exact neighboring sections retained are recorded in preserved-sections.json.

## Read scope and source support

Read the complete canonical page and fresh Source report, quality standard and
its operator/source requirements, A98-02/A98-05/A98-13 and OPR-004/OPR-005
records, relevant AP09.8 execution requirements and unchanged deployment-trio
boundary. The task inherits those already-read contractual rules from the prior
four-page assignment; the relevant records were read again at this revision.
Inspected current complete journal/mutex/audit/parser, both CLI entry files,
resume/recovery engine, run mutation ownership and effect-recovery code; inspected
current resolver/platform-loader and validator branches that the helper uses.
New links point to exact current source lines for the changed physical/lifecycle
ordering claim. Full pinned-file currentness is independently mechanical and
not an exhaustive independent semantic acceptance of unaffected domains.

Controlled-language author review applies direct English, explicit conditions
before commands, defined placeholders, distinct storage versus lifecycle state,
stop/retention rules and bounded evidence classes. No formal ASD-STE100
certification, fresh Reader/Quality approval, source-gate approval or global
acceptance is claimed.

## Checks and exact limits

| Check | Observed result | Evidence class / limit |
| --- | --- | --- |
| All authored Bash fences | 11 extracted exact blocks, each `bash -n` exit 0 | Syntax only |
| Published signal JSON | One JSON block parses and passes actual `resumeSignal` validator | Contract only; no authenticated issuer or live resume |
| Whole source pins / ranges | 25 links, 21 revision/file pairs; complete pinned files match current bytes; valid narrow ranges | Source currentness/range check, not full semantic acceptance |
| Canonical local links | 30 resolve to present files/headings | Markdown route check, not renderer/publication proof |
| Four frozen delegated pages | Before/after bytes and hashes identical | Preservation only |
| Exact current preservation helper, private synthetic stores | Four independent captures: valid first/later state succeed; partial tail and wrong hash fail after preserving exact source/copy bytes and manifest; missing retention root fails | Private local helper/source check; no FileJournal, lock, audit or pipeline operation |
| Exact four resume/recover command fences, fake shell functions | Failed preservation exits before fake npm; synthetic exit 7/stdout/stderr are retained correctly | Local authored-control fixture; no real npm/product call |
| `npm run docs:operator-tasks:check` | Exit 0; current 13 tasks, 14 lifecycle capabilities, mutation fixtures | Structural/task-source check; no operator execution |
| `git diff --check` | Exit 0 | Focused whitespace |
| `npm run docs:check:refs` | Exit 1; only same three unassigned generated Helm anchor failures | Full references gate remains open |

The private helper fixture imported the actual platform loader, run-root
resolver and strict parser, but used only synthetic private state under this
evidence directory. It never opened FileJournal or called a real audit, resume,
recovery, signal dispatch, provider, cluster or external service. Distinct
first/later captures retain both versions. The parser failure captures keep
partial/wrong-hash bytes and manifests. No original synthetic bytes were repaired
or truncated. Shell-only command stubs demonstrate the authored fences' failure
handling, not implemented runtime behavior. All private fixture files are retained.

The reference failures are in
`docs/site/understand/buster-namespace-controller.md` links to
`docs/site/reference/helm-values.md` anchors `api-field-2d7090db945e3299f8e7`,
`api-field-e5b8003a74b771aad5b3`, and `api-field-446072fe13a4ef01e5dc`.
No outside-ownership correction was made. The complete log and actual exit
remain retained; passing assigned-page routes cannot override that full-gate FAIL.

Not executed: real Nova CLI lifecycle or journal-opening operation; live/cluster
commands; credentials or provider operations; outage, cancellation, restore,
publishing, renderer/browser, comprehensive generators/global gates or fresh
Reader/Quality exercises. Required separate deployment evidence remains absent
for EXEC-WAIT-RESUME, EXEC-CANCELLATION and EXEC-RESTART-RECOVERY. No fixture was
waived and no local syntax/source/helper result was promoted to deployment PASS.
Independent fresh review and remaining receipt/semantic-domain work stay open.

## Final artifact identity

`docs/site/use/operate.md`: 49846 bytes;
SHA-256 `aa713a0462cf8b4781831c2021f3f96fa4e4a263806c27350247d7aa5366f745`.

before.json/after.json bind the canonical and four frozen files. source-pins.json,
syntax-results.json, local-links.json, json-contract.json and
private-check-results.json record bounded results. Exact helper/fences,
synthetic stores/captures, stdout/stderr, npm gate logs/exit codes and operate.diff
are retained. manifest.json recursively records every evidence artifact's path,
byte count and SHA-256, including all synthetic raw captures; it is not a
publication or acceptance manifest.
