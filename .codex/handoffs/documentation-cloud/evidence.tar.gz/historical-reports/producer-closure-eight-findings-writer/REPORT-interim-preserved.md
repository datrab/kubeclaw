# Producer correction candidate: bounded author evidence

No global AP09 or self acceptance. Base f01d766a5c6cd06a0a733ebd09a6e75e8215dd71; exact working source binding and owned-file snapshots are adjacent. The owned files remain an AUTHOR candidate undergoing final dynamic subprocess sink closure. Receiver integrations are owned elsewhere. No final release seal exists.

## Implemented and checked

- F01: Original bootstrap Python functions and restricted original module initializers run offline. Imports/main do not execute. Environment, kube responses, Path reads and token generation are synthetic; subprocess is blocked. Missing/optional/retained/copy-disabled profiles preserve creation, optional credentials and source Secret copy. Contexts bind original source, deployment caller, adapter, environment and responses. Original add/change/remove/rename and initializer changes have observed tests.
- F02: Original bootstrapDocuments, original gitOpsName/cluster-kind helpers and original continuousDocuments execute inside an isolated VM with a controlled committed-bundle response. Current checkout has no releases/gitops committed bundle; fixture boundary remains explicit. AppProject and Application outputs include main/gitops/production/apps/directory.include applications.yaml and bind source ancestry. Existing script-render receiver dispatch applies.
- F03: API-bearing interpolated templates at stdout, file writes and returned outputs reject named qualification. Literal YAML output remains supported; exact root JSON.parse spread rejection remains unchanged. Generic serializers with no inline API identity remain unresolved, described below.
- F04: Emitted variable bindings include computed-key updates. Unsupported conditional/control-flow, nested/compound and changed multi-publication variants reject. Updates after terminal publication do not enter the earlier output. Mutation source positions remain bound.
- F05: Unsupported constructor/heredoc shell pipeline transforms reject before constructor acceptance; direct constructors and direct applies remain supported.
- F06: Authenticated current invocation signatures are checked independently from source sha. Actual installer argv is parsed with shlex without executing a shell; current defaults and actual version/release/namespace/values/set bindings drive the render recipe. Pure-transform callers have independently enforced symbolic positional mappings. Original Cilium disable-relay/UI plus source-sha refresh rejects; full actual external installer render passes. Source operation signatures, helper hashes and original-source renders are evidence, not a grant to refresh only a source fingerprint.
- F08: Public source roots include scripts/skills/ops/tools/bin/cmd/docker/packaging/plugins/contracts for JS/TS, Go, Python and shell. New unsupported API-bearing languages and renamed unqualified Python producers reject. Exact local kubeconfig file sink is recorded separately with its source digest and KUBECONFIG consumer; API-shaped Config submissions reject. Tests/fixtures, vendor/dependencies and experimental spikes have stated source-boundary reasons.

## Actual verification

`KUBECLAW_DOCS_GO_BINARY=/home/node/Documents/Codex/a98-evidence/argo-receiver-writer/go/bin/go node --test scripts/tests/api-reference.test.mjs`: PASS 46/46, 0 failures, 0 skips. Final tests.log is the exact observed log. Earlier failed or mid-edit suite runs are not final proof. No live cluster, credential reads, deployment, product behavior change, commit, push or generated publication was performed by this writer.

Actual current external render proof: external-actual-proof.json. Actual original Cilium changed-operation source/hash-refresh proof: changed-operation-primary-proof.json and operation.log. Non-API local file sink proof: nonapi-classifications.json. Full replay is separately running against current source and must be evaluated with its before/after binding; its counts only describe discovered contexts.

## Material remaining findings

FULL F03/F08 generic output qualification remains unresolved: JS discovery still filters source lacking inline apiVersion/kind before AST shape evaluation. A serialized unknown root JSON.parse output with no inline identity can disappear. Public code includes non-API diagnostic/config serializers, so closing this requires source/caller/sink classification rather than a blanket serialization exclusion or rejection. The current candidate must not be described as full producer completeness.

No claim of exhaustive public caller graph classification is made. The declared supported roots detect tested additions/renames, but a new public caller delegating to a newly introduced root must be qualified through its actual caller graph. Local chart branch witness checks and original pure transforms remain bounded evidence, not an exhaustive unsupported-language guarantee.

F07 belongs to Root; new selected receiver gaps belong to the workload receiver writer. Earlier mixed-source replay leads included StatefulSet/CronJob/DaemonSet/Pod terminationMessagePath and Job ports protocol. Those mixed replay logs are retained only as leads. Current stable full replay and independent SOURCE review are required before closure; source binding/operation/output/receiver/publication are separate checks. No new upstream schema authority was introduced; existing pinned schema and narrow Cilium generated-certificate classification are retained.

## Current observed status (2026-10-10)

Final literal-subprocess candidate suite: 59 PASS, 0 FAIL, 0 SKIP (observed process exit 0), /tmp/api-tests-kubectl-final-qualified.log. Exported actual output-role proof: 322 classified sinks, 0 unknown, final-output-role-proof.json. This does not prove generic dynamic argv closure; that correction is pending. Replay session 6464 began at f22a902843530e02f19f51be4b827d0c1c5b2083 and remains running; parent receiver movement to c75ec3bb invalidates a stable full-source claim. Exact source before in final-source-before.json; final-current-replay.log is interim until process terminal and final before/after audit. No known-limit global completion claimed.
