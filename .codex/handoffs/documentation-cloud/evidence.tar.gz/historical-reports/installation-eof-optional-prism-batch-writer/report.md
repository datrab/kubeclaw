# Installation EOF and optional Prism documentation batch

Writer: `/root/installation_eof_optional_prism_batch_writer`. Documentation correction only; no independent Source, Reader, Quality, package, publication, or live acceptance claim.

Repository: `/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04`, branch `docs/documentation-overhaul`. Assigned product revision: `d68da902c174574d1186ffd4a3ff29e95b63474e`; actual initial and final dirty worktree statuses are saved. Only `docs/site/use/install.md` and `docs/site/use/maintenance.md` were edited. No commits, generators, workflows, remote release actions or cluster command bodies were executed.

## Correction and scope

Read complete fresh Reader and Quality reports and Reader's exact authorization fixture/results. Inspected project quality standard, AP09 acceptance contract, relevant OPR-001/002/003 catalogue and A98-01/02/03/04/13 bindings, immutable operator fixtures, actual deployment selection functions, live Worker Trust verifier, and linked published trust/release/render context. Scope preserves all unrelated work and existing source citations.

R1: Read each raw authorization row and process a populated unterminated final row. Validate each field after splitting the row. Reject whitespace-only EOF rows, malformed rows, empty/nonregular/symlink plans and denied authority explicitly. The previous `test -s ... && test ! -L ...` also did not reliably fail closed for an empty file under `set -e`; the revised compound check has explicit `|| exit 1`. The reviewed denied final row now calls the permission checker and fails with `AUTHORITY_DENIED` with or without a terminal newline.

QUALITY-FRESH-01: Keep the real optional Prism selection. Explain actual defaults and normalization, condition installation/rendering/separate namespace creation, and distinguish full-profile trust completion from missing reduced-profile verification. The early `cmd_prism()` guard at line 1685 applies even to explicit `render prism`; the dispatch branch alone does not prove an effective unconditional render. No reduced verifier or flag was invented. A completed installation or operational approval requires stopping before first mutation when the reduced-profile trust proof is missing. An explicitly approved isolated deployment remains possible through actual supported commands but is incomplete and cannot admit operational work. The owner and measurable future positive/negative/signing/cleanup criteria are explicit. Full-profile mandatory source and live positive/negative checks remain required; Worker Trust page itself was not edited.

QUALITY-FRESH-02: Define CNI, CSI and OCI briefly at first use with primary focused links. The three primary definition pages were opened and read through the web tool on 2026-10-11. The explanation is task-specific, not a generic Kubernetes course. Saved Buster render handoff was not treated as a failure; maintenance retains that existing path with conditional Prism rendering.

Former-Qdrant section is byte identical to the initial working-tree section. Its proof is recorded in `former-qdrant-result.json`; unrelated maintenance sections and prior valid citations remain unchanged.

## Terminal local checks

Commands executed:

- `python /home/node/Documents/Codex/a98-evidence/installation-eof-optional-prism-batch-writer/check.py` — final exit 0. 45 extracted Bash blocks pass `bash -n`; syntax only for bodies not listed below.
- The same harness runs 12 exact extracted authorization-block fixtures. Empty, newline blank, whitespace EOF, valid row followed by whitespace EOF, missing field, extra field, and invalid verb exit 1. Valid terminated and unterminated rows exit 0. Denied terminated, unterminated, and second-final-row cases exit 1 with the exact denial. Actual `scripts/gitops-owner.mjs` runs only against local mocked Kubernetes reads; all commands, input bytes, calls, stdout/stderr and results are retained.
- The same harness runs eight exact extracted installation render/namespace blocks for true/false and shared/separate namespaces against local shell functions. All exit 0; only true renders Prism, and only true plus a separate namespace applies Prism namespace YAML. This proves shell branching, not Kubernetes creation or deployment.
- Actual extracted `normalize_boolish()`/`component_enabled()` source functions execute locally; accepted spellings and invalid nonempty disabled behavior are retained in `actual-selection-functions.stdout`.
- `python /home/node/Documents/Codex/a98-evidence/installation-eof-optional-prism-batch-writer/maintenance-render-check.py` — exit 0. Exact maintenance render block against a local mock executable produces three selected YAML files for true, two for false, and no files with exit 1 for invalid selection. No repository deployment script was invoked.
- 66 local Markdown links have existing files and approximate matching heading slugs; `local-links.json` records each. This is structural validation, not actual renderer or published-route proof.
- Each added source pin/range resolves to its actual Git object, has ascending in-file bounds, and its source bytes equal current source. Existing standard/contract/source authority hashes remain unchanged in `after.json`. New source spans are saved separately.
- Former-Qdrant byte equality passes. Frozen final page bytes and focused before/after diffs are retained.

Initial harness attempts had extraction-only failures: a regex did not handle indented fenced blocks, and the first link matcher treated Bash regex text as Markdown links. Both private harness defects were corrected; no page was changed to accommodate those defects. The terminal full harness ran successfully after both corrections. Those failures were not product or documentation execution failures and are not converted into live proof.

## Limits and frozen identity

No live credentials, API connection, storage/DNS probe, image pull, mutation, resource deletion, trust request, source signing transaction, host setup, node installation, workflow dispatch or release approval was performed. No generator/build/publication aggregate gate was run. The current runtime release selection remains absent. Checks use local synthetic fixtures and shell syntax; they do not prove supported Kubernetes versions, release authenticity, provider effects, live trust or operational completion. Independent reviewers must assess the complete changed route.

Frozen pages:

- install.md: 72633 bytes, SHA-256 `319cf8f7890060422c28246e7467269f97ddb3bed3685609bd8ed855dc28da67`.
- maintenance.md: 76654 bytes, SHA-256 `70647b0073ea349545f3633a51f9c5a5553ea6c6850fd2858ca713dd0040e8ce`.

`artifact-manifest.json` records every private artifact's exact byte count and SHA-256, excluding itself to avoid a self-reference. It does not authorize acceptance.
