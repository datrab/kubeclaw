# Independent complete Deployment receiver Source review — FAIL

Reviewed immutable base `8efd6186c0e0387ef721feabf133a6571785963e` with exactly one overlay `scripts/docs-kubernetes-apps-receiver-contracts.mjs`, SHA256 `e96425368a043dd5bc23604577adf6016fd17e725c9553327c74bc590a315e58`. Base archive SHA256 `8726b3f8e832d358ce7246dad74f169182aab28dbc2b59ca5749bda519de66bf`. All other working-tree bytes, root integration, Argo and other components are excluded as acceptance subjects. Official Kubernetes implementation is pinned to `66452049f3d692768c39c797b21b793dce80314e`; 203 primary files were independently downloaded, preserved and hashed.

The complete assigned Source scope was evaluated: **1,285 records: 832 PASS / 453 FAIL; 7,712 cases: 7,665 narrow PASS / 47 FAIL; 347 assigned workitems: 112 PASS / 235 FAIL; 36 original contexts: 1 PASS / 35 FAIL.** All 201 distinct old boundary paths and 486 appearances have individual fresh dispositions. Record failure counts are unions, so correction group counts overlap. A supported typed scalar/default/validation case can PASS while its complete record fails for an absent or contradictory current runtime mechanism. Neither narrow PASS nor numerical source-range resolvability grants full-record acceptance. The one context marked PASS is `Deployment $.metadata`: its assigned nonmetadata subset is empty; this is vacuous scoped coverage and grants no metadata acceptance. The 201 distinct old boundaries have 85 PASS / 116 FAIL dispositions.

Independent pinned OpenAPI traversal found 1,267 nonmetadata recursive Deployment spec paths, root and 17 status paths, exactly matching the 1,285 records without a count guard. Independent Go JSON-tag/embedded/custom-type traversal resolved every path. Independent raw YAML and opaque Helm source parsing inspected 192 files: 33 raw Deployment documents including historical fixtures and four Helm syntactic Deployment documents. Five configured raw Deployment files independently expose exactly the original 36 object/list contexts. Their pinned schema shallow boundaries independently regenerate all 201 distinct original boundary paths / 486 appearances. The original vocabulary adds item and exact-key markers even to object schemas; actual shape decisions use Go/OpenAPI rather than treating these markers as real API collection types. Two parser errors are unrelated non-Deployment Helm artifacts and are preserved. Helm source parsing does not establish rendered values, template-generated keys or live input.

Metadata, including Deployment metadata, Pod-template metadata and embedded ephemeral PVC metadata, remains **explicit global remaining scope under the other owner**, never optional. The receiver component is not integrated or published. Canonical future publication target is `docs/site/reference/helm-values.md`; no Reader, Quality, Astra or global A98 acceptance is granted.

The complete documentation quality standard, relevant AP09 acceptance contract and fixture catalogue were inspected in the frozen base. CFG-009 requires configuration authority/owner/consumer coverage; A98-10 requires recursive typed input/default/boundary/owner/consumer coverage; A98-11 requires full authored-input to runtime precedence and conflict/empty/secret/invalid cases. The fixture JSON does not define separate direct A98-10/A98-11 fixtures; `relevant-fixtures.json` is explicitly empty, not a fabricated check. Full immutable input hashes are in `input-read-manifest.json`.

## Necessary corrections

### C01: Linux security outcomes are presented without an OS boundary

Receiver module lines `739-740`; 21 affected records (exact paths in `findings.json`).

The non-Windows verifyRunAsNonRoot branch is described as the kubelet outcome for every runAsNonRoot/runAsUser record. Windows instead uses case-insensitive ContainerAdministrator checks on authored/image usernames; the Linux CRI synthesis is also added to WindowsOptions records without supplying the selected Windows consumer. The no-image-identity nil helper case is not the normal caller outcome: getImageUser returns an explicit zero UID.

Required: State !windows vs Windows build routes, include actual Windows username/gMSA/HostProcess conversion and nonroot checks, and connect getImageUser zero fallback to Linux verification.

Pinned primary proof: [pkg/kubelet/kuberuntime/security_context_windows.go#L44-L76](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/kuberuntime/security_context_windows.go#L44-L76), [pkg/kubelet/kuberuntime/security_context_others.go#L35-L70](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/kuberuntime/security_context_others.go#L35-L70), [pkg/kubelet/kuberuntime/helpers.go#L142-L165](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/kuberuntime/helpers.go#L142-L165), [pkg/kubelet/kuberuntime/kuberuntime_container_windows.go#L123-L146](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/kuberuntime/kuberuntime_container_windows.go#L123-L146). Exact numbered byte-derived excerpts and hashes are preserved in `corrective-excerpts.json`.

### C02: Trust nil and empty selectors have a cache-dependent outcome

Receiver module lines `756; 765; trust selector refinements`; 14 affected records (exact paths in `findings.json`).

The signer manager caches by signerName and selector.String(), before lookup and optional/zero-result handling. Nothing(nil) and Everything({}) both stringify to the empty string. A successful empty-selector lookup can populate a key later hit by a nil-selector lookup. The unconditional nil -> no bundles -> failure unless optional claim only holds on the cache-miss route. The 100 KiB serialized-selector limit is also absent. This is a static source deduction; no lookup or exploit was executed.

Required: Document cache-miss semantics separately from the conditional shared-key cache hit, serialization length rejection and invalidation/TTL. Give safe stop/owner/follow-up for the implementation limitation rather than relying on nil as an unconditional no-match boundary.

Pinned primary proof: [pkg/kubelet/clustertrustbundle/clustertrustbundle_manager.go#L232-L278](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/clustertrustbundle/clustertrustbundle_manager.go#L232-L278), [pkg/kubelet/clustertrustbundle/clustertrustbundle_manager.go#L39-L46](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/clustertrustbundle/clustertrustbundle_manager.go#L39-L46), [staging/src/k8s.io/apimachinery/pkg/labels/selector.go#L93-L105](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apimachinery/pkg/labels/selector.go#L93-L105), [staging/src/k8s.io/apimachinery/pkg/labels/selector.go#L432-L438](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apimachinery/pkg/labels/selector.go#L432-L438). Exact numbered byte-derived excerpts and hashes are preserved in `corrective-excerpts.json`.

### C03: Deployment controller knobs stop at validation

Receiver module lines `33-49`; 10 affected records (exact paths in `findings.json`).

Counts/defaults are mostly correct, but actual rollout scaling, percentage rounding, zero-fencepost fallback, revision cleanup eligibility, MaxInt32 infinite-history/no-progress-deadline sentinels, pause/resume progress accounting and deadline failure consequences are absent. A controller setting is not a complete receiver contract merely because validation accepts it.

Required: Attach exact current controller/helper paths and explain these outcomes, including that pause still permits scaling and deadline reporting does not implement automatic rollback.

Pinned primary proof: [pkg/controller/deployment/util/deployment_util.go#L887-L919](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/controller/deployment/util/deployment_util.go#L887-L919), [pkg/controller/deployment/sync.go#L54-L77](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/controller/deployment/sync.go#L54-L77), [pkg/controller/deployment/sync.go#L442-L477](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/controller/deployment/sync.go#L442-L477), [pkg/controller/deployment/progress.go#L35-L100](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/controller/deployment/progress.go#L35-L100), [pkg/controller/deployment/util/deployment_util.go#L744-L816](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/controller/deployment/util/deployment_util.go#L744-L816). Exact numbered byte-derived excerpts and hashes are preserved in `corrective-excerpts.json`.

### C04: DNS effective precedence and exact literal evidence remain missing

Receiver module lines `172-174;187;195; DNS descendants`; 10 affected records (exact paths in `findings.json`).

DNS records give API limits and enum membership but omit the actual node DNS resolver path: ClusterFirst on hostNetwork falls back to host DNS, missing cluster DNS emits warnings and falls back, None starts with an empty base, authored options replace same-name base options and assembled lists are deduplicated/truncated. The selected validator range starts at4156; literal 3/32/2048 declarations are4124-4131. Relaxed search-name gate/old-object predicates are not explained.

Required: Add the exact constants, option construction and source-backed node resolver policy/merge/limit routes. Keep resolver configuration and working DNS as external inputs, not proof prerequisites invented by review.

Pinned primary proof: [pkg/apis/core/validation/validation.go#L4124-L4131](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L4124-L4131), [pkg/kubelet/network/dns/dns.go#L304-L352](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/network/dns/dns.go#L304-L352), [pkg/kubelet/network/dns/dns.go#L378-L450](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/network/dns/dns.go#L378-L450), [pkg/api/pod/util.go#L520-L541](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/api/pod/util.go#L520-L541). Exact numbered byte-derived excerpts and hashes are preserved in `corrective-excerpts.json`.

### C05: Hostname, hosts-file and namespace consumers are missing

Receiver module lines `177-187;196;hostAliases descendants`; 14 affected records (exact paths in `findings.json`).

Hostname/subdomain/FQDN/override and HostAliases contracts do not reach node hostname or hosts-file construction. Relevant feature dropping, Pod-name fallback/truncation, domain construction, host-network/Windows HostProcess and an existing /etc/hosts mount alter the outcome. Host namespace/user namespace settings are described as requests without the actual sandbox namespace and user-mapping consumer.

Required: Describe each exact fallback/precedence and selected namespace/sandbox route with supplied parent and OS conditions; retain actual node/runtime inputs as bounded external dependencies.

Pinned primary proof: [pkg/kubelet/kubelet_pods.go#L268-L290](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/kubelet_pods.go#L268-L290), [pkg/kubelet/kubelet_pods.go#L475-L553](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/kubelet_pods.go#L475-L553), [pkg/kubelet/kubelet_pods.go#L555-L617](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/kubelet_pods.go#L555-L617), [pkg/kubelet/kuberuntime/kuberuntime_sandbox.go#L164-L256](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/kuberuntime/kuberuntime_sandbox.go#L164-L256), [pkg/api/pod/util.go#L803-L819](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/api/pod/util.go#L803-L819). Exact numbered byte-derived excerpts and hashes are preserved in `corrective-excerpts.json`.

### C06: Placement and readiness stop at API name checks

Receiver module lines `197-200; readiness/scheduling/toleration descendants`; 16 affected records (exact paths in `findings.json`).

Readiness gate missing/non-True conditions, scheduling gate PreEnqueue rejection/requeue, toleration matching and NoExecute duration/eviction, schedulerName routing and nodeName placement/bypass consumers are not supplied. A name/domain validator cannot establish the actual hold, readiness or eviction consequence.

Required: Attach actual current consuming predicates, removal/requeue and eviction/time semantics. Explain missing readiness conditions distinctly from false conditions and retain scheduler/node configuration as an external input.

Pinned primary proof: [pkg/kubelet/status/generate.go#L125-L165](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/status/generate.go#L125-L165), [pkg/scheduler/framework/plugins/schedulinggates/scheduling_gates.go#L45-L58](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/scheduler/framework/plugins/schedulinggates/scheduling_gates.go#L45-L58), [pkg/scheduler/framework/plugins/tainttoleration/taint_toleration.go#L109-L130](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/scheduler/framework/plugins/tainttoleration/taint_toleration.go#L109-L130), [pkg/controller/tainteviction/taint_eviction.go#L129-L184](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/controller/tainteviction/taint_eviction.go#L129-L184), [staging/src/k8s.io/api/core/v1/toleration.go#L47-L112](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/api/core/v1/toleration.go#L47-L112). Exact numbered byte-derived excerpts and hashes are preserved in `corrective-excerpts.json`.

### C07: Resource accounting and DRA consumption are incomplete

Receiver module lines `97-105;205;470-475;750`; 34 affected records (exact paths in `findings.json`).

Resource map names/quantities and gate dropping do not explain scheduler request accounting, effective restartable-init aggregation, Pod overhead/Pod-level overrides, Linux/Windows runtime limits or node pressure. DRA references stop at membership and disabled-field dropping: actual generated-claim resolution, ReservedFor/ownership/UID checks, driver preparation/CDI and cleanup are absent despite available implementations.

Required: Connect each retained field to the exact accounting and OS-specific runtime route. For DRA include controller/scheduler claim generation/allocation and node prepare/unprepare/cache/CDI failure boundaries; external device/driver state remains bounded.

Pinned primary proof: [pkg/kubelet/cm/dra/manager.go#L268-L320](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/cm/dra/manager.go#L268-L320), [pkg/kubelet/cm/dra/manager.go#L330-L411](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/cm/dra/manager.go#L330-L411), [pkg/scheduler/framework/plugins/noderesources/fit.go#L293-L318](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/scheduler/framework/plugins/noderesources/fit.go#L293-L318), [staging/src/k8s.io/component-helpers/resource/helpers.go#L144-L188](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/component-helpers/resource/helpers.go#L144-L188), [staging/src/k8s.io/component-helpers/resource/helpers.go#L207-L281](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/component-helpers/resource/helpers.go#L207-L281), [pkg/kubelet/kuberuntime/kuberuntime_container_linux.go#L134-L180](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/kuberuntime/kuberuntime_container_linux.go#L134-L180). Exact numbered byte-derived excerpts and hashes are preserved in `corrective-excerpts.json`.

### C08: Probe/lifecycle failure and ordering contexts are incomplete

Receiver module lines `115-144;265-284;801-802; lifecycle/probe copy loops`; 226 affected records (exact paths in `findings.json`).

Handler dispatch is available, but probe threshold/startup gating/readiness/restart actions and lifecycle call ordering/failure/grace-budget consumption are absent. PostStart runs after the container start and a hook failure kills it. Sleep has API field dropping and a node no-op gate branch; TCP-only lifecycle reports invalid handler. A live-result disclaimer does not document these source mechanisms.

Required: Add selected worker/prober-manager and runtime caller routes; distinguish API-valid actions from actual hook execution, failure/restart and PreStop remaining grace. Include Sleep preparation/old-object and node gate branches.

Pinned primary proof: [pkg/kubelet/kuberuntime/kuberuntime_container.go#L320-L339](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/kuberuntime/kuberuntime_container.go#L320-L339), [pkg/kubelet/lifecycle/handlers.go#L76-L125](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/lifecycle/handlers.go#L76-L125), [pkg/api/pod/util.go#L908-L940](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/api/pod/util.go#L908-L940), [pkg/kubelet/prober/worker.go#L278-L336](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/prober/worker.go#L278-L336). Exact numbered byte-derived excerpts and hashes are preserved in `corrective-excerpts.json`.

### C09: Mount, device and HostPath node semantics are missing

Receiver module lines `106-114;166-168;248-250`; 29 affected records (exact paths in `findings.json`).

Mount/device records mostly cite validation alone. Actual subPathExpr expansion, safe directory/open binding, forced read-only source state, propagation and recursiveReadOnly runtime capability/error behavior are not attached to these fields. HostPathUnset does no type check; DirectoryOrCreate/FileOrCreate can create, while exact type variants fail mismatches. The source-backed path-type implementation cannot be waived as node external state.

Required: Explain exact mounts/devices and HostPath consumer branches, including retained nil/empty/type values and creation/type-error consequences; separate filesystem existence/permissions from available implementation proof.

Pinned primary proof: [pkg/kubelet/kubelet_pods.go#L277-L418](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/kubelet_pods.go#L277-L418), [pkg/kubelet/kubelet_pods.go#L230-L267](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/kubelet_pods.go#L230-L267), [pkg/volume/hostpath/host_path.go#L241-L256](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/volume/hostpath/host_path.go#L241-L256), [pkg/volume/hostpath/host_path.go#L462-L502](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/volume/hostpath/host_path.go#L462-L502). Exact numbered byte-derived excerpts and hashes are preserved in `corrective-excerpts.json`.

### C10: Selected narrow ranges still omit their claimed implementation

Receiver module lines `65-66;177;470-475;750; inherited resource evidence`; 32 affected records (exact paths in `findings.json`).

enableServiceLinks653-711 excludes the actual same-namespace-and-enableServiceLinks branch717-719; Pod resource4759-4845 starts after validatePodResources name/quantity dispatch; restart dropping1788-1812 is only the helper and omits the enabled/old-in-use selector781-783. Pod resource validator evidence is also appended to embedded PVC resource maps, although the direct PVC spec validator only validates storage request, not all Pod keys/limits.

Required: Correct the specific range claims and supplying caller context; distinguish true helper behavior from whether this record actually reaches that helper. Remove irrelevant PVC Pod-resource dispatch claims.

Pinned primary proof: [pkg/kubelet/kubelet_pods.go#L683-L726](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/kubelet_pods.go#L683-L726), [pkg/apis/core/validation/validation.go#L4732-L4758](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L4732-L4758), [pkg/api/pod/util.go#L778-L784](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/api/pod/util.go#L778-L784), [pkg/apis/core/validation/validation.go#L2491-L2538](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L2491-L2538). Exact numbered byte-derived excerpts and hashes are preserved in `corrective-excerpts.json`.

### C11: Image pull and termination-message consumers remain incomplete

Receiver module lines `65-66;57-58`; 8 affected records (exact paths in `findings.json`).

Image/imagePullPolicy describes tag-dependent defaults and permitted policies, but the original image manager policy/present-image/backoff/pull-error consumer is absent. Termination message records give defaults/enum membership but omit real file-read/empty-file/error/log fallback and its limits. Image availability and executable contents are external; the current pull/message implementation is available source proof.

Required: Add the actual original pull and message collection paths, failure/cached behavior and literal byte/line limits, without asserting registry/image existence or successful execution.

Pinned primary proof: [pkg/kubelet/images/image_manager.go#L120-L199](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/images/image_manager.go#L120-L199), [pkg/kubelet/kuberuntime/kuberuntime_container.go#L565-L617](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/kuberuntime/kuberuntime_container.go#L565-L617). Exact numbered byte-derived excerpts and hashes are preserved in `corrective-excerpts.json`.

### C12: Status numeric validation is correct but full observation semantics are incomplete

Receiver module lines `771-791`; 17 affected records (exact paths in `findings.json`).

All17 status paths are present; normal vs /status preparation and numeric checks are supported. The complete status contracts still do not explain actual count aggregation, availability/minReady timing, unavailable clamping, observedGeneration/completion and Progressing/ReplicaFailure timeout/pause/reason transitions. Condition source references show creation/update helper but not the exception in progress.go that changes lastUpdateTime even for the same True/status reason.

Required: Keep direct decoding/validation claims, supply actual aggregation helpers and all current publisher/diagnostic transitions with observed consequences, including the timestamp update exception.

Pinned primary proof: [pkg/controller/deployment/sync.go#L495-L537](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/controller/deployment/sync.go#L495-L537), [pkg/controller/deployment/util/deployment_util.go#L666-L736](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/controller/deployment/util/deployment_util.go#L666-L736), [pkg/controller/deployment/progress.go#L35-L119](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/controller/deployment/progress.go#L35-L119), [pkg/controller/deployment/util/deployment_util.go#L744-L816](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/controller/deployment/util/deployment_util.go#L744-L816). Exact numbered byte-derived excerpts and hashes are preserved in `corrective-excerpts.json`.

### C13: Issuance authorization/lifetime and certificate refresh contexts are incomplete

Receiver module lines `659-674;768;813`; 13 affected records (exact paths in `findings.json`).

Token source prose reaches configured audiences and issuance but not the authorization/bound identity policy route as a complete operation contract. Certificate manager prose only creates/gets a bundle; key generation failure, API default for nil lifetime, request state transitions, denial/expiry/renewal and no-op manager selection are not described. These are available source, distinct from signer availability or minted credentials.

Required: Explain the full selected request/default/admission/manager/refresh/expiry route and the blocked state safely. Do not invent token/certificate issuance success or require a live proof to establish source behavior.

Pinned primary proof: [pkg/kubelet/podcertificate/podcertificatemanager.go#L736-L820](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/podcertificate/podcertificatemanager.go#L736-L820), [pkg/apis/certificates/v1beta1/defaults.go#L28-L49](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/certificates/v1beta1/defaults.go#L28-L49), [pkg/kubelet/token/token_manager.go#L109-L130](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/token/token_manager.go#L109-L130), [pkg/registry/core/serviceaccount/storage/token.go#L126-L212](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/registry/core/serviceaccount/storage/token.go#L126-L212). Exact numbered byte-derived excerpts and hashes are preserved in `corrective-excerpts.json`.

### C14: Workload references stop before consuming workload policy

Receiver module lines `751-752`; 4 affected records (exact paths in `findings.json`).

GenericWorkload field dropping and reference-name validation are documented, but the current workload manager namespace/workload/group/replica-key identity, Pod membership states, absent-group error and conditional gang scheduling deadline are not. No source-backed unsupported-product boundary is stated.

Required: Trace the current workload/group consumers and reference/replica lookup effects, or document an actual implementation boundary with blocked step, owner, safe action and later acceptance. Available missing implementation evidence remains a documentation gap.

Pinned primary proof: [pkg/apis/core/validation/validation.go#L9586-L9600](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L9586-L9600), [pkg/api/pod/util.go#L1834-L1847](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/api/pod/util.go#L1834-L1847), [pkg/scheduler/backend/workloadmanager/workloadmanager.go#L60-L129](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/scheduler/backend/workloadmanager/workloadmanager.go#L60-L129), [pkg/scheduler/backend/workloadmanager/podgroupinfo.go#L30-L54](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/scheduler/backend/workloadmanager/podgroupinfo.go#L30-L54), [pkg/scheduler/backend/workloadmanager/podgroupinfo.go#L168-L184](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/scheduler/backend/workloadmanager/podgroupinfo.go#L168-L184). Exact numbered byte-derived excerpts and hashes are preserved in `corrective-excerpts.json`.

### C15: Aggregate parent contracts do not close unfinished child receiver routes

Receiver module lines `33;51-56;147-149;199-203`; 14 affected records (exact paths in `findings.json`).

The root/spec/template/spec/containers/initContainers/volumes/affinity/security parent outcomes and generic changeImpact cannot be accepted as complete receiver mechanisms while applicable current child/default/gate/consumer gaps C01-C14 remain. This is an explicit aggregate record failure; it does not change a supported child typed API outcome into a false scalar claim.

Required: Complete the individually named mechanisms and then repeat Source evaluation of these parent operation contexts. Preserve metadata as another owner global remaining scope.

Pinned primary proof: [pkg/registry/apps/deployment/strategy.go#L73-L135](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/registry/apps/deployment/strategy.go#L73-L135), [pkg/apis/apps/validation/validation.go#L638-L675](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/apps/validation/validation.go#L638-L675), [pkg/apis/core/validation/validation.go#L4625-L4758](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L4625-L4758). Exact numbered byte-derived excerpts and hashes are preserved in `corrective-excerpts.json`.

## Supported claims and qualifications

The fresh receiver repairs provide source-backed typed null distinctions: absent pointers differ from retained ordinary zero scalar/struct elements; string-map null retains a key with an empty string; value Quantity null retains zero Quantity, pointer Quantity null is nil; IntOrString null keeps integer zero; Time custom null creates its zero value. Field cases assume the immediate parent/item exists and do not silently substitute absent-parent or nil-collection outcomes. Parent/list/map/item/leaf decisions are preserved separately in the per-record and independently resolved shape ledgers. Projection null source items and missing Secret/ConfigMap references do not manufacture payload; ephemeralContainers are forbidden in the Deployment Pod template rather than runnable. Correct source-supported status strategy clears status on normal create, preserves it on ordinary update and restores spec/labels at /status update. These bounded outcomes remain PASS where applicable, while C12 identifies unfinished controller production mechanisms.

The vSphere inline storagePolicyName qualification is independently confirmed by static source: the selected translator constructs a PV with CSI only, then for nonempty input StoragePolicyName reads nil `pv.Spec.VsphereVolume.StoragePolicyName`. This is a conditional static path, not an executed panic or an assertion every deployment chooses migration. Exact lines 127–156 and fresh source hash are retained in `source-supported-special-dispositions.json`; preserve a conditional safety boundary and the storage-owner CSI/PVC follow-up.

Trust nil-vs-empty selector conversion alone does not establish the whole manager outcome. Both Nothing and Everything stringify to the same empty cache key. The successful empty-selector result can be returned before a later nil-selector lookup reaches the missing-result branch. Only the directly contradicted selector omitted case and applicable generated consumer cases fail; descendant omitted/null typed cases are not automatically failed by the parent issue. No live lookup or exploit was executed.

Honest source-backed unavailable backend/plugin/external image/driver/issuer/node/target-environment state remains a separate implementation qualification. It cannot excuse absent available pinned implementation evidence. Existing qualification strings are assessed individually in `qualification-dispositions.json` and never used as a waiver for C01–C15. No mandatory live prerequisite was invented.

## Evidence and independence

`record-case-dispositions.json` supplies every individual record, every case, operation scope, prose/default/omitted/null/empty/invalid/change-impact/cross-field/qualification disposition and source link. `exact-range-claim-dispositions.json` preserves all 387 attached exact source ranges and 546 distinct authored claims, their original fresh bytes/hashes and narrow dispositions. Current indirect caller, OS, gate, inherited fallback, admission, scheduler, controller, kubelet, environment/resource, security, restart, DRA, storage and consumer gaps are attached to the full record findings; a helper-only narrow claim does not prove the full route.

Original reports, author correction and manifests were used only to locate assigned paths/workitems/source filenames. Their verdicts and acceptance were not inherited. The 347 workitem assignment identities and original context/boundary vocabulary are retained as navigation; all outcomes were computed from this frozen candidate and freshly retrieved implementations. Private YAML library bytes were copied from `network-admission-source-final-candidate-fresh/yaml-library` to this immutable evidence package and reused only as parser dependency (all copied bytes hashed in the manifest); `raw-recount.mjs`, `recount.py`, `go-shapes.py`, `review.py` and all outcomes are new and rerun here. No prior outcome cache was reused. Source hashes, YAML parser errors, complete raw/Helm appearances and independent scope/path/Go-shape inventories are preserved.

Executed checks: frozen module syntax, fresh record import, pinned authority hash, independent recursive path equality, independent Go-shape resolution, raw/opaque Helm parsing, complete review bounds/disposition checks, and every fresh primary byte hash. Earlier review-tool overlong excerpt bounds and shallow-recount checks rejected incorrect evidence-tool ranges/synthetic boundary filtering; ranges and typed-path filters were corrected against actual source and all checks rerun. Final checks pass. These checks are Source/static proof. Actual API server/default/validation/controller/kubelet execution, Helm rendering, live cluster/backend/image/driver verification and the conditional vSphere panic were not executed. Root Unit 24 structural fixtures and author probe are not full actual API or runtime proof and their results were not reused. Detailed command output and nonexecuted checks are in `executed-and-nonchecks.json`.

No repository edits, registry/generator/docs changes, commits, push, secrets, host or cluster mutation were made. `artifact-manifest.json` binds this report, source bytes, scripts and individual ledgers; `subject-manifest.json` binds the immutable base and exact overlay. The snapshot tree is represented by its git archive and single overlay, rather than duplicated per-file entries in the artifact manifest.
