# Fresh bounded Source review at425

**PASS for the complete63 selected receiver records.** Reviewed revision: `425be378fa25d26835a5418d65bfd457e151cc16`. Reviewer identity: `/root/stateful_425_recovery_source_fresh`, Source role, fresh initial context, read-only product scope. No material source finding remains in this bounded set. This is neither whole CFG-009/A98 acceptance nor Reader, Quality, architectural, language, deployment or live acceptance.

The immutable candidate archive and baseline `03fd8741ad168a5042711f87a83c944d7c4b203e` were each authenticated against every tracked Git blob: 5,580 candidate files. An independent import/diff derives exactly62 StatefulSet and1 PodDisruptionBudget records,424 cases,1,423 prose/case component occurrences and1,783 caption occurrences. All have individual PASS rows in the four ledgers.443 distinct prose/case texts and171 distinct captions were read completely, with complete occurrence membership retained; identical text was evaluated under each member's actual typed/parent path. No record/case/caption was sampled, and prior author/reviewer verdicts were not adopted.

The quality standard was read completely; the AP09 product boundary, Source/evidence rules, applicable A98 acceptance conditions, CFG-009 catalogue entry, execution-plan configuration requirements and relevant fixtures were inspected. Applicable criteria have separate bounded Source and complete-gate statuses in `criterion-ledger.json`. Full gates remain UNREVIEWED by this role. The assigned c1 specification is retained as a scope instruction; it is not correctness evidence for425.

All63 recursive typed paths independently resolve against authenticated apps/core/meta/policy type declarations.67 upstream files were freshly obtained at their exact Kubernetes or Go revision and their Git blob hashes checked against the corresponding complete GitHub tree. Every published caption was compared with its exact bounded span, plus relevant function/caller/type/default context where needed. `caption-groups.json` preserves every span, byte binding, membership and verdict; `type-ledger.json` records the actual declarations. Supplementary source proof covers generated default visitors, OnDelete validation, child-PVC/Pod construction and eviction status checks.

Verified mechanisms include fresh pointer/scalar/list/map/null decoding and custom IntOrString decoding; retained null string map keys; absent immediate parents; the old-invalid-StatefulSetSpec update compatibility branch and its independent selector, metadata, Always and deadline restrictions; PVC-name volume substitution before generic validation and controller mounting; child identity/metadata handling; affinity namespace/selector/gate preparation; ConfigMap environment precedence and optional fetch behavior; fieldRef validation and created-Pod defaults; probe startup, threshold, transport/error and result-consumer ordering; host-port placement and regular-only sandbox mapping; Linux/Windows security and namespace consumers; service links; RuntimeClass and Priority admission; supplemental groups and sysctls; Secret/ConfigMap remount/subPath behavior; cleaned-path collisions, Windows link replacement and post-publication failure limits; emptyDir media; StatefulSet rollout budgeting; and separate PDB validation/controller/eviction semantics. Unused upstream alternatives are not expanded into a product-wide schema obligation.

62 records have actual emitted field witnesses in reparsed raw output. StatefulSet `maxUnavailable` has no emitted witness in any selected19 StatefulSet output, and11 contexts independently satisfy the relevant conditional parent predicate: an empty type can materialize RollingUpdate, or authored RollingUpdate already has its rollingUpdate parent. The API-server gate controls the nil->1 default; preparation uses old stored in-use state to decide disabled-gate dropping. An explicit RollingUpdate type with no parent does not materialize all its children. API-server and controller gates and actual stored state were not observed.

The PDB `maxUnavailable` is independently emitted in18 raw-document occurrences, all with integer1, across original infrastructure and external Helm invocations. Its budget has no StatefulSet default. Its controller obtains expected scale, rounds percentage conversion upward, derives desiredHealthy and reports disruptionsAllowed with observedGeneration. The eviction API separately considers readiness/policy and checks/decrements the budget. Direct deletions and StatefulSet rollouts are not universally prevented by a PDB. Every PDB witness has producer/profile, source digest, exact argv/input/stdout digest and qualified chart archive.

The budget-path deletion correction is verified against [the controller](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/controller/statefulset/stateful_set_control.go#L817-L826): non-NotFound errors return immediately; NotFound continues through deletion accounting and decrements CurrentReplicas. [DeleteStatefulPod](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/controller/statefulset/stateful_pod_control.go#L196-L199) returns the original deletion error. The new caption accurately describes that branch. The rest of all63 was reviewed anew, not declared correct from this fix or retained equivalence.

Six bounded unit tests completed with exit0: exact key/index selection and unknown descendant/version rejection; removed-contract failure; new StatefulSet/PDB/Job parent limits; retained legacy identities; finite-batch/StatefulSet restart restrictions; and PDB selector/health distinctions. Independent scope derivation, source/tree authentication, full Git binding, raw-output validation and type derivation also completed with exit0. The initial source fetch failed404 on an incorrectly located supplementary eviction path; the corrected path fetched and authenticated successfully. Initial derivation attempts lacked yaml/typescript and are not successes. There was no interrupted process reported as PASS.

Historical raw Helm receipts were reused only after independently checking the existing seal, all1,451 manifest artefacts, raw/stdout/stderr/input hashes, producer input byte equivalence and actual parsed YAML.5,572 unchanged source input files bind the original d8 render environment to425; the eight changed files do not change producer inputs.351 successful captured template receipts were reparsed. Npm versions match the immutable lock (yaml2.9.0/typescript5.9.3) and copied tool bytes are bound. The actual Helm binary matches the sealed executable digest;13 relevant cached/vendor chart archives were independently hashed and retained. Reused receipts are historical offline Render evidence, not a new Helm execution or a target write. New decoding/selection work is Source evidence, and the six current checks are Unit evidence.

**Remaining global limitation:** producer-discovery closure is open. Known original-producer/capability families include lexical declarations and aliases, returned/callback/escaping writers and serializers, ordered mutation and native/API-role classification, shell stream/emitter boundaries, workspace conditional exports, and complete future public-root detection. Active correction work in six producer files is excluded from accepted source. This bounded presence review does not close these families or grant all-input precedence/maintenance mutation proof. Global producer suite/role/join closure and full fixture Add/Change/Remove runs were not executed here. Old interrupted/failed snapshots remain historical.

No main repository file was edited and no commit, push, deployment, API write or live claim was made. The isolated archive is byte-bound but is not a clean full-repository acceptance evidence commit. The live main worktree contains six active producer edits; its observation is retained only to establish exclusion. No managed-runtime status tool was available and `/etc/codex/network-policy.json` was absent, so no managed network/credential readiness is claimed. The ordinary inherited HTTPS configuration was used with certificate checks enabled.

All individual record rows follow. The full cases/components/captions, typed paths and producer/default proofs remain in the machine-readable ledgers.

| Record | Cases | Captions | Selection | Source verdict |
| --- | ---: | ---: | --- | --- |
| `StatefulSet:$.spec.template.spec.affinity.podAffinity` | 6 | 26 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.affinity.podAntiAffinity` | 6 | 26 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.affinity.podAntiAffinity.preferredDuringSchedulingIgnoredDuringExecution` | 6 | 26 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.affinity.podAntiAffinity.preferredDuringSchedulingIgnoredDuringExecution[]` | 6 | 26 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.affinity.podAntiAffinity.preferredDuringSchedulingIgnoredDuringExecution[].podAffinityTerm` | 6 | 26 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.affinity.podAntiAffinity.preferredDuringSchedulingIgnoredDuringExecution[].podAffinityTerm.labelSelector` | 6 | 27 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.affinity.podAntiAffinity.preferredDuringSchedulingIgnoredDuringExecution[].podAffinityTerm.labelSelector.matchLabels` | 6 | 27 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.affinity.podAntiAffinity.preferredDuringSchedulingIgnoredDuringExecution[].podAffinityTerm.labelSelector.matchLabels[<exact-key>]` | 6 | 34 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.affinity.podAntiAffinity.preferredDuringSchedulingIgnoredDuringExecution[].podAffinityTerm.topologyKey` | 6 | 26 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.affinity.podAntiAffinity.preferredDuringSchedulingIgnoredDuringExecution[].weight` | 6 | 26 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.affinity.podAntiAffinity.requiredDuringSchedulingIgnoredDuringExecution` | 6 | 26 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.affinity.podAntiAffinity.requiredDuringSchedulingIgnoredDuringExecution[]` | 6 | 26 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.affinity.podAntiAffinity.requiredDuringSchedulingIgnoredDuringExecution[].labelSelector` | 6 | 27 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.affinity.podAntiAffinity.requiredDuringSchedulingIgnoredDuringExecution[].labelSelector.matchLabels` | 6 | 27 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.affinity.podAntiAffinity.requiredDuringSchedulingIgnoredDuringExecution[].labelSelector.matchLabels[<exact-key>]` | 6 | 34 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.affinity.podAntiAffinity.requiredDuringSchedulingIgnoredDuringExecution[].topologyKey` | 6 | 26 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.containers[].env[].valueFrom.configMapKeyRef` | 6 | 30 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.containers[].env[].valueFrom.configMapKeyRef.key` | 6 | 30 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.containers[].env[].valueFrom.configMapKeyRef.name` | 6 | 30 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.containers[].env[].valueFrom.configMapKeyRef.optional` | 6 | 30 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.containers[].env[].valueFrom.fieldRef` | 6 | 35 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.containers[].env[].valueFrom.fieldRef.fieldPath` | 6 | 36 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.containers[].livenessProbe.httpGet` | 8 | 35 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.containers[].livenessProbe.httpGet.path` | 8 | 34 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.containers[].livenessProbe.httpGet.port` | 8 | 36 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.containers[].ports` | 7 | 31 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.containers[].ports[]` | 7 | 31 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.containers[].ports[].containerPort` | 7 | 31 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.containers[].ports[].name` | 7 | 31 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.containers[].ports[].protocol` | 7 | 31 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.containers[].readinessProbe.httpGet` | 8 | 35 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.containers[].readinessProbe.httpGet.path` | 8 | 34 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.containers[].readinessProbe.httpGet.port` | 8 | 36 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.containers[].securityContext.privileged` | 7 | 27 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.containers[].securityContext.seLinuxOptions` | 7 | 27 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.containers[].workingDir` | 6 | 19 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.enableServiceLinks` | 7 | 22 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.hostIPC` | 7 | 24 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.hostNetwork` | 10 | 40 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.nodeSelector` | 6 | 20 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.nodeSelector[<exact-key>]` | 6 | 27 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.priorityClassName` | 6 | 22 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.securityContext.supplementalGroups` | 7 | 28 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.securityContext.sysctls` | 7 | 28 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.shareProcessNamespace` | 7 | 26 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.volumes[].configMap.items` | 8 | 40 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.volumes[].configMap.items[]` | 8 | 38 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.volumes[].configMap.items[].key` | 8 | 38 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.volumes[].configMap.items[].path` | 8 | 38 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.volumes[].configMap.optional` | 7 | 32 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.volumes[].emptyDir.medium` | 7 | 26 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.volumes[].secret.items` | 8 | 40 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.volumes[].secret.items[]` | 8 | 38 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.volumes[].secret.items[].key` | 8 | 38 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.volumes[].secret.items[].path` | 8 | 38 | emitted | PASS |
| `StatefulSet:$.spec.template.spec.volumes[].secret.optional` | 7 | 32 | emitted | PASS |
| `StatefulSet:$.spec.template.metadata.name` | 6 | 13 | emitted | PASS |
| `StatefulSet:$.spec.updateStrategy.rollingUpdate.maxUnavailable` | 6 | 17 | conditional-default | PASS |
| `StatefulSet:$.spec.volumeClaimTemplates[].apiVersion` | 6 | 12 | emitted | PASS |
| `StatefulSet:$.spec.volumeClaimTemplates[].kind` | 6 | 12 | emitted | PASS |
| `StatefulSet:$.spec.volumeClaimTemplates[].metadata.labels` | 6 | 12 | emitted | PASS |
| `StatefulSet:$.spec.volumeClaimTemplates[].metadata.labels[<exact-key>]` | 6 | 12 | emitted | PASS |
| `PodDisruptionBudget:$.spec.maxUnavailable` | 5 | 5 | emitted | PASS |
