# Independent integrated Source review

Verdict: **FAIL** for the targeted documentation-only qualification maintenance correction. Current PV classification, preserved generic detection and actual PATCH identity pass the bounded checks below, but five independently executed loader probes remain false green. No whole A98 gate, AP09 package, publication, live operation or global acceptance is awarded.

Reviewer: `/root/pv_documentation_boundary_integrated_source_fresh`, independent fresh-context Source role, initially and throughout read-only in the repository. I did not design or write this candidate, and did not reuse the earlier design-review identity. Earlier design evidence was context only. Repository HEAD `ebcc04066d42c94b4a4e0fc85e3393dae3d61f78`, branch `docs/documentation-overhaul`, Node `v24.21.0`; worktree already dirty with the candidate and unrelated documentation work (status.txt). No commits or repository edits. Private fixture/evidence writes only.

Exact frozen reviewed candidate hashes:

- scripts/docs-api-output-discovery.mjs: `0a181f5e50339b2d71994dbb94c99cdfc8333856c7711405029a6552cd44dac9`
- scripts/docs-api-producer-adapter-authorities.json: `4b5878506b2a70929cc33349b6441787ecd001b629f9d4400532de2cfc51374f`
- scripts/tests/api-output-publication.test.mjs: `bcad0dacdf44fde1dcfdedba45c8fd86caac305916973022eabbaed893e642a7`

## Applicable authority

Read the full documentation quality standard and AP09 acceptance contract, particularly the approved 10 October product boundary, section 2 negative/current/independent evidence rules, A98-10 recursive selected input/consumer coverage, A98-11 source-to-runtime custody and A98-14 negative mutations. This review applies those requirements to the exact qualified PV exclusion and its maintenance; it does not purport to close all their obligations. A documentation-only exclusion requires actual static metadata/no product API effects plus its real documentation invocation and direct/reverse import graph. A hash alone or a docs filename is insufficient.

## Criteria and evidence

| Exact bounded criterion | Verdict | Evidence and scope |
| --- | --- | --- |
| Exact PV module is pure authored metadata, not a public product producer | PASS | Read scripts/docs-kubernetes-pv-selected-receiver-contracts.mjs in full. Fixed string/link constructors, seven fixed selected paths, one receiverContracts export at line 117, fixed description/case records; no imports, argv/env input, file/network/process effects or API/publisher sink. Qualification binds every AST statement through producerAdapterOperationRecipe (discovery lines 266–277), not only a SHA. |
| Actual documentation authority and selected static direct/reverse paths | PASS | product-scope import line 23, registry join 761–762, productApiReceiverRecords 783; inventory import 20/buildApiResourceInventory 2770; reference import 2/render 113; generate import 14/render 344. boundary.json records four actual reverse graph transfers and five exact package documentation invocations. Current checkout passes qualification and yields no false PV script body. |
| Source and operation invalidation including digest-only refresh | PASS | Independent probes mutate qualified metadata/export/API writer/unknown publisher after successful cached discovery and update SHA only; all reject operation drift. Author tests independently executed too. |
| Standard import/re-export/require and named/aliased createRequire, package alias/publications and doc-edge mutations | PASS | Independent direct/transitive/re-export/require/named import factory probes, package #pv alias, bin/main/conditional exports, non-doc invocation, changed/renamed docs command, removed/changed alias edge, renamed/deleted qualified source all reject after cached successes. |
| Unresolved dynamic consumers and unknown loader changes must fail closed | FAIL | Five valid loader forms below are absent from graph.edges AND graph.dynamicOperations and yield [] without diagnostic. A full unresolved-operation frozen inventory cannot protect operations never collected. |
| Complete cache invalidation for represented graph/source/symlink inputs | PASS | Byte inventory, package bytes and realpaths feed graph.inputKey (line 36); boundary feeds qualificationKey (108). Qualification runs before script cache hit (573). Independently introduced file symlink, directory symlink and qualified module realpath replacement reject after cached baseline. Standard env/argv dynamic import changes reject. This does not repair the unsupported loader forms. |
| Existing generic producer discovery / unknown-output rejection / token cache remain preserved | PASS | candidate.diff against HEAD restores and leaves original generic scanner/role/mutation implementation. Independent generic function API root and docs-named producer remain discovered; docs-command unknown writer fails role qualification. The installer token cache at 1947–1958 still keys text, cwd and sorted complete environment, returns a copy and stores successful parsed copies. It is unchanged in the diff. This is source preservation plus bounded regression evidence, not universal language certification. |
| Actual selected remove-qdrant partial PATCH and all seven selected PV fields remain | PASS | Full checkout script/shell discovery terminal exit 0: 36 scripts, 111 shell contexts, zero false PV script bodies, one actual remove-qdrant PV PATCH. checkout-probe.json records three ordered test guards and add Delete, core/v1 PersistentVolume receiver, JSON PATCH and controlled PVC identity custody; seven fixed receiver paths unchanged. preservation.json proves remove-qdrant, receiver bytes, and entire selected-PV discovery function are byte-identical to HEAD. No live request or deletion ran. |

## Material findings and required correction

**F1 — FAIL, public namespace/default/destructured Node loader consumer is silently accepted.** scripts/docs-api-output-discovery.mjs:51–52 collects only named import factories; requireLoader at 80–83 follows identifiers and only compares a factory call expression text against that set. Property expressions such as module.createRequire are missed. The independent probes add tools/public.mjs after a successful qualification/cache baseline, with these valid Node forms:

```js
import * as module from 'node:module';
const r = module.createRequire(import.meta.url);
r('../scripts/docs-kubernetes-pv-selected-receiver-contracts.mjs');
```

Default import with r(process.argv[2]) and destructured namespace factory with r(process.env.MODULE_PATH) also remain green. Actual discovery returns [] in all three; the graph cannot invalidate the public consumer or newly unresolved runtime loader. loader-runtime-witness.json proves namespace factory loads all seven actual records in this Node environment without product effects.

**F2 — FAIL, tracked require capability invoked through call/apply is silently accepted.** scripts/docs-api-output-discovery.mjs:89 only calls requireLoader on the complete call expression target; r.call/r.apply are property expressions and return false even though r is already a tracked named-import createRequire result. Independent literal r.call(null,'../'+qualified) and runtime-selected r.apply(null,[process.argv[2]]) remain green after cache success. Runtime witness proves call/apply both load all seven records. These are actual public consumer/dynamic transfers, not hypothetical arbitrary JS semantics.

Required correction for F1/F2: identify the standard Node module namespace/default/destructured createRequire capability transfers and call/apply forwarding, resolve their static argument where supported or classify the unsupported/dynamic transfer as an unresolved graph operation and fail qualification. Keep the narrow qualification design and generic producer scanner unchanged. Add negative tests for all five observed forms, exercise cached success then mutation, and obtain fresh independent review of the corrected frozen candidate. Updating source/graph authority hashes to admit these public consumers is not correction.

## Executed and not executed

- `node --test scripts/tests/api-output-publication.test.mjs`: terminal exit 0, 9/9 tests, author-tests.log. This is author-test reproduction, not my sole acceptance evidence.
- `node independent-probes.mjs`: terminal exit 1 because five intended-rejection cases falsely remain green; 33 independent private probes, 28 pass, five fail. independent-probes.json and exact independently authored harness retained. Every mutation follows a successful same-root cached baseline.
- Full current checkout `KUBECLAW_DOCS_GO_BINARY=/home/node/Documents/Codex/a98-evidence/argo-receiver-writer/go/bin/go node checkout-probe.mjs`: terminal exit 0, logs and full actual output retained. Offline producer/AST tool execution only.
- Runtime loader witness: terminal exit 0, pure actual metadata module only, namespace/call/apply each return seven descriptions. No API/cluster/image/product mutation.
- Read full standards, selected module, changed discovery implementation and diff, actual imports/joins/entry authority, selected shell PATCH, current product scope and adapter boundary. Baseline source snapshot retained. The superseded generic compiler rewrite was not treated as the candidate.
- Did not run whole docs configuration gate, publication renderer, upstream PV semantic acceptance, target image, deployment, live cluster authorization/controller/storage behavior, whole AP09 acceptance, or root's separate nine-suite run. Their independent supplied outcomes are not borrowed as my own executed evidence.

Input-hashes.json captures initial tracked scripts/tests, exact untracked candidate test, contracts and package inputs. end-hashes.json and changed-inputs.json capture their terminal state. Full product-root graph-source hashes are also recorded at seal time separately; that later inventory is not falsely described as an initial hash snapshot. Candidate hashes stayed exactly frozen. Artifact manifest binds private evidence files. A green current checkout and nine author tests do not compensate for the five material false-green maintenance mutations.
