# Independent fresh-context Prism SOURCE review

Date: 2026-10-10. Reviewer identity: `/root/a98_prism_diagnosis_source_fresh`. Role: **SOURCE only**; fresh task context; initially read-only. This reviewer did not author the candidate and does not perform Reader or Quality acceptance. Verdict for the assigned source partition: **FAIL**. Two material documentation findings remain. No verdict for the whole AP09.8 package, its machine gates, or live acceptance is granted.

## Candidate and isolation

- Committed product/documentation archive base: `ab4a6ef31c3187c6daebb2d5f36482d1aa0b2e1b` on `docs/documentation-overhaul`.
- Immediately frozen Prism overlay: `docs/site/use/prism-studio.md`, 2,111 lines, SHA-256 `3b774234c53c2b4c846987958932692614a6c402399ae09439d3c37424b17f95`.
- Immediately frozen shared glossary overlay: `docs/site/reference/glossary.md`, SHA-256 `1e9892cc26de4a66b1cf5f5c8d32a68a61348376927c15607ed1579243e49eeb`.
- Exact frozen overlays are retained in `candidate/`; the full Git archive with those overlays is extracted in `review/`. `base-ab4a6ef.tar` preserves the full unmodified archive. `provenance.json` contains its digest and the candidate hashes.
- Product evidence pin independently resolves to `ec2a42ed215a2fa7dbd3172ef70ef446084963a9`. Historical execution pin independently resolves to `082db288f7bc5e686e47306d60cf4db7d8ba8cfc`.
- All 194 GitHub source links in the two candidates were independently checked by reading immutable Git objects. Their 69 unique targets are regular files, their stated ranges are in bounds, and their bytes equal the private committed-base product files. All 69 files also equal the historical pin byte for byte. `source-links.json` and `historical-byte-equality.json` retain the individual results. Additional unlinked authorities `agent-job-routes.ts` and `engine-snapshots.ts` were separately compared with the product pin.
- Byte equality permits inspecting the archive against the pinned claims. It does **not** establish that any historical test ran. The page preserves its historical dates and execution pins; this reviewer did not relabel or independently rerun those old executions.
- No mutable main generator/product module was imported; no main generated output was used as candidate. No main-tree edit, generation, dependency replacement, commit, push, deployment, product repair, full mutation run, browser download, or native attempt occurred. Private harnesses and reports are outside the product tree. The author Quality report was not used as proof.

## Individual assigned criterion partitions

These decisions concern the SOURCE obligations of this candidate only. They do not replace a separate Reader exercise, Quality review, required gate ledger, or actual live product result.

| Criterion | SOURCE verdict | Exact partition and reason |
| --- | --- | --- |
| OPR-010 | **FAIL** | Full Prism/Studio journey: the initial directions and natural-language revision paths omit the mandatory SPIFFE agent boundary; see S2. Other interrupted-action distinctions were checked individually below. |
| A98-02 | **FAIL** | Prism procedure prerequisites/authority and diagnostic explanation: S2 leaves a required journey precondition unstated; S1 leaves retained counter semantics unexplained. Locations, selected-release limit, versions link, bound shell, ordered health calls, owners, retention, and cleanup are otherwise source-consistent. |
| A98-04 | **PASS** | Prism worker process, native initialization, nonce dependency, and functional readiness are distinguished with the implemented exact signals. `/health`, `/bootstrap`, and mode-dependent `/ready` match `worker-service.ts:72–105`; probes do not claim authenticated/native completion. Does not prove actual cluster/service/network readiness. |
| A98-06 | **FAIL** | Prism diagnosis map and worker observations: corrected revision-conflict and Nova-resume stop rules are sound; native/HMAC/lifecycle branches are sound. S1 prevents interpretation of saved counters; S2 leaves the SPIFFE-only agent blocker outside the journey prerequisite/diagnosis path. |
| A98-12 | **FAIL** | Prism journey implementation/status/failure boundaries: individual fixture/local/live classifications, separate human approval, abort, publication, and Nova import are represented honestly; S2 leaves a mode in which design work cannot progress without an explicit unavailable-step boundary. Demo Delivery is outside this review. |
| A98-13 | **FAIL** | Source completeness needed by a fresh technical reader: S1 and S2 require undeclared knowledge. This verdict does not pretend to be the independent Reader role. Two independent live executions remain recommended product validation, not demanded here. |

## S1 — Saved diagnostic counters have no meaning supplied to the reader

**Verdict: FAIL.** Affected page: `docs/site/use/prism-studio.md:1568–1604` (structured log filter), `:1662–1677` (phase/code interpretation). The code preserves `durationMs`, `active`, `open`, and `pending`, and the introduction promises exact counters. The ensuing interpretation explains phases and codes only. None of these four fields has a definition elsewhere on the page or in the glossary.

**Authority at the product pin:** `skills/prism/server/worker-readiness.ts:12–19` declares the diagnostic fields; `:41–48` sets the private pool limit and idle reporting; `:51–55` creates the snapshot; `:59–95` defines admission, connection, cancellation, and query timing and active-operation lifetime. The values are not native attempt counters or a statement of current health.

**Necessary correction:** Add a short source-backed explanation beside the diagnosis table:

- `durationMs` is nonnegative, rounded elapsed milliseconds since this dependency operation began; idle reporting starts its timer when handling that idle error, so it is not the age of the connection.
- `active` is the number of admitted nonce dependency operations at the instant the event is created, before the failing operation's final decrement. The admission limit is four.
- `open` is the pool's `totalCount` snapshot; `pending` is its `waitingCount` snapshot. They concern database pool clients/acquisition, not native scopes or Prism jobs.
- These are event-time snapshots. An isolated nonzero value does not prove a leak, a still-running request, or fresh health; correlate the phase, time, bounded log window, and repeated endpoint result.

The definition should preserve exact field names and link narrowly to the producer. No product change is required. A fresh source/reader recheck must verify the corrected explanation against this producer.

## S2 — The governed Studio journey omits SPIFFE-only agent admission

**Verdict: FAIL.** Affected page: `docs/site/use/prism-studio.md:23–34` (journey prerequisites), `:147–155` (Before You Start), `:271–290` (conditionally active trust settings), `:537–540` (service chart defaults SPIFFE disabled), `:657–730` (initial request/directions), `:860–884` (natural-language revisions), `:1797–1801` (pending-direction diagnosis).

The guide permits determining HMAC or SPIFFE from selected values and treats sidecars/settings as conditional. It does not state that the supported governed agent journey requires SPIFFE even when a HMAC worker can be healthy. A CSI driver registration is a separate prerequisite and does not enable the agent's application trust mode.

**Exact authorities at `ec2a42ed215a2fa7dbd3172ef70ef446084963a9`:**

- [`handleAgentJobs`, `skills/prism/server/agent-job-routes.ts:8–10`](https://github.com/datrab/kubeclaw/blob/ec2a42ed215a2fa7dbd3172ef70ef446084963a9/skills/prism/server/agent-job-routes.ts#L8-L10) rejects the whole internal job route family when SPIFFE is disabled, before body/database work, with `Prism agent jobs require SPIFFE trust`.
- [`skills/prism/server/control-server.ts:243–245`](https://github.com/datrab/kubeclaw/blob/ec2a42ed215a2fa7dbd3172ef70ef446084963a9/skills/prism/server/control-server.ts#L243-L245) rejects design-set commits without SPIFFE and requires the trusted Prism Agent peer.
- [`skills/prism/server/control-server.ts:263–265`](https://github.com/datrab/kubeclaw/blob/ec2a42ed215a2fa7dbd3172ef70ef446084963a9/skills/prism/server/control-server.ts#L263-L265) imposes the same boundary on natural-language revision tool commits.
- `skills/prism/server/agent-job-runner.mjs:27–28` must claim the durable job before external work. `charts/prism/values.yaml:75–84` defaults service SPIFFE to false; the agent overlay separately enables it at `my-values/prism-agent-values.yaml:59–60`.
- The existing contextual architecture already states this at `docs/site/understand/prism-runtime.md:195–206`. That contextual statement does not make the required task precondition visible in this canonical operator procedure.

**Consequence:** A HMAC-mode Control can admit/store the initial design request, and HMAC worker readiness can succeed, while agent claiming and design commits cannot progress. The operator can wait indefinitely at the first-direction step or misdiagnose it only as provider/job delay. Natural-language revisions have the same missing precondition.

**Necessary correction:** Make SPIFFE-enabled Control/agent trust and the exact trusted Agent identity an explicit prerequisite of the governed Studio journey before dispatch. Keep HMAC worker health diagnosis as its own supported boundary. Add the exact agent-mode rejection and the responsible Prism/trust owners to pending-directions diagnosis. If the approved selected release lacks that journey prerequisite, stop before submitting design work, identify that blocked step and the closure check, and preserve original identities if admission already occurred. Do not suggest changing trust mode to clear an active worker error. The release/trust owner must supply a matched configuration and prove agent claim/commit permission separately from health probes.

## Individually checked preservation partitions

All rows below are **PASS for source correspondence**, with no claim that their live or browser path executed in this review.

| Partition | Verdict | Authority and observation |
| --- | --- | --- |
| Architecture dispatch interruption | **PASS** | `stage.ts:20–34`, `control-server.ts:214–230`, `design-generations.ts:25–44`: original run/architecture identity; new architecture is successor work; no uncertain external replay. |
| Session renewal | **PASS** | `control-server.ts:152–172`, `app.tsx:97–126`: new cookies and stable user hash do not reconcile prior writes. |
| Child-round interruption | **PASS** | `design-round-client.ts:8–48`, `app.tsx:124–149,332–348,608–632`: retained request/key, same-generation completion, storage and UI stop limits. |
| Direction selection/rejection | **PASS** | `direction-decisions.ts:14–61`, `app.tsx:277–330`: decision/preference transaction, same user/key/body replay, short client key lifetime, failure-screen limit. |
| Direction feedback | **PASS** | Same decision sources and `control-decisions.test.mts:54–63`: a fresh key records another event; selection alone does not prove separate feedback. |
| Typed-edit interruption and revision conflict | **PASS** | `domain/index.ts:104–113`, `storage/index.ts:262–293`, `app.tsx:161–183`: old base rejects, uncertain committed-first response can look like another-edit conflict, and changing base is new work. Corrected diagnosis follows this distinction. |
| Natural-language revision interruption | **PASS** | `agent-revision-client.ts:6–34`, `app.tsx:124–126,491–499`, `agent-admission.ts:16–23`: original instruction/base/key/job retained; current error/reload UI hides reconciliation; NeedsNova forbids unbound replay. S2 separately affects its prerequisites. |
| Undo/restore interruption | **PASS** | `storage/index.ts:237–260`, `app.tsx:232–248,808–823`: each successful restore makes a new revision and has no durable client retry key; exact source/actor/time/content reconciliation is required. |
| Preference retraction | **PASS** | `app.tsx:250–275`, `preferences.ts:18–28`: each click makes another event; exact recorded wire event alone deduplicates; current UI does not retain it. |
| Evaluation interruption | **PASS** | `app.tsx:406–442`, `control-server.ts:425–453`, `native-operation-store.ts:28–68`: embedded document ID/revision key and exact input/result binding; old warning acceptance and changed revision must not be reused. |
| Human approval interruption | **PASS** | `app.tsx:350–405`, `control-server.ts:521–565`, `001_prism.sql:67–70`: approval precedes publication; digest uniqueness can reject a repeat while preserving the first approval. |
| Baseline publication interruption | **PASS** | `control-server.ts:567–797`: same project/document/approval saved-baseline lookup is a server capability; render/capture and artifact-before-row ordering preserve uncertainty. Studio's Approve action does not replay that request. |
| Nova resume interruption/rejection | **PASS** | `engine-run.ts:84–122`, `engine-snapshots.ts:137–144`: terminal/active-wait checks precede signal recording; identical journal content cannot make resolved waits replay; audit and stop rules preserve original identities. Corrected diagnosis does not authorize arbitrary replacement. |
| Baseline versus Nova import | **PASS** | `control-server.ts:226–240`, `archive.ts:6–88`, `stage.ts:36–39`: publication does not resume; archive bytes/identity/checksums/members are validated, then Nova stores a governed imported JSON artifact with the verified archive and original design request. This is distinct from Prism artifact storage and from human approval. |
| Unconditional CSI requirement | **PASS** | `deploy.sh:974–981,1757–1760` unconditionally checks the named CSI driver. The candidate preserves this regardless of selected trust mode. |
| Fixed build-1228 browser limitation | **PASS** | Both spike configs unconditionally select the fixed path; Studio's config has an existence fallback. The candidate preserves version/build distinction, failed-launch status and aggregate `&&` ordering. No browser preparation or gate success is asserted by this review. |
| Glossary HMAC/nonce | **PASS** | `internal-auth.ts:5–87`, `worker-service.ts:72–86`: shared-secret integrity/authentication versus one-use stored nonce; mode-dependent nonce-table readiness; no human identity claim. |
| Glossary CSRF | **PASS** | `control-server.ts:108–123,152–172`: separate cookie/header matching on session writes; supplement to session/permission authority. |
| Glossary job fence | **PASS** | `agent-jobs.ts:47–53,84–97`: live current claim for new commit; distinct exact committed-result replay with matching digest; no authentication/approval conflation. |
| Glossary ARIA snapshot | **PASS** | `render-operation.ts:118–128`, `control-server.ts:711–734`: separate screenshot/tree capture and bound publication evidence; no complete accessibility guarantee. |
| Worker selector/binding/permissions | **PASS** | `workloads.yaml:5–9,24–36,55–88,127–162`, `install.md:157–235`: correct label/container/port/mode; original cluster shell; one selected Pod/UID; before/after restart comparison; required namespace inspection permissions plus inherited binding access. Actual kubectl parsing and cluster RBAC were not exercised. |
| Worker HTTP and safe log commands | **PASS** | Original health source and lifecycle agree with the bounded exact GET/body checks and failure codes; log field/code allowlist matches the producer. Private fixtures support branch/body/filter behavior, not kubectl/service/network proof. S1 separately affects explaining retained counters. |
| Owner repair, repeat, functional check, retention and cleanup | **PASS** | `native-worker-execution.ts:10–26`, `native-worker-ownership.ts:179–199,244–281`, `worker-readiness.ts:8–10`: no invented manual state repair; owner stop; post-repair UID/reselection, repeated health and separate exact-input functional proof; retained evidence precedes local-directory deletion. Exec uncertainty is not reported as remote cleanup success. |

## Reads performed

Full candidate reads: all 2,111 Prism lines in contiguous chunks and the complete shared glossary. Full quality-standard read: `docs/blueprint/07-documentation-quality-standard.md`. Acceptance contract read, including non-negotiable proof classes and exact A98 criteria; OPR-010, SPC-002/003, CDV-009 and the broader SPC/CDV catalogue context read. Relevant fixture objects read in full: post-documentation product-validation classification, READER-OPERATOR-01–04, READER-QUALITY-01, EXEC-PRISM-JOURNEY, EXEC-DEMO-JOURNEY, EXEC-FAIL-POSTGRESQL. Other fixture/gate families are context only, not accepted here.

Full source reads include Control service/configuration; worker service/readiness/lifecycle/startup/configuration/native execution; internal authentication; agent job routes/jobs/admission/runner; direction decisions, round generations, preference replay; revision storage/domain/artifacts; render capture/evaluation; Studio application and both request clients, preview/assets/flows; Nova Prism stage/importer; baseline archive; Prism workload chart/default values; agent overlay; worker Dockerfile; readiness fixtures and selected interruption fixtures. The complete remaining mobile-sheet tail was also read; its action handlers reuse the checked request paths.

Targeted source reads cover deploy precedence/Secret/release admission/native/CSI/migration/smoke order; common-chart and schema excerpts; identity/SVID settings; Nova CLI and resume validation; command and lockfile/browser-config declarations; relevant historical test source ranges. The link validator's byte/range checks are mechanical evidence only. Contextual reader-page reads include full `understand/prism.md`, agent-route/trust sections of `understand/prism-runtime.md`, the first 180 lines of `extend/platform/prism.md`, install binding/version context, and operate signal-authority/retry rules. No contextual historical prose replaces current product authority.

## Executed checks and honest limits

Environment: Linux container; Node.js `v24.21.0`; GNU Bash `5.3.9` (x86_64 Alpine/musl). Private archive lacks `.git`; review source identity is fixed by the retained Git archive and exact overlays, not by pretending the overlay tree is a clean committed candidate. Cloud runtime instructions were read; no `environment_status` capability was exposed. No remote infrastructure was accessed. The public PostgreSQL 17 error-code page was opened to confirm named SQLSTATE meanings: [PostgreSQL error-code authority](https://www.postgresql.org/docs/17/errcodes-appendix.html).

| Check | Command/result | Retained evidence and limitation |
| --- | --- | --- |
| Candidate freeze | `cp` then `sha256sum`; exit 0, exact requested hashes | `candidate/`, `provenance.json`; proves bytes, not semantics. |
| Private full archive | `git archive ab4a6ef...` extraction and retained `base-ab4a6ef.tar`; exit 0 | Base archive plus exact overlays; main worktree is not the source authority. |
| Pin/range/mode/equality | Independent Python/Git-object verifier; exit 0 | `source-links.json`, `historical-byte-equality.json`; 194 valid links, 69 byte-equal files; no proof of historical execution. |
| Shell syntax | `bash -n` on all 14 exact fenced Bash blocks; all exit 0 | `harness/block-*.bash`; syntax alone is not operational execution. |
| Initial private HTTP harness | `node harness/check.mjs`; exit 1: `EADDRINUSE` on loopback port 8080 | `harness/check-initial-port-conflict.stderr.txt` and `.stdout.txt`; failed attempt retained. No existing listener was changed. |
| Repeated bounded HTTP/filter fixture | `node harness/check.mjs`; exit 0 | `fixture-results.json`, `harness/check.stdout.txt`, `.stderr.txt`; healthy HMAC, native-unready, nonce-failure, healthy SPIFFE/skipped database check, and exact safe-log filter passed. |
| Lifecycle fixture | `node harness/lifecycle.mjs`; exit 0 | `harness/lifecycle.stdout.txt`, `.stderr.txt`; original lifecycle source with synthetic handler/lower limits rejects capacity and returns STOPPING after unsafe result; not native cleanup proof. |
| Agent-mode rejection fixture | `node harness/agent-mode.mjs`; exit 0 | `harness/agent-mode.stdout.txt`, `.stderr.txt`; original agent route with imports redirected to explicit stubs rejects HMAC before body/DB/authentication. Proves this source guard only. |

The worker HTTP fixture preserves original health handler/lifecycle logic in private files. Only dependencies outside the tested health path are explicit stubs; the nonce database result is simulated. After the initial port collision, the exact extracted documentation probe was run with a fetch wrapper mapping its fixed loopback-8080 URL to a private ephemeral port. The probe source itself remains unchanged in `harness/probe.mjs`; `probe-isolated.mjs` records this environment adaptation. Therefore the result proves JavaScript response handling and original route branches, not that the published exec reaches port 8080 in a selected image. The exact log-filter source is retained in `harness/filter.cjs`; the fixture confirms phase/code/counter retention and excludes injected arbitrary credential fields and unknown native messages.

Not executed: live kubectl JSONPath/custom-column selection, auth can-i/RBAC, Pod UID races, installed worker exec/log requests, Service/proxy paths, real PostgreSQL nonce queries/replay, native ownership/journal/attempt execution, actual repair, post-repair functional operation, deployment/render/generator/mutation gates, browser installation/capture/recovery, full local aggregates, or live Studio-to-Nova journey. No result above is substituted for one of those classes. Historical local successes and failed spike executions remain candidate-declared historical records with independently checked source pins/bytes, not newly reproduced results.

Exploratory reads of guessed `wait-signals.ts` and `lifecycle/waits.ts` paths returned missing-file diagnostics; they were not tests and prove no behavior. Follow-up read of actual imported `engine-snapshots.ts:137–144` supplied the signal-validation authority. These navigation failures are not silently treated as successful source reads.

## Separate gate notification from the parent

After this source report was drafted, the parent reported its independent reader-boundary command as terminal **FAIL** on the frozen glossary lines 196, 224, and 248 because of source-inspection bookkeeping. That is a separate gate finding supplied by the parent, not a check executed or accepted by this SOURCE reviewer. It does not change the source-correct definition checks above and must not be hidden by them. No candidate edit was made; both reviewed hashes still match. No global PASS is inferred.

## Freeze release

This review is complete for the stated frozen hashes. The parent may now release its freeze on these two documents. This report and the retained private evidence remain tied to the reviewed bytes. Correct S1 and S2, then obtain the required fresh-context rechecks; no author self-check or unchanged link/hash count closes these findings.
