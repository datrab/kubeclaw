# Frozen core receiving contracts — independent SOURCE review

**Verdict: FAIL.** Reviewed revision: `07d3a25b8afeec5eaacbefe6440a615dfb6b0d65`. This reviewer had no authorship and made no shared repository edits. All work and original upstream downloads are private to this evidence directory. The verdict remains tied to this freeze even if main advances. This is SOURCE evidence only; it grants no Reader, Quality, Astra, CFG-009, A98 gate, or global acceptance.

The independent source/OpenAPI traversal discovers exactly ConfigMap 42, Namespace 49, PVC 89, Service 92: 272 boundaries, no missing or extra identity. The frozen export contains 1467 individually retained cases. Each of the 454 unique cited URL ranges is within independently downloaded original source; all 94 cited file bytes match their independently downloaded recursive Git tree blob SHA-1 and regular file mode. There are 614 distinct URL-plus-caption propositions, rather than 454 distinct captions. The cached OpenAPI bytes exactly equal the original pinned Kubernetes swagger bytes. These facts are mechanical provenance and enumeration PASS, not semantic PASS.

The all-item semantic review remains incomplete: the artifacts explicitly mark every unproved claim, record dimension and case FAIL rather than inventing a universal PASS from source byte verification. This bundle is sufficient to reject closure and contains concrete new source findings, but **does not claim that a full independent semantic inspection of all 614 caption propositions and every record dimension has been completed**. An unproved item is not asserted to be false. This limitation must remain visible if this report is integrated into a completion matrix.

## New findings

### CCF-01 — exact request-map key outcomes still conflate arbitrary keys with storage

Candidate: `scripts/docs-kubernetes-core-receiver-contracts.mjs:120`, qualified later at line 528. Record: `PersistentVolumeClaim:$.spec.resources.requests[<exact-key>]`. Its omitted case says “Without requests.storage the required positive storage check fails”; its zero/null case also unconditionally says requests.storage fails positivity. The immediate case condition is absence/null/empty at **the exact key**, with the parent present. An absent or zero non-storage key leaves an independently supplied positive storage request intact. The added later cross-field qualifier restricts consumer sizing but does not correct these individual outcomes.

Authority: Kubernetes `66452049f3d692768c39c797b21b793dce80314e`, `pkg/apis/core/validation/validation.go:2493-2500`, which reads and validates only `Requests[core.ResourceStorage]` in this branch. Necessary correction: give explicit storage-key and other-key variants for omitted, null, empty/zero and invalid quantities, retaining the exact-key record and prior case names. No storage-specific failure should be inferred merely from an unrelated absent/zero entry.

### CCF-02 — selected conditional SMB route omits volume-attributes provisioning rejection

Candidate: lines 375–425, with `$.spec.volumeAttributesClassName` qualified by the broad source group at line 424. The module documents generic volume-attributes preparation and modification observation but not the actual capability boundary selected by the conditional SMB driver route.

Authority: external-provisioner `986812da302189f395030a72c3099dc7302b4899`, `pkg/controller/controller.go:618-628` selects `requiredCapabilities.modifyVolume` for an enabled, nonempty VolumeAttributesClass; lines 451–456 reject a driver that does not advertise MODIFY_VOLUME. SMB `1bd5463f965be7b173ff1e7fc3c9a3c29972539c`, `pkg/smb/smb.go:187-192` advertises CREATE_DELETE_VOLUME, SINGLE_NODE_MULTI_WRITER, CLONE_VOLUME and EXPAND_VOLUME, **not MODIFY_VOLUME**. Thus a source-qualified SMB provisioning route with an enabled nonempty class has a concrete rejection before CreateVolume, separate from API acceptance and from generic resizer status writers.

Necessary correction: qualify feature/class selection, capability lookup/rejection and the selected SMB restriction at the class record and affected root/consumer records. Add bounded cases. Do not describe this available source gap as an arbitrary later provider or an unimplemented product waiver. Independently qualify later modification startup, RPC handling and its selected driver if modification is claimed.

### CCF-03 — PVC retirement stops before available reclaim/deletion consumers

Candidate: lines 552–554 explains PVC protection and correctly says removing it does not execute PV reclaim or server-data deletion. It does not continue the available selected consumer path. The current conditional SMB route has source for this handoff; “application recovery” being open does not replace the reclaim obligation.

Authority: Kubernetes `pkg/controller/volume/persistentvolume/pv_controller.go:663-690` detects the absent claim, records Released and invokes reclaim; lines 1180–1223 distinguish Retain, Recycle, Delete and unknown policy. External-provisioner `pkg/controller/controller.go:1247-1311` resolves CSI identity, capabilities, deletion secrets, deadline and attachment guard before DeleteVolume; lines 1383–1405 reject deletion while a matching VolumeAttachment remains. SMB `pkg/smb/controllerserver.go:150-263` validates/locks the volume, selects configured onDelete behavior, and performs retain, archive or removal. In particular, absent secrets or retain policy returns success without deleting the subdirectory; malformed parsed IDs can also return success. Archive/removal failures and post-operation unmount logging are distinct outcomes.

Necessary correction: preserve PVC-protection explanation and extend its deletion/recovery contract to PV policy and external-driver deletion, including identity/preconditions, retries, secrets, locks, retain/archive/remove and partial state. Keep data-integrity and application recovery proof separate. Actual PV policy/driver and SMB onDelete values must be observed; no driver or deletion policy is inferred from empty chart class defaults.

### CCF-04 — ConfigMap has an authored case for an unavailable status/finalize route

Candidate: line 343 adds `subresource-ignores-authored-ownership` to every kind’s `$.metadata.managedFields`; ConfigMap therefore has a case conditioned on “A status or Namespace finalize update”. Its actual storage route has neither subresource. Kubernetes `pkg/registry/core/configmap/storage/storage.go:37-58` creates only its ordinary store; the frozen module’s own `routes.ConfigMap` also states there is no status route.

Necessary correction: preserve the existing case identity if required, but explicitly qualify operation applicability for each resource. For ConfigMap, the case must establish the unsupported route rather than report field-manager behavior at a route it does not expose. Namespace finalize must be scoped to Namespace; PVC/Service status to their actual status routes. A common mechanism’s correctness does not establish its installation for every kind.

### CCF-05 — GC orphan policy selection lacks the actual orphan-worker contract

Candidate: core lines 319/350 imports ownership and deletion mechanisms. `scripts/docs-kubernetes-metadata-receiver-contracts.mjs:38-40`, `:54` and `:149` establish propagation selection and deletion decisions, but do not qualify the orphan worker after policy selection.

Authority: Kubernetes `pkg/controller/garbagecollector/garbagecollector.go:673-708`, `:716-766`. The worker snapshots graph-known dependents under the graph lock, concurrently removes the specific owner UID from their ownerReferences with the dependent UID as a precondition, tolerates NotFound and aggregates other patch failures. An aggregate failure returns before removing the owner orphan finalizer, leaving a partial set of already patched dependents; the queue rate-limits a retry. Only after successful dependent patches does it attempt to remove the owner token, and that failure also retries. This sequence and its graph boundary are separate from selecting the orphan token.

Necessary correction: qualify the shared canonical mechanism with the orphan worker’s identity, graph snapshot, concurrency, partial-patch and finalizer-removal/retry behavior, then retain the core strategy/scope overrides. Add individual cases without removing previous identities. An owner disappearing does not itself prove that every dependent outside the observed graph was orphaned, and a policy-selection source range does not prove completion of this operation.

## Current selection and open applicability

Read-only discovery used actual charts, GitOps bootstrap/value files, my-values and source consumers. `gitops/platform/bootstrap/csi-driver-smb.yaml:15` selects chart 1.20.0; its values only set controller replicas. This supplies a selected **installation candidate**, not proof that each delivered PVC uses SMB. Delivered chart storageClass defaults are empty. KubeClaw PVC templates omit storageClassName in that branch (`charts/kubeclaw/values.yaml:283`, `:288`, `:544`; corresponding PVC templates), permitting unresolved cluster-default selection. Prism and Ops templates instead emit storageClassName: "" and request classless binding; they do not select the cluster default. `my-values/infra/postgresql-recovery.yaml:12` is null and its renderer omits the class. `my-values/infra/registry-local.yaml:11` is the unresolved required placeholder. No concrete default StorageClass object/provisioner association was discovered in these authored current surfaces. The default-class driver contract is therefore unresolved for current delivered claims, not N/A.

`my-values/infra/cilium-values.yaml:27` selects kubeProxyReplacement false. This supports retaining kube-proxy for that migration configuration; it does not select an exact deployed mode/version. The pinned iptables/IPVS/nftables source branches are conditional source contracts. Their actual selection remains an observation/configuration obligation. No actual DNS deployment/image selection was derived from current code/charts/config; the Kubernetes upstream addon’s CoreDNS image cannot stand in for that selection. Likewise the authored Service chart surface defaults to internal Service types and exposes type overrides, but no concrete load-balancer class or cloud provider was discovered. Arbitrary unselected LB extensions do not create an infinite-provider proof obligation. The actual provider/class contract remains OPEN when a delivered override or environment selects it; existing available-source markers remain open and no effect is accepted from the default cloud interface alone.

Custom populator, non-SMB snapshot driver/controller and application recovery remain OPEN where selected. SMB’s concrete unsupported snapshot path is source-backed, but does not waive another actual driver. Selected load-balancer provider/class/condition writer remains OPEN. No source marker was removed. Unknown current default driver/DNS/dataplane/provider selection is not silently reclassified as an arbitrary unselected extension.

## Verification and scope limits

Executed on Node 24.21.0, Python 3.14.8, Git 2.54.0, Linux x86_64:

- Syntax: exit 0.
- Actual focused coverage/reference tests: exit 0, 12 passed, none skipped.
- Independent original OpenAPI traversal/cached byte comparison/Git blob/range checks: exit 0, counts above.
- Actual configuration inventory check: exit 1, `DOC_DRIFT_CONFIG` for configuration-values.json and configuration-runtime-inputs.json. This is not waived.
- Actual generator check in the private clean frozen Git checkout: exit 1, source lock `6fa4830a48244d29655104a5be58957d5fa87d2f` does not match the freeze’s source tree. This preserves the source-lock F05 obligation. An initial archive-only check failed because no Git commit was available; a private Git object alternate plus frozen HEAD corrected the harness and the clean rerun still fails the real lock. The dependency symlink is excluded only in private `.git/info/exclude`; frozen tracked files remain unmodified.
- AP09 acceptance-structure check: exit 0, 89 points/261 catalogue requirements/122 fixtures, `evidenceValidated:false`. This is not gate acceptance.

No official frozen CFG-009/A98-14 fixture mutation run, Reader exercise, publication renderer check, controlled-language/architecture review, API/SSA conflict, admission authorization, GC/controller reconcile, mount, network/DNS, storage population/resize/reclaim, backup or restore operation was performed. Source bytes do not establish those results. Binding quality07/acceptance rules and the relevant CFG-009/A98-10/A98-11/A98-14/execution/fixture scope were inspected; this report does not certify an exhaustive semantic reading of every unrelated execution-plan/fixture section.

Bounded schema identity and source provenance: PASS. Complete receiving-contract semantic proof: FAIL. Whole CFG-009: FAIL. A98-10/A98-11 complete source partition: FAIL. A98-14 official frozen mutation proof: FAIL (not executed). No lower evidence class substitutes for a missing gate.

`records.json` preserves the entire actual export; `individual-verdicts.json` and `case-verdicts.json` enumerate every record/dimension/case with a binary verdict and reason. `schema-discovery.json` is independent traversal, `sources.json` records original file identities, `ranges.json` retains exact original excerpts and range verdicts, and `captions.json` retains all 614 caption propositions without blanket semantic approval. The complete original archives and recursive trees are independently retained. `artifact-manifest.json` seals the report, scripts, exact export, logs, verdicts, source identities, original archives and tree replies. Author evidence was used only as navigation.
