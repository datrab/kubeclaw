# Complete GNU working-copy correction: author evidence

Author correction and bounded local execution only. No independent Source, Reader, Quality, package, global-gate, deployment or live approval is claimed.

Exclusive edits: `docs/site/use/install.md` and `docs/site/use/worker-trust.md`. The previous frozen author evidence and fresh Source FAIL report remain unchanged in their original directories. Read the complete new Source report, retained GNU v9.4 copy/cp source authorities and actual uid-1000 EACCES reproduction before correction. No product change, shared generator edit, host package install, cluster operation, key-file read, commit or push was performed.

## Complete correction

A shared `probe_working_copy` now publishes each latest file through a unique private staging file. It requires a regular non-symlink source, rejects directory/symlink destinations, copies into the new writable staging file, explicitly sets staging mode 0600, checks the destination again, then uses `mv -f -T` to publish at that exact path. Every allocation, copy, mode change and rename propagates failure. Force suppresses an interactive readonly-destination prompt; it does not bypass the directory/symlink checks. A failed staging file remains retained with its incomplete attempt. Exclusive evidence-directory ownership is an explicit prerequisite because path checks cannot prevent a competing writer.

All three observer working-file outputs use this helper after original receipt sealing. The capture working-file snapshot and cleanup-clearance copy use the same exact-path publication mechanism. The capture loop also rejects unexpected source symlinks. Snapshot directories are sealed only after their required copies/index writes succeed. Existing working-log removal, terminal output, local status/identity errors, command-exit versus retention-status distinctions and incomplete-capture cleanup stops remain guarded. Historical observation/capture files remain read-only; latest copies remain writable and can refresh repeatedly. No historical permission was weakened.

The creating provenance family is unchanged in meaning: separate single-object authenticated Namespace/PVC/Pod CREATE JSON responses, strict validation and read-only original UIDs; later name reads never supply original provenance. Owner-enforced exclusion permits original owned creation/provisioning/initial binding but blocks competing replacement/writes through final API/provider disposition. Original namespace and PVC checks precede dependent mutations. Pending/new bindings need fresh authenticated clearance; UID DELETE does not freeze later namespace membership/provider operations. Unknown identity still requires owned audit reconciliation, rather than generic adoption.

Worker Trust's direct TLS implementation range now selects lines 43–55 of the unchanged pinned script. Those lines contain both `request.on("error",...)` and `request.on("timeout",...)`. The wrong-SVID commands remain correctly linked at lines 146 and 182. Checked the other linked range bodies and retained all 57 complete-file-equal pinned product references with selected excerpts. Existing timeout/5xx ambiguity, reachable positive controls, genuine receiver rejection, signing, lifecycle, pre-first-mutation and retained-resource gates remain explicit.

## Native GNU tooling and original-defect reproduction

Actual GNU coreutils 9.1 `cp` and `mv` executables were extracted privately from Debian's official HTTPS package pool. Their Debian libc and dependent libraries were also extracted beneath this evidence directory. Scoped subprocess PATH wrappers invoke the private loader and exact executables; host tools and libraries were not installed or replaced. Package bytes, wrapper bodies, ELF/library bytes, version output, loaded-library paths and uid 1000 are bound by the manifest and `gnu-tool-provenance.json`.

This is native GNU executable evidence, not a Python/GNU-open model. It is GNU **9.1**, not native GNU 9.4 or an Ubuntu cluster run. GNU 9.4 remains separately source-qualified by the review's retained upstream source. The privately loaded cp 9.1 also reproduces the original exact observer defect: first latest file mode 0400; second actual cp reports Permission denied; actual remote command exit remains 0 while retention returns 1. The corrected full family succeeds with the same native executable. Initial extraction/library-bootstrap attempts encountered a rejected absolute package symlink and missing private dependencies; those attempts were resolved before native verification and are not presented as successful tests.

Official package sources were `deb.debian.org/debian/pool/main/c/coreutils/`, `.../g/glibc/`, `.../libs/libselinux/`, `.../p/pcre2/`, `.../a/acl/` and `.../a/attr/`. Exact filenames and SHA-256 values are in the artifact manifest. Package extraction accepts regular files/directories and bounded relative symlinks; the absolute loader symlink was omitted. No package-signature or full distribution compatibility qualification is claimed.

## Executed complete final families

Both final runs reached terminal status: native BusyBox host cp/mv in `final2/`, and actual private native GNU 9.1 cp/mv in `gnu-final2/`. `busybox-receipts.json` and `gnu2-receipts.json` retain terminal timestamps/exits; individual controls retain command bodies and raw stdout/stderr. Earlier new-directory iterations are preserved separately, not substituted for final extraction.

For **each** native tool path, final exact extracted controls passed:

- All 24 assigned Bash fences syntax checks and the exact whole observer/CREATE/run/capture blocks.
- Thirteen positive/ordinary/List/denied/replacement creating-flow cases and twelve empty/malformed/missing/partial-response cases. Failed or invalid responses do not establish creating UIDs.
- Thirteen original local capture failure cases, plus output-open, exit-write and unexpected working-directory controls. Actual command exits remain distinct from retention failure.
- Nine denied observations (namespace/Pod/PVC/StorageClass/PV/events/logs/namespace-after/PV-after) followed by nine repaired reads; all historical stdout/stderr/exit hashes remain unchanged and all 18 observations remain sealed.
- Original/success/failure observer-history preservation and copy-failure controls.
- Exact positive clearance-schema cleanup with one original-UID DELETE body, simulated namespace/PV absence; three replacement and three unknown-original cleanup guards exit nonzero before DELETE.
- Working destinations explicitly changed to 0400, then three successful refreshes; latest file/output/stderr/exit modes become 0600 while prior sealed hashes remain unchanged.
- Existing/dangling destination symlink and directory rejection; non-symlink source validation; observer rename failure; full-capture rename and source-symlink failures. Unrelated symlink referents remain unchanged and capture stays failed.
- Explicit staging temp/copy/mode failures preserve the sealed source and prior working destination.
- Two full captures followed by the exact cleanup recapture and **three** PV-after poll results at the same working filename, finishing absent. No polling refresh was skipped.
- Private native kubectl v1.34.11 single-object Namespace/PVC/Pod CREATE calls retained server UIDs/kind/name/namespace. This loopback HTTP fixture disables validation only for its bounded PVC/Pod clients; published commands retain default validation. No real API/authentication/admission/storage result is claimed.

Additionally, 30 fresh strict CREATE validator controls passed for all three kinds (valid, wrong kind/name/namespace/version, empty/numeric UID, deletion timestamp, List and array). All five exact Node heredoc bodies passed Node syntax. Fifty-seven pinned references passed whole-file byte equality/range bounds; the direct-TLS error and timeout handlers were explicitly checked within the new selected range. Fifty-three local links/routes/anchors passed the repository's shared Markdown parser/anchor implementation. All final fence bodies equal both final native extraction directories.

Fresh `npm run verify:worker-core:trust` and `npm run docs:operator-tasks:check` both exited 0. Full logs and durable terminal receipts are retained. Scoped `git diff --check` exited 0. The actual publication check exited 1 for other-page/generated-catalogue findings; it named neither assigned page. This global FAIL remains a FAIL, not an approval.

## Limits and remaining acceptance

These are local command contracts with synthetic API/storage responses and clearances, plus real native file tools and a real private kubectl caller. They do not establish externally enforced ownership, authenticated real owner approval, actual Kubernetes/provisioner execution, provider disposition, signing-owner provisioning, production receipt, installed trust denial, runtime release selection, live installation or maintenance, browser publication, Reader/Quality/Astra or global configuration qualification. GNU 9.4 native execution remains unexecuted. Unavailable product paths and their pre-mutation stops remain intact.

Controlled-language method: full assigned prose/command-family review, direct sentences and explicit conditions, exact technical terminology, actual publication findings and semantic source-range inspection. No formal ASD-STE100 certification is claimed. Fresh independent complete Source/Reader/Quality review is still required. The older Source FAILs remain tied to their frozen revisions.

Final page hashes, current source/tool/governance inputs, old report/manifest authority, private package/executable/control bytes and every retained artifact are bound by `manifest.json`. The final page copies are retained under `final-source/`.
