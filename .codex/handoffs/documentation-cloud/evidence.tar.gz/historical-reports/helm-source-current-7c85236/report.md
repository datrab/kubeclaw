# Fresh Source review: CFG-009 Helm/GitOps/infrastructure

Verdict: **FAIL for CFG-009 and the Helm/GitOps partitions of A98-10 and A98-11.** This is an independent Source review. It is neither a Reader review nor a Quality review. It does not certify either whole A98 gate. Unread semantic authorities and unexecuted acceptance fixtures remain **UNPROVEN**, which is not an acceptance PASS.

Reviewed repository: `/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04`. Reviewed revision: `7c85236b9a1992466ceb33b64f657062be57b4dd`. Documented source lock: `1c0c780211a98fd2ebf9beffb1ace937fe079c04`. This report retains that identity after unrelated root commits. The isolated `snapshot/` was made with `git archive HEAD` while HEAD was 7c. Its node_modules link uses the installed dependency tree. Helm is host `v3.22.0+g144ca65`; Node is `v24.21.0`. No network, live Kubernetes operations, repository generation, repairs, or full mutation restart were performed. All synthetic overrides and output are outside the repository.

`frozen-scope-manifest.json` records exact SHA-256 and byte size for 165 scope files, their equality with the reviewed Git commit, and their equality with the main tree at sealing. All comparisons passed after fixing the evidence script's initial default subprocess buffer limit. Main-tree review files were explicitly released to root after this seal. Later repairs require fresh evidence; they cannot alter this original result.

## Requirement and gate partitions

| Requirement | Partition | Verdict | Evidence and boundary |
| --- | --- | --- | --- |
| CFG-009 | Assigned Helm, GitOps, infrastructure values | FAIL | Collections absent from canonical publication; directly disproved allowed/empty forms. All meaningful fields are not independently semantically closed. |
| A98-10, contract line 265 | Helm/GitOps recursive inventory with type, required state, default, limits, owner, consumer | FAIL | 1,613 nonroot array/object nodes are mechanically present in the JSON inventory but absent from the page, with blanket structural semantics. Independent array/list contracts are demonstrably meaningful. |
| A98-11, contract line 266 | Helm/GitOps authored input to effective receiver; conflict, empty, Secret, invalid cases | FAIL | Empty URL and mounted policy descriptions contradict rendered results. Prism allowed forms contradict schema. Empty arrays, empty maps and null have different effective merge results. Twenty bounded render assertions were executed; this is not every field/variant. |
| A98-14, contract line 269 | Registered Helm-field documentation-drift fixture | UNPROVEN | Official registered mutation runner not executed in frozen snapshot. The frozen all-inventory baseline fails because the Git archive lacks seven ignored generated observer inputs. Own render mutations do not replace the registered drift fixture. Root's newer corrected run is separate evidence. |
| Quality standard Correctness | Reviewed Helm claims | FAIL | Findings H2–H5 reproduce contradictions against local implementation. |
| Quality standard Depth | Recursive options, consequences, empty values | FAIL | H1 omits independently meaningful collection contracts; generic leaf prose cannot supply them. |
| Quality standard Maintenance | Helm generation/semantic authority chain | FAIL | Generator permanently filters collection rows and authority loader treats collections as structural; wrong empty/accepted behavior is copied from local authority prose into generated output. Byte-pinned prose is not validated semantic correctness. |
| Quality standard References | All scope source links and published code display | UNPROVEN | Selected local receivers resolve and source hashes are preserved; every link and deployed published view was not independently opened/checked. |
| Quality standard Operations | Current Helm change consequences | FAIL in reviewed partition | Wrong empty/accepted forms cause a different render or an early render failure, before the promised consumer behavior. Complete operator lifecycle procedures are outside this Source assignment. |
| Quality standard Reasons | Significant source decision reasons | UNPROVEN | Source mechanism was checked; every decision reason was not. |
| Readability, Controlled language | Reader/Quality exercises | UNPROVEN | Not this reviewer's role; no semantic source inspection is substituted for these reviews. |
| Extensions | Clean-environment extension exercise | Not applicable to this partition | No extension exercise claimed. |
| Truthful status | This review's evidence classification | PASS, narrowly | Failed checks, local renders, skipped fixtures, incomplete manual reading and absence of live validation are explicit. This does not certify authored status pages. |

The standard at `docs/blueprint/07-documentation-quality-standard.md:204–220` requires every applicable gate, and expressly rejects green builds/counts/headings as completeness evidence. The catalogue's historical “at least 28 sources” (`docs/blueprint/generated/ap09-catalogue.json:1990–2004`; audit line 284) was not used as a discovery ceiling. Independent filesystem traversal found all 67 currently selected authored YAML sources, agreeing with the source inventory. `dynamic-discovery.json` lists every selected source plus excluded chart template/payload YAML. This PASS is solely source-path closure within the five declared Helm/GitOps/My-values/example/release input roots, not whole configuration-source closure or semantic closure.

## Findings

### H1 — Collection contracts are discarded, including empty collections

`scripts/docs-generate.mjs:396–400` filters every nonroot object/array from the canonical value reference. `scripts/docs-configuration-inventory.mjs:1886–1892` assigns structural containers no independent value, failure, runtime owner, precedence or constraints; line 2072 assigns blanket “Child leaf rows define configurable behavior”; line 2190 declines semantic authority for collections. Leaf discovery at 999 onwards descends into populated containers; empty containers cannot contribute child rows.

`collection-loss.json` and the compact `collection-loss.tsv` enumerate **every** omitted node by exact source, YAML document, canonical path, source line, array/object type, empty/nonempty state, direct entry count and scalar descendant count. The artifact also retains generated consumer links with an explicit warning that these links are not independent semantic proof. There are **1,613 nonroot collections: 35 empty and 1,578 nonempty. All 1,613 exact rows are absent from their corresponding source section**. These are mechanical losses, not a claim that all 1,613 require independent options; some envelopes are properly structural. The defect is blanket removal without deciding or documenting independent collection semantics.

Independently established effects include:

- `charts/gitops/values.yaml:6–9`: `groups: []`, `destinations: []`, and both resource whitelists are absent. `templates/applications.yaml:5` rejects empty groups. Supplying a group and destination creates an Argo CD Application and namespace destination; the template forwards whitelist collections. No child row can describe the empty default or minimum group requirement.
- `charts/kubeclaw/values.yaml:512,518–521`: customSkills, nodeSelector, tolerations, annotations and extraEnv have active template effects. `templates/deployment.yaml:38,1393,1655–1663` adds annotations/env/scheduling; `templates/configmap-skills.yaml:12` emits custom skill content. Own synthetic populated render proves these outputs. Ordered overlays prove `extraEnv: []` replaces earlier entries, `nodeSelector: {}` retains earlier keys, and `nodeSelector: null` removes the earlier mapping. Generic “later value wins” does not explain the different results.
- `charts/prism/values.schema.json:94–109` requires nonempty `imagePullSecrets` with named items. Explicit `[]` fails schema with `minItems: got 0, want 1`; normal CI values succeed. The scalar `imagePullSecrets[0].name` row cannot express the array minimum. `control.productDecisions.operators` at schema lines 141–150 additionally has uniqueItems and maximum 100; enabling the decision mode has further conditional minimum constraints. Those collection constraints are not child scalar semantics. This review has not executed every decision-mode variant.
- Empty infrastructure collections, including NetworkPolicy empty selectors, Cilium ingress/egress, K3s registry mappings and SPIRE namespace selectors, are included exactly in the loss artifact. Their API/controller meaning must be evaluated individually. This review does not certify every such runtime effect from leaf rows or generic versioned schema labels.

The 35 empty collections are separately enumerable with `rows.filter(r => r.empty)`; the TSV marks them without hiding populated collection losses. `configuration-precedence.md` is a useful generic description, but its Helm defaults/files/CLI explanation does not close array replacement, recursive map merge and null removal as independent collection behavior.

### H2 — GitOps revision accepts more in docs than the chart accepts

`docs/site/reference/helm-values.md:117` describes `$.revision` as a Git revision resolvable by the source repository. `scripts/docs-local-helm-field-authorities.json:200–206` supplies the same authority prose. `charts/gitops/templates/applications.yaml:3` instead requires exactly 40 lowercase hexadecimal characters and fails with `revision must be a complete Git commit`; `scripts/gitops.mjs:45` also validates complete commits.

With otherwise identical synthetic group/destination inputs, a 40-hex revision renders successfully; `revision=main` exits 1. The artifact does not claim the synthetic SHA exists in a real Git repository. The contradiction is local accepted form and early Helm rejection.

### H3 — Empty configuration documents restore checked-in files

`docs/site/reference/helm-values.md:210` (`$.eslintConfigMjs`), line 297 (`$.semgrepConfigYaml`) and line 313 (`$.swarmConfigJson`) say empty removes the selected tool/swarm policy. Local authority ranges `10511–10517`, `18308–18314`, `20004–20010` repeat that claim.

`charts/kubeclaw/templates/configmap-swarm-config.yaml:11–26` branches on Helm truthiness: an empty value loads `.Files.Get` for each checked-in policy/config file. The independent explicit-empty render compared all three ConfigMap payloads byte-for-byte after trailing newline normalization to their source files; all are retained. The proof ends at rendered ConfigMap content. It does not claim a running pod or persisted init-state policy update occurred.

### H4 — Empty gateway URL selects local fallback

`docs/site/reference/helm-values.md:226` says empty `$.gateway.url` disables the integration or leaves it without a destination; local authority range `11509–11515` repeats it. `charts/kubeclaw/templates/deployment.yaml:1297` uses Helm `default` to select `http://127.0.0.1:<gateway.port>`. Explicit empty with port 19003 produces `OPENCLAW_GATEWAY_URL=http://127.0.0.1:19003` in the rendered container env. No runtime connection attempt is claimed.

### H5 — Prism pullPolicy allowed/empty rules contradict checked-in schema

`docs/site/reference/helm-values.md:444,447,450,453` and Prism overlay rows `3091,3094,3097,3100` advertise `Always`, `IfNotPresent`, `Never`, and describe empty as allowing Kubernetes to derive the policy. `charts/prism/values.schema.json:7–10,21–25` requires pullPolicy and allows **only IfNotPresent or Never**. Its four image references are at lines 79–89. `charts/prism/templates/workloads.yaml:74` passes the selected policy into the workload only after validation.

Eight independent renders cover Always and explicit empty for each of control, ingestion, studio, worker. Every one exits 1 with the same schema enum restriction, before any Kubernetes policy derivation. CI baseline renders successfully. The values authority for these fields is therefore not sufficient proof despite source/range digests.

## Executed checks and actual outcomes

All render commands are preserved as tokenized exact argv in `render-results.json` (14 cases) and `collection-precedence-results.json` (6 cases), with stdout/stderr files. No shell interpolation or live Secret was used. A render returning 1 is a successfully asserted expected negative result, not a successful deployment.

| Command or operation | Location | Result |
| --- | --- | --- |
| `git rev-parse HEAD`; `git status --short`; targeted `git diff --name-only 1c0c780... HEAD -- ...` | Main repository, before unrelated root changes | Initial reviewed HEAD and clean worktree confirmed. Source/generator scope unchanged since documented lock; generated Helm page is newer. |
| `git archive HEAD` piped to tar in external snapshot | Main read; external write | Snapshot of reviewed 7c created; no repository modification. |
| `helm version --short`; `node --version`; executable checks | Host | Helm 3.22.0, Node 24.21.0. OpenSSL unavailable at checked boundary; no TLS/live tests attempted. |
| `node scripts/check-local-helm-boolean-semantics.mjs` | Snapshot | Exit 0; 93 Boolean authorities/control renders passed. Log retained. This establishes the checker assertions, not all prose correctness. |
| `node scripts/docs-configuration-inventory.mjs --check` | Snapshot | Exit 1: only `configuration-runtime-inputs.json` stale. Log retained. |
| `node scripts/docs-configuration-inventory.mjs --out-dir ../regenerated` | Snapshot; external output directory | Exit 0. Regenerated configuration-values and configuration-schemas are byte-identical to frozen outputs. Runtime inventory differs. |
| Missing ignored/generated observer inputs comparison | Main tracked-file reads and snapshot JSON comparisons | Seven canonical observer `src/generated/agent-observability/*.ts` inputs are absent from Git archive, present in original inventory discovery. Artifact `runtime-inventory-difference.json` retains actual differences. No Helm semantic failure is inferred from this unrelated input generation boundary. |
| `node ../probe.mjs` (final run) | Snapshot | Exit 0; 14 independently asserted cases. `probe-rerun2.log` retained. Initial run failed a harness regex for the current Helm schema error; second failed because namespace was not made explicit. Both were corrected in the outside-repo harness, retaining initial logs. These are harness setup failures, not extra product findings. |
| `node collection-precedence.mjs` | Evidence directory; snapshot Helm cwd | Exit 0; 6 cases. Ordered YAML files are retained; explicit namespace default. |
| `node seal-evidence.mjs` | Evidence directory | Exit 0. Independent dynamic discovery source closure; per-section missing collection rows; reviewed/main hashes; regenerated output comparisons. Initial git-show hash probe exceeded default subprocess buffer for six large files; setting a bounded 200 MiB buffer produced exact reviewed-commit agreement. |

The 20 render cases cover empty/nonempty collections, required group failure, complete versus branch revision, synthetic existing-Secret name/key reference, repeated CLI scalar precedence, ordered YAML map/list/null precedence, schema rejection, policy-file fallback and URL fallback. The synthetic Secret render proves reference name/key selection and absence of generated Secret; it does not prove a Secret exists, that its key is populated, or pod readiness. Expected existingSecret selection is bounded by template output. No API admission, Argo CD reconciliation, resource rollout, runtime load, credential validity, external chart live behavior, persistence restart, rollback or cluster recovery was executed.

Official frozen `docs:drift:config:mutations` was skipped: root requested no full mutation restart and the isolated baseline lacks required ignored generated observer inputs. These own local render cases are semantic evidence, not registered documentation-drift fixture evidence. Newer root-run evidence must be appended with its own revision and results. No gate was weakened to turn the frozen baseline failure or skipped fixture into PASS.

## Manual reading and unread boundaries

`manual-read-coverage.json` is the path-level record. All 67 discovered authored YAML sources were manually read completely, recursively parsed mechanically, and SHA-pinned. The full quality standard, acceptance contract and fixtures were read; CFG-009 and the assigned contract/plan sections were read. The two compact precedence/change-impact pages and the full 790-line docs generator were read. Selected local receiver/helpers/schema/API authority scripts were read as recorded.

The canonical 5,126-line Helm page was **not** manually read in full. Its complete bytes and source sections were parsed for collection-row publication, and its introductory coverage plus selected reproduced rows were manually read. The 6,716-line configuration inventory generator was **not** manually read in full: the Helm discovery, value-tree, consumer, authority, semantics, publication-relevant and main output portions were inspected, with exact conservative ranges in the coverage artifact. Portions that yielded truncated tool output are marked partial. The 96,193-line local field-authority registry was mechanically consumed and selected conflicting authorities read, not completely manually reviewed. The external snapshot registry, vendor/external chart logic, some YAML-authority registrations, full deployment/init loaders and all remaining consumer variations are likewise unclosed.

This is a completed independent **FAIL report with bounded evidence**, not a completed positive exhaustive semantic review. The outstanding reading is not silently satisfied by parser traversal, source hashes, source counts, Boolean regex assertions or successful freshness. No reviewer should reuse this identity for Reader or Quality acceptance of the same package. Parent may assign fresh corrective authors and later fresh reviewers; this reviewer made no repair.

## Artifact index

- `frozen-scope-manifest.json`: reviewed commit, documented lock, main head at seal, file hashes and equality checks.
- `snapshot/`: immutable review snapshot retained outside the repository.
- `dynamic-discovery.json`: recursively discovered sources and consumer/payload YAML separation.
- `collection-loss.json`, `collection-loss.tsv`: every omitted map/list with exact path/line/document and empty/nonempty status.
- `discovered-source-hashes.json`: every authored YAML source hash and document count.
- `probe.mjs`, `collection-precedence.mjs`, their exact result JSON and generated YAML/error files: independently reproducible local probes.
- `boolean-semantics.log`, `inventory-freshness.log`, `regenerated/`, `runtime-inventory-difference.json`: executed checker outcomes and isolated reproduction boundary.
- `manual-read-coverage.json`: full/partial/mechanical/unread declarations.
- `artifact-index.json`: content hashes for evidence artifacts (excluding self and snapshot dependency link).
