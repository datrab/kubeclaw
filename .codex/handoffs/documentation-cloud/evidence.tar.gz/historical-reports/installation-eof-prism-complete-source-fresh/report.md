# Independent SOURCE review — complete frozen installation batch

Verdict: **FAIL**. Reviewer identity: installation_eof_prism_complete_source_fresh. Fresh-context, independent SOURCE role; repository read-only throughout. No Reader, Quality, package, Astra, live, or global approval is issued.

Repository: `/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04`, branch `docs/documentation-overhaul`, HEAD `8c22254ea6cc3f6e98e3e453f2ff91c8ec4eba32`. The evaluated pages are the frozen working-tree snapshots, not falsely represented as clean HEAD:

- `docs/site/use/install.md`: 72633 bytes, SHA-256 `319cf8f7890060422c28246e7467269f97ddb3bed3685609bd8ed855dc28da67`.
- `docs/site/use/maintenance.md`: 76654 bytes, SHA-256 `70647b0073ea349545f3633a51f9c5a5553ea6c6850fd2858ca713dd0040e8ce`.

Root later committed matrix-only `2a8558d795054d25aa4b72dbdc296c9321ba38f6`; this unrelated bookkeeping does not alter the initial HEAD/frozen-byte review binding or grant acceptance. Final HEAD custody is retained in `head-custody.json`. All 34 initially snapshotted page/source authorities remained byte-identical (`before.json`, `after.json`). Additional source custody uses both current bytes and HEAD comparison (`supplemental-source-custody.json`). The dirty workspace includes concurrent documentation scanner/API qualification work and matrix updates; those are excluded from this page/product verdict. Neither frozen page was edited. The former-Qdrant subsection equals HEAD byte-for-byte; its prior independent acceptance is neither inherited nor repeated as global acceptance.

The full actual install and maintenance pages, quality standard and acceptance contract were read before inspecting the writer's terminal harness. The relevant OPR-001/002/003 catalogue entries, A98-01/02/03/04/13 requirements, operator registry, static fixtures and post-documentation operator-validation classification were inspected. Source assessment used actual deployment/release functions and main guards, live trust script, ownership guard, release workflows, registry template/generator/entrypoint, infrastructure/native preflight authorities, linked Worker Trust, Prism deployment and four-level readiness routes. Studio journey is assessed only for its installation-versus-approval boundary, not accepted as a complete Prism journey.

## Material finding F1 — missing production-receipt authority in the required final trust route

**FAIL — A98-02, A98-03, A98-13; OPR-002 and OPR-003 within this installation scope.**

Published locations: `docs/site/use/install.md:38` (all earlier gates must pass before first mutation), `install.md:1170` (required full-profile Worker Trust step), `docs/site/use/worker-trust.md:46` (preconditions), and `worker-trust.md:109` (live command).

The linked procedure sends the operator to `npm run verify:worker-core:trust:live`. `package.json:157` dispatches `bash scripts/deploy.sh worker-trust-e2e`. Actual `scripts/deploy.sh:2672-2679` first runs `tests/verification/live/worker-trust-cluster-e2e.sh`, then runs `cmd_nova_unit_preflight`. The latter (`deploy.sh:2045-2052`) invokes the remote unit transaction and receipt path. `run_nova_production_receipt_preflight` at `deploy.sh:2011-2034` reaches the remote invocation before calling `sign_and_store_production_receipt`. That signer (`deploy.sh:1970-2008`) requires:

1. an operator-provided `KUBECLAW_PRODUCTION_RECEIPT_PRIVATE_KEY_FILE`;
2. the independently installed trusted public key at `/etc/kubeclaw/production-receipt-authority.pub`;
3. both resolved files outside the repository, a valid remote worker revision, and matching sign/verify authority.

Neither the installation prerequisites nor the Worker Trust preconditions name this separate authority and fixed destination, explain its provisioning/qualification, or stop before live writes when absent. The environment reference has a generic private-key entry; it does not supply the exact fixed public-key installation prerequisite or bind it to this mandatory Worker Trust command. The pipeline source-attestation Secret is a different authority and does not satisfy this signer.

Exact-source extracted-function reproduction: `missing-receipt-authority.bash` uses the actual four functions above with synthetic subprocess responses only. Exit **1**. It prints `SYNTHETIC_TRUST_VERIFIER_EXECUTED` and a synthetic remote-unit receipt, then rejects the absent private-key authority with the actual message naming both required paths. `missing-receipt-authority.stdout`, `.stderr`, and `receipt-authority-result.json` retain the result. This is a local command-sequence proof, not a real remote unit transaction or cluster execution.

Required documentation fix: add the production-receipt signing authority to installation planning/preflight before the first probe/workload mutation and to Worker Trust preconditions. Name the private-key input, fixed trusted-public-key destination, separate authority owner, externally supplied installation/qualification and sanitized evidence, and safe stop when missing, mismatched or unqualified. Explain the complete live command sequence and post-trust receipt requirement. If an owner-supplied maintained setup/qualification procedure is unavailable, record the exact blocked step and future acceptance condition; do not fabricate a key, weaken verification, or treat the pipeline Secret as the receipt signer.

## Facet decisions

| Facet | Verdict | Source conclusion |
| --- | --- | --- |
| Canonical installation/lifecycle ownership | PASS | `docs/operator-tasks.json` and Use index assign installation/preflight once and link readiness, recovery, maintenance and trust to their separate canonical authorities. |
| Existing-cluster/host/storage/DNS starting boundary | PASS | Host/K3s/CNI/StorageClass/node preparation is explicitly owned externally. Unknown compatibility or recovery access is a stop; no bootstrap success is fabricated. |
| Complete final-verification prerequisites | FAIL | F1: the mandatory linked live route has an undocumented separate production-receipt authority. |
| Release acquisition and manual/automatic promotion boundary | PASS | Build/promotion workflow names, source run/attempt, successful main inputs, durable receipt, App token permissions, PR/merge ownership, scan and GitOps auto-deployment consequences match actual workflows. No dispatch or merge is claimed. |
| Selection/configuration/code/image identities | PASS | Actual selectedRelease rejects absence; release configuration binds exact file set/bytes to selected code or image commit; materializer checks generated values; optional code receipt validates image-input equality. Approved checkout identity remains separate from receipt identity. |
| Values precedence and immutable render admission | PASS | Selected generated role values contain source `my-values` input; private overlays and supported overrides follow; image/bundle substitutions fail before cluster access. Actual deployment tests passed. |
| Cluster binding and scoped authorization | PASS | Dedicated exported kubeconfig, context/server/namespace-UID binding, namespaced versus cluster scopes, explicit subresource checks and all-namespace Argo guard agree with actual clients. EOF rows are evaluated; blank/malformed/denied final rows fail. External provider permission is separately owned. |
| Pre-probe ownership and Argo separation | PASS | Actual guard checks CRD, Applications across all namespaces, then retained workload metadata even without the CRD; role render returns before later deployment guard, so early explicit guard is necessary and provided. |
| Disposable probe creation/capture/recovery | PASS | Exact snippets retain uncertain creation/apply/wait results, distinguish API absence from failure, avoid empty-name PV requests, capture Pending/partial states and explicit unavailable logs, and retain resources on incomplete observation. |
| UID-bound cleanup/provider disposition | PASS | Clearance identities, provider reconciliation, once-created DeleteOptions UID precondition and raw DELETE local-file syntax agree with API/client authority. Kubernetes absence and provider disposition remain separate; no force/PV-delete fallback is supplied. |
| Optional Prism deployment selection | PASS | Actual bool normalization/early return/default/main guards match true/false branch behavior. Disabled Prism is not uninstalled; no extra namespace is created. Current full live verifier requires four deployments and lacks a reduced-profile route. |
| Optional-profile product limit | PASS | Complete stop before mutation when operational completion is required, explicit isolated/incomplete deployment boundary, platform/trust owners, paired denial/source-signing/cleanup future criterion, and exact-cluster live closure are visible. No reduced verifier or approval is invented. |
| Prism installation versus human approval | PASS | Installation links deployment/health first and does not require an invented Nova approval wait. Real design submission/notification/wait remains a later separate bounded journey. |
| Four readiness levels/evidence classification | PASS | Process, Service endpoint, dependency smoke and functional transaction observations remain distinct; local checks/render do not claim live readiness/trust or production approval. |
| Current narrow full-SHA source spans | PASS | All 59 page source links resolve and are in range; every cited span equals current bytes. Fourteen whole-file comparisons differ only because deploy.sh:909 changed an informational docs pointer outside every cited span. No relevant behavior or cited span drift was accepted. |
| Former-Qdrant maintenance preservation | PASS | Subsection byte-identical to HEAD; preservation only, no retirement replay or acceptance inheritance. |

## Per-ID source decisions

These are separate source-role findings for the assigned installation partition, not package-wide acceptance:

- **OPR-001 PASS:** canonical lifecycle order and task ownership retained; no duplicate installation authority.
- **OPR-002 FAIL:** supported topology/version/cluster boundary is truthful, but F1 omits a mandatory final-verification prerequisite.
- **OPR-003 FAIL:** acquisition, Helm route, GitOps unsupported takeover and client preparation are source-faithful, but first verification cannot be completed from its stated preconditions because of F1.
- **A98-01 PASS:** installation and linked operator tasks have distinct canonical authority in the machine-readable registry.
- **A98-02 FAIL:** F1 prevents the complete Operate prerequisite/authority contract for the required linked trust command.
- **A98-03 FAIL:** cluster/storage/DNS gates are sound, but F1 is an unqualified prerequisite discovered only after the route performs live effects; the full stated installation gate list is incomplete.
- **A98-04 PASS:** actual four levels and Prism health distinctions are preserved; no Running/HTTP-only acceptance.
- **A98-13 FAIL:** F1 requires discovering the separate external signer setup from implementation rather than a self-contained supported operator procedure.

## Executed checks and limits

Environment: Node.js `v24.21.0`, Bash `5.3.9` on Alpine/musl; Python 3 standard-library harnesses; Git and installed repository dependencies. No dependency installation or generation/output edit was performed in the repository.

Executed locally:

- All **45** extracted Bash blocks across both pages: `bash -n`, all exit 0. Initial handwritten console text said 48; actual extraction/replay records correctly count 45.
- Independent exact probe snippets: success, partial apply, Pending/unbound claim, denied log capture. All four final harness executions exit 0 with expected recorded statuses. Denied observation retains the namespace; Pending capture records no PV and unavailable logs. Fixture plumbing errors in the first local mock versions were corrected; only `probe-v3-*` are the passing final scenario artifacts. None is a live proof.
- Independent exact registry snippet: HTTPS with mirror, HTTPS without mirror, anonymous HTTP lab succeed; missing credentials and colliding endpoints reject with exit 1. Actual generator writes private new files. Synthetic credentials are fixture literals only.
- Actual `node --test tests/verification/deployment/release-configuration.test.mjs`: exit 0, 3/3 tests passed. Expected invalid Git-tree negative prints `fatal: not a tree object`; test passes by observing rejection. Tests create isolated temporary repositories only.
- Actual `node --test tests/verification/deployment/deployment-release.test.mjs`: exit 0, 8/8 tests passed; saved `deployment-release-test.log`. Real source Git/Helm/shell render boundaries are tested using isolated temporary repos and a kubectl that refuses cluster access.
- Actual ownership function with injected local responses: absent CRD/unclaimed Applications allowed; outside-argocd ownership, retained tracking, malformed annotation and denied read rejected. Actual selectedRelease rejects the repository's absent runtime selection (`ownership-release-results.json`).
- Writer terminal harness inspected only after independent assessment, then replayed in reviewer-owned evidence location: 12 authorization variants, 8 profile variants, 3 maintenance-render variants, 66 structural local links. Author results were not inherited as independent proof.
- Exact-source missing signer sequence: expected exit 1 after synthetic first verifier/unit execution; F1 retained.
- All 59 full-SHA pinned spans resolved through local Git and compared with current source. Upstream raw DELETE client source and DeleteOptions UID-precondition reference read independently: https://github.com/kubernetes/kubectl/blob/v0.34.0/pkg/cmd/delete/delete.go#L275-L307 and https://kubernetes.io/docs/reference/kubernetes-api/definitions/delete-options-v1-meta/ . No server/client compatibility range inferred.
- Before/after hashes: all 34 initially tracked authorities unchanged; both requested frozen page hashes retained.

Not run: GitHub dispatch/read receipt authentication against live API, image scanning/build/push/pull, node installation/restart/cold pull, cluster authorization/admission/provisioning/DNS, live probe/DELETE/provider cleanup, deployment, functional readiness, Worker Trust/live receipt signing, Studio approval, recovery/retirement, publication build/browser/Reader/Quality/global acceptance. The supplied repository is dirty; no clean-checkout/package/ledger acceptance is asserted. Existing product limits remain product work, not documentation completion claims.
