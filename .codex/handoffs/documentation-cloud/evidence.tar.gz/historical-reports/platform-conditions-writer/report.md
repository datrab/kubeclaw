# Platform conditions correction — author report

Role: AUTHOR only, `/root/a98_platform_conditions_writer`.
Assigned implementation authority: `94fd165ae8177ec37bb16798bfed63cb8923f413` on `docs/documentation-overhaul`.
Release HEAD observed: `25a0d2f2f2d7824b83928ca851c5df6c25cc88e8`. Parent work advanced HEAD during author checks; `release-head-source-freshness.json` proves that every page-linked source file remains byte-identical to the assigned authority. This does not relabel a historical execution as a new revision execution.

Exclusive authored path: `docs/site/reference/pipeline-platform.md`. No product, generator, shared matrix, glossary, other page, commit, push, installation or live service mutation was performed by this author. The repository was already dirty and remains dirty with other agents' unrelated generated inventory/page work; this is not a clean checkout acceptance claim.

## Correction delivered

The complete page now carries the S1–S4 conditions in its field tables, linked explanations, startup sequence and failure guidance. This is the author's correction assessment, not a Source/Reader/Quality PASS.

- S1: all configured provider entries validate a known capability and installed declaring adapter, including unused entries. Only capabilities required by enabled registrations select and enable providers. A map alone does not start an adapter. Exact missing versus ambiguous versus invalid/unknown errors are given. Recursive provider closure and its influence on actual disablement remain visible.
- S2: external allowlist keys are exactly `local:<canonical package root>`. The digest description covers sorted relative-path framing and regular file bytes, symlink rejection, relocation/key changes, built-in → source digest → attestation-map lookup, and `isolated_external` scope for both external decisions. Operator approval remains external to this lookup; no cryptographic attestation verification is claimed. Built-in trust bypass and safe stop are explicit.
- S3: an admitted enabled external adapter still fails activation because a persistent isolated adapter runtime is unavailable. The page names plugin-runtime maintainers, the blocked step and a later acceptance condition for startup/readiness/dependencies/cleanup/shutdown under isolation. Stages and observers receive wrappers during preparation; invocation separately needs a bounded context and delegated cgroup root, plus the linked native/kernel prerequisites. Schema-valid omission of isolation is distinct from `ISOLATION_CGROUP_REQUIRED`. Built-in/direct-import bypasses are prohibited.
- S4: both root lists have realpath/directory requirements and within-list canonical alias rejection; repeated package paths fail too. The errors and safe actions are explicit. The grant envelope stays open at schema level, while capability consumers require exact closed constraints. Unrequested and disabled-registration grants, including empty disabled entries, fail. Catalogue/validation links sit beside `grants`; disablement uses the actual provider closure.

Related preserved conditions: every configured adapter/observer ID exists; all configured observers enable; absent enabled configuration uses `{}` without adding schema defaults; invalid disabled adapter configuration can remain latent. The operational Node timer range remains 1–2,147,483,647 ms, overflow converts to 1 ms, and a deadline is not proof of stopped work. TTL capture at coordinator creation is explicit. Recorded provider policy, including unused entries, is separate from selected providers; the exact recovery subset and snapshot values without redaction are explained. Storage changes do not move data. The historical 2026-10-09 execution at `c8987b18b450bc27571d5037cb6ce3fb26e0cbd0` remains labelled with its true revision. Its linked source bytes were compared with the assigned current authority rather than relabelled.

## Read and author method

Fully read the independent `platform-activation-source-fresh/report.md`, the entire documentation quality standard, the entire AP09 acceptance contract, and the complete before/after platform page. Read CFG-002 and the applicable A98-10/11 requirements. Machine-extracted fixture context shows no direct static Reader/execution binding for these two gates; the configuration mutation definitions were read, not executed.

Fully read original registry discovery, digest, capabilities, capability vocabulary, activation, runtime configuration validation, registry schema validation, platform loader/schema, isolation runner/cgroup, engine-runtime, effect coordinator, and platform contract test. Contextual reads covered the linked snapshot writer/comparison and adapter startup regions; canonical plugin-runtime discovery/trust/selection/grant/activation/isolation/disablement sections and owner header; capability catalogue introduction and relevant vocabulary; existing precedence/change-impact links. These contextual reads are not claims of full-file review of those larger pages or modules.

Drafting applied the project's ASD-STE principles: direct sentences, named actors, explicit conditions/errors, ordinary explanations for source keys/context and exact technical identifiers. Shared canonical catalogue and runtime explanations remain the authorities; no second manual capability inventory or formal ASD-STE certification was created. This author method is not the independent Quality review.

## Executed checks and limits

Final page-bound checks all exited zero. `executed.json` records commands/logs and the same final page hash for the full reference, reader-boundary and platform contract runs. First-run logs are retained separately.

| Check | Actual result | Boundary |
| --- | --- | --- |
| Original platform contract | `ok:true`; exit 0 | Local configuration contract, not deployment readiness. |
| Full repository references | Passed; exit 0 | Markdown/local and pinned source validation, not rendered output. |
| Reader-site boundary | Passed; exit 0 | English/internal-boundary rules and local reader links, not a fresh reader exercise. |
| Page pin/anchor audit | 33 source links; 23 local links; maximum source range 53 lines; exit 0 | All targets regular Git files, all ranges in bounds, all source bytes match assigned revision; no Source acceptance verdict. |
| Original loader on unchanged inline example plus schema boundaries | Six cases passed; exit 0 | Optional-isolation distinction and digest-map schema rules; no package activation/invocation. |
| Page diff whitespace check | Exit 0 | No semantic acceptance inference. |

The old pinned whole-file source bytes and assigned current bytes all match. Every new link uses a full 40-character source revision and a range no wider than 60 lines. Exact pins and hashes are in `sourcepins.json`; local Markdown targets and hashes are in `page-links.json`.

`unexecuted.json` separately records fresh Source/Reader/Quality acceptance, publication/render/live isolation, full recovery, global inventory/ledger, mutation, long timer/lock/concurrency and clean checkout work that this author did not run. No single green check is used as overall acceptance. `logerrors.json` records the pending-artifact exploration failure and output-read limits. No failing authored check was hidden. No background operation or temporary runtime fixture remains intentionally active; the example checker deletes its own temporary directory.

## Released artifact

Final page: 30680 bytes, 361 lines.
SHA-256: `cbba5c3944352ce4f03996816898a2fbf0067142391b921342a412a18b36a2d1`.
Git blob: `e61d9403bd07ed5ba0fa88ef2309e4b9ab9a0faf`.

`authored-page.md`, `author.diff`, `pagehash.json`, source pins, environment, commands, logs and skipped checks are saved beside this report. This report releases the writer's exclusive page lock for parent coordination and fresh independent review. No further page edits are planned by this author. It grants no Source, Reader, Quality or global acceptance decision.
