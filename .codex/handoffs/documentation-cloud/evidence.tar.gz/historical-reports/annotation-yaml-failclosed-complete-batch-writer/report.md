# F1–F8 scanner correction: author's bounded evidence

Status: F1–F8 correction implemented and the final private receiving replay completed. This is author evidence, not independent Source approval or any SourceDoc, ReaderDoc, Quality, AP09/package/global, publication, deployment or live acceptance. Root owns semantic qualification, integration and the next independent fresh Source review.

Repository: `/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04`; branch `docs/documentation-overhaul`; HEAD at freeze `430633accc4a374a740b5f12f384eeeb9dce228d`. The byte boundary below controls these checks; the shared worktree was already dirty and concurrent root work is not claimed as mine. Only `scripts/docs-configuration-inventory.mjs` and `scripts/tests/python-environment-discovery.test.mjs` were edited in the repository. No product/runtime/page, output-discovery, shared authority registry, generator, commit, push, dependency, cluster or target-image change was made.

The full quality standard and acceptance contract were read, together with CFG-011/013/015 catalogue/audit entries, A98-10/11/14 and the actual config/Secret fixture definitions. The complete actual independent fresh report was read. Its F1–F8 form this correction batch; F9/F10 belong to the separate root/output owner. No inherited PASS is used.

## Frozen authority

| File | SHA-256 | Bytes |
| --- | --- | --- |
| scripts/docs-configuration-inventory.mjs | 6886d079dfa8da74c323382d60c7cb27e71800e0e640446021f5f772925506c6 | 835470 |
| scripts/tests/python-environment-discovery.test.mjs | 558cdeb654ec599705e6dd793b5f8932ed9a7ef36d0c8c8a7c810ce51cacae28 | 43186 |

Exact frozen source bytes are retained under `frozen/`. `freeze.json` records timing and revision. `after-freeze.json` verifies that both owning authorities remain unchanged. The preliminary freeze was superseded after additional helper-transfer family probes; preliminary logs are expressly separate and do not qualify the final hashes.

## Changed behavior and source reasons

| Finding | Correction and reason |
| --- | --- |
| F1 | Function annotations are stored by stable callable identity, so chained/conditional aliases and original-name rebinding retain the same metadata. Explicit access visits those expressions with access-time bindings. |
| F2 | Classes have stable identities carried by aliases. Class annotation evaluation combines current evaluation globals with the actual class-owned namespace snapshot and bindings. |
| F3 | Class/member role resolution follows each finite class identity. Method annotations carry their defining class namespace; direct member access, method aliases and conditional class aliases retain every finite selected identity. A recognizable unresolved annotation target rejects explicitly. |
| F4 | `pythonArgvMode` is shared by shell and executable YAML argv. Only the selected initial interpreter mode can acquire `-c`. Module/script operands, including later literal `-c`, remain passive. Unknown interpreter modes reject. |
| F5 | Executable YAML command/args acquires the finite literal env/sudo wrapper chain through `pythonInterpreterIndex`, including env assignments and supported literal options. Nonliteral Python argv/args and identifiable unresolved wrapper custody reject. YAML offsets still come from scalar decoding. Shell assignment syntax is handled only by shell acquisition; Kubernetes exec argv is not treated as shell assignment syntax. |
| F6 | Identifiable getattr reflection on os/environment capabilities rejects with source/line identity. Direct builtin, finite getattr aliases and builtins getattr acquisition are recognized. No universal reflection evaluator was introduced. |
| F7 | Absolute os star imports reject as unsupported capability acquisition, rather than silently losing imported reader authority. |
| F8 | Known environment/module/reader capability returns reject, including simple aliases, conditional expressions, containers and lambdas. Known callable returns also reject conservatively because return-role flow is unsupported. Passing identifiable environment/reader/reflector capabilities into helpers rejects at that call, so argument-based reader transfer cannot stay silently green. |

`pythonEnvironmentReads` executes only its isolated AST parser with the inspected source on stdin; it never imports or executes inspected product source. Synthetic native witnesses establish the Python/Bash behavior being modeled or explicitly rejected. `ops/pod/bootstrap.py` and `ops/pod/test/app_server_smoke.py` remain parsed sources for discovery. The existing bounded OPS test may execute its owning bootstrap functions with synthetic files and a replaced subprocess boundary; it cannot contact a cluster.

## Observed checks

- `node --test scripts/tests/python-environment-discovery.test.mjs`: exit 0, 38/38 pass, zero skips. All original 33 regressions retained; five new family tests cover identity/namespace/access timing, YAML wrapper/mode custody, explicit capability rejection, native execution and conditional class/method identities. Each supported introduced reader is checked against the production receiving gate; unsupported cases must reject with source identity.
- `node --test scripts/tests/ops-bootstrap-environment-contracts.test.mjs`: exit 0, 9/9 pass, zero skips; authorized bounded synthetic Unit execution only.
- `node scripts/docs-configuration-inventory.mjs --check-environment-coverage-only`: exit 0, exactly 436 discovered names and all current receiving/producer pairs qualified. The actual CLI was read before this exact read-only command; no invented flag or full generator was invoked.
- The Python suite retains six earlier synthetic Python/Bash native witnesses and adds ten Python native witnesses. Native output establishes function/class aliases, direct/class-local method annotations, reflection, star import and direct/container/parameter/callback helper readers. Each prints the synthetic observed value; no product source runs.
- `native-argv.py`: exit 0, three further synthetic native witnesses. A literal env wrapper executes the Python body; module/script mode preserves later `-c` and source-looking text as passive argv. No real module or application is launched.
- Final full receiving replay: exit 0 for its harness; 18/18 expected decisions pass. The baseline and restored corpus both pass with exactly 436 names; 14 identifiable new/unsupported inputs exit nonzero with their expected reader/source or unsupported/source diagnostic; two passive module/script argv controls remain green at 436 names. It uses a complete private copied corpus, linked pre-existing dependencies, and explicitly overwrites the two owning files from verified frozen bytes. Mutations touch only that private copy. All source files are restored, and the copy is removed after the run. Every command is the exact read-only coverage CLI.

`test-runs.json`, native diagnostics in `python-tests.log`, `native-argv-results.json`, and the receiving-case/results/log artifacts retain actual commands, outputs, exits and source identities. Private preliminary receiver runs passed their expected outcomes but are not evidence for final frozen bytes; they remain labelled preliminary.

## Limits and open acceptance work

F1–F8 are locally corrected and tested as one source-family batch. This does not grant individual catalogue or AP09 gate PASS. CFG-011/013/015 and A98-10/11/14 still need fresh independent qualification against the final complete integrated bytes and their broader required evidence. Root owns source-role/hash/recipe qualification and final integration. F9/F10 were not edited or approved here.

The finite scanner is not a universal Python/shell interpreter. Recognizable unsupported annotation targets, reflection, star imports, helper capability transfer and executable argv custody explicitly reject; this report does not extrapolate those checks to arbitrary indirect code. Conservative potential readers remain permitted. Unsupported cases do not become discovered configuration facts or qualified consumers.

Full generators, broad pre-registered AP09 mutation suites, published rendering, page prose/Reader/Quality acceptance, target-image/application smoke, deployment and all live operations were NOT RUN. The actual app-server smoke source was only read and parsed. No independent or global approval is claimed.

## Final complete receiving decisions

| Case | Exit | Expected decision | Observation |
| --- | --- | --- | --- |
| complete-baseline | 0 | GREEN | Expected source/diagnostic observed |
| gate-function-alias | 1 | REJECT | Expected source/diagnostic observed |
| gate-class-alias | 1 | REJECT | Expected source/diagnostic observed |
| gate-method-annotation | 1 | REJECT | Expected source/diagnostic observed |
| gate-method-local-annotation | 1 | REJECT | Expected source/diagnostic observed |
| gate-yaml-wrapper | 1 | REJECT | Expected source/diagnostic observed |
| gate-yaml-passive-module | 0 | GREEN | Expected source/diagnostic observed |
| gate-yaml-passive-script | 0 | GREEN | Expected source/diagnostic observed |
| gate-reflection | 1 | REJECT | Expected source/diagnostic observed |
| gate-star | 1 | REJECT | Expected source/diagnostic observed |
| gate-helper | 1 | REJECT | Expected source/diagnostic observed |
| gate-lambda-helper | 1 | REJECT | Expected source/diagnostic observed |
| gate-parameter-helper | 1 | REJECT | Expected source/diagnostic observed |
| gate-container-helper | 1 | REJECT | Expected source/diagnostic observed |
| gate-callback-helper | 1 | REJECT | Expected source/diagnostic observed |
| gate-yaml-unknown-mode | 1 | REJECT | Expected source/diagnostic observed |
| gate-external-stdin | 1 | REJECT | Expected source/diagnostic observed |
| complete-restored | 0 | GREEN | Expected source/diagnostic observed |

All final receiving cases used the two exact frozen owning authorities. The final post-run hash check passes. All required work within this writer scope is complete; independent semantic/source acceptance remains with root and its reviewers.
