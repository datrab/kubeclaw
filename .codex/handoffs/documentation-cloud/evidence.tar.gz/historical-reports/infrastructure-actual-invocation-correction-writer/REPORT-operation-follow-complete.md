# Follow-up author correction report — frozen original shell surface

This is writer evidence, not independent acceptance. Earlier REPORT-operation-batch.md and its sealed receipt remain unchanged. Exclusive repository edit: scripts/docs-api-output-discovery.mjs. No product/test/registry/generated edits, commit, push, live Kubernetes operation, or full configuration generation was performed by this writer.

Frozen discovery SHA-256: `d9b347c604e1e80aead4569597a5ef5b4d7db22f1b9ec21d881816518c1712ed`. Main HEAD observed at freeze checks: c978d34cf6949c0dcc49569e0a587d128851633d. Syntax and repository diff whitespace checks exited 0. The six selected helpers and all 29 original shell product sources are byte-equal between main and the coherent private snapshot (final-source-custody.json). Workspace dependency links were previously rebound inside that snapshot; dependency-links.json preserves the binding manifest.

## Observed outcomes

- 93073 terminal 0: selected-consumer boundary traversal reported no remaining entries. This traversal alone was insufficient for full discovery; later actual discovery exposed the Trivy downstream join.
- 51545 terminal 0: actual Secret encoding/read/generation/diagnostic/list channels, six refreshed flow mutations, two SOPS constructor profiles, three refreshed constructor mutations, JSON transfer helper and three deploy PATCH wire bodies.
- 56897 terminal 0: original PV Python JSON Patch four operations → receiver/pointer/schema helper; capability/receiver/variable/malformed-pointer controls fail closed.
- 28724 terminal 1: corrected actual original discovery exposed Trivy Version-header awk at scripts/scan-runtime-images.sh:54. Earlier 26871 terminal 1 exposed the author's new receiver position/regex implementation error. Both failure logs retained.
- 10767 terminal 0: corrected complete original shell discovery produced 111 API contexts and 450 classifications. Four refreshed Trivy program/producer/artifact/new-caller controls separately exited 0.
- 98789 terminal 1: actual consumer integration exposed missing __docsDynamicExpression marker on both symbolic Secret transfers. The failure log remains.
- 46049 terminal 0: corrected marker integration joined all selected new PV/Secret/Service/Deployment contexts through apiProductSelection.
- 14528 terminal 0: final exact source-expression marker bytes joined ALL 111 actual original shell contexts across 18 GVKs through apiProductSelection. This used an empty receiver-contract list, so it proves actual rediscovery/custody, schema selection and transported PATCH/transfer semantics; it is not a complete receiver-default/documentation acceptance run. Correct field counts are in actual-all-shell-api-selection-summary.json. The harness log's selectedFields display incorrectly counted result object keys; it is not a field count.
- 69390 terminal 0: final frozen dynamic-operation positive and refreshed mutation batch: all 38 real commands bound; three original table entries excluded by arithmetic syntax, with nested commands retained.

Intermediate private harness failures at companion printf/echo checks, helper return shape, and regex escaping were corrected. No pass is claimed for those failed attempts. Existing earlier terminal 87162/47816/66352/22760 failures are preserved in their original logs; the approved arithmetic registry input correction was performed separately by Root.

## Actual additional authored configuration

Finite Secret literal/file encoders now emit actual receiver-qualified partial merge bodies, with controlled offline payload inputs and exact selected keys/callers. The SOPS argv array produces both original conditional Secret variants by actual offline kubectl dry-run; SOPS, randomness, prompts, apply and live values remain unexecuted. Both live Secret transfers preserve GET schema fields/server metadata and exclude write-only stringData: YAML sed records first matching text sequence per line, not a structural namespace guarantee; JSON DATABASE_URL records exact decode/global BRE substitution/encode/jq assignment and unknown live values.

PV JSON Patch preserves the exact source-authored array and controlled original claim name/UID inputs. Service merge preserves the source default NodePort and validated operator range. Deployment JSON Patch preserves its name precondition and source-selected container-index provenance. Deployment strategic merge preserves all three delete targets and source receiver binding agent-nova; Root/strategic writer's pinned schema merge-key consumer handled the directives.

## Original 41-row table

The previous generic “native/read-only” wording must not be read as a claim that delete or authentication commands are read-only. Effects are distinguished below. All original rows are retained, with 38 actual bindings and three arithmetic parser artifacts.

| # | Actual source and line | Selected command | Final binding / effect |
|---|---|---|---|
| 1 | scripts/deploy-ops-pod.sh:31 | `${k[@]}` | BOUND_ORIGINAL: Namespace constructor → apply (actual offline client render) |
| 2 | scripts/deploy-ops-pod.sh:31 | `${k[@]}` | BOUND_ORIGINAL: Namespace apply sink; joined actual dry-run constructor |
| 3 | scripts/deploy-ops-pod.sh:38 | `${k[@]}` | BOUND_ORIGINAL: authentication/pairing administration; interactive outcomes unexecuted |
| 4 | scripts/deploy-ops-pod.sh:40 | `${k[@]}` | BOUND_ORIGINAL: authentication/pairing administration; interactive outcomes unexecuted |
| 5 | scripts/deploy-ops-pod.sh:42 | `${k[@]}` | BOUND_ORIGINAL: authentication/pairing administration; interactive outcomes unexecuted |
| 6 | scripts/deploy-ops-pod.sh:43 | `${k[@]}` | BOUND_ORIGINAL: source-bound mounted authentication shell; subsequent interactive input unexecuted |
| 7 | scripts/deploy-ops-pod.sh:45 | `${k[@]}` | BOUND_ORIGINAL: finite read-only receiver/query → selected projection/private backup/status |
| 8 | scripts/deploy-ops-pod.sh:46 | `${k[@]}` | BOUND_ORIGINAL: source-qualified supervisor native status file export |
| 9 | scripts/deploy-ops-pod.sh:49 | `${k[@]}` | BOUND_ORIGINAL: source-qualified read-only MCP verifier; diagnostics only |
| 10 | scripts/deploy-ops-pod.sh:52 | `${k[@]}` | BOUND_ORIGINAL: exact observer 403 negative control; fixed diagnostic only |
| 11 | scripts/deploy.sh:959 | `$helper` | BOUND_ORIGINAL: tracked Secret setup API child; complete selected child discovery required |
| 12 | scripts/install-native-worker-pools-stage.sh:12 | `$bundle/10-kubeclaw-native` | BOUND_ORIGINAL: source-built policy validation; supplied runtime binary unexecuted |
| 13 | scripts/install-native-worker-pools-stage.sh:13 | `$node` | BOUND_ORIGINAL: selected native Node policy version equality; diagnostic failure only |
| 14 | scripts/install-native-worker-pools-stage.sh:36 | `$node` | BOUND_ORIGINAL: selected native systemd unit file transformation; host configuration writer, not Kubernetes body |
| 15 | scripts/pipeline-light-openclaw-notify.sh:101 | `${argv[@]}` | BOUND_ORIGINAL: finite CLI/event or prefixed-log channel; external outcomes unexecuted |
| 16 | scripts/pipeline-light-openclaw-notify.sh:147 | `${agent_argv[@]}` | BOUND_ORIGINAL: finite CLI/event or prefixed-log channel; external outcomes unexecuted |
| 17 | scripts/pipeline-light-watchdog.sh:119 | `$notify_command` | BOUND_ORIGINAL: finite CLI/event or prefixed-log channel; external outcomes unexecuted |
| 18 | scripts/postgresql-recovery.sh:51 | `$1` | BOUND_ORIGINAL: finite pg_dump/pg_restore --version → validated numeric version comparison |
| 19 | scripts/postgresql-recovery.sh:53 | `10#${BASH_REMATCH[1]}` | SYNTAX_EXCLUDED: arithmetic syntax; not an executable command; nested actual commands retained |
| 20 | scripts/postgresql-recovery.sh:125 | `$(date +%s)` | SYNTAX_EXCLUDED: arithmetic syntax; not an executable command; nested actual commands retained |
| 21 | scripts/postgresql-recovery.sh:171 | `$(date +%s)` | SYNTAX_EXCLUDED: arithmetic syntax; not an executable command; nested actual commands retained |
| 22 | scripts/prepare-postgresql-production-upgrade.sh:8 | `${kube[@]}` | BOUND_ORIGINAL: finite read-only receiver/query → selected projection/private backup/status |
| 23 | scripts/prepare-postgresql-production-upgrade.sh:9 | `${kube[@]}` | BOUND_ORIGINAL: finite read-only receiver/query → selected projection/private backup/status |
| 24 | scripts/prepare-postgresql-production-upgrade.sh:10 | `${kube[@]}` | BOUND_ORIGINAL: private SQL backup export with credential environment only; not Kubernetes authored body |
| 25 | scripts/prepare-postgresql-production-upgrade.sh:22 | `${kube[@]}` | BOUND_ORIGINAL: finite read-only SQL metadata queries → recovery admission/status |
| 26 | scripts/prepare-reliability-services.sh:33 | `$destination/bin/redis-server` | BOUND_ORIGINAL: selected native version or RDB validation; external runtime unexecuted |
| 27 | scripts/prepare-reliability-services.sh:34 | `$destination/bin/redis-cli` | BOUND_ORIGINAL: selected native version or RDB validation; external runtime unexecuted |
| 28 | scripts/redis-prepare-migration.sh:26 | `$REDIS_SERVER` | BOUND_ORIGINAL: selected native version or RDB validation; external runtime unexecuted |
| 29 | scripts/redis-prepare-migration.sh:27 | `$REDIS_CHECK_RDB` | BOUND_ORIGINAL: selected native version or RDB validation; external runtime unexecuted |
| 30 | scripts/remove-qdrant.sh:18 | `${kube[@]}` | BOUND_ORIGINAL: finite read-only receiver/query → selected projection/private backup/status |
| 31 | scripts/remove-qdrant.sh:49 | `${kube[@]}` | BOUND_ORIGINAL: deletion administration; no authored replacement resource body |
| 32 | scripts/remove-qdrant.sh:50 | `${kube[@]}` | BOUND_ORIGINAL: deletion administration; no authored replacement resource body |
| 33 | scripts/remove-qdrant.sh:51 | `${kube[@]}` | BOUND_ORIGINAL: deletion administration; no authored replacement resource body |
| 34 | scripts/remove-qdrant.sh:52 | `${kube[@]}` | BOUND_ORIGINAL: deletion administration; no authored replacement resource body |
| 35 | scripts/remove-qdrant.sh:54 | `${kube[@]}` | BOUND_ORIGINAL: deletion administration; no authored replacement resource body |
| 36 | scripts/remove-qdrant.sh:71 | `${kube[@]}` | BOUND_ORIGINAL: deletion administration; no authored replacement resource body |
| 37 | scripts/repair-native-nri-launch.sh:22 | `$backup/10-kubeclaw-native` | BOUND_ORIGINAL: source-built policy validation; supplied runtime binary unexecuted |
| 38 | scripts/scan-runtime-images.sh:54 | `$executable` | BOUND_ORIGINAL: selected pinned vulnerability/version diagnostic contract |
| 39 | scripts/scan-runtime-images.sh:112 | `$trivy_executable` | BOUND_ORIGINAL: selected pinned vulnerability/version diagnostic contract |
| 40 | scripts/scan-runtime-images.sh:95 | `$trivy_executable` | BOUND_ORIGINAL: selected pinned vulnerability/version diagnostic contract |
| 41 | scripts/scan-runtime-images.sh:129 | `$trivy_executable` | BOUND_ORIGINAL: selected pinned vulnerability/version diagnostic contract |

## Boundaries remaining for Root / independent review

No known original selected shell consumer or authored shell context remains open in this bounded batch. Unknown commands, arrays, constructors, changed caller/receiver/format/channel recipes and unsupported actual transport variants still fail closed. This is finite source-supported grammar, not a recursive proof of arbitrary shell programs or external binaries. Operator inputs, interactive sessions, live GET state, authentication success, database recovery, deletion effects, Trivy findings, mounted files, and prepared binary runtime bytes were not executed or invented.

Earlier 14 infrastructure renders, imported API corrections, Go factory/conditions/method context and Python webhook/bootstrap integration were preserved; their historical writer receipts are not refreshed whole-Source acceptance. Current whole-source maintained suite, generator output, current Go producer integration, documentation completeness and independent fresh Source review remain Root's required next steps. No full generation or publication was launched.
