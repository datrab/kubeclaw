# Author correction: finite scalar graph and explicit operation boundary

Exclusive authored file: `scripts/docs-api-output-discovery.mjs`
SHA-256: `bdccc0dda7ec6c0bb4d1ca9068d5644b5a8e0791b9b21ee0da8f2f399350b98e`. Repository changes remain uncommitted; this is author evidence, not fresh Source acceptance.

The actual YAML scalar graph now binds seven helper bodies, finite callers, exact scalar programs, typed Helm/URL receivers and closed captured-value references. Actual seven selected sinks qualify in the bounded source-grammar test. Five changed-caller/program/relay controls revoke the graph. Three fully refreshed source/operation/sink-contract fixtures reject computed readers, an aliased API function, and a kubectl Namespace constructor pipeline. Each selected dynamic sink is independently rejected, so rejection does not depend on an earlier literal API sink.

Syntax and diff checks passed. `scalar-check.mjs` terminal 0; results in `scalar-results.json` and log. Initial original scan terminal 1 due to missing private Git object custody for authenticated ops renderer (`shell-scalar-batch-original.log`), retained. Private Git initialized solely with read-only original object alternates; original scan after that prerequisite repair terminal 1 at `scripts/deploy-ops-pod.sh:31:${k[@]}` (`shell-scalar-batch-original-gitbound.log`). No code or semantic qualification changed between scans.

This failure is intentional fail-closed coverage: actual create namespace --dry-run=client -o yaml → apply has no fabricated native role. The Namespace constructor and other computed original operations still need actual operation binding. The prior ops54/Go30/named-family/14-render results remain historical author evidence at their recorded candidate hashes; they are not a current complete original-shell positive. Scalar tests are bounded grammar and mutation tests, not execution of live deployment or all original paths.

## Concrete next-operation batch

All 41 selected dynamic original sinks from the read-only enumeration are listed together. Every one currently fails the computed-executable consumer guard; arithmetic entries require parser correction rather than output-role approval.

| Original source/line | Selected command/argv | Required next binding |
|---|---|---|
| `scripts/deploy-ops-pod.sh:31` | `${k[@]} create namespace $namespace --dry-run=client -o yaml` | Actual Namespace constructor must become v1 Namespace API body/context; current explicit gap. |
| `scripts/deploy-ops-pod.sh:31` | `${k[@]} apply -f -` | Bind stdin API constructor/render ancestry and submission operation. |
| `scripts/deploy-ops-pod.sh:38` | `${k[@]} -n $namespace exec -it $pod -c codex -- codex login --device-auth` | Bind actual nested command/stream, selected inline script or module and receiver. |
| `scripts/deploy-ops-pod.sh:40` | `${k[@]} -n $namespace exec -it $pod -c codex -- gh auth login --hostname github.com --git-protocol https --web` | Bind actual nested command/stream, selected inline script or module and receiver. |
| `scripts/deploy-ops-pod.sh:42` | `${k[@]} -n $namespace exec -it $pod -c codex -- codex remote-control pair` | Bind actual nested command/stream, selected inline script or module and receiver. |
| `scripts/deploy-ops-pod.sh:43` | `${k[@]} -n $namespace exec -it $pod -c codex -- bash /opt/codex/shell.sh` | Bind actual nested command/stream, selected inline script or module and receiver. |
| `scripts/deploy-ops-pod.sh:45` | `${k[@]} -n $namespace get pod $pod -o wide` | Bind actual query argv, resource/format and selected receiver; do not classify arbitrary API JSON as native. |
| `scripts/deploy-ops-pod.sh:46` | `${k[@]} -n $namespace exec $pod -c codex -- cat /tmp/codex-ops-status.json` | Bind actual nested command/stream, selected inline script or module and receiver. |
| `scripts/deploy-ops-pod.sh:49` | `${k[@]} -n $namespace exec -i $pod -c codex -- python3 -` | Bind actual nested command/stream, selected inline script or module and receiver. |
| `scripts/deploy-ops-pod.sh:52` | `${k[@]} -n $namespace exec $pod -c ops-mcp -- node --input-type=module -e import {createKubeRequest} from "/app/src/kubernetes.mjs"; try {await createKubeRequest()("/api/v1/namespaces/" + encodeURIComponent(process.env.OPS_DEFAULT_NAMESPACE) + "/secrets");process.exit(1)} catch(e) {if(!e.message.includes("Kubernetes API 403:"))throw e; console.log("PASS: observer Secret access denied by API");}` | Bind actual nested command/stream, selected inline script or module and receiver. |
| `scripts/deploy.sh:959` | `$helper ` | Resolve actual setup-secrets.sh selected helper and its public outputs/submissions. |
| `scripts/install-native-worker-pools-stage.sh:12` | `$bundle/10-kubeclaw-native --check-policy $generated/native-nri.json` | Bind selected executable/module/generated bundle and actual native output or API constructor semantics. |
| `scripts/install-native-worker-pools-stage.sh:13` | `$node -e const fs=require("fs"); const p=JSON.parse(fs.readFileSync(process.argv[1])); if(p.nodeVersion!==process.versions.node) throw Error("Selected host Node version mismatch") $generated/native-node-policy.json` | Bind selected executable/module/generated bundle and actual native output or API constructor semantics. |
| `scripts/install-native-worker-pools-stage.sh:36` | `$node - $generated/kubeclaw-native-pools.service $staged_unit << JS` | Bind selected executable/module/generated bundle and actual native output or API constructor semantics. |
| `scripts/pipeline-light-openclaw-notify.sh:101` | `${argv[@]} 2` | Bind finite CLI argv/capture to existing summary/framed-log consumers; dynamic emitter itself still gaps. |
| `scripts/pipeline-light-openclaw-notify.sh:147` | `${agent_argv[@]} 2` | Bind finite CLI argv/capture to existing summary/framed-log consumers; dynamic emitter itself still gaps. |
| `scripts/pipeline-light-watchdog.sh:119` | `$notify_command 2` | Bind finite CLI argv/capture to existing summary/framed-log consumers; dynamic emitter itself still gaps. |
| `scripts/postgresql-recovery.sh:51` | `$1 --version` | Resolve selected binary and bounded native version-output contract. |
| `scripts/postgresql-recovery.sh:53` | `10#${BASH_REMATCH[1]} * 10000 + 10#${BASH_REMATCH[2]}` | Arithmetic substitution parsed as an emitter; requires arithmetic-aware exclusion, not a native API role. |
| `scripts/postgresql-recovery.sh:125` | `$(date +%s) - started` | Arithmetic substitution parsed as an emitter; requires arithmetic-aware exclusion, not a native API role. |
| `scripts/postgresql-recovery.sh:171` | `$(date +%s) - $(metadata "$selected" started_epoch)` | Arithmetic substitution parsed as an emitter; requires arithmetic-aware exclusion, not a native API role. |
| `scripts/prepare-postgresql-production-upgrade.sh:8` | `${kube[@]} get pvc data-postgresql-0 -o json` | Bind actual query argv, resource/format and selected receiver; do not classify arbitrary API JSON as native. |
| `scripts/prepare-postgresql-production-upgrade.sh:9` | `${kube[@]} get statefulset postgresql -o json` | Bind actual query argv, resource/format and selected receiver; do not classify arbitrary API JSON as native. |
| `scripts/prepare-postgresql-production-upgrade.sh:10` | `${kube[@]} exec postgresql-0 -c postgresql -- sh -ec    password_file=${POSTGRES_POSTGRES_PASSWORD_FILE:-${POSTGRESQL_POSTGRES_PASSWORD_FILE:-/opt/bitnami/postgresql/secrets/postgres-password}}   export PGPASSWORD="$(cat "$password_file")"   exec pg_dumpall -h 127.0.0.1 -U postgres ` | Bind actual nested command/stream, selected inline script or module and receiver. |
| `scripts/prepare-postgresql-production-upgrade.sh:22` | `${kube[@]} exec -i postgresql-0 -c postgresql -- sh -es << REMOTE` | Bind actual nested command/stream, selected inline script or module and receiver. |
| `scripts/prepare-reliability-services.sh:33` | `$destination/bin/redis-server --version` | Resolve selected binary and bounded native version-output contract. |
| `scripts/prepare-reliability-services.sh:34` | `$destination/bin/redis-cli --version` | Resolve selected binary and bounded native version-output contract. |
| `scripts/redis-prepare-migration.sh:26` | `$REDIS_SERVER --version` | Resolve selected binary and bounded native version-output contract. |
| `scripts/redis-prepare-migration.sh:27` | `$REDIS_CHECK_RDB $snapshot` | Bind selected executable/module/generated bundle and actual native output or API constructor semantics. |
| `scripts/remove-qdrant.sh:18` | `${kube[@]} get pvc -o json` | Bind actual query argv, resource/format and selected receiver; do not classify arbitrary API JSON as native. |
| `scripts/remove-qdrant.sh:49` | `${kube[@]} delete statefulset qdrant --ignore-not-found --wait=true` | Bind exact destructive-command argv and output contract independently of name. |
| `scripts/remove-qdrant.sh:50` | `${kube[@]} delete service qdrant qdrant-headless --ignore-not-found` | Bind exact destructive-command argv and output contract independently of name. |
| `scripts/remove-qdrant.sh:51` | `${kube[@]} delete secret qdrant-auth qdrant-tls --ignore-not-found` | Bind exact destructive-command argv and output contract independently of name. |
| `scripts/remove-qdrant.sh:52` | `${kube[@]} delete networkpolicy kubeclaw-qdrant-ingress --ignore-not-found` | Bind exact destructive-command argv and output contract independently of name. |
| `scripts/remove-qdrant.sh:54` | `${kube[@]} delete ciliumnetworkpolicy kubeclaw-qdrant-ingress --ignore-not-found` | Bind exact destructive-command argv and output contract independently of name. |
| `scripts/remove-qdrant.sh:71` | `${kube[@]} delete pvc $claim --ignore-not-found --wait=true --timeout=180s` | Bind exact destructive-command argv and output contract independently of name. |
| `scripts/repair-native-nri-launch.sh:22` | `$backup/10-kubeclaw-native --check-policy /etc/kubeclaw/native-nri.json` | Bind selected executable/module/generated bundle and actual native output or API constructor semantics. |
| `scripts/scan-runtime-images.sh:54` | `$executable --version` | Resolve selected binary and bounded native version-output contract. |
| `scripts/scan-runtime-images.sh:112` | `$trivy_executable --version` | Resolve selected binary and bounded native version-output contract. |
| `scripts/scan-runtime-images.sh:95` | `$trivy_executable --version` | Resolve selected binary and bounded native version-output contract. |
| `scripts/scan-runtime-images.sh:129` | `$trivy_executable image --cache-dir $database_cache --scanners vuln --severity HIGH,CRITICAL --exit-code 1 --format table --output $report $image` | Bind selected executable/module/generated bundle and actual native output or API constructor semantics. |

Additional open boundaries: the separate yaml_get_first_named_list_item parser graph is not authorized by the finite scalar proof; literal kubectl/Helm and statically named helper skipping in the shell scanner is not a complete source-wide API-operation closure proof. Parent observed bootstrap.py discover() public-JSON mutation omitted when Python roles=[], recorded without independent fresh review. No acceptance claim for these boundaries. Pinned nativeHttpResponseRecipe unchanged.

No full configuration generation, full moving-Source suite, commit or push was performed. All reported process handles are terminal. File released to root for coherent Source freeze and independent review; further authored correction requires a new bounded batch.
