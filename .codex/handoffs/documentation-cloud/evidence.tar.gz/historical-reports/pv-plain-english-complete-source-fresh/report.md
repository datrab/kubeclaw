# Independent complete PV receiver Source review

PASS for the seven records in the frozen module SHA-256 `27c46abc1d156ffb4827a98bcbd672ab944e1e63297d7dba116325f8350c1d4a`, repository HEAD `4a381a370e4ca90bdae53f27bfee759704f1300c`. No material Source finding. This is bounded Source acceptance only, not global A98, Reader, Quality, Astra or live acceptance.

I read the full quality standard and applicable AP09.8 A98 contract before reviewing all seven original semantics and all revised wording. The source boundary is existing-PV retirement from `scripts/remove-qdrant.sh`; complete provisioning alternatives remain upstream. A98-06/09/10/11/13 apply to diagnosis, retirement, selected configuration, value precedence and honest execution limits; their global completeness is not judged here.

| Record | Source result | Reviewed distinctions |
| --- | --- | --- |
| `$` | PASS | PATCH array versus typed existing PV; absent request, null/empty body, malformed shape, missing target, complete update rejection and partial retirement |
| `$.spec` | PASS | Existing parent required; absent/null/empty/scalar/array failure; unmentioned spec retained at patch application |
| `$.spec.claimRef` | PASS | Existing reference condition; missing/null/empty/incompatible parent failure; three guards do not mutate binding |
| `$.spec.claimRef.name` | PASS | Exact captured claim name; missing/null/empty/wrong type/wrong string failure; no field assignment |
| `$.spec.claimRef.namespace` | PASS | Exact kubeclaw namespace; no namespace-scope default; cluster-scoped PV authority |
| `$.spec.claimRef.uid` | PASS | Exact captured claim lifetime; replacement lifetime differs; matching reference does not fence PV UID or later name-only PVC delete |
| `$.spec.persistentVolumeReclaimPolicy` | PASS | Add creates/replaces member under existing parent; absent/null/empty prior value overwritten; Delete is supported; no prior-policy guard or storage completion promise |

Every record passes the seven Source criteria in `report.json`: producer agreement/scope, input cases, encoding/decode/default/stage separation, guards/concurrency, controller/backend uncertainty, pinned spans/schema, semantic preservation after English revision.

Evidence and checks: I independently fetched all 14 upstream/product inputs identified by the locator provenance, with matching SHA-256 values. The writer's files/results were used only to locate inputs. The independently fetched schema equals decompressed locked schema bytes, and the current producer equals pinned producer bytes. `span-audit.json` captures all 36 distinct narrow citations from independent bytes. Each cited function/type body and its claim was read; membership at validation.go 2015–2025 must be paired with supported set 1942–1945, which expressly includes Delete.

The handler encodes current state, applies JSON Patch, decodes the whole result, updates managed fields, applies mutating admission and then enters storage Update. Strategy preparation preserves status/drops disabled fields; complete PV validation and update rules still apply. Additional independently fetched versioning codec and REST update sources corroborate defaulting before conversion/update validation and preparation before strategy validation. defaults.go 282–292 defaults an empty typed reclaim policy to Retain. The module does not claim that every omission remains unchanged after all server stages: retention language is expressly at patch application, and its fixed add writes nonempty Delete before decode. Raw null/empty/malformed current-state examples are explicitly receiving-stage hypotheticals, not assertions that malformed PVs can be stored.

Focused Go tests use unmodified pinned bundled patch.go/errors.go with the qualified Go binary. They pass seven policy assignments, nine malformed current parents, 24 missing/incompatible guard cases, null/empty operation arrays and three malformed request bodies. Null and empty patch arrays add no Delete operation; `{}` is not an operation array. The harness proves bundled-library behavior only and does not emulate a Kubernetes API server.

Controller evidence preserves nil reference versus empty UID versus matching claim paths, replacement-UID checks, separate Delete scheduling, migration handoff to an external provisioner, reread/release recheck, plugin errors/retries, and backend deletion before possible finalizer/API deletion failure. A matching claim bound to a different PV is covered by the cited release checker; the simplified wording does not claim that every existing matching claim prevents release. No backend erasure conclusion is inferred from API absence or the script message. Storage owner checks, uncertain-result stop rules and irreversible deletion limits remain explicit.

The producer captures PVC identities, checks references before uninstall, removes named resources before the guarded patch, and later deletes PVCs by captured name without UID preconditions. Its trap removes temporary inventory: the documentation's instruction to preserve original inventory/storage handle is an operator evidence requirement, not a false claim that the script automatically archives them. The export/retention precondition is likewise normative, not an implemented script check.

Unexecuted limits: no live API, RBAC/admission, controller, storage driver, backend erasure or recovery execution; no full generator/render/publication check, mutation/drift gate or global acceptance. Typed Kubernetes integration behavior is source-reviewed rather than integration-executed. Controlled-language semantic preservation is reviewed; formal ASD-STE100 compliance and independent reader usability are not claimed. Repository remained read-only; review outputs are external.
