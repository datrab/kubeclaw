# Fresh installation and release Quality review

Verdict: **FAIL** for the entire assigned Quality scope. Two current material findings remain. This does not grant or deny any separate Source, Reader, package, Astra, publication, native or live result.

Reviewer: `installation_release_probe_complete_quality_fresh`, Quality role only. Fresh assignment; repository initially and throughout read-only. I read the installation and release-acquisition pages before standards or prior-review material. I did not use Source/Reader summaries, author check counts, or the previous bounded findings as proof.

Reviewed HEAD: `d68da902c174574d1186ffd4a3ff29e95b63474e`. The repository was already dirty; its exact status is retained in `before-state.json` and `after-state.json`. The reviewed documents are frozen working-tree bytes, not falsely described as clean committed pages:

- `docs/site/use/install.md`: SHA-256 `60fff6c2df19bedc3f027850013f8c69f83d8cf0a03de63b7edf3720a067489b`.
- `docs/site/use/maintenance.md`: SHA-256 `e6d219a7bf5b54c4b98658ff50a41945aac8e53779c834f3d44e99e4bab28b44`.

Both page hashes and all 24 initial selected authority snapshots remained unchanged across this review. Additional task-map, glossary and live-test source snapshots are included. The manifest records byte counts and hashes.

## Current findings

**QUALITY-FRESH-01 — selected Prism is inconsistent with required final proof.** Install lines 341–346 require all three renders. Lines 1069–1075 call Prism installation “When Selected”, then lines 1088–1095 require the complete Worker Trust exercise. Worker Trust lines 20–22 require installed Nova, Buster and Prism; lines 105–109 demand all Prism trust results. Actual test source `tests/verification/live/worker-trust-cluster-e2e.sh:69–84` always waits for and inspects Prism Control/Worker. `scripts/deploy.sh:96` exposes `KUBECLAW_DEPLOY_PRISM`; its `all` pre-render branch at 2861–2864 respects that selection, while the explicit Prism render branch at 2875–2880 is unconditional. Thus a reader selecting false cannot complete the advertised canonical path or determine the supported acceptance profile without outside knowledge. State that the canonical install requires the full showcase before mutation, or document a reduced route only where real implementation supports it. Do not invent a reduced live-test flag or waive required trust checks. This is a workflow/profile Quality failure, not a request to implement an optional product feature.

**QUALITY-FRESH-02 — necessary terms are not defined on entry.** Install line 15 uses CNI, line 61 uses CSI, and line 72 uses OCI without an expansion, ordinary-language explanation or definition link. Their roles select networking, driver and registry prerequisites. Explain these briefly at first use and link focused definitions. SVID, PV/PVC, UID, authorization, receipt and projection explanations already provide a good pattern. Formal ASD-STE100 dictionary/certification review was not available or claimed; the method applies the project's full controlled-language requirements and technical-vocabulary rules.

The saved Buster-render handoff was considered during the review, then rejected as a material finding: mandatory client preparation explicitly links Render and Compare, whose commands save the render. This is an available published route, not hidden author knowledge.

## Scope and observed checks

I read the full 1,176-line install journey, maintenance release acquisition/change/identity and registry-client sections, binding/rotation/upgrade/decommission context, the full 312-line documentation quality standard, AP09 acceptance contract and relevant immutable fixture records, OPR-001/002/003 definitions, and A98-01/02/03/04/13. Required linked context inspected included the operator index/shared placeholders/tool limits, locked dependency installation, readiness levels, Prism deploy prerequisites/precedence/deployment/health, Worker Trust, the deployment-success exercise, Helm/environment/Secret reference entry context and relevant settings, and operational/live acceptance boundaries. Huge generated reference tables were inspected for the relevant entries, not independently accepted in full.

Implementation inspection included deployment scope/order/render/overlays/atomic guards, release receipt validation/configuration byte matching/materialization/provenance verification, promotion workflow/app/scan/PR/merge effects, infrastructure offline staging/render checks, Argo ownership discovery, native-node preflight permissions, Secret source copying, registry projections and the actual full trust-test prerequisite branch. The selected snapshots preserve exact source bytes.

Observed local checks: all **44** Bash fenced examples from both pages passed `bash -n` (syntax only, no command bodies executed). **61** local Markdown links in these pages have existing files and structurally matching heading slugs. That link check is a Markdown approximation, not a renderer/publication/route/HTTP proof. I also verified the 13 task-map IDs are unique and the scoped canonical mapping matches the operator index. Source pins/spans were read for Quality relevance; the independent Source role owns comprehensive pin/currentness proof.

Not run: dependency installs, repository generator/gate suites, mock cluster simulations, kubectl/Helm/deploy bodies, credentials, GitHub provenance HTTP requests, promotion/workflow/PR operations, image pulls, cluster storage/DNS/live trust, native host actions, publication/browser rendering, or post-documentation live operator fixtures. Local syntax and navigation do not imply any of those results. The runtime selection is actually absent. No invented release or live success was used.

The former-Qdrant section remains outside this new bounded acceptance decision. Its source was not edited; its Bash examples were syntax-checked with the other page blocks. Previous bounded three-role proof is not whole-maintenance acceptance, and this review does not renew it.

## Facet results

| Assigned facet | Verdict | Reason / limit |
| --- | --- | --- |
| OPR-001 / A98-01 assigned navigation and ownership | PASS | The task index and machine task map give one canonical install, readiness, trust and maintenance route; no internal review file is required. |
| OPR-002 / A98-03 supported states and prerequisites | FAIL | Existing-cluster, authority, storage/DNS, independent access and absent-selection stops are clear, but the advertised non-Prism selection has no complete accepted route (QUALITY-FRESH-01). |
| OPR-003 whole Helm/install handoffs | FAIL | Dependency order and release acquisition are usable; the selected-Prism/trust mismatch makes the complete advertised selection surface incomplete (QUALITY-FRESH-01). |
| A98-02 exact procedures and explained inputs | FAIL | The full-profile commands, placeholder rules, scopes, expected observations and cleanup are well developed; the selected-profile prerequisite and initial necessary terms remain unresolved (01/02). |
| A98-04 assigned readiness distinctions | PASS | The linked canonical readiness separates process, Service endpoint, dependency smoke and functional transaction; Prism /bootstrap,/ready,/health limits are distinct. No live readiness result is inferred. |
| A98-13 current task usable without chat | FAIL | A reader can safely stop on absent release and can follow full-profile release acquisition and prerequisite links, but cannot resolve the advertised reduced selection from the published instructions (01). |
| English and project controlled-language method | FAIL | English, direct action verbs and consistent SVID/PV/PVC/UID explanations generally work. Necessary initial CNI/CSI/OCI terms remain undefined (02). This is project STE-inspired review, not formal certification. |
| Execution locations and authority scopes | PASS | Independent administration versus Ops Pod is explicit. Bound kubeconfig/context/server/UID, namespace scope, chart/RBAC hooks, Secret source, Argo all-namespace reads, native node proxy and provider authority are distinguished. |
| Release identity and legitimate approval boundary | PASS | Image build, selected commit, code bundle and run/attempt identities are separated. App-token, selection PR/review/merge and GitOps merge effects are operator product behavior. No workflow success is claimed. |
| Probe expected observations, partial failure and diagnosis | PASS | Apply/wait failures retain statuses; Pending claims without visible PV and unavailable logs are distinguished; denied reads do not imply absence. Ownership/provider reconciliation precedes cleanup. |
| Retry/recovery/rollback/cleanup/evidence | PASS | Probe repeat needs cleanup plus new identities; uncertain effects require reconciliation. Atomic application rollback is separate from data rollback. UID-precondition namespace removal does not claim provider deletion; external disposition remains mandatory. |
| Purposeful depth and navigation | PASS | Detailed authorization/provider checks answer concrete safety questions. The client-preparation link supplies a Render and Compare path to saved YAML; this is sufficient navigation and is not treated as an undocumented blocker. No generic Kubernetes encyclopedia or new external framework is required. |
| Quality assessment of source-adjacent evidence and truthful status | PASS | Inspected product explanations use source links with full pins and relevant spans; local versus cluster/live limitations are stated. This is a Quality relevance assessment of inspected spans, not whole Source validity or publication acceptance. |
| Internal work language exclusion | PASS | No AP work-package, reviewer handoff or author-check status is required by the product journey. Repository PR approvals, rollout checks and human design approvals describe actual product behavior. |
| Current product boundaries | PASS | Absent runtime selection, lack of host bootstrap/node registry procedure, no accepted upgrade pairs, no takeover, and missing independent/live proof remain explicit. Those honest limits do not create a documentation failure by themselves. |

No overall AP09/A98 gate, package, publication or live approval is issued. Findings apply to these frozen bytes and require a fresh affected-route Quality review after correction.
