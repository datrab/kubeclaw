# Independent SOURCE review: selected product Service routes

Reviewed revision: `946073d5a51509f235fa153c3e3d0a8ade8fa467`.
Role: independent fresh-context SOURCE reviewer; read-only repository throughout. No author reports, prior summaries or mutable draft content used as semantic evidence. Review scope is selected Service records, service.type authority, service-routing.md, navigation/change impact, and their actual product/upstream producers and consumers. This is not Core, global CFG-009, global A98, or AP09 acceptance.

## Verdict: FAIL within assigned bounded scope

### F1 — supported deployment changes the claimed LiteLLM route and raw-manifest namespace

Affected prose: `docs/site/reference/service-routing.md:18-19` (LiteLLM and registry-local producer rows).
Authority: `scripts/deploy.sh:82,91,680-684,716-720,1166-1180,1195-1216`; `scripts/render-litellm-deployment.mjs:11-23`; `my-values/infra/litellm-deployment.yaml:84-97`; `my-values/infra/registry-local.yaml:94-106`; `scripts/render-registry-local.mjs:42-72`.

The table assigns both GitOps and raw my-values producers to namespace kubeclaw. Only the GitOps resources explicitly select that namespace. Both raw Service manifests omit metadata.namespace; the supported script applies them with `-n "$NAMESPACE"`, initialized from a configurable environment and subsequently replaceable by workspace selection. Raw input does not establish kubeclaw as its namespace.

More importantly, the LiteLLM row stops at omitted nodePort and automatic allocation. The supported deploy route renders that manifest, applies it, and then merge-patches the entire single Service port list with `LITELLM_NODE_PORT`. This defaults to 30050, uses the nonempty environment override, and validates 30000-32767 before apply. The main route therefore has a later explicit nodePort authority, with an intermediate allocated state and possible apply-success/patch-failure state. The environment reference independently mentions this setting, but the new canonical route page neither links that setting nor describes the supported later patch, and its grouping actively misstates the effective selected procedure. The raw direct-apply route can request allocation; it must be separated from the script route. Registry renderer retains ClusterIP but the configurable apply namespace applies there too.

Necessary fix: separate GitOps fixed kubeclaw namespace, direct raw selected namespace, and script-render/apply/patch route. Explain NAMESPACE/workspace selection and LiteLLM environment/default/range, later patch precedence, read-after-uncertain-patch and intermediate state. Link exact producer/patch authority and the environment setting. Preserve the valid distinction between unrelated producers.

### F2 — canonical Service symptom path is absent from the operator symptom index

Affected navigation: `docs/site/use/diagnose.md:188-216` and the new page `docs/site/reference/service-routing.md:1-103`.
Authority: the diagnosed stages in the same Service page at lines 61-101, pinned EndpointSlice selection/port conversion, proxy and DNS sources preserved below.

The reference index does link the new page (`docs/site/reference/README.md:37`) and configuration-change-impact links it (`:442-448`), so entry/reference/change navigation is present. The operator symptom index, however, has no Service-unreachable, missing-backend/named-port, stale DNS, NodePort or pending/uncertain LB row linking this diagnostic path. Existing Redis and registry-specific rows do not route those other supported Service failures. The new page contains discriminating checks and safe stops, but the requested canonical symptom route does not lead operators to them.

Necessary fix: add symptom-led entries or one suitable Service symptom entry with explicit stage distinctions and a direct canonical-page link. Do not begin from an assumed controller/provider failure.

## Individual bounded criteria

| Assigned criterion | Verdict | Source review result and boundary |
| --- | --- | --- |
| CFG-009, selected Service product relationships | FAIL | F1. The existing field inventories do not cure a contradictory authored route. No judgment on other Helm/GitOps settings. |
| A98-02, this read-only Service inspection procedure | PASS | Page :53-103 specifies workstation/tools/read RBAC, compatible supplied version, context/namespace/service and controller placeholders, ordered reads, observations, stop rules, retention, concurrency, no-mutation cleanup and separate recovery. This is documentation/source qualification, not execution or reader certification. |
| A98-06, canonical Service symptom route | FAIL | F2. Discriminating checks in the destination are source-consistent; symptom-index routing is absent. |
| A98-10, selected/derived Service configuration relationship | FAIL | F1 omits the supported script-derived effective port and misstates raw apply namespace. No assertion that the global inventory fails to enumerate LITELLM_NODE_PORT: environment-variables.md:229 does enumerate it. |
| A98-11, selected Service effective precedence | FAIL | F1: render omission/allocation is followed by explicit script patch, absent from canonical receiving path. Local field defaulting and service.type empty behavior themselves agree with source. |
| A98-13, source sufficiency of the Service operator identity/route | FAIL | F1 can send an operator to the wrong namespace and port authority. Generic read-only steps, external prerequisites and honest execution status are otherwise sufficient in the inspected scope. No fresh reader exercise claimed. |

## Consumer and producer findings without additional material errors

- Main chart defaults and named ports; NodePort-only fixed gateway/bridge branches; extra port main/dedicated NodePort branching; Prism Services/PostgreSQL; Buster/Prism SPIFFE proxy named listeners; demo-ready selector/readiness policy; archviewer Nova guard/private ingress policy; Ops headless identity and loopback-only MCP were inspected against frozen templates/values/listener configuration. Declared ports remain explicitly distinct from actual listeners. Default gateway command uses lan bind. Prism bridge itself binds loopback and is reached through the selected trust proxy.
- `service.type` authority :23479-23489 accurately distinguishes supported policy from explicit empty-string render: type becomes YAML null, fresh Go scalar decode stays empty, Service defaulting produces ClusterIP. ExternalName has no chart alias input and is correctly excluded as an unsupported chart interface while linking upstream.
- Service-specific definitions :141-182, status definitions :248-260, later consumer clauses :535-631, final record construction/null handling :2110-2144 and all Service reader references :2177-2179 were checked. Common decoder semantics distinguish fresh decode from patch/update, nil versus retained empty selector, map/list items and IntOrString null.
- Directly downloaded originals prove namespace-local EndpointSlice selector handling, nil skip versus retained {}, named/protocol port resolution (including restartable init containers), readiness/serving/terminating, CoreDNS ordinary/headless/endpoint paths and readiness filtering. Proxy iptables/IPVS/nftables paths remain conditional on actual deployment; Cilium values explicitly keep replacement false. Storage allocation is a separate transactional stage with configured ranges/families and genuine failure boundaries.
- Directly downloaded cloud controller source proves GetLoadBalancer first, EnsureLoadBalancerDeleted only when exists=true, deletion ImplementedElsewhere tolerance, subsequent finalizer attempt, creation finalizer-before-provider, nil status/error paths, status publication and retry distinctions. Page honestly requires external provider/controller authority, never assumes K3s ServiceLB, and does not equate status/finalizer removal with reachability/erasure.
- Product pinned links at 57ba25bb were compared with frozen affected template blobs; the four linked templates have no diff through the reviewed revision.

## Actual/unexecuted extent

Actual: frozen git archive; source reads; repository discovery; direct HTTPS retrieval of 22 original files at exact Kubernetes/CoreDNS commits; focused two-test file run in frozen copy after a dependency symlink. Both tests passed. Its first attempted run failed solely for absent yaml package; that was a tool prerequisite failure, not semantic proof. The tests establish a null render and linked records/string invariants; source review supplies semantic evidence. Helm /usr/local/bin/helm and Node v24.21.0 were used. `focused-tests.log` contains successful run output. Symlinked dependencies come from the existing repository node_modules and are tooling only, not product source authority.

Unexecuted: kubectl reads, admission/defaulting requests, EndpointSlice/controller deployment, DNS queries, kernel rules, allowed/denied probes, cloud/provider effects/deletion, deployment/live validation, publication render, interactive navigation and fresh-context reader execution. No deployment, Secrets read, live mutation, repository edit or commit occurred. External installed modes/provider inputs remain deliberately unknown; their absence does not invalidate the honest conditional source explanation.

Original source URLs and SHA256 are in source-provenance.json. The immutable reviewed Git blob inventory is frozen-git-blobs.txt; the complete archive copy is frozen/. seal-manifest.json hashes the regular frozen files, original downloads, provenance, focused log and this report; sealSHA256.txt seals that manifest. Remaining material findings in this assigned scope: F1 and F2 only.
