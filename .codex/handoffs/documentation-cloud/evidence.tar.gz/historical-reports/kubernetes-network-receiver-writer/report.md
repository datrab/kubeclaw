# NetworkPolicy and Ingress receiver-contract author report

This is an author report, not an independent Source, Reader or Quality acceptance. The only repository file written by this author is `scripts/docs-kubernetes-network-receiver-contracts.mjs`. It exports `receiverContracts` without file access, network access, process access or import-time external mutation. The export has 122 unique kind/fieldPath records: 75 NetworkPolicy records and 47 Ingress records. The array and its records are frozen. Record construction and order are deterministic. No copied OpenAPI schema node store was introduced; schema keywords and required membership remain with the existing schema-authority module.

Final module SHA-256: `34867e26cdd61a4c390d74b46d1d475d2e06c36b798377faf08d95f9fc0a67d8`.

The observed shared repository is branch `docs/documentation-overhaul`, HEAD `6fa4830a48244d29655104a5be58957d5fa87d2f`. The module remains untracked for root integration. This author did not commit, push, generate main outputs, deploy, contact a real cluster or change any existing repository file. Other authors' shared changes were left intact. This is a mutable shared authoring tree, not a clean acceptance commit.

## Authority and inputs

The documentation quality standard, AP09 acceptance contract, AP09 fixtures and CFG-009 catalogue entry were read. The full Source report and complete JSON semantic ledger were loaded; the assigned NetworkPolicy/Ingress field boundaries, work items, scalars and distinct receiving-route instances were assessed. The assignment includes recursive alternatives absent from the authored manifests. Shared metadata subtrees and ObjectMeta remain outside this module.

Kubernetes implementation sources are pinned to v1.35.0 commit `66452049f3d692768c39c797b21b793dce80314e`. The prior Source bundle's report, ledger, primary-source manifest and pinned OpenAPI bytes were checked against its artifact manifest. The pinned OpenAPI hash is `483500149ee52ce5753d75f5639101d985bb4f5e902cc05b1ba7627465d62446`; the semantic ledger hash is `0fd4f29cd5d8ec1573ea0ca428b96ef6171664eb1863704347f2da03c79c1bc9`. Each emitted upstream source link has the complete immutable commit and a line range. The private checker resolves every distinct evidence claim to its actual fetched bytes, verifies its recorded SHA-256, and rejects an out-of-file range.

Additional official sources were fetched from that same full Kubernetes commit: networking/v1 API types, generated network defaults, NetworkPolicy and Ingress storage strategies, DefaultIngressClass admission, JSON serializer, the vendored sigs.k8s.io/json decoder and wrapper, LabelSelector conversion helper, IntOrString decoder, path-segment validator and label-content validator. Their exact URLs, lengths and hashes are in `additional-sources.json`. The 404 for a guessed labels.go filename was corrected by reading the official content directory and fetching its actual kube.go; no claim uses the missing URL.

## Scope and mapping

The private independent OpenAPI traversal resolves references and recursively enumerates every spec/status property, list item and map-value path for both kinds. It found 120 paths, all matched by the authored contracts. The two additional records are kind-specific constraints at `$`, whose shared envelope remains centrally owned. This path-coverage result does not independently approve the truth of every semantic sentence.

`ledger-to-contract-mapping.json` preserves every one of the 175 boundaries from the 21 assigned non-metadata contexts. It preserves the original context, boundary name, ledger path and all 69 named work-item IDs. There are 142 boundary occurrences backed by a receiver record and 33 boundaries whose pinned schema explicitly has no item/map contract. These 33 are retained as mechanical schema absence, not invented receiver fields. Parent aliases `<API object>` map to `$`. Repeated definitions are deduplicated by kind/fieldPath while every ledger obligation remains separately mapped. No assigned mapping is missing.

`recursive-path-coverage.json` lists all 120 recursive spec/status paths individually. `contract-export.json` retains all 122 final records. `scalar-to-contract-mapping.json` preserves the 39 repeated selected-scalar appearances, representing 11 distinct scalar contexts, with exact authored instances and normalized receiver identity. Exact map keys are mapped to `[<exact-key>]` and numeric list indices to `[]`; the original instance path remains preserved.

## Authored mechanisms

NetworkPolicy contracts distinguish omitted/empty direction lists from retained empty rules, omitted/empty peer lists from rejected `{}` peers, and empty selectors from nil peer selector pointers. They explain same-namespace Pod selection, combined namespace/Pod selection, separate OR peer alternatives and AND conditions within a rule. Recursive label maps and expressions cover legal empty label values, label key/value grammar, In/NotIn nonempty values and Exists/DoesNotExist empty values. Create and old-policy selector compatibility are separate.

Both ingress and egress policy alternatives are covered, including complete peers, Pod/namespace selectors, IPBlock CIDR and strict-subset exception items. Source validation uses feature-gated legacy CIDR validation. The actual update strategy runs normal validation plus update validation; the update helper's old-CIDR exception is not presented as unconditional acceptance by the complete strategy.

Port records distinguish nil protocol default TCP from an explicit empty protocol string, numeric and quoted/named ports, all-port behavior within a selected protocol, and endPort's numeric-only inclusive range. `ports: []` is unrestricted while `ports: [{}]` defaults the retained item to TCP. Numeric limits come from the real port validator, not absent schema keywords. `policyTypes` defaults from list length, so `egress: []` does not add Egress. Explicit Egress-only, deny-all egress and the pinned validator's lack of a duplicate-item rejection are explained.

Ingress contracts cover spec parent requirements, default Service and resource backend alternatives, their names/groups/ports and all HTTP-rule/backend alternatives. They distinguish optional nil HTTP from invalid present empty HTTP, valid empty host rules, path-type-dependent empty/absolute paths, rejected path sequences and numeric versus named Service port selection. An explicit empty resource APIGroup pointer is rejected; omission identifies core. Backend syntax validation is separate from dependency lookup and controller support.

The DefaultIngressClass contract includes create-only admission, nil field versus explicit empty field, the legacy annotation bypass, no default, multiple defaults, newest-class and name tie-break selection, and lister-error Forbidden. Create-only field/annotation equality checking is distinguished from update. The actual tailscale controller and serving outcome remain unproved.

TLS contracts distinguish absent/empty lists, accepted `{}` TLS entries, invalid empty host items, optional empty Secret names and old-invalid-name update compatibility. SNI termination and HTTP Host routing remain separate. Secret existence, data keys, certificate coverage, access, load and reload are not inferred from name validation. Changing Secret bytes alone does not establish Ingress spec generation or successful rotation.

Wildcard-rule update compatibility is adjacent to every recursive HTTP/path/backend contract to which it applies. An old invalid wildcard HTTP value can cause new wildcard rule values to skip validation; host syntax still runs. This prevents the normal rejection claims from silently becoming unconditional update claims.

The recursively exposed status alternatives have their own operation scope. Normal create clears status and normal spec update preserves old status; status-subresource update preserves spec. The named hand-written validator checks nonempty IP/hostname, and has no per-port loop. Port-status type comments are not presented as proved implemented numeric/protocol/error rejection. Any broader declarative validation/admission outcome remains explicitly outside that named validator claim.

## Actual checks

- `node --check <module>` completed with exit 0.
- `node check.mjs` completed with exit 0: 122 unique records, 175 mapped ledger boundaries, 69 work-item occurrences, zero missing mappings, 120 recursive schema paths, zero missing recursive paths and 88 distinct source claims with verified hashes/ranges. Required record strings, arrays and immutable upstream URL shape were checked.
- `python3 source-probes.py` completed with exit 0. It inspected 12 named branches in the original fetched Go files. It did not execute or duplicate a Go validator, and its result is explicitly Source inspection rather than runtime PASS.
- Two independent Node imports serialized the export to the same SHA-256: `013830d8621afcfdd6a89f3bc41860a9c9d69427ca66a3df4f8f795d3d37e03a`.
- Source-bundle report/ledger/OpenAPI/manifest hashes and every cited source hash were checked. Every final line range resolves to retained bytes.

During drafting, the first range checker found a label-content range beyond the fetched file; the module range was corrected and the final check passed. The initial scalar mapper rejected a concrete quoted map key because it had not normalized exact-key paths; the private mapper was corrected and all selected scalars now map. Neither failed intermediate check is runtime or acceptance evidence.

## Proof not performed and receiving limits

No Go executable was available in this environment, so no Kubernetes defaulter, decoder, validator, admission or storage strategy was invoked. Expectations derive from the named original implementation and API type contract. There is no live create/update/null/empty/controller/Secret test result. No full mutation run was duplicated and no mirror implementation was labelled runtime evidence.

Root owns inventory lookup, coverage integration, generation and publication. Those were not run here. This report does not claim clean generation, rendered Markdown/HTML fidelity, reader task success, controlled-language independent acceptance, whole CFG-009 completion or either configuration acceptance gate. A fresh independent Source/Reader/Quality pass remains necessary.

The authored NetworkPolicy route passes its Kubernetes object through a renderer that changes only Cilium objects; the deploy path applies the combined result with a selected namespace. The optional Ingress route selects the authored tailscale Ingress file. These were read as conditional source routes; an actual invocation, namespace, client mode, current cluster objects, credentials, field managers and GitOps sync were not established. Root's contextual inventory must attach the final current route/writer evidence; this module does not replace it with inferred live permission.

All records retain separate ownership and recovery limits: omitted fields at fresh typed create are not unconditional apply deletion; client-side create prunes map nulls; server-side apply has field-manager conflicts. After an interrupted request, the resulting object must be inspected before retry. Force takeover is not justified by a source expectation.

Network enforcement, additive current policy union, traffic tests, packet-address translation, named-port realization and convergence are network-operator boundaries. Actual class/controller selection, resource-backend support, Service and endpoint readiness, request serving, TLS Secret access/certificate reload and convergence are ingress-operator boundaries. Each record states a safe stop before relying on that result and the observation needed to establish it. Status records limit the claims to the named hand-written validator; feature-gated broader validation remains a separate source/runtime qualification, never an assumed acceptance.

Writing used plain technical English with field names retained, short cause/effect clauses and explicit conditional source limits. CIDR is defined in its contracts. TLS/SNI and conventional HTTP/DNS/protocol terms remain technical vocabulary for the independent language reviewer and the canonical page's glossary. No formal ASD-STE100 certification is claimed.
