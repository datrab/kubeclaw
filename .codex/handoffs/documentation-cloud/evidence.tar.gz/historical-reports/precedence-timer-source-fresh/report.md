# Independent source review: precedence, change impact, and platform timer context

Overall assigned review: **FAIL**, because the explicitly added supplementary platform page has two independently reproduced material source contradictions. No material source contradiction was found in the two original assigned pages. This is a Source review only, not a Reader or Quality review, and not final AP09 acceptance.

Reviewer identity: `/root/a98_precedence_timer_source_fresh`. Fresh context, initially and throughout read-only against the main repository; not an author, Reader, or Quality reviewer. No subagents. No main changes, commits, or pushes. Reviewed on 2026-10-10 with Node `v24.21.0` and Helm `v3.22.0+g144ca65`.

## Exact candidate identity and scope

The complete immutable Git archive is commit `9d085bb20af0cc70201cc41801011b63c626301c`, branch `docs/documentation-overhaul`, archive SHA-256 `8889575047f31dc50552723ea779b345779a1088c206d27c945599be8baf19f1`. I independently created and extracted the FULL archive, rather than reviewing the mutable main tree or other writers' files. All archived regular files still match the archive after execution. `identity.json` records this check. This integrity check establishes identity, not semantic acceptance.

Read in full: `docs/blueprint/07-documentation-quality-standard.md` (257 lines), `docs/blueprint/AP09-acceptance-contract.md` (466 lines), `docs/site/reference/configuration-precedence.md` (471 lines), and `docs/site/reference/configuration-change-impact.md` (310 lines). Reviewed catalogue entries CFG-013 and CFG-014, contextual CFG-009, the fixture structure and matching entries, A98-10 named timeout semantics only, and A98-11 source partition for both complete pages. Catalogue/fixture extracts are in `assigned-catalogue-and-fixtures.json`; the complete fixture and catalogue are retained in the FULL archive. No matching static fixture constitutes a executed acceptance run.

The root explicitly added a supplementary frozen page after the base archive review started: canonical `docs/site/reference/pipeline-platform.md`, copied as `pipeline-platform-supplementary.md`, SHA-256 `9ab8e318fa7ccbd13c3d1562e02c0d4b1613232c4eaed9d78df0ba77ac94d17a`. The exact hash matched the assigned value. Read its full 183-line context and reviewed its shutdown field as an added CFG-002 Source subset. This is an explicit working-page overlay, not a relabeling of the historical whole candidate. The original archive retains its original version of this page.

## Separate per-ID and partition verdicts

| Item | Source verdict for actual assigned scope | Limit |
| --- | --- | --- |
| CFG-013 | PASS: complete `configuration-precedence.md` source review | Whole family inventories, final rendered output, Reader and Quality review are UNPROVEN. |
| CFG-014 | PASS: complete `configuration-change-impact.md` source review | Full runtime recovery, live changes, rollout, drain and migration execution are UNPROVEN. |
| CFG-009 | PASS for contextual local Helm merge/receiver subset present in the two assigned pages | Complete Helm/GitOps/infrastructure inventory is outside scope and UNPROVEN. This is not a whole CFG-009 PASS. |
| CFG-002 | FAIL for added supplementary whole-page Source context: findings S1 and S2 below | Shutdown row42 itself passes the named timer subset. Complete recursive CFG-002 inventory is outside scope and UNPROVEN. |
| A98-10 | PASS for named `shutdownTimeoutMs` / `effectLockTtlMs` Source semantics partition only | Complete recursive configuration inventory gate is UNPROVEN. |
| A98-11 | PASS for Source partition on the original two complete pages | Whole gate, all families/consumers, Reader/Quality and final publication remain UNPROVEN. Supplementary page context fails independently and blocks the combined review. |

No whole AP09.8, AP09, publication, generated-output, controlled-language, mutation, Reader, target-image, deployment, or Live gate passes from this report. Current shared generated and rendered outputs are stale for acceptance purposes and were not accepted or imported. Historical author test summaries were not used as proof of the assertions reviewed here.

## Material finding S1: `activeAdapters` is not the exclusive activation set

**FAIL location:** supplementary `pipeline-platform.md:38`, `activeAdapters` row: “Only these adapters activate.”

The source first enables graph owners, configured observers, and `activeAdapters`, then recursively enables the selected provider of each required capability. The final enabled set can therefore contain a provider adapter absent from `activeAdapters`. Configuration alone still does not activate an adapter; that separate statement remains true.

Full dependency chain at base commit:

- `skills/nova/core/execution/engine-runtime.ts:34-41`: initial enabled registrations → `resolveCapabilityGrants` → configuration validation → `activateRegistry(...new Set(granted.grants.keys()))`.
- `engine-runtime.ts:44-50`: seeds graph stage owners, observer keys, and explicit active adapter IDs.
- `skills/common/plugin-runtime/foundation/registry/capabilities.ts:149-159`: `enableProviders` recursively adds selected provider IDs for requirements of every enabled registration.
- `capabilities.ts:183-216`: uses expanded enabled set, creates grants entries for those registrations, exposes that set in the GrantedRegistry.
- `skills/common/plugin-runtime/foundation/registry/activation.ts:125-136`: loads adapter registrations from the final enabled set.
- `skills/nova/core/execution/adapter-startup.ts:25-28`: starts each adapter in `granted.enabledRegistrations`.

**Independent execution:** `node supplementary-probes.mjs`, exit0. A synthetic original-registry package had one graph stage requiring `runtime.dispatch`, a selected adapter provider, a valid stage grant, and `activeAdapters: []`. `prepareRuntime` included the provider in both enabled and activated registries. `AdapterRuntime.start` executed its synthetic factory once. The runtime shut down normally. No effect or external operation ran.

**Required correction:** Describe `activeAdapters` as explicit activation roots, and state that required capability providers and their dependencies are enabled recursively. Retain the distinction that an `adapters` config entry alone does not activate one. Link the actual provider enablement and startup sources beside the claim.

## Material finding S2: registered disabled adapter values are not all schema-validated

**FAIL location:** supplementary `pipeline-platform.md:37`, `adapters` row says registration configuration validation checks each value against the installed adapter schema, without the enabled-registration condition.

**Source:** `skills/common/plugin-runtime/foundation/registry/configuration.ts:53-61` checks every configured adapter ID exists in the registry. `configuration.ts:73-81` skips disabled adapters and validates schema only for enabled ones. `engine-runtime.ts:37-40` hands the expanded enabled set to that function. Adapter startup additionally validates the enabled consumer's config at `adapter-startup.ts:50-53`.

**Independent execution:** same `supplementary-probes.mjs`, exit0. A registered adapter schema required `mode`, if present, to be a string. With no required capability and `activeAdapters: []`, `{mode:5}` passed `prepareRuntime`; the adapter remained disabled. With the same config and `activeAdapters:[id]`, `prepareRuntime` rejected with `REGISTRY_RESULT_INVALID`. This is a source-derived negative proof, not successful invalid adapter operation.

**Required correction:** Distinguish validation of all configured registration IDs from schema validation of enabled registrations. Warn that invalid disabled adapter configuration can remain latent until activation. Apply the corresponding observer condition if describing that family generally. Preserve existing closed-envelope and enabled-registration checks.

## Main-pair semantic results

The governing consumer-local rule agrees with the actual loaders: there is one platform file, canonical-directory path resolution, immutable loaded values, no project/platform merge, and unchanged stage/observer/adapter configuration validation. Provider resolution clones authored config and inserts schema defaults in the clone. The approval parser applies its own `??60` fallback; its schema rejects empty/zero values. The direct-command provider's absent arrays/environment and `CI:true` insertion agree with its code, and the shipped command-runner rejects any environment payload. Buster's generated startup expression uses `||2`, including the stated empty-string and nonempty `"0"` distinction. The observer's registration/service/hook merge ignores only undefined, selects defined config before environment, then normalizes; empty/null host does not fall back to environment afterward.

Test suite resolution matches the full affected composition: recursive object override, array/scalar replacement, fixed provider contract under node overrides, separate evidence merge, suite-add collisions even after exclusion, direct-node collisions, matrix merge before cloned provider default resolution, rejecting maxima, minimum suite concurrency, and scope narrowing that cannot widen the suite limit. Original suite-resolver contract execution passed locally (10 nodes, 2 links), with its synthetic registry and no provider execution.

Compact expansion matches the actual expander and caller: exact fixed feature/tuning/profile input, closed top-level compact fields, supplied context inserted before known-path recursive overrides, array/null replacement, original-root placeholder substitution, and missing/whitespace-root rejection. Noncompact input passes through. The real run builder supplies roots/run ID before expansion and then normalizes, reassigns the run ID, selects its webhook, clamps gateway health timing, and applies scenario changes. Those complete builder operations were read from original source, not executed; the helper probes cannot prove the builder or deployment result.

Helm merge and receiver claims independently passed: left-to-right files, recursive maps, whole-array replacement, `{}` retention, checked `null` selector removal, reversed files, repeated same-kind `--set`, exact pod environment/selector/resource receivers, synthetic Secret name/key reference, gateway URL fallback, and three file fallbacks. Prism baseline and collection/image-policy rejection paths and GitOps group/revision guards behaved as documented. Init copies/normalization, conditional persistence of Semgrep/ESLint, startup webhook replacement, selected checksums, Prism startup snapshot/signing-key capture, and GitOps reconciliation settings were checked from original templates/loaders only. No live process or credential was inspected.

The platform timer correction is sound. Original schema requires `shutdownTimeoutMs` integer ≥1 and has no max; original loader accepts 2147483648. Node's version-specific official timer page confirms overflow to1ms. Original startup and normal shutdown paths independently produced the overflow warning and rejection; the 2147483647 startup check completed promptly and cleared the timer without measuring the full delay. Invocation cleanup races rejection against the operation and cannot repeat its allowance. Failed-readiness teardown and late cleanup send timed abort but await settlement: the host's promise remained pending after abort until I explicitly released the synthetic adapter. The same abort-only character of rollback was source-checked, not separately executed.

Original coordinator and durable invocation passed actual captured-duration checks: absent300000, minimum60000, maximum86400000 are supplied to acquisition/renewal, with interval `max(1,floor(TTL/3))`. Actual memory journal and lock manager were used; the interval callback was deliberately driven through a synthetic scheduler instead of waiting60seconds or longer. This verifies duration propagation and interval arithmetic, not production expiry or cross-process lock recovery. Every interval was cleared and lock released.

Prepared/persisted authority excludes both platform timeout fields and includes providers, grants, adapters, activeAdapters, observers, optional isolation. Timeout-only edits passed the original package and graph pin checks without rewriting the snapshot; changed adapter configuration rejected the runtime subset check, and changed stage execution timeout rejected the graph digest check. The original CLI → recoverPipeline → supplied platform → fresh adapter/effect construction chain retains run ID and selects current timings after other gates. Terminal-run, wait/signal, cooldown, unresolved effect and external-continuation stops remain separate. Full recoverPipeline/resumePipeline and actual interrupted effects were not executed. Graph/package drift and conservative change/drain/rollback boundaries in the two pages agree with these source distinctions.

## Execution and evidence limits

`validation-commands.json` retains exact commands, working directories, exits, artifacts, first failures, correction causes and rerun results. Each Helm command/argv and expected error is separately retained in `helm-evidence/commands.json`, with input YAML and stdout/stderr. No full mutation duplicate, full acceptance check, pipeline run, cluster, native sandbox, host prep, external request, credential, rollout, admission, reconciliation, restore, rotation, decommission, or live recovery ran. No deployment success is inferred from local renders.

Third-party dependency provenance is disclosed in `dependency-provenance.json`: existing ajv and its dependencies, plus yaml, were copied into the archive extraction; workspace symlinks resolve back into the archived candidate. No mutable main implementation was loaded. The archived observer sync script generated its ignored contract import from the archived tracked contract, which was absent in the FULL Git archive. It did not alter tracked files. That setup dependency is part of reproducing these synthetic probes; this report is not a clean Reader baseline acceptance.

First failures are preserved: initial missing path/environment reads in `initial-failures.txt`; missing generated observer import in `probes-first.stderr`; reviewer synthetic pipeline/manifest omitted required fields in `probes-second.stderr` and `probes-third.stderr`; wrong reviewer Helm container lookup in `helm-first.stderr` and complete `helm-first-evidence`. The final probe script passed18 groups. These fixture/setup errors were corrected only in private evidence scripts, not in product code or docs. Synthetic temporary directories were removed; every pending synthetic promise was explicitly released, every adapter runtime was shut down, and every test timer/interval cleared.

All pinned source excerpts from the two pages and overlay are retained with comparison results in `all-source-pin-comparison.json`. They matched the candidate's actual bytes and valid ranges. Narrow original sources for the findings and timer/recovery paths are in `narrow-source-evidence.txt`. These mechanical comparisons are identity/reference support; the semantic verdicts above rely on source reading and independently executed assertions, not pin counts or hashes. The official Node source used was [Node.js24.21.0 Timers](https://nodejs.org/download/release/v24.21.0/docs/api/timers.html#settimeoutcallback-delay-args).

## Freeze release

Review of the exact base archive pair and exact supplementary overlay is complete. **The freeze on all three reviewed main pages is explicitly released.** Root may now correct S1/S2. Changes require a fresh affected Source review; this FAIL is not cleared by author commentary or by a green generator. Artifact hashes and the report's SHA-256 are provided separately so the report does not claim its own circular hash.
