# Canonical dependency-installation prose correction

Writer: `/root/installation_eof_optional_prism_batch_writer`. Root authorized one narrow maintenance prose correction; no independent acceptance claim.

Read actual `scripts/check-operator-task-registry.mjs:158–171` and the surrounding release-checkout procedure plus canonical Locked Dependency Installation. The unchanged checker requires each linked task page to link the canonical safety contract and prohibits repeating its literal installation command. Maintenance repeated that command in prose, causing the actual gate failure.

Edited only `docs/site/use/maintenance.md` at the release-checkout handoff: use plain English for locked installation in the disposable checkout; retain the canonical link, registry identity, lock digest, tool versions, result, and subsequent GitHub authority conditions. No product, tooling, task registry, generated output, commit, dependency installation, cluster or network operation. Other two pages remain byte identical; maintenance's unrelated content and former-Qdrant section are byte identical by reversal comparison.

Terminal command `python /home/node/Documents/Codex/a98-evidence/install-task-canonical-command-correction-writer/check.py`: exit 0. Exact unchanged checker excerpt against private initial page copies returns 1 with the documented duplication assertion; corrected copies return 0. This is the real canonical-installation rule only, not a complete operator-task checker or generated-inventory result. All 49 Bash examples across three pages pass syntax checks. The canonical link file/heading exists. No executable block or other link changed. Detailed inputs, stdout/stderr, exact excerpt, focused diff, before/after snapshots and preservation records retained.

Frozen pages:

- install.md: 75100 bytes; SHA-256 `b05606ae8eef0344ceab47ea3055d5f3e1b0b463dcdae4984a476d2b4f0d644d`.
- worker-trust.md: 28663 bytes; SHA-256 `c42a770a6967cf44d7b1fc3c8f06c8d2e1b2bbfc29eb5ceb369569c916e57ca1`.
- maintenance.md: 76640 bytes; SHA-256 `e9042aa685979808dbd41d6c57c2e445f10fef74127e60b71997af6520a3fff7`.

Root owns complete registry/generation checks. Syntax and local rule checks do not prove live product execution or independent Source/Reader/Quality acceptance. Manifest excludes itself and records exact bytes/hashes of every retained artifact.
