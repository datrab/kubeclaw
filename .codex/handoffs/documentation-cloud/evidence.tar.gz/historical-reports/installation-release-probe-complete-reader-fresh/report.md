# Fresh Reader review: installation, linked release acquisition, and disposable probe

Result: **FAIL for the assigned documentation scope**, because the selected-scope authorization gate can silently omit a required plan row. All other listed facets below pass this bounded Reader review. This is neither full READER-OPERATOR-01 execution nor Source, Quality, package, live, retirement, or global AP09 approval.

Reviewer: independent child agent `/root/installation_release_probe_complete_reader_fresh`. Fresh-context review; no prior author/reviewer summaries were used. Actual install and linked maintenance pages were read first, before the quality standard, acceptance contract, fixtures, catalogue, and current implementations. Repository remained read-only throughout. Only private evidence and synthetic/local fixtures outside the repository were written. The initial task supplied the frozen revisions and scope, not prior findings.

## Frozen evidence identity

Repository: `/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04`, branch `docs/documentation-overhaul`, HEAD `d68da902c174574d1186ffd4a3ff29e95b63474e`.

Actual edited page bytes, not HEAD versions:

- install.md: SHA-256 `60fff6c2df19bedc3f027850013f8c69f83d8cf0a03de63b7edf3720a067489b`.
- maintenance.md: SHA-256 `e6d219a7bf5b54c4b98658ff50a41945aac8e53779c834f3d44e99e4bab28b44`.

`before.json` and `after.json` record byte counts/hashes for both pages and 18 primary/contract sources around extracted-command executions; they are identical. `additional-primary-sources.json` records extra inspected sources. `final-primary-sources.json` checks all of those again at completion. The repository already had unrelated/assigned dirty changes; this review did not repair or alter them. `frozen-pages.json` records that boundary.

## Necessary correction

**R1 — required authorization row skipped at EOF**

Path: `docs/site/use/install.md:449` (loop through line 455), with format authority at lines 419–427 and expected complete check at lines 486–493. A reviewed UTF-8 authorization file is described as one space-separated row per operation; a terminal newline is neither required nor checked. Bash `read` assigns the last row but returns nonzero at unterminated EOF. The loop body therefore never validates or calls `require_authority` for that row. A one-row file can omit the whole selected-operation plan while the hardcoded probe/ownership checks still pass.

Independent reproduction used the exact extracted block and actual ownership script, with private mocked Kubernetes reads/permission responses. `delete secrets kubeclaw\n` is denied and exits 1 with `AUTHORITY_DENIED`; the same row without the final newline exits 0 and never asks that denied permission. This is not a live RBAC result. It proves the documented shell gate omits a required check, rather than failing closed.

Evidence: `auth-plan-fixture.py`, `terminated-authorization.bash`, `unterminated-authorization.bash`, their exact input files and call lists, and `auth-plan-fixture-results.json`.

Correction: process a populated final row even when `read` reports EOF, or explicitly reject missing final newlines before entering the loop. Preserve field/verb/resource/scope validation and deny handling. Recheck empty file, blank/malformed rows, terminated/unterminated valid final rows, and a denied final row. No repository edit was made by this reviewer.

Acceptance authority: the quality standard's exact ordered actions and stop-before-mutation requirements, AP09 A98-02/A98-03/A98-13 for the assigned installation facet, and OPR-002/OPR-003. They cannot pass this facet merely because runtime selection is currently absent: the document publishes an executable gate for an accepted future selection.

## Assigned facet results

| Facet | Reader result | Authority and observation |
| --- | --- | --- |
| Canonical installation route and scope | PASS | use/README.md canonical task map; generated operator-tasks.json installation entry; install.md:18. One authority, existing independently recoverable cluster, ordered gates, no hidden host/K3s installer. OPR-001/A98-01 assessed for this assigned route only. |
| Supported prerequisites and platform boundaries | PASS | install.md:50, 118, 133, 152, 239, 318, 506; use/README.md version boundary; quickstart locked dependency procedure. Existing API/host/CNI/storage, Node 24/npm, Go observation, version acceptance, explicit release requirement, independent recovery, registry/node owner prerequisites are visible. Missing compatibility, host bootstrap and node installer remain product work with safe stops and owned removal conditions; they do not waive command review. |
| Release acquisition and change authority | PASS | maintenance.md:553–610 and actual promote-runtime.yaml/build-images.yaml/auto-promote-runtime.yaml. Correct workflow display names, family/source_run_id, main successful push/dispatch source run/attempt, persistent receipt, GitHub App setup, read/write authority, scan before PR, review/merge and GitOps automatic-deployment boundary, partial-branch retry reconciliation. No workflow dispatch was performed. |
| Exact clean selected checkout versus image/code commits | PASS | maintenance.md:611–698; actual verify-release-source, deployment-release, materialize-release, release-configuration and code-release. Exact accepted checkout commit is separate from image/build and optional code commit; clean detached checkout; remote receipt verification ownership; --check instead of installer repairs; byte/file-set configuration comparison and separately approved documentation successor. Local exact-checkout fixture uses distinct synthetic build/selection commits; actual configuration/deployment tests passed. |
| Nonmutating selected-scope authorization gate | **FAIL R1** | install.md:373–505 correctly inventories distinct probe/application/Prism/SPIRE/Tailscale/Secret-source/cluster/provider rights and subresources, but line 449 skips an unterminated final plan row. Hardcoded checks cannot cover every selected rendered operation. |
| Actual all-namespace ownership guards | PASS | install.md:467–493; gitops-owner.mjs:14–27 and deploy.sh render/deploy branches. Actual implementation fixtures prove outside-argocd Application ownership rejection, retained workload ownership rejection even after CRD absence, malformed annotation/denied CRD failure, and successful optional CRD absence. The guard checks application and separately selected Prism namespaces before effects; role render returns before its later mutating-path guard. |
| Positive disposable DNS/storage task | PASS | install.md:519–825. Explicit image/class/request, creation UID, partial apply receipt, guarded waits/capture, expected Bound/Succeeded/log marker, subsequent owned cleanup. Exact extracted success fixture completes and emits UID-precondition DeleteOptions; YAML was fed as exact command stdin to fixture, not submitted to Kubernetes. Alpine BusyBox availability, actual image pull, DNS and storage were not executed. |
| Probe partial/uncertain states and evidence | PASS | install.md:565–840. Exact fixtures cover apply response loss with PVC present and Pod absent; PVC timeout/Pending/no PV/no started-container logs; namespace-create response lost; namespace UID read denied; denied Pod capture; replaced namespace UID. Results preserve separate run/capture status and retain resources, never infer denied reads as absence, never look up empty PV names or require logs from an absent/unstarted Pod. |
| Owner/provider identity and cleanup boundary | PASS | install.md:547–564, 842–945. Bound and in-progress/unbound provisioning require owned reconciliation; clearance must match creating namespace/PVC/PV UIDs and CSI handle when present; approval JSON shape is explicitly not approval authentication. External provider proof is separate from API/PV absence. No invented universal provider cleanup. |
| Raw namespace DELETE and absence/wait interpretation | PASS, bounded transport/contract | install.md:890–945. Actual installed kubectl v1.34.11 sent DELETE to isolated localhost HTTP fixture with exact namespace path and UID-precondition body. This proves client transport only; fixture does not enforce Kubernetes preconditions. The document separately requires selected-client acceptance, preserved nonzero exits, successful empty named snapshots, PV observation, provider proof; deletion wait timeout fixture exits 1 without automatic repeat/force/finalizer stripping. |
| Repetition, installation order, failure and rollback | PASS | install.md:826–945, 946–1167; maintenance.md:28–64, 746–787, 880–894. Failed probe remains failed after cleanup; next run requires new name/evidence and corrected owned cause. setup prepares Helm repos and Secrets; identity namespaces precede infra. Dependency/readiness/smoke/trust precede final result. Failed resources/evidence retained; no broad teardown as install cleanup; atomic-agent history and data-compatible rollback only. Unsupported takeover/upgrade pairs stop explicitly. |
| Four readiness levels and final evidence | PASS for identification | install.md:40–48, 1042–1110, 1168; operate.md:15–91. Process rollout/Pod, Service ready endpoints, component dependencies/smoke, functional terminal transaction/audit/receipts are distinct; identity trust requires positive and negative proof. No live readiness or transaction execution claimed. A98-04 assessed for linked identification, not complete operate package. |
| Practical placeholders, paths and scopes | PASS apart from R1 input format | install and linked maintenance/registry procedures plus shared placeholder table. Exact namespace validation and read-only exported authority, private new paths, explained UIDs/PVs/PVCs/receipts, configuration/Secret/provider ownership and checkout locations support fresh Reader reasoning. Registry render-file capture is available in maintenance Render and Compare; it is not a hidden source operation. |
| Evidence truth and retirement preservation | PASS for assigned boundary | Local/source/installed-client/contract/live classes remain distinct. maintenance retirement section was read as surrounding material but neither exercised nor accepted; no three-role/global retirement approval is issued. |

A98-02/A98-03/A98-13 and OPR-002/003 do not pass the complete assigned executable installation scope until R1 is corrected and rechecked. Other facet PASS results are individually bounded; they are not a package or gate ledger update.

## Checks actually performed

- Read actual frozen pages first, then applicable quality standard, AP09 acceptance contract/fixtures, OPR-001/002/003 catalogue, operator task registry and linked task pages/current source implementations.
- Extracted every install Bash block and checked Bash syntax; retained exact extracted text.
- Executed eight exact probe fixtures: success/cleanup; Pending PVC wait timeout; partial apply response lost with no Pod; denied Pod capture; replaced namespace UID; uncertain namespace creation; denied namespace UID read; deletion wait timeout. Only fixture resources were written outside the repository.
- Executed actual source functions for absent runtime selection, frozen runtime configuration bytes, and six ownership cases.
- Ran independently `node --test tests/verification/deployment/release-configuration.test.mjs tests/verification/deployment/deployment-release.test.mjs`: exit 0, 11/11 tests pass. Tests create local synthetic Git/Helm fixtures outside the source repository and mock kubectl to reject cluster access. Parent tests were not counted.
- Executed exact selected-checkout block with a local synthetic Git origin, full accepted selection commit distinct from build commit, detached clean checkout and receipt-file gate. It does not claim authentic release receipt contents.
- Exercised real installed kubectl raw DELETE against an isolated localhost HTTP endpoint and retained version/request/body. Initial HTTP harness failed to decode chunked transfer; fixed the harness and reran successfully. Initial harness failure retained separately; no product correction or live-delete claim.
- Executed exact authorization-plan block against denied final-row inputs; observed R1.
- Compared primary-source/page hashes before/after; no reviewed bytes changed.

## Not performed and explicit limits

No live cluster, cluster credentials, provider lookup, image pulls, actual DNS/storage/CSI/admission/RBAC, real namespace deletion, readiness/smoke/trust/functional transaction, host/node bootstrap or rollback was exercised. No GitHub network request, workflow dispatch, PR/comment/message, scan, merge or real receipt authentication occurred. No npm ci or generated-documentation aggregate gate was run in the shared dirty repository. Node/client fixtures do not establish accepted Kubernetes versions or provider disposition. No full READER-OPERATOR-01 participant attempt was performed: its Ubuntu-without-cluster/DNS-fault setup and facilitator rules differ from this bounded read-only documentation review. No Source/Quality or role-independent global acceptance is inferred from Reader fixtures.
