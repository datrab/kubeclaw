# Independent fresh-context Reader report: Prism/Studio

Reviewed revision: `fe426bd75db277b04cf405cc2057063b75fa0a1d` (resolved before archive).
Product evidence pin: `ec2a42ed215a2fa7dbd3172ef70ef446084963a9`.
Date: 2026-10-10 UTC.
Identity: `/root/a98_prism_reader_after_browser_fresh`; role `reader`, independent of the author, Source reviewer, and Quality reviewer. Root records the spawn as `model=gpt-6.1-sol`, `reasoning_effort=high`, `fork_turns=none`. Those are requested tool parameters; an exact runtime model identity is not independently introspectable here. No full-history fork was supplied. Initially and throughout read-only for the candidate: no main-tree edits, commits, generation, shared mutations, product repair, release fabrication, native execution, or cluster/live action.

Verdict for the assigned Prism Reader partition: **FAIL**. One material prerequisite contradiction remains. The revised fixed-browser limitation passes its bounded documentation exercise. This report gives no global gate, package, publication, or product-operation acceptance.

## Scope and reader boundary

Read the complete 1,759-line `docs/site/use/prism-studio.md`, the complete quality standard and acceptance contract, relevant immutable fixture entries, the OPR-010 catalogue entry, canonical locked dependency installation, cluster/version binding, Nova run audit/signal/interruption boundaries, Prism backup/restore/upgrade/decommission boundaries, operator routing, and current Prism issue/status sections. Sources and original tests were read as evidence; no package README or old review report was needed to perform the reader task. Earlier reports named in the assignment were not reused as proof.

The catalogue requirement is **OPR-010**, owner **Prism maintainers**, canonical target `docs/site/use/prism-studio.md`, work package **AP09.4**. It is reviewed here as the cross-package A98 Prism partition, not reassigned to AP09.8. Its Reader verdict is **FAIL** because setup prerequisites remain contradictory; the design-to-Nova path, failures, concurrency, and recovery were nevertheless reviewed in full.

The contract permits complete, accurate documentation of a real product limitation. `EXEC-PRISM-JOURNEY` and `READER-OPERATOR-01` through `04` are post-documentation product validation; they were not run and are not marked passed. Local bootstrap, launch errors, and focused checks remain local evidence. They are not deferred live evidence or successful aggregate evidence.

## Material finding R-CSI-01

**FAIL — conditional prerequisite contradicts the maintained deploy guard.**

Frozen page `docs/site/use/prism-studio.md:151` says: “SPIFFE CSI support when the selected deployment enables worker trust.” That allows a reader to infer that the CSI driver is unnecessary with worker trust disabled. In the current source, `scripts/deploy.sh:1759` calls `require_spiffe_csi_driver` unconditionally, before `cmd_prism_secrets` at line 1760. The helper at lines 974–981 always checks `CSIDriver/csi.spiffe.io` and returns failure if it is absent. No selected Prism trust-mode condition controls that guard.

The canonical entry at page lines 22–25 already requires SPIRE/CSI, and deployment-order prose at lines 477–490 includes the CSI check. These statements do not make the incompatible secondary prerequisite accurate. An operator should not have to resolve contradictory prerequisites by inspecting the deployment implementation.

Necessary correction: make the maintained deployment's SPIRE/CSI prerequisite unconditional in `Before You Start`; explain that the deploy command checks the CSI driver even when the selected chart disables SPIFFE worker authentication. Preserve the separately documented HMAC/SPIFFE readiness behavior. Use the pinned guard/helper as narrow evidence. Do not change the product guard merely to satisfy the text.

Source evidence:
- https://github.com/datrab/kubeclaw/blob/ec2a42ed215a2fa7dbd3172ef70ef446084963a9/scripts/deploy.sh#L974-L981
- https://github.com/datrab/kubeclaw/blob/ec2a42ed215a2fa7dbd3172ef70ef446084963a9/scripts/deploy.sh#L1757-L1760

No cluster command was executed to provoke this admission guard. This finding is an independently read prerequisite/command contradiction, not a claimed live failure.

## Assigned gate partitions

| Requirement | Prism Reader verdict | Concrete evidence and limits |
| --- | --- | --- |
| A98-02 | FAIL | Purpose, location, authorities, selected source/release versions, exact commands, observations, stop/recovery/cleanup/evidence are present at page 17–112, 143–555, 1148–1478, 1479–1688. R-CSI-01 makes the required deployment prerequisites inconsistent at line 151. Correct that prerequisite; no other material Reader defect found in this partition. |
| A98-04 | PASS | Page 502–554 and 1401–1414 distinguish process `/health`, native `/bootstrap`, HMAC nonce-database `/ready`, SPIFFE `/ready` without nonce query, Control `SELECT 1`, PostgreSQL readiness, and functional journey. Read actual `worker-service.ts:72–105`, `worker-readiness.ts:8–10`, `control-server.ts:143–147`, chart probes `workloads.yaml:157–162`, and deploy smoke `deploy.sh:1802–1811`. Focused Helm check passed. Original chart fixture initially failed its namespace precondition; explicitly bound render-only rerun passed. Native PG readiness was skipped, and no live readiness/functional result is claimed. |
| A98-06 | PASS | Complete diagnosis map at 1441–1470 connects observable launch/session/project/job/revision/preview/evaluation/approval/publication/resume/archive/worker symptoms to retained evidence and safe action. Recovery at 1148–1440 distinguishes lost response from rollback, original identities from new work, native ownership from HTTP process health, and duplicate approval/restore from replay. Fresh direct browser errors, release-stop result, TCP refusal fixture, client loss/error fixtures, embedded decision/round/storage fixtures, session negatives, and artifact failure fixtures support the bounded local observations. No blanket restart or uncertain external replay is authorized. |
| A98-12 | FAIL | The whole intended Prism journey at 555–1120, approval/bundle identity at 980–1147, abort/resume/cleanup at 1150–1400, status boundaries at 555–576 and 1689–1714, and final checklist at 1737–1759 accurately separate implemented, source-only, fixture-only, unavailable, and live-unexecuted steps. The local browser boundary passes. R-CSI-01 remains a setup prerequisite defect, so the complete setup-to-human-acceptance partition cannot pass yet. No complete live journey is claimed. |
| A98-13 | FAIL | A fresh technical reader can identify authorities, commands, observations, stop/recovery boundaries, and unsupported controls from the published page and canonical links. Actual bootstrap and bounded failure exercises were reproducible without maintainer assistance. The conflicting CSI precondition still requires implementation reading to resolve; correct it before fresh full-affected-path re-review. Live operator executions were not required or claimed. |

Each verdict is only the assigned Prism portion. A PASS here cannot close another procedure, Demo Delivery, another review role, or the entire gate.

## Complete page and interruption coverage

| Frozen page lines | Critical reader content reviewed | Current source/fixture evidence |
| --- | --- | --- |
| 1–142 | Status, two-phase task, cluster binding, stop at absent release, evidence authorities, responsibility handoffs | `deploy.sh`, materializer, Nova `stage.ts`, Control admission and bridge |
| 143–421 | Setup, selected values/overlays, Secrets, runtime process inputs, agent and stage configuration | Current deploy admission/overrides, Control/Studio/worker loaders, chart values/templates, stage closed schema; R-CSI-01 |
| 422–554 | Render, setup/Secrets, deployment order, rollback limits, status/smoke and health layers | Deploy contract passed; original chart render fixture plus explicit namespace rerun; exact worker/Control/nonce/probe/smoke sources |
| 555–644 | Per-step execution status and all 13 interruption operations | Original client retention, component lifetime/error screen, decision/preference receipts, revision/restore storage, native operation receipts, approval/baseline writes, Nova wait/signal guards |
| 645–811 | Governed project, trusted session, exactly three directions, selection/feedback, child round | `stage.ts`, Control dispatch/session/directions routes, `design-generations.ts`, `direction-decisions.ts`, agent admission, round helper and original embedded/HTTP fixtures |
| 812–979 | Typed and natural-language revisions, history/restore, preview, exact-revision evaluation | `app.tsx` commit/restore/revision/evaluation, helper, repository CAS/history, preview/assets/flows, evaluator and native operation storage |
| 980–1147 | Separate human approval then publication, bundle members, unsigned authorized CLI signal, Nova archive verification | `app.tsx:350–405`, Control `521–797`, SQL approval/baseline uniqueness, Nova `stage.ts` and `archive.ts`, canonical archive assembler |
| 1148–1440 | Stop/abandon, child/revision/edit/restore/preference/approval/publication/resume interruptions, worker/migration/artifact recovery | Current source paths read; 21 passing original health/interruption fixtures, 7 passing session/artifact fixtures; no usable browser recovery or uncertain external replay inferred from helper tests |
| 1441–1478 | Symptom map and canonical backup/restore/removal boundaries | Diagnosis evidence surfaces, immutable artifact reader/writer, current canonical recovery/maintenance limits |
| 1479–1688 | Tools, clean locked installation, five-tree bootstrap, package-local CLI/browser selection, fixed-path STOP, direct failures, aggregate short-circuit, focused checks | Independent actual installs, lock digests, installed registries, CLI dry-runs, exact STOP, 12 + 3 launch failures, script order, focused deploy/Helm checks |
| 1689–1759 | Implemented/unavailable capabilities, developer routing, complete handoff checklist | Whole journey/source review; no live/native/browser/aggregate acceptance fabricated |

All 13 interruption operations from the page's table were checked individually:

| Operation | Evidence and reader conclusion |
| --- | --- |
| Nova architecture dispatch | `stage.ts:20–34`, Control `214–240`, round store and source transition fixtures: retain original run/architecture; new architecture is new work. |
| Studio session renewal | Control `152–172`, session implementation and two original session tests: same trusted user, new session/CSRF; session does not reconcile writes. |
| Child round | Round helper `8–48`, app startup and `332–348`, current admission: retain exact storage/key/generation; source/fixture replay does not recover missing storage. |
| Direction select/reject | Component-memory keys, decision receipt transaction and four decision fixtures: exact replay differs from fresh key; error UI hides controls. |
| Direction feedback | Receipt event identity/deduplication and original tests: a new key creates another event; selected direction alone is not its feedback receipt. |
| Typed edit | App `161–183`, domain base revision, repository `262–293`, embedded domain/storage fixture: reload/history before any new edit; stale original operation can conflict after commit. |
| Natural-language edit | App pending/error paths, revision helper and original dropped-response/NeedsNova fixture: retained helper job is distinct from accessible browser recovery. |
| Undo/history restore | App `232–248`, repository `211–260`, embedded restore fixture: each successful restore creates a new revision; no blind repeat. |
| Preference retraction | App `250–275`, exact wire-event/owner replay in preference storage and Control history: fresh click creates a fresh event; reconcile before mutation. |
| Evaluation | App `406–442`, immutable requested revision, native operation input/result guards: unchanged exact input and known ownership only; no native attempt was executed. |
| Human approval | App `350–405`, Control `521–565`, SQL uniqueness: approval commits separately; lost ID and duplicate digest are stop conditions. Exact source inspection, no new approval HTTP exercise claimed. |
| Baseline publication | Control early same-approval result lookup, current authority checks, approval-bound capture IDs, artifact-before-row order: original ID/receipt required; no browser retry/control or publication success claimed. |
| Nova resume | Original `engine-run.ts:84–122`, canonical run-control audit/signal procedure and stage archive verifier: audit original wait/run; resolved or terminal waits can reject unchanged retries. No real signal invocation claimed. |

## Independent executed checks

All commands ran in `execution/`, a separate detached clone at the exact candidate. Initial and final tracked worktrees were clean. `snapshot/` is an independent `git archive` of the candidate, not a copy of the dirty main working tree. Canonical command texts, UTC timestamps, stdout/stderr, and actual exit codes are stored under `logs/`; dependency output is stored under `dependency-evidence/`. The Python harness itself exits successfully after capturing the command; the command's real result is its JSON `exit` field, not the harness process exit.

Environment: Alpine Linux 3.24.2 x86_64/musl; Node v24.21.0; npm 11.19.0; Bash 5.3.9; Helm v3.22.0; Git 2.54.0. OpenSSL is absent and its prerequisite was not silently supplied. npm used the existing package cache with `NPM_CONFIG_OFFLINE=true` and `NPM_CONFIG_CACHE=/tmp/kubeclaw-prism-npm-cache`. This validates the documented locked install with a complete cache, not registry networking or installation on a different host. No browser downloads or host library installation were performed. Only non-secret environment selectors were recorded.

| Log | Actual command result | Observation |
| --- | --- | --- |
| 01-canonical-locked-install | exit 0 | Canonical Quickstart locked install passed, completed npm installation, before/after tracked status empty and identical. Registry selector sanitized. |
| 02-prism-bootstrap | exit 0 | Maintained root + four-spike locked bootstrap passed; five lock digests unchanged and five dependency directories present. |
| 03-stop-path | exit 1, expected STOP | Exact missing/non-executable managed build-1228 path reported. No spike/aggregate success inferred. |
| 04-mobile-direct | exit 1 | Typecheck passed; all 12 browser tests failed before launch at the fixed path. |
| 05-preview-direct | exit 1 | All 3 browser tests failed before launch at the same fixed path. |
| 06-health-and-interruption-fixtures | exit 1 | 23 tests: 21 passed, 1 failed, 1 skipped. Passing original client/decision/round/domain-storage/Control/TCP-refusal fixtures remain individual successes; the whole command failed. |
| 07-deploy-contract | exit 0 | Workflow YAML, deploy-command contract, Bash syntax passed. No deployment. |
| 08-release-stop | exit 1 | `materialize-release.mjs --family=runtime --check` reports ENOENT for `releases/runtime-images.json`, exactly as documented. No release created. |
| 09-cli-selection | exit 0 | Exact local npx CLI and `install --dry-run chromium`: root/Prism 1.62.1 build 1234; each spike 1.55.0 build 1187. Dry-run is selection evidence, not an actual download or browser launch. |
| 10-session-and-artifact | exit 0 | Seven original tests passed: trust/session tamper/expiry, corruption/symlink/FIFO refusal, caller-byte ownership, concurrent durable writes, acknowledged bytes after killed writer. Local filesystem/process fixtures, not cgroup or deployment proof. |
| 11-environment | exit 0 | Tool/host versions, missing OpenSSL, and actual installed Playwright browser registries retained. |
| 12-focused-helm | exit 0 | Exact documented `npm run verify:prism:helm` passes; its script explicitly selects `--namespace default`. Render-only synthetic CI values, not a selected runtime release. |
| 13-chart-fixture-explicit-namespace | exit 0 | Original chart fixture passed with command-local `HELM_NAMESPACE=default`. This is a separate bounded render rerun, not a rewritten test or a replacement for the earlier failed command. |

The initial chart fixture failure is retained: it calls Helm without a namespace. The inherited `KUBECONFIG` path is `/var/run/kubeclaw-ops/kubeconfig/config`; `HELM_NAMESPACE` was unset. The fixture selected a namespace incompatible with the synthetic CI binding `worker.native.namespace=default` and stopped at `workloads.yaml:6` before assertions. The canonical focused Helm command explicitly selects default and passes. The rerun binds that same synthetic namespace through a command-local selector. No kubeconfig contents or credentials were inspected, no cluster access was exercised, and no source/config file was changed. This failed auxiliary fixture is not concealed as a pass and does not contradict the page's statement that no historical execution result for it is recorded.

The skipped test is `native PostgreSQL query cancellation settles and releases its actual pool client`: `REAL_POSTGRES_DATABASE_REQUIRED (isolated migrated test database)`. No isolated native database was supplied. The TCP refusal test passed and does not replace that native test.

## Browser limitation assessment

The fixed-path section at 1536–1651, diagnosis row at 1444, current issue record, and capability status at 1694–1695 accurately identify:

- package-local locked installation/selection versus the unconditional build-1228 executable;
- absence of a supported environment override/fallback;
- STOP before aggregate work and no ad hoc browser alias/config patch;
- each aggregate's `&&` short-circuit and unexecuted later stages;
- Prism maintainer ownership, stable current product issue, and measurable supported preparation plus direct-spike and complete-aggregate closure conditions;
- separation of this local product limit from live validation.

The complete local gate remains unavailable in this exercise. `verify:prism`, `verify:prism:repository`, and `verify:prism:production` were not run after the documented STOP. Browser download, Studio browser assertions, native cgroup/supervisor execution, actual PostgreSQL readiness/cancellation, provider route, trusted ingress, real human approval/publication, Nova round trip, backup/restore/retirement, and `EXEC-PRISM-JOURNEY` were not executed and have no successful result here. No fake browser, symlink, release, native/live result, or test skip was used to make a gate green.

## Integrity and cleanup

`snapshot-hashes.json` records exact bytes/SHA-256 for the page, canonical prerequisites/status/contracts and linked source files. The Prism page hash is `f7c45a1982d06205e6c2423907000fdf733d11cfd209102747859e42160717a7`. `source-link-audit.json` confirms all 153 pinned citations across 54 files resolve with valid line ranges and identical current candidate bytes. This mechanical result supports identity/range resolution; behavioral conclusions above also use actual source reading. `local-link-audit.json` confirms all 39 relative/self links resolve to existing repository files/headings. It does not establish rendered publication, accessibility, or route acceptance.

Final whole-affected-page review used the same immutable page and checked the complete setup, successful intended sequence, every interruption operation, diagnosis, local checks, status, cleanup and completion criteria. No further material Reader issue was identified beyond R-CSI-01. No main edits were made. The final candidate clone tracked diff remains empty. Owned dependency trees and generated spike test results are removed after evidence capture; original test servers had already exited. Frozen snapshot and hashed evidence remain. The corrected candidate needs a new independent fresh full-affected-path review; this frozen verdict cannot be relabeled by changing the working tree.
