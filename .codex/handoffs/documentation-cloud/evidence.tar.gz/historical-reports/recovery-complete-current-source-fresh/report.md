# Completed independent current-content Source review

Verdict: **FAIL** for the complete OPR-007 Source partition of the assigned candidate. Two retained technical findings remain. This is not a Reader, language/Quality, package, whole-gate or global verdict. No repository file was changed.

Reviewed repository HEAD: `4d3068465a2e202d2d5073b77e9273c308497995`. Reviewed complete page: `docs/site/use/recovery.md`, SHA-256 `9f0652adb9c2219b5f36f30e7d841cac32a481165fe7712c05f8d05e212754b1`, 1061 lines. This is an explicitly guarded dirty candidate, not a clean evidence commit. No clean-commit acceptance is claimed. Backend model identity was not independently measured; no backend configuration claim is made.

The reviewer read the full page and applicable quality-standard 07, AP09 acceptance contract, OPR-007 criteria/catalogue and backup-restore task inventory, operator fixtures 02/03, current component scripts/chart/native harness, linked restore contracts and boundaries, install binding/permission procedure, and Nova inspection/recovery authorities. The author report and existing root seals were leads only. They supplied no acceptance result.

## Individual Source facets

| Assigned facet | Finding |
| --- | --- |
| A98-01, backup-restore canonical ownership only | PASS. `docs/operator-tasks.json:189-211` binds the task to this page and both implementation authorities. `recovery.md:26-60` declares the one canonical procedure; no second canonical procedure was found in the assigned task. This does not accept other inventory tasks. |
| A98-02, complete source-correct operation on this page | FAIL. F1 makes the published scheduled-Job observation fail to select the chart-produced Jobs. Required access, versions, place, ordered backup paths, stops and cleanup are otherwise present. |
| A98-07, complete source-correct backup and restore explanation | FAIL. F2 incorrectly describes the selected backup-volume access boundary. The matched-group, key/encryption, isolated-target, retention and unsupported-restore boundaries otherwise agree with current sources. |
| A98-13, Source component of fresh-context completeness | FAIL. F1 gives a successful empty observation where the stated task is inspection of scheduled executions. The page cannot establish that observation from its published selector. No Reader exercise is accepted by this report. |
| Original A98-READER-BACKUP-GROUP, current Source content closure only | PASS. `recovery.md:723-739,788-830,842-846` correctly explains independent lexical latest selection, per-invocation PVC lock, per-CronJob overlap policy, matched backup/verify logs and unbound same-server smoke. `prism-backup.sh:119-154,156-169` and `backup.yaml:9-29` agree. The comparator rejects a newly selected group, missing path and duplicate path. This Source result does not retroactively change the original Reader result. |

## All necessary corrections

### F1 — Scheduled Prism Job inspection uses a Pod-only label

FAIL. `docs/site/use/recovery.md:386-388` tells the operator to inspect last executions with `kubectl -n "$PRISM_NAMESPACE" get jobs -l app=prism-backup --sort-by=.metadata.creationTimestamp`. The actual chart sets `app: prism-backup` at `charts/prism/templates/backup.yaml:28` in `jobTemplate.spec.template.metadata.labels`. It does not put that label on `jobTemplate.metadata` or on the Job itself. An actual private Helm render confirmed empty Job-template labels and the label only on the Pod template for all three CronJobs. Selecting Jobs by this label therefore omits the chart-produced Jobs. A successful empty result is not evidence that no scheduled backup ran.

Correction needed: replace this observation with a command that reads the actual Jobs and their CronJob owner references (and explain how to identify the three named owners), or explicitly inspect the labelled Pods as Pods and explain that scope. Do not change product labels solely to make the documentation command pass. Preserve the distinction between scheduled observations and the uniquely named manual Job CREATE identities.

Evidence: `prism-render.yaml` and `prism-render-observations.json`. The latter records each CronJob, empty `jobLabels`, and labelled `podLabels`. This is actual Helm rendering with private synthetic native-worker settings, not a deployed execution.

### F2 — Source callout invents read-only backup-volume mounts

FAIL. `docs/site/use/recovery.md:405` says that `charts/prism/templates/backup.yaml:52-79` defines “separate writable/read-only backup mounts.” All three backup, verify and database-proof containers mount `backups` at `/backups` without `readOnly: true` (`backup.yaml:65-74`). Only the artifact source mount in the backup mode is read-only (`backup.yaml:69,79`). Verification also needs writable backup-root access: `prism-backup.sh:29,59,62,164-165` creates temporary index files and acquires the shared file lock there.

Correction needed: say that all three operations use a writable backup PVC for locking and verification scratch files, while only backup receives the read-only artifact source mount. Preserve the separate fact that verify receives no database credentials. No product change is necessary.

Evidence: exact pinned-link whole-file equality plus actual private Helm render. The linked old commit has the same current chart bytes, so a working pin does not make the false wording true.

## Other complete-page mechanisms checked

The shared helpers at `recovery.md:62-214` require owner-supplied namespace UIDs and explicit exclusion of namespace/Job/Pod replacement; they do not portray UID comparison as enforcement of that exclusion. CREATE evidence is written before UID adoption and its kind/name/namespace/nonempty UID is validated. Invalid or denied CREATE stops; subsequent lookup cannot establish ownership. Log capture uses the returned positive active deadline plus 30 seconds, one succeeded Pod with the creating Job as controller owner, current Job and Pod UID comparisons, then the exact Pod/container. The cleanup body contains the creating UID as a server-side DeleteOptions precondition and Foreground propagation; wait plus a successful empty named read is required. Denied reads or present objects are not absence. The exclusion window and preserved private evidence are essential stated conditions. These helpers do not themselves implement namespace exclusion, owner fences, or trusted external authority.

Independent mocked checks accepted a successful path and rejected namespace mismatch, denied/invalid CREATE, foreign owner, ambiguous Pods, timeout, deletion conflict, denied absence read and still-present Job. Early identity failures made no mock DELETE call. The returned deadline 3630 became a 3660-second wait. These results prove shell branching with fixtures only. They do not prove kubectl wire behavior or server-side enforcement. Local `kubectl delete --help` recognizes the raw DELETE transport; actual API transport testing remains separate root work and is not claimed here.

LiteLLM (`recovery.md:459-717`) agrees with `postgresql-recovery.sh` and its renderer: scheduled reuse is possible; the exact logged group is exported through an owner-supplied method; no completed Pod is assumed to provide PVC access. The private single-group root and returned-path equality constrain the latest-only verifier. Tools are required even for offline verify. Required regular/non-symlink/singly linked files, exact three checksum lines, metadata/key/image/database/version/time and archive-list checks agree with the native script. Supplementary owner/source/client/authority/schema and archive-catalogue comparison checks add boundaries without executing copied metadata. The selected master/salt inputs remain external; archives are unencrypted locally and independent storage requires separate encryption/key authority. Restore provisioning, original image/API/model/budget behavior, cutover and rollback are explicitly absent. The native harness actually requires two externally supplied servers and a pinned source crypto runtime, creates disposable roles/databases there, checks schema/ownership/transactional failure/SQL login/legacy and AES decryption, and does not start the application. No native restore was run by this reviewer.

Prism (`recovery.md:362-413,721-900`) agrees with the implementation on database-first immutable artifact superset, durable artifact publication precondition, source administrative fence, publication and checksum index, group/total-byte and duration limits, retention of incomplete attempts and absence of automatic completed-group expiry, nonblocking per-invocation lock, lexical latest selection, three separate CronJobs, owner-supplied exact-group export and encrypted independent copy, and absence of a requested-group proof or executable external application restore. The temporary database proof uses the source server, restores in one transaction, queries three tables, and prints only the temporary database name. The page correctly forbids attributing that output to the matched backup/verify group. Existing Job histories concern Jobs, not backup media. F1 and F2 are the only material retained Source findings collected in this complete review.

Nova raw preservation/strict copied-journal parsing before audit or recovery (`recovery.md:902-957`) agrees with `operate.md:281-441,615-706`, `FileJournal` constructor/tail handling and original graph snapshot recovery. Audit can create a lock and truncate a partial tail before parsing. The page requires stopped run and adapter writers and retains raw rejected bytes; it does not accept tail truncation as external-effect reconciliation or successful recovery. No Nova recovery operation was executed.

State inventory, RPO/RTO targets versus measured outcomes, general six-step routine backup, smallest restore scope, empty isolated targets, verification through original consumers, rollback after new writes, failed evidence and retained media are explicit. Host/cluster, Redis and independent administrative access remain owner-dependent boundaries, with safe stops and linked issue closure requirements. No missing full-platform implementation was counted as a documentation failure. No environment-wide targets or successful live recovery are invented.

## Actual checks and limits

- 25 primary/page/contract inputs frozen in `inputs/`; SHA-256 manifest in `before.json`.
- All 28 narrow page Git source links independently resolved locally. Their full pinned source files equal current working-tree source bytes; every referenced range exists. Result: `pinned-link-check.json`.
- Nine exact Bash blocks parsed with `bash -n`, all exit zero: `bash-syntax.json` and `block-*.bash`.
- Independent reviewer-written `check-local.py`: ten fixture helper cases and four exact page comparator cases, all matched expected exits. Results: `local-check-results.json`, `check-*`, `comparison.cjs` and log fixtures.
- Actual `helm template` with private synthetic native worker node/namespace/digest settings succeeded. The base ci-values render first failed its actual native-worker precondition; a first synthetic digest incorrectly included `sha256:` and failed the schema. The final unprefixed 64-hex digest render succeeded. No host setting, chart or repository file was changed. The render is configuration proof only.
- No cluster/product/provider/credential/bootstrap/host installation, native SQL, deployed media verification, encrypted transfer, cutover, rollback or Git mutation was performed. No publication, language/Quality or Reader acceptance is claimed. Full-platform and independent-access live exercises were not run.
- `after.json` independently rehashes the frozen inputs; `manifest.json` binds every private artifact. Any page or primary-input change invalidates these current-content conclusions.

The report is complete before corrections. Do not merge these two findings into the already-corrected latest-group Reader finding; the entire changed page needs the required fresh role-specific review after correction.
