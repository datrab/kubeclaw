# Complete independent Quality review of the stable operator and Nova scope

Reviewer: `/root/stable_operator_core_language_complete_quality_fresh`, Quality only, fresh context, read-only repository throughout. No authorship, separate Source role, Reader participation, Astra role or global acceptance is claimed.

Reviewed repository: `/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04`; branch `docs/documentation-overhaul`; HEAD `f212bd14273a7357fca23a338933afbcc2d95902`.

**Complete assigned Quality verdict: FAIL. Exactly two material documentation findings remain: QF-01 and QF-02, both in Nova Core.** Install, Worker Trust, maintenance and the assigned Prism notification source issue each pass this Quality partition. The failed complete scope cannot be accepted until both findings are corrected and independently reviewed. This is neither a publication result nor a grant for a full catalogue requirement, acceptance gate, reader execution or live operation.

## Frozen scope and full semantic read

I manually read all 1,501 lines of `docs/site/use/install.md`, all 492 lines of `docs/site/use/worker-trust.md`, all 1,404 lines of `docs/site/use/maintenance.md`, and all 1,329 lines of `docs/site/understand/nova-core.md`. This includes metadata, headings, tables, source callouts, every executable block, Mermaid and its text alternative, failures, unsupported operations, recovery, cleanup and retained evidence. Truncated tool-output gaps were reread. The review is of the complete four pages, not the previous cached-image finding or the ten corrected language findings alone.

I read the complete 312-line quality standard, 489-line acceptance contract and 510-line acceptance fixtures. I read individual OPR-003, OPR-008, NVC-002 through NVC-018 and QUA-001 through QUA-010 catalogue entries. Catalogue baseline findings are requirements/leads, not current failures or approvals. I applied the assigned A98-02/03/09/13 and applicable English, truthfulness, reason, technical depth and diagram facets.

I read the complete `PRISM-NOVA-NOTIFICATION-001` record in `docs/status/open-issues.json`, including problem, impact, current state, owner and safe action, reproduction, closure conditions, evidence limitations and all source entries. Actual comparison with the retained before input confirms exactly four changed fields: `problem`, `impact`, `reproduction`, `acceptance_criteria`. The complete current record, rather than just those fields, was assessed. The tracked generated status page is stale and excluded from approval. A private current render was generated only to assess wording. It is not the published page and cannot establish current publication quality.

Linked reader prerequisites and boundaries were read in the actual current files: operator task map/placeholders/version rules; locked dependency installation; four-level readiness and run-control start; raw preservation before audit/recover/resume; Prism deployment/status/smoke and stop/retention; recovery start/backup-set boundary; capacity start; registry BuildKit healthy/fault/recovery exercise; glossary definitions; Core lifecycle decision and operational configuration/recovery decisions. `reader-inputs.json` binds their whole-file hashes, but the review only approves the relevant supporting sections as dependencies, not those complete supporting pages.

Actual product authorities were read for actor and meaning judgment. The saved per-page excerpts cover deploy setup/infrastructure/role readiness/Prism selection, value precedence and release acquisition, GitOps ownership, registry projection generation/consumption, complete Qdrant selector/patch/deletion sequence, trust test effects/rejection limits/cleanup, Control dispatch admission, unit receipt/signing, Worker Core identity checks, project/graph/registry/snapshot admission, stage executor/context/authorization, reducer/repair/wait/recovery, effect/fencing/checkpoint/administrative boundaries, remote plan dispatch/deadline/result import, audit and observer delivery. For QF-02 I also read the complete actual `dispatch-operation.ts`, production composition and actual transport response classification, rather than infer behavior from prose or the link label. The entire messaging payload parser and the wait-store create/commit path were read for the source issue.

The 188 pinned authored-page blob links refer to 102 unique revision/path authorities. Every full linked product file is byte-identical to the current checkout; all referenced line ranges are in bounds. Nine source-issue source entries also match their pinned full files and current bytes. These checks preserve evidence currency; they do not replace source reading or confer a separate Source approval.

Five previously retrieved upstream files were independently rehashed against their saved URL/hash manifest and copied into this bundle. I read the relevant JSON Patch apply, PV deletion/backend/finalizer, named get/list/watch wait, tolerated wait denial and single-body raw DELETE branches. No new upstream fetch, network assumption or live Kubernetes enforcement result is claimed.

## Language method and vocabulary

This is project controlled-language review inspired by ASD-STE100 principles. No licensed full dictionary/writing-rule set was available; no formal ASD-STE100 compliance or certification is claimed. Manual assessment checks named actors, conditions before actions, unambiguous identifiers, technical vocabulary consistency, explanations connected to tasks, limits and consequences, and distinction between uncertain effects, failed observations and absence. I reviewed tables, metadata, source callouts and code-adjacent prose that the mechanical helper excludes.

Relevant technical terms include graph/stage/attempt, registration/provider/adapter, capability/grant, invocation lease/resource lock/fencing token, effect/request/receipt, wait/signal/guidance, journal/snapshot/audit projection, repair/retry, digest/source/selection commit, code bundle, PVC/PV/UID/resourceVersion, provisioner/backend/asset/finalizer, CSI/CNI/OCI, SVID/SPIFFE/SPIRE, mutual TLS, allowlist, signing authority/trust anchor and positive control. The pages supply local explanations where operational use needs them, together with linked shared vocabulary. Terms identify distinct authorities; an API read, receipt, cache hit, loaded certificate or successful transport is not promoted into another kind of proof.

The unmodified current production `checkLanguage` helper and its constants were extracted and run privately on all four complete pages and the private current status render. It reports zero findings. This only proves that bounded helper's result; it excludes tables, headers, metadata and code, and is not full language approval. The manual review found two substantive completeness/meaning defects despite that zero result.

## Material findings: complete correction batch

### QF-01 — incomplete adjacent diagram text alternative

**FAIL:** `docs/site/understand/nova-core.md:41–64`; Mermaid relationships at 43–56; adjacent text at 59–64.

**Authority:** acceptance contract `A912-06` requires a text alternative for every diagram. The fixtures' `diagrams-have-readable-fallback` criterion requires a visible adjacent fallback naming every node and directed relationship. Nova is not in the currently registered browser-layout paths; this is a manual content/fallback judgment, not an invented browser fixture execution.

The diagram names 13 nodes and 14 edges:

1. Project input → Project compiler → Fixed pipeline definition → Registry and grant resolution → Atomic run snapshot → Scheduler loop → Bounded stage attempt.
2. Bounded stage attempt → Authorized effects → Durable receipts → Lifecycle reducer.
3. Bounded stage attempt → Typed stage result → Lifecycle reducer.
4. Lifecycle reducer → Lifecycle journal → Scheduler loop.
5. Lifecycle journal → Redacted audit projection.

The six-sentence text version says that the compiler creates a definition, the runtime resolves packages, Nova stores both views, the scheduler starts attempts, Core records effects/results, and recovery/audit rebuild views. It does not state the two separate reducer inputs, reducer-to-journal handoff or journal-to-scheduler feedback. It also does not explicitly connect project input to the compiler or snapshot to scheduling. The four-truth table and later sections explain these mechanisms, but do not provide the required equivalent adjacent fallback. A reader using only that alternative loses the branching and feedback relationships shown in the visual.

**Necessary correction:** expand the adjacent text alternative to name all 13 nodes and 14 directed relationships, preserving branch direction, both reducer inputs and the feedback/audit split. No diagram/source/product change is required for this finding. `diagram-required-relationships.json` records the exact required relationships and actual fallback.

### QF-02 — any failed request is incorrectly promised persisted reconciliation

**FAIL:** `docs/site/understand/nova-core.md:1043–1046`, including the broad supporting callout at 1062.

The page says that if a request fails, Nova queries the remote job and persists reconciled state before returning the failure. This is broader than the actual implementation.

**Actual authority:** `skills/nova/core/test-gates/dispatch-operation.ts:18–35` catches the original error, checks the deadline, and calls `reconcileInterruption` only if that deadline check throws and the operation has reached `prepared`. If the deadline is still active, it throws the original error at line 34. `pollRemote:37–54` turns a classified 404 into submission, retries classified retryable transport failures through status polling, and propagates other errors. The actual HTTP transport at `remote-dispatch.ts:139–174` can produce nonretryable HTTP errors, invalid JSON, schema errors and identity errors without timing out.

For interruption, `dispatch-operation.ts:56–82` uses a separate cleanup deadline; it first attempts cancellation with the existing job identity, then polls status. It can retain `remoteState=unknown`. It writes that interruption record, and the persistence-failure branch retains both causes. It does not guarantee a resolved remote result.

**Impact:** after an ordinary rejection or response/identity validation failure, the operator can expect a persisted reconciliation observation that need not exist. This changes the meaning of failure evidence and the safe decision before another dispatch.

**Necessary correction:** separate retryable polling and direct ordinary-error propagation from prepared-operation timeout/cancellation reconciliation. Explain cancellation-first, same-identity polling, separate bounded cleanup and unknown outcome. Limit the dual-cause statement to reconciliation persistence failure in that interruption branch. Preserve the requirement to retain original identities and stop unsafe replay when no reconciled outcome exists. No runtime change is authorized or necessary.

## Individual requirement facets

These are individual Quality facets at the frozen revision, not complete ledger acceptance of wider catalogue requirements.

| Requirement | Quality verdict | Location, authority and conclusion |
| --- | --- | --- |
| OPR-003 | PASS | Complete install page; deploy/release/GitOps authority. Existing-cluster start, source-bound selection, permission/ownership/client preparation and trust stop precede mutation. No correction. |
| OPR-008 | PASS | Complete maintenance page; version/release/GitOps/registry/teardown/Qdrant authority. Empty upgrade matrix and unavailable generic rotation/takeover/node operations are explicit owned limits. Retirement preserves data/access/evidence order. No correction. |
| NVC-002 | PASS | Nova:128–144, project CLI/compiler. Command selection, admission and baseline meanings remain distinct. No correction. |
| NVC-003 | PASS | Nova:145–210, compiler/source admission. Fixed control-file and baseline/ownership binding precede work. No correction. |
| NVC-004 | PASS | Nova:211–249, graph/build/recovery. Ordinary/repair/activation edges, freeze, invalid input and identity mismatch are explained. No correction. |
| NVC-005 | PASS | Nova:368–412, graph/pipeline loop. Stable ready selection, fan-in/out, concurrency and repair ordering are explained. No correction. |
| NVC-006 | PASS | Nova:250–304 and 413–479, runtime/context/stage executor. Registry activation, validation, dispatch, lease, result and cleanup responsibilities are connected. No correction. |
| NVC-007 | PASS | Nova:413–479, stage executor/effect locks. Invocation lease and renewed external lock/fence are distinct; wall time versus process-isolated resources is honest. No correction. |
| NVC-008 | PASS | Nova:545–610, schema/compiler/reducer. Explicit graph budgets versus compiler policy, spent attempts and repair authority limits are explained. No correction. |
| NVC-009 | PASS | Nova:611–764, wait contracts/consumer table and resume sources. Envelope, payload consumers, expiry, original identities, storage idempotency versus stale/terminal replay and blocked Prism handoff are explicit. No correction. |
| NVC-010 | PASS | Nova cancellation/shutdown section:888–935, loop/executor/engine cleanup. Local authority, external effects, timeout and cleanup-error precedence remain separate. No correction. |
| NVC-011 | PASS | Nova:765–857, durable invocation/coordinator/locks/effect recovery. Request/acceptance/receipt/fence and unsupported continuation are connected with safe stop and owners. No correction. |
| NVC-012 | PASS | Nova artifact checkpoint section:858–887, checkpoint recorder/executor. Partial checkpoint, exact repeat/conflict, producer binding and ancestor visibility do not claim final success. No correction. |
| NVC-013 | PASS | Nova:305–367, run-root/journal/snapshot/plugins. Stored subset, raw-tail preservation, external trusted head, JSON safety and filesystem durability limits are clear. No correction. |
| NVC-014 | PASS | Nova stage/result/event tables:480–544, reducer/run decisions/recovery state. Typed results, spent counters, repairs and terminal priority are explained. No correction. |
| NVC-015 | PASS | Nova:812–857 and administrative reopen:974–1010, effect gate/admin sources. Administrative authority neither imports missing receipts nor proves external continuation. No correction. |
| NVC-016 | FAIL | Nova:1043–1046; dispatch-operation/transport. QF-02 overstates reconciliation for ordinary errors. Other source binding, deadline and import-authority explanations pass. |
| NVC-017 | PASS | Nova audit/observer section:1089–1146, audit/journal/observer source. Derived authority, raw-byte side effects, redaction, external-head limitation and delivery bounds are clear. No correction. |
| NVC-018 | PASS | Nova failure families:1147–1205. Families identify effects/retry/owner response, including wait distinctions and dynamic suffixes; exact throw sites remain the detailed source index. This Quality verdict does not grant a generated exhaustive-error-inventory gate. No correction. |
| QUA-001 | FAIL | Complete four-page manual read; Nova:41–64 lacks the required equivalent diagram alternative (QF-01). Other English/depth/readability facets pass. |
| QUA-002 | PASS | Complete manual vocabulary/actor/condition review plus zero bounded helper findings. No formal certification is claimed. No correction. |
| QUA-003 | PASS | Nova:1205–1308 labels historical evidence unknown and current alternatives/reasons as inference; maintenance Qdrant source comment, cost and reassessment distinguish history. No invented approval. |
| QUA-004 | FAIL | QF-02 at Nova:1043–1046; pinned links are valid/current but do not prove this broader claim. No source-link mechanism failure was found. |
| QUA-005 | PASS | Complete pages and assigned source issue keep source, local synthetic/parser, selected image, deployment and live proof separate. Corrected install:629–642 does not claim uncached pull. No live/global completeness claim found. |
| QUA-006 | PASS | Quality partition only: complete reader-facing text assessed without author help; QF-01/QF-02 are recorded rather than hidden. No independent participant exercise is claimed. |
| QUA-007 | PASS | Operator-language/procedure partition only: complete install/trust/maintenance prerequisites, authority, observations, stop/recovery/cleanup and limits are understandable. No live operator execution claimed. |
| QUA-008 | PASS | Applicability/claim facet only: these pages do not claim a clean extension creation exercise; Core safe-change checklist is explanatory routing. Actual extension participant acceptance is outside this scope. |
| QUA-009 | FAIL | Core developer explanation facet: QF-02 changes the meaning of failure evidence in the remote dispatch mechanism. No platform-change participant execution is claimed. |
| QUA-010 | PASS | Truthfulness/applicability facet only: no four-page claim substitutes a linter or link count for complete drift mutation proof. Mutation-suite acceptance is outside this scope. |
| PRISM-NOVA-NOTIFICATION-001 | PASS | Complete source record, nine actual source entries and pure parser probe. Conditional selected adapter, admitted Control/wait-store state, failed notification, blocked result, no active Core wait, stop/owner and measurable closure conditions are complete; no installed journey or fix is claimed. |

## Assigned and related gate facets

| Facet | Verdict | Exact reviewed scope and limit |
| --- | --- | --- |
| A98-02 install | PASS | Full install task, including binding:191, prerequisites:273, authorization:443, probe:622, ordered install:1238, recovery/evidence:1440. Versions/rights/placeholders/impact/observations/stop/retry and provider proof boundaries are complete. |
| A98-02 Worker Trust | PASS | Full 492-line procedure; supported start:17, separate receipt authority:83, source/readiness/live boundary:180–317, observations/cleanup/recovery:319–492. No missing live proof is invented. |
| A98-02 maintenance | PASS | Full 1,404-line page, including Qdrant:139–568, release acquisition:581–704, registry:950–1130, retirement:1160–1404. Conditional unavailable operations have owner/safe action/closure boundary. |
| A98-03 install/preflight | PASS | Install:23–61 plus all preparation/probe sections. Absent release, unsafe storage ownership, missing rights and trust qualification stop before mutation for complete installation. |
| A98-03 trust prerequisite | PASS | Worker Trust:46–178 and 208–317; install:31–48. Key qualification alone cannot remove lifecycle/denial gaps. |
| A98-09 install cleanup | PASS | Install:1066–1236. Original creating identities, exclusion, owner clearance, strict independent reads and backing-provider disposition constrain cleanup; unknown/replaced identities stop. |
| A98-09 Worker Trust cleanup | PASS | Worker Trust:238–410. Suppressed trap, lost request/resource identities and retained Prism state forbid generic cleanup/replay. Exact owners and closure results are named. |
| A98-09 maintenance retirement | PASS | Maintenance:121–568 and controlled retirement section. Export/restore/evidence before deletion; whole-window exclusion; original PVC/PV/provider identities; retained recovery objects; no API-absence-to-erasure inference. |
| A98-13 operator procedural understanding | PASS | Complete three operator pages, linked canonical prerequisites and actual authorities. Quality comprehension only; no Reader participation or live execution result. |
| A98-08 upgrade/rollback language | PASS | Maintenance:29–66 and change/rollback sections. No accepted pair exists; incompatible data writes prevent image rollback. |
| A912-01 English/reader boundary | PASS | All four pages and assigned source issue/private wording. One descriptive H1 each; no internal AP/review/migration work history prerequisite. Product review, source review/merge and data migration words refer to real product/operations. No publication-manifest run. |
| A912-06 diagram content | FAIL | Nova:41–64, QF-01. Diagram purpose/source/owner are present; adjacent text alternative is incomplete. No rendered-browser result. |
| A912-09 references | PASS | Repository facet only: 92 local links/anchors and 188 pinned source line ranges. Public routes/rendered IDs/assets/network availability remain unexecuted. |
| A913-02 mechanism/depth | FAIL | Four-page complete content partition; QF-02 affects remote failure/reconciliation meaning, QF-01 its diagram alternative. |
| A913-06 controlled-language method | PASS | Scope/method/vocabulary/findings recorded; manual review supplemented by exact bounded helper. No certification claim. |
| A913-07 reasons | PASS | Significant Core/local operational choices label evidenced versus unknown historical reasons and present inference, benefits/costs/reconsideration. |
| A913-10 truthful product limits | PASS | Missing release selection, host/bootstrap/restore/capacity, trust capture/denials, reduced profile, node cold pull, upgrade pair/rotation/takeover, Prism notification and general effect continuation remain owned explicit limits. Honest unavailable functionality is not a prose failure. |
| A913-12 status | PASS | Truthfulness partition: every local/source/live limit remains explicit. No global gate or final documentation acceptance claim. Complete assigned Quality still FAIL because two findings remain. |

## Executed checks and deliberately unexecuted work

Executed read-only/local checks:

- HEAD/branch/status and assigned SHA guards. Every assigned page/source issue matches the assignment; unrelated dirty generated/scanner/API/tooling files are captured and excluded, never approved or erased.
- Full manual semantic/language/actor/authority reading described above; two findings collected in one complete report.
- Pinned whole-source-byte/range comparison: 188 links, 102 unique authorities, no byte drift or invalid range. Nine source-issue entries also match.
- Exact production language helper: zero findings on all four pages and private current status render; source status validation and private rendering exit zero. No tracked output was changed.
- Existing repository Markdown parsing/anchor helper: 92 local destinations/anchors, zero failures; four unique descriptive H1s and zero AP labels.
- `bash -n` on 49 freshly extracted authored Bash fences: all exit zero. Syntax is not execution or live verification.
- Exact fence-body comparisons: install 20, Worker Trust 4, maintenance 25, Nova 1; every body matches the named retained prior input. This establishes unchanged executable/diagram bodies across prose edits, not borrowed page approval or fresh runtime proof.
- Pure actual `parsePayload` producer-shaped probe: exit zero after observing exactly `OPERATOR_PAYLOAD_UNKNOWN_FIELD:architectureDigest`. It exercises no stage, adapter reservation, network, Core or deployment.
- Independent SHA verification of five saved upstream files before bounded source reading. No previous reviewer verdict is reused as this reviewer’s judgment.

Not executed: global generation/publication checks (tracked output is known stale), public rendering/search/browser/accessibility/layout/route tests, installation/build/package changes, arbitrary native suites or thousands of repeated tests, network/live cluster, production keys/trust anchor/signing, release dispatch/build/scan/PR/merge, cold pulls on nodes, live trust/unit transaction, Qdrant/data deletion, upgrade/rollback/rotation/retirement, restore, registered deployment scenarios or Reader participant exercises, mutations, AP98/AP09/global/final acceptance. No skipped item is reported as passed.

No product/runtime change, repository edit, commit, push, live mutation or production-key access occurred. Evidence writes are confined to this private reviewer directory. The working tree contains unrelated concurrent tooling/generated changes; a globally clean checkout is expressly not claimed. Final input guards and the artifact manifest seal this exact review scope. They do not grant the clean-evidence-commit or publication gates.
