# Complete frozen Apps Source review

**Result: FAIL; complete required Source qualification remains open.** This report grants no global, Reader, Quality, Astra or package acceptance. It evaluates the immutable subject below. Later root/writer commits are outside this report.

Subject commit `8fd110869b233f6995d1d2263eb0dff34772190f`; tree `fe45d1a6e05fa0c2dc377a0d49b78f110e73de07`. The 5533 archived regular files match the frozen snapshot byte for byte. Subject `scripts/docs-kubernetes-apps-receiver-contracts.mjs` SHA-256 `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`. Kubernetes v1.35.0 implementation is pinned to `66452049f3d692768c39c797b21b793dce80314e`. See [frozen subject](frozen-subject.json), [all archived file hashes](frozen-files-sha256.json) and [fresh primary provenance](primary-source-manifest.json).

## Complete scope and disposition

The review retained every 1285 authored receiver record,8450 case,740 distinct (URL, exact caption) proofs and 22522 evidence appearances. It separately re-enumerated the full1389 Deployment paths:104 metadata/envelope paths have no receiver and remain FAIL. Every347 original workitem,201 distinct boundary,486 boundary appearance and 36 context identity was recovered without inheriting a verdict. A scope disclaimer, another owner, parent text, corrected companion citation or successful exporter cannot waive any original requirement.

| Ledger | Total | PASS | FAIL |
|---|---:|---:|---:|
| records | 1285 | 0 | 1285 |
| cases | 8450 | 3703 | 4747 |
| dimensions | 12850 | 4753 | 8097 |
| captions | 740 | 722 | 18 |
| evidenceAppearances | 22522 | 22392 | 130 |
| originalWorkitems | 347 | 0 | 347 |
| originalBoundaryAppearances | 486 | 0 | 486 |
| distinctBoundaries | 201 | 0 | 201 |
| originalContexts | 36 | 0 | 36 |
| missingAuthority | 104 | 0 | 104 |

The record ledger uses the full required authored-to-runtime criterion: all 1285 remain FAIL because actual apply ownership/merge/force/conflict/omission/null is unqualified (N33), in addition to individual defects. This is not an assertion that all typed defaults are wrong. The separate typed-only record column is679 PASS /606 FAIL. Case PASS means only its explicitly named typed/source condition and outcome survived scrutiny; already-permitted-update cases FAIL because that condition assumes the ownership resolution the original requirement asks to prove. All attached exact proof defects conservatively fail cases on that record. A caption PASS means its own fresh narrow range supports its literal caption; it grants no record or consumer completeness. All original workitems and contexts remain FAIL.

The independent binary ledgers are [records](record-ledger.json), [cases](case-ledger.json), [all behavior dimensions](dimension-ledger.json), [distinct exact captions](caption-ledger.json), [every evidence appearance](evidence-appearance-ledger.json), [original workitems](workitem-ledger.json), [distinct original boundaries](distinct-boundary-ledger.json), [every original boundary appearance](boundary-appearance-ledger.json), [original contexts](context-ledger.json) and [every absent authority path](missing-authority-ledger.json). Each retained identity has its own verdict and finding references; no identity is replaced by an aggregate count.

## Scrutiny and authorities

The Documentation Quality Standard, AP09 acceptance contract, acceptance fixtures and generated AP09 catalogue were read in full. CFG-009, A98-10 and A98-11 require recursive alternatives and complete effective precedence to the actual consumer. Catalogue/source inventory presence is not receiver proof and does not close the remaining independent gate. The old report C01–C15 and writer report served only as navigation; inherited conclusions were discarded. Source bytes were fetched afresh rather than reused as evidence.

The complete subject and its routed schema, coverage, configuration inventory and API-reference renderer authorities were read. Fresh primary source re-enumeration covered API declarations, fresh typed decoding (scalar/struct/pointer/list/map/custom Quantity/IntOrString), Deployment/template vs created-Pod defaults, direct validation/options/old-object/gate/OS selection, update strategies, ReplicaSet/Pod consumers and observations. All ordinary/init/ephemeral cloned entries were checked against their selected caller boundaries:231 init and 232 ephemeral-item paths; a retained ephemeral item rejects the Deployment route rather than promising a live ephemeral-container runtime. Structural case/dimension joining is retained separately in [case route audit](case-dimension-route-audit.json) and is explicitly not semantic acceptance.

Manual scrutiny covered every distinct case condition/mechanism and behavior text, including unchanged entries: admission/scheduler routes, NodePorts/affinity/topology/gates/preemption/gang membership, effective resource accounting/cgroups/OS/DRA, namespace/hostname/DNS/hosts/service links, image credentials/backoff/nonroot/security/AppArmor, mounts/devices/PVC/legacy storage/atomic projection, probes/lifecycle/restart/grace/readiness, token binding/default/caps/refresh, certificate issuer/authorization/renewal/error paths and trust nil-versus-empty cache keys/TTL/events. Parent routes, ownership, precise empty/null dispatch, selected precedence and error/rollback/recovery/rollout/status limits were examined rather than inferred from schema descriptions. Existing explicit selected legacy storage limits, including the vSphere nil-dereference boundary, were retained as static limits; no panic was executed. The selected SSA handler/field-manager route was inspected; its absence from the required authored contract is N33, not a waiver.

All 740 exact captions were compared to their own linked range in freshly fetched bytes. The 740 indexed decisions carry the primary SHA and read excerpt, not a successful URL/bounds check. Every22522 attachment joins to the same literal (URL, claim) identity. The 18 failed captions produce130 failed appearances. Companion wider citations do not repair a failed narrow attachment.

Full authority facts come from fresh pinned OpenAPI bytes (SHA-256 `483500149ee52ce5753d75f5639101d985bb4f5e902cc05b1ba7627465d62446`) verified against the frozen locked authority. Recount:1389 paths,1285 authored,104 missing,0 extra. Fresh Go shape enumeration found1285 authored shapes; its type/decode cross-check found the remaining CSI fsType pointer defect. Enumeration is separate from semantic judgment.

## Material remaining findings

Each finding identifies the frozen subject location, exact primary implementation and required correction. [Machine-readable findings](findings.json) preserve affected exact paths/selectors and source hashes. The location below is in the frozen snapshot, not a moving writer file.

### N01: Ports lack selected scheduler/runtime consumers and host-network validation

**FAIL — available-source-documentation-gap**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:89` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

Ports carry API/default/decode proofs only. Selected NodePorts uses positive host ports, empty hostIP wildcard conflicts and concrete scheduling rejection. Regular hostNetwork ports must match containerPort unless zero at template boundary. Runtime constructs CRI mappings for regular containers only, while scheduler considers Always-init hostports too.

Correction: Document exact regular versus Always-init/ordinary-init routes, hostNetwork equality/default distinction, wildcard/protocol conflicts, mapping duplicate handling, failed scheduling observation and safe owner action. Treat init mapping mismatch as a conditional static implementation boundary.

Primary: [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L4223-L4237), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/scheduler/util/utils.go#L181-L215), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/scheduler/framework/plugins/nodeports/node_ports.go#L161-L189), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/kube-scheduler/framework/types.go#L599-L637), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/container/helpers.go#L433-L469), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/kuberuntime/kuberuntime_sandbox.go#L117-L139).

### N02: Init restart-rule clearing is conflated with policy predicate

**FAIL — available-source-documentation-gap**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:978` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

The new caller outcome says 'non-Always init overrides/rules'. dropContainerRestartRules preserves Always init policy but clears rules for every init container, including Always.

Correction: State separately non-Always init policy clearing and unconditional init rule clearing under the actual caller predicate; add an Always+rules/no-old-use disabled-gate case.

Primary: [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/api/pod/util.go#L781-L783), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/api/pod/util.go#L1794-L1807).

### N03: PVC reference receiver stops before available kubelet checks

**FAIL — available-source-documentation-gap**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:162` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

Three PVC source records do not describe namespace lookup, deletion/protection, Bound/VolumeName, PV ClaimRef UID or actual readOnly propagation. PVC existence and successful driver mount are external inputs, but selected checks are available source.

Correction: Attach current createVolumeSpec/getPVCExtractPV/getPVSpec and downstream readOnly route; explain current error and recovery owner, keeping actual bound PV/driver state conditional.

Primary: [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/volumemanager/populator/desired_state_of_world_populator.go#L426-L475), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/volumemanager/populator/desired_state_of_world_populator.go#L523-L588).

### N04: Strict Deployment selector caption omits strict option

**FAIL — available-source-documentation-gap**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:405` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

Attached apps validation647–648 only checks wholly empty selectors. Strict AllowInvalidLabelValueInSelector:false is at646.

Correction: Replace the exact narrow range with 646–648 and retain actual label-value validator proof.

Primary: [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/apps/validation/validation.go#L645-L648).

### N05: Positive Quantity caption shows integer helper instead

**FAIL — available-source-documentation-gap**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:718` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

375–391 supports negative Quantity rejection but excludes ValidatePositiveQuantityValue397–404. The caption asserts positive Quantity zero rejection.

Correction: Attach the exact397–404 Quantity implementation, separating int64 scalar checks from Quantity checks.

Primary: [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L379-L404).

### N06: Certificate sign caption omits changed-status selector and validation

**FAIL — available-source-documentation-gap**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:1018` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

The new152–175 range starts inside user-lookup failure and omits status validation143–146 and changed-status predicate150.

Correction: Use143–164 or separate exact ranges proving validation, changed-status predicate and signer authorization.

Primary: [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/registry/certificates/podcertificaterequest/strategy.go#L139-L166).

### N07: Required lazy node-affinity route is applied to preferred scoring

**FAIL — available-source-documentation-gap**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:754` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

Blanket nodeAffinity consumer says OR matching and deferred errors on all records. Preferred constructors return aggregate errors regardless of other matches, then score sums matching weights; plugin propagates constructor errors.

Correction: Split required lazy matching from preferred constructor, weighted scoring and normalization, including parse-error and matching alternatives cases.

Primary: [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/component-helpers/scheduling/corev1/nodeaffinity/nodeaffinity.go#L81-L149), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/scheduler/framework/plugins/nodeaffinity/node_affinity.go#L252-L301).

### N08: Topology spread records stop before skew filter and scoring

**FAIL — available-source-documentation-gap**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:755` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

Selector/default/inclusion preparation does not establish the actual DoNotSchedule maxSkew/minDomains condition or ScheduleAnyway scoring/normalization.

Correction: Attach actual eligible-domain/count/minDomains/global-min/Pod-self-match filter and selected soft score/normalization. Explain missing topology and insufficient domains, with scheduler owner and observed pending/score boundary.

Primary: [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/scheduler/framework/plugins/podtopologyspread/filtering.go#L54-L76), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/scheduler/framework/plugins/podtopologyspread/filtering.go#L314-L360), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/scheduler/framework/plugins/podtopologyspread/scoring.go#L195-L270).

### N09: Forbidden Pod-level claim children receive valid DRA consumers

**FAIL — available-source-documentation-gap**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:926` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

All 4 PodSpec.resources.claims records gain DRA allocation/preparation and resource consumer cases despite retained nonnil claims being rejected. Their valid-container-claim consumer conditions do not establish a route for these forbidden fields.

Correction: Exclude forbidden Pod-level claims from DRA/accounting/runtime case generators. Preserve nil/drop/rejection distinctions and explicit no downstream route when retained, as for ephemeral containers.

Primary: [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L4736-L4758).

### N10: Lifecycle HTTP fallback and request construction are omitted

**FAIL — available-source-documentation-gap**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:951` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

Actual HTTP runner has current-Pod-IP lookup/error and conditional HTTPS downgrade to HTTP deleting Authorization; dispatcher/order/grace evidence does not show these effective values and recovery.

Correction: Describe and prove HTTP request construction, host/named port/default/custom headers and selected HTTPS fallback, Authorization stripping, runtime status failures and fallback event; distinguish lifecycle from probes.

Primary: [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/lifecycle/handlers.go#L127-L170).

### N11: Probe action request and result consumers are omitted

**FAIL — available-source-documentation-gap**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:130` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

The HTTP/TCP/exec action records stop at API validation and dispatcher/worker state. They omit effective PodIP host fallback, concrete named-port lookup and errors, HTTP header defaults and overrides, transport TLS/proxy rules, redirect/result handling, and exec command expansion/exit/timeout semantics available in pinned implementation. Runtime reachability cannot waive these available-source branches.

Correction: Add exact action request/construction/execution/result cases with narrow evidence; keep source construction distinct from actual application success.

Primary: [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/probe/http/request.go#L40-L91), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/probe/util.go#L27-L58), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/probe/http/http.go#L40-L68), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/probe/http/http.go#L99-L141), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/prober/prober.go#L149-L199), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/probe/exec/exec.go#L50-L79), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/probe/tcp/tcp.go#L46-L73).

### N12: Pod hugepage-limit create default and request-key precedence omitted

**FAIL — available-source-documentation-gap**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:205` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

The actual gated Pod-create path calls defaultHugePagePodLimits before defaultPodRequests. A partly specified nonnil Pod resource object gains missing supported hugepage limits from aggregated container limits unless an exact Pod hugepage request key exists. Subject only documents request defaulting and its linked 443–496 range stops before the fill and suppression logic.

Correction: Document and prove both container-derived hugepage limit insertion and suppression by exact present Pod request/limit keys, including nil/empty Pod resource boundaries; preserve Deployment-template versus Pod-create distinction.

Primary: [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/v1/defaults.go#L191-L198), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/v1/defaults.go#L486-L527).

### N13: Status update collisionCount cannot decrease or become nil

**FAIL — available-source-documentation-gap**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:781` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

The status record only gives fresh pointer/numeric validation and controller count publication. Actual status update validation rejects decreased collisionCount and every old nonnil to new nil transition, including old zero; omitted/null old-object cases are undocumented.

Correction: Add separate /status update cases for old nil versus old nonnil, equal/increased/decreased values and nil clearing, with exact update-strategy, apps validator and IsDecremented proof.

Primary: [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/registry/apps/deployment/strategy.go#L179-L182), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/apps/validation/validation.go#L718-L729), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L8717-L8725).

### N14: Shared inventory contradicts selected port, image and probe behavior

**FAIL — available-source-documentation-gap**. Frozen `scripts/docs-configuration-inventory.mjs:2342` (file SHA `1d4504afaba59fcf282dd664b389b8fa2ff78e697dc7189fea785cabfa720dfd`).

The routed inventory claims container-port names unique across a Pod, malformed image strings rejected by admission, and all empty probe scalars invalid. The selected implementation instead scopes port-name uniqueness per container, only checks nonempty image length at this template validator, and defaults zero probe timing/threshold scalars. Frozen receiver module correctly separates several of these facts, leaving inconsistent shared reader authorities.

Correction: Reconcile the routed inventory to exact per-container uniqueness, image API versus resolution failure and field-specific probe default/empty behavior. Do not assert image execution or Service readiness from these corrections.

Primary: [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L2722-L2759), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L3880-L3898), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/v1/defaults.go#L233-L246).

### N15: Created Pod forbids direct PVC reference to its generated ephemeral claim

**FAIL — available-source-documentation-gap**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:162` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

Deployment template validation supplies nil Pod metadata, so it skips the generated-name-dependent cross-volume check. On actual Pod validation, ValidateVolumes rejects a direct PVC source referencing a claim generated for any ephemeral volume in that Pod. Subject253 already documents actual generated-PVC-name validation; the direct/generated reference conflict and exact nil-template versus actual metadata predicate remain omitted.

Correction: Add separate Deployment-template and actual-Pod cross-volume admission cases for the direct/generated claim conflict, using exact metadata predicates and source ranges; retain the already documented generated-name check and keep metadata104 completeness open.

Primary: [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L453-L494), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L783-L797), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L7066-L7071).

### N16: Projected token trust and certificate modes override defaultMode

**FAIL — available-source-documentation-gap**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:613` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

The actual sensitive-source collector selects defaultMode only when FsUser and FsGroup are both nil; either nonnil value forces0600 for token, trust and certificate payloads and carries FsUser for writer ownership. Generic filesystem ownership uncertainty does not explain this deterministic selected source override.

Correction: Add exact mode/default/FsUser/FsGroup precedence cases and caller provenance for selected mounter arguments; separately qualify effective post-ownership filesystem permissions.

Primary: [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/volume/projected/projected.go#L320-L354), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/volume/projected/projected.go#L380-L390), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/volume/projected/projected.go#L399-L428), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/volume/util/operationexecutor/operation_generator.go#L581-L590), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/volume/util/util.go#L539-L557).

### N17: Accepted projected path collisions use ordered last payload write

**FAIL — available-source-documentation-gap**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:632` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

Validation records checked explicit paths but excludes token paths and object-all-keys paths. The runtime visits source entries in order and assigns payload[path]; accepted collisions from these unchecked routes overwrite earlier content. Subject identifies token validation exclusion but omits its runtime effective-key precedence and collision cases.

Correction: Document ordered payload map writes and collision branches between automatic object keys, token and explicit outputs; separate API rejected explicit duplicates from accepted runtime collisions and atomic-writer errors.

Primary: [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L1159-L1230), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/volume/projected/projected.go#L258-L318), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/volume/projected/projected.go#L349-L354), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/volume/projected/projected.go#L385-L428).

### N18: iSCSI portals evidence caption asserts nonexistent list checks

**FAIL — exact-evidence-caption-gap**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:601` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

The generator attaches a caption that the direct branch checks list presence or combination. The selected iSCSI validator does not inspect Portals at all; the narrow caption is false even though the element outcome correctly avoids asserting independent empty-element rejection.

Correction: Use an iSCSI-specific caption stating no independent Portals check, instead of borrowing FC/monitor-list presence rules.

Primary: [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L839-L877).

### N19: AppArmor pending admission and cached host-support error omitted

**FAIL — available-source-documentation-gap**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:742` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

Selection and CRI synthesis omit the standard Linux node admission consumer. Pending Pods requiring AppArmor fail cached host-support errors; non-Pending Pods bypass this handler. Host support is established once at validator construction and not reevaluated until kubelet restart. Generic host-dependency qualification omits these available deterministic branches.

Correction: Document Linux handler registration, isRequired nil/Unconfined/other-profile predicate, Pending-only admission, named error and cached startup support/restart recovery. Do not claim loaded local-profile availability or live enforcement.

Primary: [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/kubelet.go#L1064-L1068), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/lifecycle/handlers.go#L200-L215), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/security/apparmor/validate.go#L40-L62), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/security/apparmor/validate.go#L86-L107), [pinned primary source](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/security/apparmor/helpers.go#L26-L50).

### N20: Old divisor literal caption retains a range that omits its CPU and memory declarations

**FAIL — narrow-primary-proof-gap**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:715` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

The original 2982–3017 appearance claims CPU and full memory literal sets, but CPU is declared at2978 and memory starts2979–2982. The range only contains a lookup and diagnostic for CPU. Correct added2978–3017 evidence at836 leaves the original attached appearance unrepaired.

Correction: Replace the original range with 2978–3017 or narrow its caption to the included validator, and audit every retained appearance.

Primary: [pkg/apis/core/validation/validation.go:2978-3017](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L2978-L3017).

### N21: Termination-message policy caption omits the required-policy predicate

**FAIL — narrow-primary-proof-gap**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:63` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

The caption attached to both terminationMessagePath and terminationMessagePolicy claims required and restricted policy validation, but3900–3914 omits3893–3898 including the empty-policy Required branch. Record behavior can be correct while this retained appearance fails exact-range proof.

Correction: Link3893–3903 or adjust the caption to only what the original range proves; retain distinct path and policy captions.

Primary: [pkg/apis/core/validation/validation.go:3893-3903](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L3893-L3903).

### N22: Supplemental-group caption omits its loop and ID helper

**FAIL — narrow-primary-proof-gap**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:474` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

5548–5553 begins inside an error branch; loop and IsValidGroupID invocation are5546–5547.

Correction: Expand to5546–5550 to prove every group is validated.

Primary: [pkg/apis/core/validation/validation.go:5546-5550](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L5546-L5550).

### N23: Capability conflict captions omit the escalation=false guard

**FAIL — narrow-primary-proof-gap**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:362` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

8396–8405 starts after the outer conditional at8393. It shows CAP_SYS_ADMIN equality and an error, but omits the condition deciding whether this branch runs.

Correction: Expand to8393–8405 and retain container/pod precedence separately.

Primary: [pkg/apis/core/validation/validation.go:8393-8405](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L8393-L8405).

### N24: Ephemeral-container categorical prohibition captions omit the nonempty-list guard

**FAIL — narrow-primary-proof-gap**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:54` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

7076–7078 contains the Forbidden append and closing braces but omits7075 len>0. Full7066–7080 is also attached on some records but does not repair these appearances.

Correction: Expand all retained7076–7078 appearances to7075–7078 or full7066–7080.

Primary: [pkg/apis/core/validation/validation.go:7075-7078](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L7075-L7078).

### N25: Availability caption overstates the nonzero transition-time requirement

**FAIL — caption-semantic-error**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:1005` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

Caption731 says IsPodAvailable requires Ready and elapsed minReadySeconds from nonzero transition time. Actual283–295 returns true for Ready with minReadySeconds==0 regardless of transition-time zero.

Correction: State the zero-delay immediate-availability branch separately from the nonzero-delay/nonzero-transition-time branch.

Primary: [pkg/api/v1/pod/util.go:283-295](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/api/v1/pod/util.go#L283-L295).

### N26: Init-order caption links only initialization-status detection

**FAIL — narrow-primary-proof-gap**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:1033` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

1040–1065 identifies whether a Pod was previously initialized and ends mid-comment. It does not contain the ordering operation claimed. The reverse scan is1093 and initial-start/reversal1275–1287.

Correction: Replace this old appearance with exact ordering ranges and include the failed/unknown normal-init branches1199–1270 when describing the full operation.

Primary: [pkg/kubelet/kuberuntime/kuberuntime_container.go:1093-1104](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/kuberuntime/kuberuntime_container.go#L1093-L1104), [pkg/kubelet/kuberuntime/kuberuntime_container.go:1275-1290](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/kuberuntime/kuberuntime_container.go#L1275-L1290).

### N27: Pod cgroup caption omits hugepage request provenance

**FAIL — narrow-primary-proof-gap**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:1046` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

163–222 assigns precomputed hugePageLimits at208 but omits161 HugePageLimits(reqs), which selects request provenance.

Correction: Include161 in the linked range or remove the unsupported request-provenance part of the caption.

Primary: [pkg/kubelet/cm/helpers_linux.go:126-222](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/cm/helpers_linux.go#L126-L222).

### N28: DRA CDI device request filter omits the match-all empty-device-request branch

**FAIL — available-source-documentation-gap**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:944` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

Actual cdiDevicesAsList admits a device when requestName==empty OR device.RequestNames has length0 OR contains the exact requested name. The receiver states optional request filtering without this deterministic empty-device-list branch and only links the manager caller. This is available implementation, separate from actual driver inputs.

Correction: Add the exact helper predicate, empty/nonempty request and device RequestNames cases, and source evidence. Exclude forbidden Pod resources.claims routes per N09.

Primary: [pkg/kubelet/cm/dra/claiminfo.go:122-137](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/cm/dra/claiminfo.go#L122-L137), [pkg/kubelet/cm/dra/manager.go:492-504](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/cm/dra/manager.go#L492-L504).

### N29: Accepted large int64 seconds have omitted duration-overflow and sentinel limits

**FAIL — conditional-static-product-limit-undocumented**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:919` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

API tolerationSeconds has no upper bound in 4360–4421. Actual getMinTolerationTime uses MaxInt64 as the infinite sentinel and multiplies the minimum positive int64 seconds by time.Second at181. Positive9223372037 wraps to-9223372036709551616; processPodOnNode473 treats it as infinite. ExplicitMaxInt64 also retains the sentinel. Sleep validates seconds against the nonnil Pod grace only, and runSleepHandler116 uses the same multiplication: an accepted positive 9223372037 with at-least-matching grace and enabled node gate yields a due-now timer. Current longest-wait/shortest-seconds prose omits these static selected limits. No selected hook/eviction was executed.

Correction: State signed nanosecond conversion and MaxInt64 sentinel as conditional static implementation limits. Add large positive seconds cases for Sleep/grace and NoExecute, qualify owner action to use bounded durations, and keep Unit/Live execution separate.

Primary: [pkg/apis/core/validation/validation.go:3376-3393](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L3376-L3393), [pkg/apis/core/validation/validation.go:4360-4421](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L4360-L4421), [pkg/apis/core/validation/validation.go:4625-4734](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L4625-L4734), [pkg/controller/tainteviction/taint_eviction.go:160-181](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/controller/tainteviction/taint_eviction.go#L160-L181), [pkg/controller/tainteviction/taint_eviction.go:471-476](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/controller/tainteviction/taint_eviction.go#L471-L476), [pkg/kubelet/lifecycle/handlers.go:112-125](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/lifecycle/handlers.go#L112-L125), [doc/go_spec.html:5025-5031](https://github.com/golang/go/blob/go1.25.0/doc/go_spec.html#L5025-L5031), [src/time/time.go:911](https://github.com/golang/go/blob/go1.25.0/src/time/time.go#L911), [src/time/time.go:930-937](https://github.com/golang/go/blob/go1.25.0/src/time/time.go#L930-L937), [src/time/sleep.go:52-64](https://github.com/golang/go/blob/go1.25.0/src/time/sleep.go#L52-L64), [src/time/sleep.go:202-204](https://github.com/golang/go/blob/go1.25.0/src/time/sleep.go#L202-L204).

### N30: Token cap evidence excludes its governing condition

**FAIL — missing-available-source-proof**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:1014` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

Attached token.go223–258 cap caption excludes222: shortening occurs only when configured maximum is positive and requested seconds exceeds it. Companion212–252 range does not repair each exact caption.

Correction: Extend exact cited range to222 and retain conditional cap wording.

Primary: [pkg/registry/core/serviceaccount/storage/token.go:222-258](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/registry/core/serviceaccount/storage/token.go#L222-L258).

### N31: Signed named-bundle trust cache survives signer invalidation

**FAIL — conditional-static-product-limit-undocumented**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:762` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

GetTrustAnchorsByName caches ctbName-only keys. dropCacheFor on a signed bundle removes only signerName-matching keys; named signed-bundle entries survive its informer events until TTL/eviction. This limit differs from the correctly documented nil/empty selector shared key. No cache event was executed.

Correction: State named-signed-bundle stale-cache limit and distinguish unsigned name invalidation, signer invalidation and TTL; add named signed update/delete cases.

Primary: [pkg/kubelet/clustertrustbundle/clustertrustbundle_manager.go:200-225](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/clustertrustbundle/clustertrustbundle_manager.go#L200-L225), [pkg/kubelet/clustertrustbundle/clustertrustbundle_manager.go:143-194](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/kubelet/clustertrustbundle/clustertrustbundle_manager.go#L143-L194).

### N32: Projection path normalization and publication failures remain unqualified

**FAIL — conditional-static-product-limit-undocumented**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:769` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

API checked-path set uses raw strings; accepted a//b and a/b differ there. Secret/ConfigMap map payload retains raw paths, whereas atomic validatePayload cleans keys and replaces a previous cleaned key in Go map iteration order. File/prefix a and a/b can pass raw API checks but writePayloadToDir fails before publication. Windows deletes old data link before creating a new link; after successful publication, visible-link/cleanup errors return without restoring old data. Current atomic-writer/update prose does not enumerate these effective precedence and error/recovery limits. Static source deduction; no node volume operation executed.

Correction: Document cleaned-path alias overwrite and prefix setup failures, selected Windows publish sequence and post-publication error/no-rollback behavior; owners must use distinct cleaned output paths and verify actual files before consuming.

Primary: [pkg/apis/core/validation/validation.go:1159-1230](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L1159-L1230), [pkg/apis/core/validation/validation.go:1405-1429](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L1405-L1429), [pkg/apis/core/validation/validation.go:1491-1508](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/apis/core/validation/validation.go#L1491-L1508), [pkg/volume/util/atomic_writer.go:141-281](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/volume/util/atomic_writer.go#L141-L281), [pkg/volume/util/atomic_writer.go:417-453](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/volume/util/atomic_writer.go#L417-L453), [pkg/volume/secret/secret.go:267-291](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/volume/secret/secret.go#L267-L291), [pkg/volume/configmap/configmap.go:271-300](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/volume/configmap/configmap.go#L271-L300), [pkg/volume/downwardapi/downwardapi.go:245-274](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/volume/downwardapi/downwardapi.go#L245-L274), [doc/go_spec.html:6746-6754](https://github.com/golang/go/blob/go1.25.0/doc/go_spec.html#L6746-L6754).

### N33: Original apply-ownership boundary is not qualified

**FAIL — missing-required-available-source-proof**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:18` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

All 347 retained workitems require changed value with apply ownership and parent constraints. Current operationScope excludes apply construction and ownership; permitted-update cases assume an already-permitted typed update. The shared manifest authority identifies client-side apply for registry-local and a named apply/synchronization operation elsewhere. Those actual authored routes must be qualified separately. For server-side apply specifically, fresh source uses unstructured patch, fieldManager.Apply(force/manager), structured fieldsets and merge before defaults/admission/strategy. That available route is not interchangeable with client-side apply or ordinary typed create. Scalar fresh-decode prose and a scope disclaimer cannot fulfill the required ownership operation.

Correction: Qualify the actual named authored operation for each original identity: client-side apply/strategic or other patch versus selected server-side apply, ownership/conflicts/force/omission/null/collection merge and parent constraints. Retain a separate typed-create boundary; do not infer that every authored route uses SSA.

Primary: [staging/src/k8s.io/apiserver/pkg/endpoints/handlers/patch.go:499-540](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apiserver/pkg/endpoints/handlers/patch.go#L499-L540), [staging/src/k8s.io/apiserver/pkg/endpoints/handlers/patch.go:655-704](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apiserver/pkg/endpoints/handlers/patch.go#L655-L704), [staging/src/k8s.io/apimachinery/pkg/util/managedfields/internal/structuredmerge.go:121-181](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apimachinery/pkg/util/managedfields/internal/structuredmerge.go#L121-L181), [staging/src/k8s.io/apiserver/pkg/endpoints/handlers/create.go:116-208](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/apiserver/pkg/endpoints/handlers/create.go#L116-L208).

### N34: CSI fsType pointer is falsely described as ordinary scalar

**FAIL — incorrect-typed-decode-contract**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:531` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

The child row uses string generator and describes omission as empty scalar and null as unchanged scalar. Actual FSType is *string: absent/null is nil, explicit empty is nonnil. CSI mounter branches on nonnil before dereference; equal effective driver text does not erase authored pointer distinction.

Correction: Use pointer-string field generator; change omitted/null/cases to nil and explicit empty to nonnil empty, preserving effective CSI fallback.

Primary: [staging/src/k8s.io/api/core/v1/types.go:2267-2294](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/staging/src/k8s.io/api/core/v1/types.go#L2267-L2294), [vendor/sigs.k8s.io/json/internal/golang/encoding/json/decode.go:453-525](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/vendor/sigs.k8s.io/json/internal/golang/encoding/json/decode.go#L453-L525), [vendor/sigs.k8s.io/json/internal/golang/encoding/json/decode.go:950-1004](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/vendor/sigs.k8s.io/json/internal/golang/encoding/json/decode.go#L950-L1004), [pkg/volume/csi/csi_mounter.go:146-160](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/pkg/volume/csi/csi_mounter.go#L146-L160).

### N35: Full Deployment authority retains 104 missing metadata/envelope paths

**FAIL — missing-full-authority-receiver-proof**. Frozen `scripts/docs-kubernetes-apps-receiver-contracts.mjs:1032` (file SHA `dfeefe8f3cec699739d1e81ab3b6ce2f1ef212d3f72ac0db67fa7908ef03c9b6`).

Fresh independently enumerated Deployment authority has 1389 paths; subject authors1285 and has104missing metadata/envelope paths. Full coverage fails. Parent metadata-owner disclaimer cannot waive those globally required records or retained contexts.

Correction: Keep every missing path open and supply full receiver behavior before aggregate acceptance; do not remove original identities or count1285as full Deployment.

Primary: [api/openapi-spec/swagger.json](https://github.com/kubernetes/kubernetes/blob/66452049f3d692768c39c797b21b793dce80314e/api/openapi-spec/swagger.json).

## Executed checks and limits

All 14 relevant private Node tests completed with exit0: receiver coverage, recursive schema boundaries and API-reference renderer tests. No tests were skipped or cancelled. The isolated additions/removals detected a new/missing child despite the 104 baseline holes. The individual type mutation rediscovered the changed type; this is not a passing semantic-drift test. Import/export determinism and file/hash checks also passed. Full coverage correctly FAILS with `API_RECEIVER_CONTRACT_MISSING`. See [test log](tests.log), [checks](checks.json), [coverage](coverage.json), and [executed/nonexecuted ledger](executed-and-nonexecuted.json).

The large-seconds finding includes an executed Python signed64 arithmetic witness, backed by pinned Go1.25.0 source/spec; no Go timer, eviction or lifecycle receiver was executed. Trust-cache stale-key behavior and atomic projection alias/Windows/postpublication behavior are conditional static source deductions, not live demonstrations. They are distinct from missing available-source proof: the latter needs documentation/citations now, while actual node/gate/driver/issuer inputs and runtime results remain unexecuted.

No cluster/API requests, source-case Go runtime tests, node/probe/storage/DRA/issuer/cache operations, deployments, published generation, repository edits, commits or pushes were performed. No running Pod, successful HTTP response, rendered reference, synthetic provider or test count is claimed as product success. Two independent live journeys and other Reader/Quality/package gates remain outside this review and are not granted. Failed guessed-path404 fetches and a rate-limited contents API request supplied no evidence; exact raw primary fallback fetches are separately recorded.

## Provenance and seal

The 244 fresh primary fetches have individual URL, byte count, SHA-256 and local bytes. All were verified against the saved manifest. [Frozen files](frozen-files-sha256.json) bind every archived subject/shared-authority file to the immutable archive. Private YAML dependency setup and mutation/test artifacts are included in the artifact manifest; they are not frozen Git subject files.

The [sealed artifact manifest](artifact-manifest.json) covers every regular artifact and separately records symlink targets, excluding only the manifest and its own digest to avoid self-reference. `artifact-manifest.sha256` binds that manifest. No later writer correction is evaluated here. Further correction requires another fresh review of the corrected immutable subject; these findings and original identities remain open until then.
