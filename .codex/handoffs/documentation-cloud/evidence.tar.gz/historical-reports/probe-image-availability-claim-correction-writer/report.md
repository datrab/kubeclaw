# Image-availability assurance correction

Author correction only, addressing complete Quality finding QF-01. Exclusive repository edit: one prose paragraph in `docs/site/use/install.md`. No command, fenced body, Pod manifest, product behavior, other page, generator, commit, push or live action changed.

Read-only preparation completed while root's full-suite guard was active. The author retained a before-page snapshot and proposed prose privately, and did not edit a repository page until root explicitly released edits after its reported terminal full-suite result. Root reported 268 PASS/0 fail/0 skip; that is root's execution, not an author execution or approval of the revised prose.

Read the complete sealed `late-pv-identity-complete-quality-fresh/REPORT.md` and QF-01 record, current project quality requirements and applicable A98 expected-result contracts. Inspected the entire install image/pull/cache/node claim family, selected Pod, immutable image authority and supporting node qualification route. The only unsupported assurance was the paragraph claiming the probe establishes an exact-image pull. Registry uncached-proof requirements, earlier node prerequisites, failure diagnosis and later actual image-ID/readiness checks remain separate and correct within this correction scope.

The paragraph now limits successful proof to availability and execution of the pinned image on the node that ran the Pod. It states that `IfNotPresent` can use a cached image and explicitly excludes uncached registry pull, registry reachability, other-node availability and later workload images. It links the existing platform-owner node/client qualification, which requires separate per-node uncached proof and says the repository supplies no complete node installation/restart/rollback/uncached-pull procedure. No cache eviction, policy change or unsupported pull command was added. The final small wording refinement explicitly names registry reachability as requested by QF-01.

Primary upstream authority checked: [Kubernetes image pull policy](https://kubernetes.io/docs/concepts/containers/images/#image-pull-policy), specifically its IfNotPresent semantics and cached-layer distinction. The source Pod still selects `imagePullPolicy: IfNotPresent`. `versions.json` and Ops Dockerfile complete pinned Git blobs equal current files; the OPS_NODE_BASE selection is unchanged. This is source-backed semantic qualification, not a new live cached-image/pull experiment.

Actual verification:

- All 20 install Bash bodies and every fenced body are byte-identical before/after; `body-guard.json` retains their exact hashes. Prior native observation/create/capture/cleanup execution evidence therefore applies to unchanged command bodies, not to any new operational claim.
- 57 pinned source references pass complete Git-file equality and range bounds; 54 scoped local links/anchors pass the repository shared Markdown parser, including the new canonical qualification link.
- Fresh operator-task check exits0; fresh Worker Core trust check exits0. Terminal command/timestamp/exit receipts and full logs are retained.
- Actual publication check exits1. Exact reasons remain stale generated plugin catalogues and operator plugin matrix; long sentences in open-issues; passive voice in nova-core/maintenance; and long maintenance source-callout sentences. It names no install or Worker Trust finding. The check ran before the final registry-reachability wording refinement; that refinement changes no route/body/source contract and passed the final manual sentence/condition check. No global publication PASS is claimed.
- Final scoped diff check exits0; the before/after page and final body/input/artifact guards pass.

No source/runtime/security/control semantics or successful live result was created by this prose correction. Controlled-language method: direct sentences, explicit scope limits, stable technical terminology, actual publication findings, and manual final wording review. No formal ASD-STE100 certification is claimed. Fresh independent complete Quality confirmation remains required; previous Quality FAIL and Source/Reader judgments remain tied to their frozen revisions.

Final install/frozen Worker Trust hashes, the supporting maintenance snapshot, read authorities, QF report/manifests, exact source links, proposed/before/final prose, current checks and all private artifacts are bound by `manifest.json`. No unexecuted build/browser/cluster/pull/provider/signing/Reader or package gate is reported as passed.

Root assigned a separate language writer to maintenance/Nova/issue sources after these checks. Maintenance is retained here only as the supporting read snapshot used for uncached-node qualification, not a current author-owned frozen page. Concurrent later language changes are excluded from this install-only seal.
