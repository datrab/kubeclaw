# Author transitive custody correction — frozen, independent review pending

The generic API producer evaluator, output adapters, token/shlex rules and source roots remain unchanged. This correction is bounded to documentation qualification and its input graph. No product runtime source, commit, push, full configuration generation or publication was changed/performed.

## Capability admission and closure

Binding admission now matches the finite binding grammar actually recorded by the graph. Nested, array and defaulted binding projections are rejected at the first capability transfer rather than permitting identifiers with lost provenance. Object projection is admitted only for builtin namespace capability; destructuring a saved Promise cannot erase Promise custody. Await derives namespace capability from its operand's known Promise provenance, including saved aliases and finite identifier assignments. Assignment target syntax is treated as a binding name, while subsequent consumers retain the assigned capability. Require call/apply acquisition uses the same actual forwarded argument extraction as the load inventory. Unknown destinations retain unresolved operations and cannot be qualified through fingerprints.

Every actual finite selected local module is inventoried to dependency closure. Static imports, reexports, literal dynamic imports and recognized local loader edges enqueue their resolved targets. Existing edges from modules already scanned as execution roots propagate into the closure too. Local unresolved edges are retained even if their source enters the closure only later. Unsupported capabilities and unknown edges in bridges fail closed. Canonical local dependencies cannot escape into vendor/node_modules or outside the repository.

The graph cache binds primary inventory, complete closure bytes and canonical paths, and original dependency resolution paths. This detects bridge-only changes and symlink retargeting even when an unchanged original canonical file remains present. On invalidation, closure is rebuilt from primary inputs, so removed edges do not leave stale consumers. Syntax cache reuses only ASTs whose complete source bytes are identical; qualification still checks current recipe caller/guard inputs before using a positive cache result.

## Source authority unchanged

All 12 compiled semantic recipe anchors, their 27 actual operation fingerprints, primary Source authority, caller/schema/package guard authority and the registry remain byte-identical to the preceding author freeze. No JSON row/digest was refreshed to admit a consumer. These remain finite actual role recipes, not universal language classes.

| Primary Source | Operation count | Semantic class |
|---|---:|---|
| `scripts/check-ap08-effectful-guide.mjs` | 3 | `fixed-repository-modules` |
| `scripts/check-ap08-minimal-plugin.mjs` | 2 | `fixed-repository-modules` |
| `scripts/check-core-architecture-guides.mjs` | 1 | `fixed-repository-modules` |
| `scripts/check-platform-specialist-guides.mjs` | 1 | `finite-repository-modules` |
| `scripts/docs-configuration-inventory.mjs` | 6 | `finite-documentation-runtime-semantics` |
| `scripts/docs-lint-policy-reference.mjs` | 2 | `finite-repository-modules` |
| `scripts/updates/check-renovate.mjs` | 3 | `external-renovate-fixed-suffixes` |
| `skills/buster/engine/test-gates/provider-child.mjs` | 1 | `registered-package-protocol-module` |
| `skills/buster/engine/test-gates/report-adapter-child.mjs` | 1 | `registered-package-protocol-module` |
| `skills/common/plugin-runtime/foundation/isolation/child.mjs` | 1 | `registered-package-protocol-module` |
| `skills/common/plugin-runtime/foundation/registry/activation.ts` | 1 | `trusted-package-registration-module` |
| `skills/common/plugin-runtime/foundation/registry/import-audit-child.mjs` | 5 | `bounded-builtins-and-trusted-registration` |

Fixed repository and ESLint/configuration input paths now include their local dependency closure. Registered-package child recipes remain qualified only under the actual verified parent protocols, canonical package selection, digest/snapshot and schema/trust guards. Arbitrary standalone stdin/argv use of those child internals is not claimed safe. Renovate still uses an external RENOVATE_PACKAGE_ROOT or /usr/local/renovate with three fixed suffixes; external dependency integrity remains an external authority, not repository containment proof. The existing recipes and limits were re-read against the preceding independent review's complete class/guard assessment.

## Executed author evidence

Final focused suite: 16 PASS, 0 FAIL, 0 SKIP. New cases cover nested namespace acquisition families, saved Promise aliases/assignment, builtin forwarding, unsupported Promise bindings, two-level bridges, cached bridge mutation, symlink retargeting, unresolved/missing edges and unknown capability transfers inside bridges.

The exact preceding independent harnesses were copied privately and rerun: old55 PASS plus fresh25 PASS, total80 PASS. Their results are author reproductions, not fresh Source acceptance. All six actual Node witnesses were also privately reproduced; each reaches the unchanged seven receiver descriptions. Exact final checkout verification is running; its terminal result will be appended below.

Failures are preserved: focused-expanded-candidate.log records a cache guard TypeError; focused-expanded-candidate2/3.log record assignment-target custody being conservatively rejected while the test required a known public-consumer diagnostic. The final implementation retains simple identifier assignment provenance and the final test requires the public consumer rejection. Prior sealed writer/reviewer logs remain untouched. No historical green full API run is acceptance for this candidate.

## Freeze and limits

Frozen HEAD: 5e41169d8b334b12ffceb7143511b33bcfb9454a (root-owned unrelated changes).

- `scripts/docs-api-output-discovery.mjs` SHA256 `204c0247771ea81cc757003bc7a25f20b428ddca14c3d40c25690de8738905fe`
- `scripts/docs-api-producer-adapter-authorities.json` SHA256 `c64a6acbf641f2b72696dcc2e7872bd1b03e0dcccb503f30b5737d292327e337`
- `scripts/tests/api-output-publication.test.mjs` SHA256 `b3e79add1386cbf2b0f7cc36185665636d32e70973c90392f8dc15e556eb201e`

Frozen source snapshots and frozen-source-manifest.json preserve exact bytes. git diff --check passed. This remains a conservative documentation helper boundary rather than a general JavaScript publication interpreter. Unsupported capability transfers can reject legitimate new Source patterns until separately reviewed; no scope reduction, filename exemption or generic public producer suppression was added. Whole-critical-scope fresh independent Source review and root-owned integrated API verification remain outstanding. No closure of A98/AP09 or broader Reader/runtime/upstream acceptance is claimed.

Final checkout terminal: exit0, 36 script outputs, 111 shell outputs, zero false PV helper selectors, one actual remove-qdrant PersistentVolume PATCH with all seven selected fields. Known YAML warnings remain in the retained log. All three frozen repository Source hashes remained unchanged.
