# Independent whole critical Source review: FAIL

This is a fresh independent read-only Source review of the complete current affected qualification, builtin admission/custody, canonical finite closure/cache, 12 compiled semantic recipes and 27 operations, actual parents/callers/schema authorities, public-consumer discoverability and preservation of the selected PV producer boundary. I am neither the author nor the Reader/Quality reviewer. This report grants no Reader, Quality, Astra, package, whole-gate or global acceptance. The product repository remained read-only; every probe mutation occurred in a disposable privately owned fixture.

## Exact inputs and scope

Initial observed checkout HEAD: `51975b92ed5154b76c65793e55933b4d8659d05d`. During unrelated root work HEAD advanced to `c837505ac9757841351d618d7189b9e907490d24`; scoped code remained frozen. The checkout has pre-existing modifications and is not a clean final AP09 evidence commit. `revision.txt` records the later HEAD; `input-hashes.json`, 86 frozen source snapshots and `end-hashes.json` bind every inspected input. All 86 end hashes match their captured bytes; 84 were captured at review start, and two additional primary sources were captured when reviewing actual harmless export uses and executable input support.

Independently observed SHA256:

- Discovery: `f3576c41006180edf300d5829333a185d5b163001372fef49f34175bba85d3d7`.
- Registry: `c64a6acbf641f2b72696dcc2e7872bd1b03e0dcccb503f30b5737d292327e337`.
- Current focused tests: `e3fa4c70e5f5f295f506431808fa7c218a26df5579d0f9016a0df5282a832a3a`.
- Pure PV metadata helper: `e91c3f85ee49f07e79aacabe185919120836979e6f4f5e61f8a62074b8c395c5`.

Quality basis: full `docs/blueprint/07-documentation-quality-standard.md` and `AP09-acceptance-contract.md`, notably product scope, unsupported exclusions, independent actual-source inspection, truthful evidence classes and negative discovery proof. A97-12/A98-14 forbid silently accepting new supported surfaces; this receives a bounded Source facet only. A98-01 task mapping receives no whole-gate PASS. Fixtures and the 261-entry catalogue were inspected as applicability inputs; no Reader exercise or full acceptance ledger was executed. A green current inventory is not complete consumer detection.

## F1 — executable input admission silently drops supported TypeScript modules and CommonJS unknown extensions

Material FAIL in current `scripts/docs-api-output-discovery.mjs:123`, `:127`, `:173–180` (especially the unconditional skip at line 180). Initial product discovery and finite selected source admission use `[cm]?js|ts`. Finite transitive resolution adds any existing file to `finiteClosure` and reads its bytes at lines 173–175, but the source visitor then silently skips every path outside this extension grammar. A canonical seed is subject to the same skip after symlink resolution. No executable/passive/unsupported classification rejects these skipped inputs.

This is an actual supported source class. `skills/common/plugin-runtime/foundation/packages/install.ts:126` explicitly accepts `.mts` registered modules, while `:133` scans `[cm]?js|[cm]?ts`, and `:138` strips TypeScript syntax. Default Node v24.21.0 in this environment executes `.mts` and `.cts`. Under CommonJS, require also executes unknown-extension and extensionless files as JavaScript. Their apparent filename type cannot establish passive data.

Independent valid default-Node witnesses, all returning the helper's seven records while current discovery accepts and returns `[]`:

1. A reviewed finite ESLint `.mjs` seed reexports from `bridge.mts`, which reexports the helper.
2. The same selected seed imports a default CommonJS `bridge.cts` that requires the helper.
3. Selected `.mjs` symlink resolves to canonical `.mts` or `.cts` seed that reaches the helper.
4. A safe canonical `.mjs` symlink seed imports an actual canonical `.mts` bridge; alias-side source identity does not repair its skipped body.
5. A cached safe `.mts` bridge is changed, and only that bridge, to reexport the helper. Discovery still accepts.
6. Selected `.mjs` -> scanned `gateway.cjs` -> `unknown.txt` requires the helper; the `.txt` body is skipped. A safe `.txt` bridge-only cache mutation also accepts.
7. Equivalent `.yaml` and extensionless CommonJS dependency bodies reach the helper and accept.
8. New public `tools/public.mts` and `tools/public.cts` helper consumers accept.
9. New public `.mts` imports named `_load` from node:module and returns the helper records. The new finite named-import guard is bypassed because the complete source is skipped before guard admission.

`independent-probes.json` has 14 cases: 11 valid silent nonrejections, two correctly rejected relative query/fragment inputs, and one accepted passive JSON baseline. `finite-class-probes.json` has 11 cases: `.mjs/.js/.ts/.cjs` correctly reject, `.mts/.cts/.txt/extensionless/.yaml` silently accept with valid actual runtime witnesses, passive `.json` accepts with zero records, and `.node` silently accepts the admission investigation. Each runtime observation is stored separately as `*-runtime.json`; the private harnesses reconstruct disposable fixtures.

The `.node` probe uses a deliberately invalid addon and actually fails with `ERR_DLOPEN_FAILED`. It establishes missing unsupported-input admission and the actual native-loader branch, not an executed native addon/helper consumer. No native addon was built, installed or claimed as a valid execution witness. Query/fragment `.mjs` imports were valid Node consumers but current discovery rejects them; they do not prove a current failure. The initial `.cts` named reexport experiment was corrected to a valid default CommonJS import before the final sealed probe run; final `.cts` witnesses return seven.

The bridge-only results do not prove that the cache key stayed unchanged: current cache facts can invalidate and rebuild, then the rebuilt visitor still skips the changed body. The material defect is incomplete graph admission and interpretation, not merely a stale cache digest. The graph misses the final edge and cannot invalidate the helper's docs-only exclusion.

Necessary correction: define intrinsic finite admission consistently for selected paths, their canonical identities, every local dependency, already-root/shared closures and cached rebuilds. Scan the actual supported executable JS/TS formats, including `.mts/.cts`; justify passive inputs by the selected loader's semantics (for example ordinary JSON), and intrinsically reject unsupported native/unknown executable inputs at their first transfer unless a narrowly reviewed finite scanner supports them. CommonJS `.txt/.yaml/extensionless` default execution makes adding only `.mts` insufficient. Preserve finite node:module named admission and first unsupported custody in every admitted executable body. Rerun the complete affected Source scope, not only these failing cases.

## Complete current claim-group Source assessment

| Claim group / applicable Source facet | Result | Source and observed evidence |
| --- | --- | --- |
| Exact pure helper and seven selected rows | PASS | Helper:1–137 unchanged, no imports, env/runtime loaders or publication; fixed exported receiver descriptions and exact operation recipe. |
| Docs exclusion needs qualified ancestry, direct/static/reexport/package consumer detection | FAIL complete supported domain | Discovery:319–368 checks inspected formats, prior probes pass; public `.mts/.cts` consumers evade acquisition. F1. |
| Finite named node:module admission, unknown future exports | PASS within visited executable grammar | Discovery:21–25, :186–194; actual runtime unreviewed names and hypothetical future name reject before transfer. F1 prevents whole executable-domain PASS. |
| Default/namespace/Module/createRequire/require acquisition; alias, assignment, forwarded calls | PASS within visited grammar | Discovery:196–252, prior 55 + 25 + 16 probe families independently rerun; unknown path/forwarding/custody escapes reject. |
| First unsupported transfer, nested/default/array/object/return/export/control custody and Promise continuations | PASS within visited grammar | Discovery:254–302; unsupported transfers fail before a recipe can authorize them; awaited saved Promise aliases remain capabilities. No general JS interpreter claim. |
| Narrow harmless builtinModules/stripTypeScriptTypes/syncBuiltinESMExports uses | PASS bounded semantics | plugin-source-closure.mjs:3–6 inventories builtin names; packages/install.ts:4,:133–138 transforms source text for syntax checks; import-audit-child.mjs:1,:105 synchronizes already-denied builtin effects. Their admission grants no general loading capability. |
| Canonical `.mjs` seed resolution, safe symlinks, alias decoys/retarget, repository/vendor escapes | PASS current inspected grammar | Discovery:127–147; current focused canonical tests and old closure witnesses independently pass. Original F2 is corrected for these executable forms. |
| Whole finite executable closure, fixed point/cycles/shared roots and cache rebuilds | FAIL | F1. `.mts/.cts`, unknown CommonJS and extensionless dependency bodies can be read but skipped; seed and bridge-only cached witnesses accept. |
| Compiled Source semantic authority independent of refreshed JSON | PASS bounded 12/27 recipes | Discovery:31–120; own recipe audit verifies every compiled recipe and primary/caller/schema hash, own AST operation audit verifies actual 27 operations; refreshed-digest/source/schema/caller mutations reject. |
| Actual guide/configuration/ESLint finite selected source classes | PASS finite class authority; FAIL executable closure | Actual fixed path imports, four-name ESLint arrays, literal importSource callers and --root boundary inspected; F1 prevents complete transitive input authority. |
| External Renovate fixed suffix authority | PASS bounded interpretation | check-renovate.mjs:6–9 selects external root/default and three exact suffixes; versions.json Source-bound. External dependency integrity is external authority, not repository containment or arbitrary runtime package integrity. |
| Registered provider/report/isolated/trusted package protocols | PASS bounded interpretation | Actual canonical package/file containment, digest/snapshot/trust/protocol/export/schema guards independently inspected below. No standalone arbitrary stdin/argv or universal imported-plugin effect proof. |
| Generic producer/output-role/public discoverability and token/shlex semantics preservation | PASS preservation | Own byte comparison finds complete discovery suffix from documentationEdgeOrder through EOF unchanged versus prior Source; current public docs emitter discovered, unknown writer rejected and generic conservative producer tests pass. Inherited executable coverage defect is separately F1, not hidden by preservation. |
| Actual PV retirement PATCH four operations/seven fields | PASS Source/offline discovery | remove-qdrant.sh:57–77 and discovery:1951 onward; current checkout discovers exactly one PV PATCH with three ordered tests then add Delete and all seven selected receiver fields. No live API/controller/backend claim. |
| Complete critical Source qualification | FAIL | New supported executable consumers can retain the docs-only helper exclusion; prior F1/F2 focused corrections and green tests do not close the complete domain. |

## All actual primary authorities and caller guards

`recipe-audit.json` was generated by this reviewer from current compiled primary-code anchors, separately comparing registry recipe bytes and every complete source/caller authority input. All twelve anchors match. `operation-audit.json` independently walks the current TypeScript AST for every actual call expression and enclosing function, recording exact source line and operation fingerprint. All 27 agree; no author PASS or regenerated registry hash is used as semantic authority.

| Actual source | Semantic class | Operations |
| --- | --- | ---: |
| scripts/check-ap08-effectful-guide.mjs | fixed-repository-modules | 3 |
| scripts/check-ap08-minimal-plugin.mjs | fixed-repository-modules | 2 |
| scripts/check-core-architecture-guides.mjs | fixed-repository-modules | 1 |
| scripts/check-platform-specialist-guides.mjs | finite-repository-modules | 1 |
| scripts/docs-configuration-inventory.mjs | finite-documentation-runtime-semantics | 6 |
| scripts/docs-lint-policy-reference.mjs | finite-repository-modules | 2 |
| scripts/updates/check-renovate.mjs | external-renovate-fixed-suffixes | 3 |
| skills/buster/engine/test-gates/provider-child.mjs | registered-package-protocol-module | 1 |
| skills/buster/engine/test-gates/report-adapter-child.mjs | registered-package-protocol-module | 1 |
| skills/common/plugin-runtime/foundation/isolation/child.mjs | registered-package-protocol-module | 1 |
| skills/common/plugin-runtime/foundation/registry/activation.ts | trusted-package-registration-module | 1 |
| skills/common/plugin-runtime/foundation/registry/import-audit-child.mjs | bounded-builtins-and-trusted-registration | 5 |

Actual guide roots are const repository roots; effectful and minimal guides use literal fixed modules, core architecture imports literal capability vocabulary, specialist/lint generators select the actual four-name ESLint array and lint's fixed tool-registry path. Configuration runtime semantics uses its documented selected checkout --root and literal importSource callers at :7015–7129, plus the five literal imports at :7182–7227. These are specific finite input classes, not arbitrarily author-renewable dynamic paths.

Provider-loader.ts:43–77 canonicalizes the registered module within copied package and verifies original/copied digest; :199–205 sends initialize module/export. Provider-child:50–57 enforces initialize and function factory. Report-adapter-runtime.ts:283–304 verifies source and snapshot digest then canonical package module; report child:17–25 enforces one adapt request and function export. Isolation runner:23–33 canonicalizes package and module, :41–48 supplies bounded filesystem reads and invokes the selected module; isolation child:78–84 checks invoke/surface/export. Registry build.ts:33–60 canonicalizes and validates registered module/schema files. Discovery.ts:78–102 uses trusted builtin roots, source digest allowlists and verified attestations; digest.ts:6–27 rejects package symlinks and hashes package contents. Activation.ts:28–45 checks digest, :55–89 distinguishes trusted/isolated loading, :121 audits before trusted activation. Import-audit parent:27–48 selects trusted registered module/export; child:14–100 patches fixed builtin effects, :105 synchronizes ESM exports, then imports the module and checks function/global/process state. Actual JSON schema and parser authorities are full-byte-bound in the audit and frozen inputs. The parent protocol trust boundary does not assert that arbitrary direct child stdin/argv is safe, nor that every outside package import has no public effect.

## Executed checks and limits

Own executed broad probes: old 55 PASS, prior-new 25 PASS, admission 16 PASS, closure 7 PASS: 103 total, zero failures. This independently reproduces corrections and broad previously covered behavior rather than accepting author evidence. Own current focused tests terminal 18 PASS, zero FAIL/SKIP/CANCEL, 4817 ms. The first private focused relocation missed imports, and the second overbroad text replacement also changed embedded fixture strings; their failed logs are retained. The final relocation changes actual top-level imports and real Source URLs only, and is terminal 18/0. Product code was never changed to fix the reviewer harness.

New independent tests: 25 cases, eight expected outcomes pass and seventeen silent nonrejections. Sixteen nonrejections have valid default Node runtime witnesses returning seven records; the remaining native-addon case is an admission investigation with actual runtime failure, not valid helper execution. Prior runtime witness sets are also independently rerun and return seven records in their recorded cases. Checkout discovery terminal exit0: 36 script outputs, 111 shell outputs, no false PV helper output, one actual PV PATCH and seven fields; checkout log retains YAML warnings.

Root independently reports its whole dynamically discovered nine-file API suite terminal0: 190 PASS, zero FAIL/SKIP/CANCEL, 187344 ms; artifacts are `/home/node/Documents/Codex/a98-evidence/root-integrated-api-named-canonical-corrected/result.json` and `tests.log`. That root-owned suite was not duplicated and is bounded testing evidence, not semantic Source acceptance. This report's new probes expose uncovered consumers despite those green results.

Not executed: live Kubernetes writes, API admission/update/controller/storage-driver/backend behavior, native addon compilation, full config regeneration, target image/deployment/product runtime, cluster/provider/media/SQL/Secret operations, all 84 full-contract acceptance mutations, Reader/Quality/Astra/global/package acceptance, commits/pushes or installs. No current upstream runtime or storage-erasure acceptance is inferred from unchanged helper prose. Every PASS above is confined to its stated Source facet and executed finite grammar.

The finding is material and requires renewed whole critical Source review after correction. Prior immutable FAIL reviews retain their original revision/scope; this new FAIL does not retroactively alter them.

## Individual executed probe results


| old-probes case | Observed |
| --- | --- |
| namespace | PASS |
| default | PASS |
| namedAlias | PASS |
| computed | PASS |
| destructured | PASS |
| cjs | PASS |
| awaitNamespace | PASS |
| call | PASS |
| apply | PASS |
| bind | PASS |
| reflect | PASS |
| dynamicCall | PASS |
| dynamicApply | PASS |
| dynamicReflect | PASS |
| pass | PASS |
| returnLoader | PASS |
| returnFactory | PASS |
| returnNamespace | PASS |
| objectShorthand | PASS |
| objectProperty | PASS |
| objectAssignment | PASS |
| arrayTransfer | PASS |
| exportLoader | PASS |
| exportDefaultLoader | PASS |
| factoryObject | PASS |
| namespaceSpread | PASS |
| conditionalLoader | PASS |
| reassignment | PASS |
| plainRequireProperty | PASS |
| plainRequireReturn | PASS |
| dynamicBuiltin | PASS |
| nohintUnknown | PASS |
| publicDirect | PASS |
| publicTransitive | PASS |
| publicReexport | PASS |
| packageAlias | PASS |
| packageConditionalAlias | PASS |
| bin | PASS |
| main | PASS |
| exports | PASS |
| nonDocsInvocation | PASS |
| fileSymlink | PASS |
| directorySymlink | PASS |
| sourceDeleted | PASS |
| sourceRenamed | PASS |
| edgeChanged | PASS |
| edgeDeleted | PASS |
| docInvocationChanged | PASS |
| docInvocationRenamed | PASS |
| digestRefreshed:
console.log(JSON.stringify({apiVersion:"v1",kind:"ConfigMap"})); | PASS |
| digestRefreshed:
process.stdout.write(process.argv[2]); | PASS |
| digestRefreshed:
export const extra=1; | PASS |
| docsNamedPublicEmitter | PASS |
| docsNamedUnknownPublisher | PASS |
| publicDynamicRegistryRefresh | PASS |

| new-probes case | Observed |
| --- | --- |
| nestedNamespace | PASS |
| nestedDefault | PASS |
| nestedAwait | PASS |
| nestedRequire | PASS |
| nestedDynamic | PASS |
| exportNested | PASS |
| arrayDestructure | PASS |
| arrowReturn | PASS |
| getterReturn | PASS |
| asyncReturn | PASS |
| logicalFactory | PASS |
| optionalCall | PASS |
| templatePath | PASS |
| namespaceRest | PASS |
| asyncPromise | PASS |
| finiteOutsideTransitive:static | PASS |
| finiteOutsideTransitive:reexport | PASS |
| finiteOutsideTransitive:dynamic | PASS |
| finiteOutsideTransitive:bridge-cache | PASS |
| runtimeAuthority:skills/buster/engine/test-gates/provider-loader.ts:refresh=false | PASS |
| runtimeAuthority:skills/buster/engine/test-gates/provider-loader.ts:refresh=true | PASS |
| runtimeAuthority:skills/common/plugin-runtime/contracts/plugin-system/v2/plugin-system-v2.schema.json:refresh=false | PASS |
| runtimeAuthority:skills/common/plugin-runtime/contracts/plugin-system/v2/plugin-system-v2.schema.json:refresh=true | PASS |
| runtimeAuthority:skills/common/plugin-runtime/foundation/registry/digest.ts:refresh=false | PASS |
| runtimeAuthority:skills/common/plugin-runtime/foundation/registry/digest.ts:refresh=true | PASS |

| additional-probes case | Observed |
| --- | --- |
| namedPreload | PASS |
| namedPrivateLoad | PASS |
| namedPrivateLoadDefault | PASS |
| namedPrivateLoaderEscape | PASS |
| namedPrivateLoadDynamic | PASS |
| importEquals | PASS |
| namedRegister | PASS |
| registerHooks | PASS |
| moduleConstructor | PASS |
| namespacePrivate | PASS |
| nestedPromiseDefault | PASS |
| promiseAssignment | PASS |
| forwardingRequire | PASS |
| privateBuiltinReexport | PASS |
| builtinNamespacePrototype | PASS |
| deferredPromise | PASS |

| closure-probes case | Observed |
| --- | --- |
| finiteOutsideTransitive:selected-symlink | PASS |
| finiteOutsideTransitive:selected-symlink-cache | PASS |
| finiteOutsideTransitive:multibridge-cycle | PASS |
| finiteOutsideTransitive:shared-root | PASS |
| finiteOutsideTransitive:extension-resolution | PASS |
| finiteOutsideTransitive:missing-after-cache | PASS |
| finiteOutsideTransitive:unknown-bridge | PASS |

| independent-probes case | Observed |
| --- | --- |
| mts | FAIL: expected rejection; discovery accepted |
| cts | FAIL: expected rejection; discovery accepted |
| mts-canonical | FAIL: expected rejection; discovery accepted |
| mts-cache | FAIL: expected rejection; discovery accepted |
| mjs-query | PASS |
| mjs-fragment | PASS |
| seed-mts | FAIL: expected rejection; discovery accepted |
| seed-cts | FAIL: expected rejection; discovery accepted |
| unknown-txt | FAIL: expected rejection; discovery accepted |
| unknown-cache | FAIL: expected rejection; discovery accepted |
| passive-json | PASS |
| public-mts | FAIL: expected rejection; discovery accepted |
| public-cts | FAIL: expected rejection; discovery accepted |
| named-mts | FAIL: expected rejection; discovery accepted |

| finite-class-probes case | Observed |
| --- | --- |
| transitive-class:mjs | PASS |
| transitive-class:js | PASS |
| transitive-class:ts | PASS |
| transitive-class:cjs | PASS |
| transitive-class:mts | FAIL: expected rejection; discovery accepted |
| transitive-class:cts | FAIL: expected rejection; discovery accepted |
| transitive-class:txt | FAIL: expected rejection; discovery accepted |
| transitive-class:extensionless | FAIL: expected rejection; discovery accepted |
| transitive-class:yaml | FAIL: expected rejection; discovery accepted |
| transitive-class:node | FAIL: expected rejection; discovery accepted |
| transitive-class:json | PASS |
