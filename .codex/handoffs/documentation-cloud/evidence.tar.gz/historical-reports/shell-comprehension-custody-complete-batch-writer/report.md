# AUTHOR — coherent shell and comprehension custody correction

Owning correction source/unit/native work is complete. Actual full receiving gates are **NOT RUN**, pending Root-coordinated semantic API rebind and a new independent complete Tool Source review. This author does not award independent Source, Reader, Quality, package, or global acceptance.

Agent `/root/shell_comprehension_custody_complete_batch_writer`, explicitly assigned configuration gpt-6.1-sol/medium/fresh-none. This records assigned tool configuration, not backend identity certification. Repository `/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04`, branch docs/documentation-overhaul, observed HEAD30824cc555fa2623142752646f26dcc43072b5f7. Shared working tree is dirty; this is exact working-tree evidence, not clean-checkout or commit evidence. Exclusive writes are the two owning repo files; all other author writes are private evidence. No API authority, generated/documentation/nav/library/classification/matrix/product source was edited. Root owns integration, commits and pushes.

## Primary authority and historical failures

The independent complete report `wrapper-named-write-integrated-complete-tool-source-fresh/report.md` SHA027d7f610353d6a0a0e4628c889fdb191999ea2e7446a5ba7b991dfab42df080 and manifest SHA210859a6cdd884d97bb121207d183ce36a67935276d40283ff6e7b56a19c1120 bind all61 artifacts. `independent-artifact-guard.json` rehashes all61 with zero mismatch. The full report and its individual F1–F10, Source facets and catalogue/gate decisions were read; actual native/receiving results, counterexamples, full-source witnesses and diagnostic were used as primary authorities. Quality07/AP09 contract/fixtures/execution plan and catalogue govern the source correction; binary gates cannot offset material failures with green counts.

The terminal COMPLETE FAIL3 retains R1 diagnostic identity, R2 two substitution false greens and R3 four comprehension capability false greens. The earlier COMPLETE FAIL2 and prior author actual21 receiving result20 PASS/1 FAIL remain historical failures. No old verdict is relabelled. Root's prior287 result is Root evidence, not author execution or semantic approval.

## Coherent corrections

R1: `acquiredPythonEnvironmentReads` constructs a new Error containing the receiving source and original reason, with the original error as cause. Mutating a previously rendered AssertionError.message was insufficient. `rendered-error.log` is a real uncaught child-process output from current production acquisition over the complete actual workload witness; exit1 includes `charts/ops-pod/templates/workload.yaml` and `unresolved nested shell stdin custody`. This is source-only production acquisition, not the full API-qualified environment receiver CLI. New unit controls also assert actual rendered stacks for missing body, dynamic body and unterminated heredoc through the same catch.

R2: both dollar and backtick command-substitution acquisition edges retain `unresolvedStdin`, pass depth+1 into bounded recursion, and preserve mapped source positions only where present, retaining file-input records. Nested shell -c still rejects recognized unresolved stdin before its parent can erase custody. No general shell expansion, fd-flow execution, provider operation or shell interpreter was added. Passive quoted recipes and Python script/module argv operands remain passive; supported inline substitution source still maps to its original os.getenv offset. Direct, dollar, backtick and nested-dollar stdin witnesses each execute natively with synthetic values and reject usefully in production acquisition.

R3: active comprehension AST identities delimit the temporary comprehension body. NamedExpr walks its actual AST parents up to an independent module/function/lambda boundary; a recognized transferred capability in an active comprehension rejects before binding/restoration. All list/set/dict/generator paths share this guard. The first iterable is visited before activating the temporary scope; direct local NamedExpr behavior remains supported. Function/class/method annotation getters, direct readers, filter and nested comprehension cases retain useful source-qualified rejection. Pure values and foreign methods remain passive. A lambda-local callable case retains its pre-existing explicit unresolved-callable rejection, without inheriting the comprehension escape label. This is finite capability custody, not arbitrary interprocedural evaluation or comprehension execution.

Adjacent useful-diagnostic repair: the existing capability-container iteration boundary used ast.comprehension.lineno, which does not exist. It now uses the owning comprehension node's actual lineno. This prevents a recognized rejection from devolving into AttributeError. It does not broaden evaluator semantics.

The complete delta is in `before-scanner.mjs.patch` and `before-tests.mjs.patch`. Actual TypeScript complete-function comparison has128 top-level bodies,125 unchanged; exactly acquiredPythonEnvironmentReads/pythonShellPrograms/pythonEnvironmentReads changed. Every previous65 test byte is an unchanged prefix (`existing-test-prefix-guard.json`).

## Stable exact owning pair

- Scanner SHA56949279c3f1099fd32cbb275bb757e3996be27cc2d42f6e7bd735a3ccbafe2d,873658 bytes.
- Tests SHA9aa832438e2aa253aa5dbbff0164bada122fb83b952f63bc8f2cb42f9af564e0,107777 bytes.

`freeze.json` and the complete private `frozen/` sources bind these bytes. The previous952-input qualification seal was rehashed (`dependency-guard.json`):950 unchanged, only the two owning files changed. This proves narrowly unchanged dependency/body currency, not reuse of a whole former verdict or validity of the now-stale API qualification. API rebind remains mandatory.

## Actual executions

`test-receipts.json` records original handles and terminal outcomes. Initial targeted run finished exit1 because its new generator fixture expected the new escape label despite an earlier existing helper-argument boundary. The fixture became a legally assigned generator plus next. Session75483 exit1 exposed a new first-iterable control that used a compile-illegal Python walrus placement; it was replaced by a legal direct first-iterable reader. Session99442 exit1 exposed a wrong new lambda-control expectation; that control now preserves its existing explicit rejection. These failed fixture attempts remain in their original logs; they are not semantic successes.

Stable targeted original38959 was observed terminal0,2 PASS/zero fail, command `node --test --test-name-pattern='nested shell stdin custody survives|comprehension walrus capabilities' scripts/tests/python-environment-discovery.test.mjs`. `targeted-complete.log` retains the actual results.

Stable full owning suite was executed once: original99673 observed terminal0,67 PASS/zero fail/skip,37.53s; command `node --test scripts/tests/python-environment-discovery.test.mjs`. `owning-full.log` and `full-native-results.json` retain150 actual native records: the previous137 plus13 new observations. Existing deliberate native failure/fallback cases retain their original expected meanings; not all records claim native success. New13 comprise four literal-shell stdin witnesses and nine comprehension capability variants, all native exit0 with observed synthetic value.

A separate source-only current probe (`current-probe.cjs`, terminal0) reacquired each of the independent report's eight complete receiving Sources using frozen production declarations. Four comprehension witnesses reject, two substitution witnesses reject, direct nested stdin rejects with source identity, and direct NamedExpr sensitivity discovers INDEPENDENT_FRESH_KEY. Its eight separate synthetic native processes exit0 with the expected value. These repeat witnesses are not counted as eight additional distinct suite cases. Whole product Python is compile-only; no bootstrap is executed. `current-complete-source-probe.json` retains actual complete-source results. Child rendered-error receipt is actual exit1, as required.

No Root whole11 suite, full generation, global mutation package, live deployment, provider/cluster/credential/host installation, product bootstrap or semantic API qualification was executed by this author. No terminal old process was restarted because of temporary model-capacity interruptions.

## Prepared actual receiving gates — NOT RUN

`receiving-cases.json` retains all17 previous-batch cases unchanged and adds the independent report's eight actual-source cases,25 cases total. With two baseline and two restored checks, the prepared full receiving harness expects29 decisions. `prepared-full-sources/` contains all25 complete future receiver mutations; every complete Python mutation compiles legally. The exact actual readiness command in whole workload YAML is replaced for shell witnesses; Python payloads append to complete bootstrap Sources. Each negative requires nonzero exit, intended key/reason and real receiving source identity; positive controls require exact436.

`prepared-receiving-status.json` is **NOT RUN**. `receiving-gates.py` deliberately requires a coordinated-api-freeze.json from Root's later semantic rebind before executing anything. No such authority is invented here. Root can copy this sealed preparation to a separate receiving supplement; this author's immutable report must not be overwritten to claim later execution. Preparation and source-only reacquisition do not replace actual receiving gates.

## Limits and remaining acceptance

R1–R3 owning regressions and native/source-only sensitivities pass at this exact pair. Full actual receiving decision, new coherent API binding, fresh complete independent Tool Source, Reader/Quality, package/global acceptance remain open. Individual previously failing F1/F2/F3/F5/F6/F8 and CFG010/011/013/015/018, REF003/012, A98-10/11/14 and A911-01/02/12 need the later independent decision; this author does not promote them to PASS. Other individually passing Source facets may reuse only exact bodies/dependencies and their bounded evidence, never an inherited aggregate verdict.

Finite shell nesting and recognized capability custody are deliberately bounded. Arbitrary shell expansion, arbitrary Python/interprocedural mutation, universal resolver behavior, target image/runtime effects and live authority are not certified. The 67-test green does not establish these higher evidence classes. No remaining failure in the assigned exact R1–R3 owning controls was observed; the rest of acceptance is explicitly deferred.
