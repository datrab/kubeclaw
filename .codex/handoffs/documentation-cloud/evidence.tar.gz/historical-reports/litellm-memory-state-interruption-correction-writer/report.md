# Authored note-state interruption correction

Author-only correction of S1 from the complete independent Source review. This report grants no Source, Reader, Quality, catalogue, package, gate, or global acceptance. A NEW complete independent Source/Reader/Quality review of the affected journey is required.

Exclusive repository write: docs/site/use/diagnose.md. Repository HEAD: 05cf01945803e4ccba8761101dc9bf1b8699135e, docs/documentation-overhaul. Shared working tree has unrelated concurrent changes; no clean acceptance checkout is claimed. No product/runtime file, commit, push, target image, cluster, provider, Secret, database/index reset, broad kill, full generator or mutable broad suite was changed or run.

Previous reviewed page SHA-256: 45c1b0c2300d7b3306b4ccdb5e4c286b233a95c3809227b557b4ef3769768870.
Frozen corrected page SHA-256: 9564e34d6357ea6cf567c7e28ac25cfeba848d1e094097e730050e94719a0804.
Exact previous/final bytes: diagnose-before.md and diagnose-frozen.md. Focused S1-only patch: authored-scope.diff. Final executable Bash blocks exactly match the extracted block artifacts that ran. No further page writes after freeze.

## Exact correction

memory_state_exec now validates the supported action and inline Node invocation, creates a unique operation ID, and writes an exclusive mode-0600 in-progress memory-stop record BEFORE remote note mutation. The record includes action, Pod, container and start timestamp. Its file is written synchronously and fs.fsyncSync is requested before exec. It persists independently of the administration shell.

The published creation program still exclusively creates one UUID-named synthetic note. It now rereads and checks the exact content, retains the note receipt with the operation ID, and emits a verified completion receipt on stderr. The published deletion program still verifies the exact receipt path/content, removes only that note, and now checks absence and emits its new operation-bound completion receipt. Both programs start no child processes.

The helper captures completion stderr in a retained private evidence file. Clearing its stop requires exit zero, a valid last completion record matching this invocation's operation ID and action, the current in-progress record's Pod/container and ID, an owned note path below the frozen workspace, and successful post-operation Pod and source identity checks. A zero exit without proof retains the stop. Nonzero, missing/invalid receipt, marker substitution, exec loss, interruption or failed post-check retains the stop and blocks subsequent stateful work.

Source identity comparison was factored into memory_source_matches_frozen. This narrow read path permits the current invocation to inspect the frozen source while its own marker exists. assert_memory_source still refuses any stop before allowing a new operation. Pod/source error paths preserve an existing JSON operation record instead of truncating its identity. No reattached shell automatically adopts or removes an in-progress marker.

The prose explicitly limits this helper to the two presented inline note programs. These short filesystem operations have no separate process watchdog or generic process framework. If completion is uncertain, OpenClaw and platform operations owners must establish the recorded note result and process/storage ownership through approved independent inspection before any stateful follow-up. The operator retains stop, note receipt and partial output and must not reindex, delete the note, retry, or remove the stop to finish the exercise.

All existing CLI observer/group behavior, frozen consumer/source identity, source-backed v2026.9.4 CLI and retry semantics, SecretRef/provider/model selection, timeout distinction, fault classification, route-versus-consumer recovery and narrow cleanup remain unchanged except preserving the state record during identity errors.

## Authority and primary reproduction

Read the FULL sealed complete Source report and seal.json, then its actual unchanged-functions state-interruption.bash, state-reattachment.bash and result log. The reviewer demonstrated first shell exit -9 with effect present and no stop, followed by a fresh shell reaching a second mutation. The correction targets that systemic before-exec window.

Read the complete relevant current procedure and its actual note/helper code. Rechecked the pinned primary OpenClaw manager acquisition/close and CLI search/recall behavior to preserve the broader semantics. The full governing quality standard and acceptance contract were read in the earlier continuous author assignment; their current hashes and catalogue hash remain unchanged. Reopened the current fixtures (file hash changed through separate work), and read the unchanged EXEC-FAIL-LITELLM conditions plus INF-012 and applicable OPR-002/005/006/007 obligations. No fixture, criterion or live result was waived. Scoped input hashes identify the exact current authorities and primary review reproduction. Read the official Node 24 fs.fsyncSync and exclusive wx API contract; the page links the flush mechanism. Device/power-loss durability is not inferred from the interruption checks.

## Executed checks

Private check.py extracts the actual current functions and creation/deletion command bodies from diagnose.md. No private state program replaces the published note code: successful and actual-interruption tests execute those exact bodies with private workspace/receipt paths substituted through their documented arguments. Cluster binding and Pod/source identities are local mocks; no actual kubectl runs.

Environment: Node v24.21.0, GNU Bash 5.3.9, Linux x86_64 on Alpine/musl.

- 29 complete page Bash blocks passed bash -n; 27 extracted inline Node modules passed node --check.
- Successful real private note creation and deletion each emitted an operation-bound receipt, passed post-checks, cleared its marker, and produced the expected content/absence.
- Nonzero after the private create effect retained its JSON in-progress stop.
- Missing and invalid completion receipts retained stop and returned 125.
- Simulated post-Pod and post-source identity changes returned 126 and retained the original JSON operation record.
- A substituted operation record failed receipt/ownership validation and remained stopped.
- The same independent-review interruption boundary was reproduced with the new extracted helper: mock effect then SIGKILL of its own Bash process. Exit -9, effect present AND stop present. A fresh Bash process returned125 before any second mutation.
- In additional tests, the exact published creation body changed the private note and the exact published deletion body removed the private note, then the mock exec killed only its own Bash process before return. Both exited -9 with the corresponding action's in-progress marker retained, despite their completion receipts already being emitted. New Bash processes refused subsequent work in both cases. The created private note remains evidence; the deleted note's absence is verified.
- Failed binding under set+e/plain, conditional and command-substitution calls returned126 before any exec.
- Scoped git diff --check passed. Final page/frozen bytes and every executed Bash block were compared exactly after tests.

A repeat initially encountered a stale private effect file from an earlier harness pass; the private fixture reset was corrected. This was a harness setup error, not a hidden documentation result. Final checks.json and logs record the successful scoped safety expectations. Deliberate SIGKILL exit -9 proves interruption handling, not successful task completion.

## Limits and handoff

These checks prove operator-helper behavior with actual local private note effects and simulated API identities/transport outcomes. They do not prove target-image behavior, live kubectl disconnect semantics, actual remote child absence after lost access, upstream callback completion, provider timeout/retry counts, live semantic recall, route enforcement, consumer recovery/cleanup, source/image attestation, remote abort, pipeline resume, publication/browser output, maintenance/mutation coverage or full acceptance.

Uncertain note completion requires owner inspection; the helper has no independent state-child watchdog. Existing CLI group quiescence remains separate from remote cancellation. No atomic Pod UID exec precondition or safe numeric-PID reattachment is invented. The complete affected journey must be freshly reviewed against the frozen corrected page. The earlier Source FAIL remains attached to its prior bytes and is not retrospectively changed.
