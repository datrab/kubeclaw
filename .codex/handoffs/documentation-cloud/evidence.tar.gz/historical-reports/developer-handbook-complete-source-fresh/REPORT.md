# Independent complete Developer Handbook Source review

Reviewer: /root/developer_handbook_complete_source_fresh. Role: fresh-context independent Source reviewer only; read-only repository. No author, Reader, Quality, participant, publisher, or approval identity is assumed.
Reviewed checkout initial/final HEAD: ad312e3e4f15223809fadef90bd90e1f689ce941. Published primary source baseline: 671234b056bf5f5f503e51e8db30f843e781ba6e. Exact candidate working bytes are separately frozen below; no clean-tree claim is made.

Overall assigned Source verdict: FAIL. Four material documentation omissions require correction. The corrected public exercise itself passes its Source coherence facet; no practical execution is inferred.

## Frozen deliverables and integrity

- docs/site/extend/developer-handbook.md: 87,656 bytes; SHA-256 b3f07aed9cebaf35a1b0a5c3ff210f8b45a0cf8092d4facab200319c7a844139.
- docs/site/extend/examples/platform-change-nova-lifecycle.json: 5,763 bytes; SHA-256 2a1d752198305331536e73a771fb0e2096eb501266f43612f6286ca786e406fc.

All 87 controlled inputs in initial-input-guard.json were unchanged at final-input-guard.json. Six supplemental authorities are explicitly identified as final comparisons against the immutable source baseline, not retroactive initial-session guards. HEAD, catalogue administrative state and unrelated dirty tool changes are not claims of whole-checkout immutability. Neither assigned file nor any repository source was edited.

The author's original MANIFEST.json and all 20 recorded artifact entries verified against actual bytes. The superseding public-fixture-boundary-correction/REPORT.md was read; it supersedes only public identity/baseline/assessment language. The composite root seal and corrected output hashes agree. All 107 source pins to 60 distinct files independently resolve to regular Git files, valid narrow ranges, and current byte equality. The 98 recorded command-authority mappings agree with their current package script bodies. Those mechanical observations do not establish semantic completeness or practical acceptance.

## Complete material findings

### SOURCE-F1: Ops network-policy test omits its Python dependency

Document location: docs/site/extend/developer-handbook.md:847-849, plus selected-route prerequisites at :134-145. The guide directs python3 tools/ops-mcp/test/policy_contract_test.py and says CI provides Python. It never names PyYAML or prepares it; the linked canonical Ops page also does not supply that prerequisite.
Primary authority: tools/ops-mcp/test/policy_contract_test.py:6 imports yaml before any test can execute. .github/workflows/build-ops-mcp.yaml:69-73 explicitly installs PyYAML==6.0.3, and the trusted publication body repeats that preparation at :162-166. Root npm installation and the separately locked MCP npm tree cannot install this Python dependency.
Observed read-only diagnostic: exact published Python command exits 1 with ModuleNotFoundError: No module named 'yaml'; retained prerequisite-check-1.log. This is a missing prerequisite, not a policy assertion failure or live network denial.
Necessary correction: name Python 3 and pinned PyYAML==6.0.3 for this selected route, give an isolated Python environment preparation/check using the same version, state its execution location and stop condition, then retain the real policy test result. Do not install globally or call the failed attempt PASS.
Affected assigned facets: DEV-002, DEV-003, A910-01, A910-03, A910-11.

### SOURCE-F2: Telemetry check chain omits a separate Go module and fixed executable path

Document location: docs/site/extend/developer-handbook.md:741-759, especially :751; setup Go rows at :137-140. Preparation names gofmt and GNU locks; the table covers root Go 1.22, NRI Go 1.26.5, and documentation parser Go 1.26.3. It omits the pipeline-observability Go module used by the published command.
Primary authority: contracts/telemetry/v1/tests/contracts.test.mjs:134 invokes actual go test; tests/verification/contracts/check-pipeline-observability-contracts.mts:45-51 hardcodes /usr/local/go/bin/go for both cross-language execution and cleanup; contracts/pipeline-observability/v1/go/go.mod:1-5 declares a separate module with Go 1.24 and its own dependency. A PATH-only Go install or gofmt alone cannot satisfy this command.
Observed read-only diagnostic: test -x /usr/local/go/bin/go exits 1; retained prerequisite-check-2.log. No contract execution was fabricated after that prerequisite failure.
Necessary correction: distinguish this Go module/lock and its compatible Go toolchain; explicitly require and verify the actual absolute executable where the existing check hardcodes it, as well as PATH go/gofmt for telemetry wire tests/generation. Give safe setup and stop rules before the command. Rerun the exact selected cross-language chain on a qualified environment.
Affected assigned facets: DEV-002, DEV-003, A910-01, A910-03, A910-11.

### SOURCE-F3: Buster remote/restart route checks PATH tar instead of the fixed path it consumes

Document location: docs/site/extend/developer-handbook.md:35-36, :73, :433-436, :567-573. The page calls for GNU tar and checks tar --version, then recommends remote runtime/restart/provider fixtures. It never states their /usr/bin/tar prerequisite.
Primary authority: tests/verification/contracts/check-pipeline-remote-process-restart.mts:169-177 supplies tarExecutable: '/usr/bin/tar'; check-pipeline-remote-real-provider.mts:115 uses the same fixed path; check-pipeline-remote-plan-runtime.mts:49 invokes /usr/bin/tar directly and :180 passes it into runtime configuration. Thus a GNU tar elsewhere on PATH is insufficient.
Observed read-only diagnostic: test -x /usr/bin/tar exits 1; retained prerequisite-check-3.log. This is an environment prerequisite failure, not evidence of a failing remote-recovery invariant.
Necessary correction: require/check GNU tar at the actual absolute path for these selected remote fixtures and explain that changing PATH does not satisfy it. Keep generic bundle PATH requirements separate where the source does so. Retain execution results only after real preparation, without host shim/mocks.
Affected assigned facets: DEV-002, DEV-003, A910-01, A910-03, A910-11.

### SOURCE-F4: CI timeout inventory omits the upstream-checksums job's declared bound

Document location: docs/site/extend/developer-handbook.md:1005 and :1017-1023. The workflow table lists detailed timeout values for other workflows but gives none for Update policy acceptance. The generic fallback statement applies only when a job has no declared timeout.
Primary authority: .github/workflows/update-checks.yaml:57-59 gives upstream-checksums timeout-minutes: 20. Policy and envoy lack declared timeouts, so the three jobs have distinct bounds. This is a source-level completeness omission within explicitly assigned DEV-005 timeout coverage, not an assertion that a hosted run failed.
Necessary correction: name the 20-minute upstream-checksums timeout and distinguish the undeclared policy/envoy limits in the workflow row. Preserve the correct statement that this workflow is a main build dependency and its missing/failed proof cannot become release success.
Affected assigned facet: DEV-005.

## Individual requirement decisions

Each decision below is only the assigned Source/content facet. PASS never means full AP09 gate, publication, Reader, Quality, or practical exercise approval.

| ID | Source verdict | Candidate locations and primary authority | Reason / necessary correction |
| --- | --- | --- | --- |
| DEV-001 | PASS | Handbook:11-24, :192-218, all component sections; package.json:5-24; packaging/runtime/package-ownership.json:9-26 | Central route selects owner by behavior and separates Core, services, UI, contracts, data, deployment and release. No nav/publication completion inferred. |
| DEV-002 | FAIL | Handbook:26-183, :751-759, :847-849; F1-F3 authorities | Broad setup has correct Linux/GNU-lock/Node/workspace/native/browser/service boundaries, but PyYAML, separate Go/cross-language path and fixed tar prerequisites are missing. Correct F1-F3. |
| DEV-003 | FAIL | Handbook:414-938, especially :433-436, :567-573, :741-759, :847-849; F1-F3 authorities; skills/prism/package.json:12-37; tools/ops-mcp/package.json:9-19 | All ten routes, library/no-daemon boundaries, service/debug/log/cleanup paths exist. Selected executable test paths still require unmentioned setup. Correct F1-F3. |
| DEV-004 | PASS | Handbook:294-357, :414-482; reducer.ts:96-136; run-decisions.ts:29-60; recovery-state.ts:39-69, :153-180; lifecycle.test.mts:31-81; project-recovery-version.test.mjs:14-34 | Six-part selection and Nova unit/contract/journal/replay/recovery/historical/docs chain are complete at source level; direct new assertions are required instead of claiming existing coverage. Prerequisite omissions are separately failed above. |
| DEV-005 | FAIL | Handbook:994-1049; all 13 complete workflow bodies, specifically update-checks.yaml:57-59 | Actual trigger/trust/job/matrix/artifact/release boundaries are correctly separated, including unknown server branch protection, but the timeout inventory omits a declared 20-minute job. Correct F4. |
| DEV-006 | PASS | Handbook:192-292, :705-728; tsconfig.base.json:1-16; check-erasable-typescript.mjs:7-95; check-runtime-package-ownership.mjs:68-174; generate-plugin-sdk-types.mjs:1-33 | Ownership directions, ESM/source extensions, erasable types, package exports, generated-source order and closed-schema/historical identity rules agree with primary code. No activation claimed from compilation. |
| DEV-007 | PASS | Handbook:940-992; check-nova-journal-scale.mts:7-37; engine-capture-retention.mts:10-29, :98-158; pipeline-reliability.yaml:139-194 | Threat questions, denial/isolation/provider routes, disposable fixtures, comparable baseline, predeclared budget, measurement interpretation and failed-scale status are truthful. No native/capacity/security guarantee inferred. |
| DEV-008 | PASS | Handbook:1051-1127; versions.json; versions.mjs:1-181; complete build-images/publish-image-receipts/promote-runtime/auto-promote-runtime/rollback-runtime workflow bodies | Distinct identities, generated/tool locks, compatibility owner, release notes, receipt preservation, promotion and irreversible data rollback boundaries agree with source. No universal private-package SemVer or platform restore invented. |
| DEV-009 | PASS | Handbook:1129-1182; docs-governance.mjs:8-155; package.json:215-229 | Existing source-dependency/owner/check map and generate/check/publication/negative add/change/remove/redirect workflow are accurately routed. Newly added page integration remains root work, outside this content Source approval. |

## Individual gate facet decisions

| Gate facet | Source verdict | Source evidence and result |
| --- | --- | --- |
| A910-01 | FAIL | Handbook:26-183 plus F1-F3. Correct missing selected-route tool/dependency prerequisites. No complete clean-checkout participant preparation run was supplied or performed. |
| A910-02 | PASS | Handbook:192-292; ownership JSON and full dependency checker, erasable/source checker, SDK/Prism/telemetry generators and package scripts. Role membership and source generation/build order remain distinct. Root publication/classification/navigation work remains outside this facet. |
| A910-03 | FAIL | Handbook command/setup paths and F1-F3. Exact commands and honest environment/exit/status boundaries mostly agree, but those missing prerequisites prevent complete source-backed preparation. No broad meta-script or failed runtime chain is accepted as a universal PASS. |
| A910-11 | FAIL | All ten component routes read; F1-F3 affect Buster/telemetry/Ops routes. Nova chain/exercise Source coherence passes, but all-ten-route completeness cannot pass with these omissions. No registered Reader-PLATFORM-02 execution is implied. |

### Public exercise Source facet: PASS

Fixture lines 1-88 define the desired internal administrative retry diagnostic, immutable unchanged baseline and non-executed status. Condition is a running administrative attempt whose ordinary bounded decision requests nonterminal work; valid retry reason remains separate from the committed blocked diagnostic. reducer.ts:96-136 rejects non-running result before decision/accounting; run-decisions.ts:29-60 intercepts administrative nonterminal actions and commits stage.blocked; recovery-state.ts:39-69, :129-144 folds the original attempt and committed blocked event without creating a reason field in StageRuntimeState. The preserved neighboring ordinary retry/other administrative wait, invalid pending transition, durable blocked crash/restart, no duplicate scheduling, retained identity/schema/generated-output and removal assertions are coherent desired obligations. They are not existing product assertions.

The public fixture uses descriptive identity nova-administrative-retry-diagnostic; READER-PLATFORM-02 remains in the external contract at AP09-acceptance-fixtures.json:221-239 and maps exactly to the same fixture path and A910-11/A913-04. Its full source baseline is an existing immutable commit and has a stated baseline purpose. The reviewed candidate documentation bytes/HEAD are not replaced with an assertion that the old baseline contains the newly authored guide. Facilitator assistance/failure rules were not moved into public content. No formal approval or independent participant success was inferred from reading it.

## Actual review scope and execution boundaries

Read the complete two assigned files, documentation quality standard, acceptance contract, acceptance fixture contract, execution plan and each DEV-001 through DEV-009 catalogue record. Read all 13 workflow bodies, package/setup/build/codegen/dependency/lifecycle/journal/service/authentication/native-registry/scale/retention/governance/version authorities. Operative test bodies were inspected for the published selected chains, including cross-language and fixed executable requirements, rather than relying on source-link excerpt counts or author summaries. The controlled input inventory is a hash inventory, not an assertion that every unrelated exported API or global tree was semantically audited. Deep SDK API, all 27 Developer records, complex plugin guides, README parity, source discovery/global drift acceptance and other roles remain excluded.

Author execution logs were inspected and hash verified. Their lifecycle/registry contract, SDK value-helper, source snapshot and targeted Nova typecheck successes remain genuinely attributed bounded author proof. Their journal/recovery aggregate exit 1, portable SDK exit 1, scale exit 1 and Ops child startup exit 1 remain FAIL attempts caused by the documented GNU-lock/separate MCP dependency prerequisites. F1-F3 identify additional missing preparation in this guide, not a reason to rename any of those failed checks PASS. No repeated broad runtime checks were needed for unchanged bytes.

Reviewer executed only repository reads/Git object resolution/hash checks and the three bounded read-only prerequisite diagnostics. No npm install, global build/generator, source mutation, shim, mock, Docker, deployment, credential access, publication, promotion or rollback was run. No browser/native/image/deployment/live route or registered practical fixture was executed. Reader/Quality and formal participant execution remain separate.

The report is complete for this frozen candidate; it collects all material findings before delivery. Corrections require a fresh affected Source re-review. Existing execution failures should be rerun only on genuinely qualified route environments. This report grants no global publication, merge, deletion, full AP09.10, Astra, or other-role approval.
