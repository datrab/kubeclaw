# Independent source review: configuration precedence and change impact

Reviewer identity: `/root/a98_precedence_source_fresh`. Role: SOURCE only, fresh-context and initially read-only. I did not author either candidate page and do not accept Reader or Quality roles. Date: 2026-10-10 UTC.

Product revision: `ec2a42ed215a2fa7dbd3172ef70ef446084963a9`, branch `docs/documentation-overhaul`. Scope: the entire current uncommitted `docs/site/reference/configuration-precedence.md` and `docs/site/reference/configuration-change-impact.md`, including their older non-Helm claims. No package or overall gate acceptance is asserted.

## Frozen inputs and authority

Before reading either page, I copied both pages and the quality/acceptance/fixture/catalogue inputs under `candidate/`, wrote `candidate-manifest.json`, recorded original HEAD/status, and extracted `git archive ec2a42ed215a2fa7dbd3172ef70ef446084963a9` into `product/`. `product-archive.sha256` identifies the archive. Product code, schemas, and chart checks use this frozen tree, not concurrent changes.

| Candidate | SHA-256 |
| --- | --- |
| configuration-precedence.md | `64fcd6cb9e4baff270a595c6661c3f345dd441caf99a4f3a503f8b63fc40ed0f` |
| configuration-change-impact.md | `e03f58f3b3a3e1cdb23377aa6b401d18826a3c7731f15b86b0d61ed058287e26` |

`scope-final-agreement.json` confirms both pages remained byte-identical through the final check. The main checkout was intentionally dirty from authorized concurrent writers; it is not represented as a clean acceptance checkout. Root later advanced only metadata to `601205ab…`; `environment.json` retains the actual final main HEAD separately. The checked product remains ec2. I made no repository edit, commit, generator run, deployment, cluster mutation, or network request. Evidence files are the only writes.

Read the complete two pages (338 and 173 lines), complete `07-documentation-quality-standard.md`, and complete `AP09-acceptance-contract.md` (466 lines). Inspected CFG-009/013/014 catalogue entries and relevant fixture structure. The acceptance fixture file has no static reader task directly assigned to A98-10/A98-11 or these two page routes; its `default-precedence` mutation targets the lint policy path, not these pages. No fixture or PRIMARY run is claimed by these ad hoc probes. The writer's report was read as context only; its probe and assertions were not reused.

## Decisions for this assigned partition

| Requirement | Verdict | Reason |
| --- | --- | --- |
| CFG-013 | FAIL | The complete page has a material wrong winner/order for compact-profile context and overrides (F1). The new bounded Helm explanations passed independent source/render checks. |
| CFG-014 | FAIL | The full change matrix asserts a required new identity for platform-timeout-only changes without that requirement in the actual recovery authority (F2). The new bounded Helm impact explanations agree with the inspected templates/loaders. |
| A98-10, two-page source partition | UNPROVEN | These pages are explanation/impact references, not the complete recursive configuration inventory. Whole-inventory source coverage belongs to the separate field/inventory partition and was not reviewed here. This result cannot be promoted to the complete A98-10 gate. |
| A98-11, two-page source partition | FAIL | F1 and F2 prevent source-faithful effective-value/impact acceptance of the full assigned pages. Local conflict/empty/Secret/invalid Helm and observer cases passed; they do not cover every effective field. |
| CFG-009 contextual Helm rules | PASS for the named local source/render claims only | Collection rules, named schema restrictions, template guards and named receivers were independently checked below. This is not acceptance of the CFG-009 inventory or its full source set. |

`UNPROVEN` is a scope/evidence classification requested by the delegation, not a contractual gate PASS with reservations. No overall A98, package, publication, Reader, or Quality PASS follows from this report.

## Material findings and concrete corrections

### F1 — compact-profile row reverses the actual winner and hides the raw placeholder input

Candidate location: `docs/site/reference/configuration-precedence.md:36`, and the compact explanation source callout at lines 326–330 should be extended with the actual expansion handoff.

The row says `Standard profile → recursive overrides → runtime-derived project, repo_root, paths, run_id → template substitution`. In `tests/verification/e2e/support/platform-config.ts:185–199`, the expander loads the standard profile, inserts a supplied webhook, inserts supplied context fields at 189–192, validates and merges `overrides` at 193–195, then substitutes templates. The override target checks at 104–118 run against that already expanded object. The corresponding old `10e95ee…` source bytes are identical to ec2, as recorded in `links-audit.json`.

Independent execution of the actual frozen expander accepts a correctly formed standard compact input and gives `project=override-project`, `repo_root=/override-repository`, `paths.example=/override-path`, and `run_id=override-run`. Unknown targets and an object override over a scalar reject. See `checks/compact-result.json` and `probe.mjs`.

Template substitution has a separate input: at 196–198 the context is `{repo_root: rawConfig.repo_root}`, not the effective overridden root. The additional executable case gives effective `repo_root=/override-repository` but expands an override string `${repo_root}/override-path` to `/runtime-repository/override-path`. Missing raw repo_root rejects this placeholder case. See `checks/compact-substitution-result.json`, `compact-probe.mjs`, and `compact-checks.log`.

Correction: order the row as standard profile → supplied webhook/context fields → validated recursive overrides → template substitution using the original raw repo_root. Explain that overrides can replace context fields only when the target exists at validation time, and that effective repo_root and the placeholder root can differ. Add narrow ec2 links to 185–199 and the target guard; do not move the validation rule or imply new arbitrary paths are accepted. Repeat this affected path with a new independent source reviewer after editing.

### F2 — timeout-only changes are classified as requiring a new run without an implemented pin

Candidate location: `docs/site/reference/configuration-change-impact.md:28` (`Platform timeouts | New run; restart current CLI process`). This row applies the page's defined New run class (lines 17, 140–146) to timeout-only platform edits.

Actual source authority: `skills/nova/core/execution/engine-runtime.ts:41` records providers, grants, adapters, activeAdapters, observers, and optional isolation. It omits `shutdownTimeoutMs` and `effectLockTtlMs`. `engine-snapshots.ts:28–40` compares that recorded subset and packages; it does not compare either timeout. `engine-run.ts:56–69` prepares recovery from the currently loaded platform and keeps the existing runId; `executePrepared` passes that platform into `createAdapterRuntime` at 27. `engine-runtime.ts:75–84` creates fresh adapter/effect objects with the current `effectLockTtlMs ?? 300_000` and `shutdownTimeoutMs`.

The source therefore establishes capture for the existing objects and reconstruction with current timeouts on a valid recovery; it does not establish a mandatory new identity caused solely by either timeout changing. The row currently conflates startup capture with persisted recovery authority. The cited recovery code is byte-identical at its older page pin and ec2. This is a source finding; I did not execute a full resumed pipeline or effects under changed timeout values.

Correction: identify these two actual settings, classify their load/recreation boundary separately from graph/package/runtime-subset drift, and state that the persisted authority comparison excludes them. Keep the existing stop/effect/recovery safety requirements. If operators should always choose a new run as a conservative policy, label that as an operational policy/recommendation with its reason rather than an implementation-required class. Add the narrow runtime/snapshot/recovery links above. Do not generalize this finding to stage timeouts (graph-pinned) or adapter configuration values (runtime-subset-pinned).

## Full-page critical audit and supported claims

This was a complete two-page audit, not a checklist of previous findings. The review traced the following families:

- Single pipeline-platform file: actual CLI load, realpath directory base, schema, deep freeze, optional effect-lock default, separate grants/providers/activation, and stored runtime subset. ActiveAdapters can be empty; installationRoots cannot. Source supports one selected file and no project authority merge.
- Explicit graph/project: original stage config handoff and validation without default insertion; project compiler's sorted topological order, project scope validation, derived bindings and new graph, recovery whole-graph digest check, and provider-plan inputs. `testAgentEnabled:false` affects the test-agent configuration rather than deleting the provider plan.
- `.swarm` test resolution: actual suite template/override/add and direct-node assembly, matrix config merge, provider default insertion, policy limits and requested-concurrency checks. Direct nodes are separate identities and duplicate identities reject; the conceptual order must not be read as a silent identity override.
- Coupled publication: complete published-pair reader/writer confirms generation pointer authority, materialization comparison, no fallback when metadata is damaged, and one pointer commit after member materialization.
- Plugin default application: registry compiles separate non-inserting and inserting validators; inserting resolution uses a clone. Approval parser uses the 60-minute fallback after validation. Direct-command builds its CI environment even from an empty map and the shipped command adapter rejects any supplied environment payload. The documented incompatibility is real and is not represented as a successful execution.
- Observer: actual registration/service/hook source order, defined-key merge, config-versus-environment selection before normalization, TLS fallback, mandatory positive limits, and the event-size guard. Independent synthetic conflict/empty/Secret/invalid tests are recorded below. No Redis connection was attempted.
- Environment snapshot conditions: Buster's generated numeric value uses `||` so empty differs from a nonempty `0`; Prism Control copies the environment before awaited key I/O. Native policy supplies aggregate host capacity rather than mutable environment policy; actual trusted pool file and cgroup verification were read.
- Whole impact page: source-pinned graph/package/runtime checks, storageRoot's selection rather than migration, publication/new plan boundaries, executable/template/replica/Secret/startup distinctions, native host preparation/readiness authority, safe sequence and bounded rollback/effect uncertainty. F2 is the substantive source mismatch discovered in the older matrix.
- Helm: actual KubeClaw array/map/null receivers, nested resource fallback, URL/file fallbacks, selected Secret name/key, checksums and init policy preservation; Prism image/pull-secret/operator schemas, enabled authority dependencies, checksum/environment and startup authority; GitOps revision/group guards and Application declarations. No unexecuted controller action is promoted into render evidence.

Every one of the 58 pinned source links resolves to a valid range in the referenced file. All older linked files are byte-identical to ec2 (`links-audit.json`: zero changed files and zero invalid ranges). This proves source-byte continuity for those references, not that mixed old pins satisfy the final acceptance ledger's exact-reviewed-revision link rule. A final uniform-revision ledger/publication check remains separate.

Minor reference precision: precedence line 253 labels the approval schema link as type and range but its L24–L29 range starts after the integer type at L23. Widen that narrow range to include the property name/type (L22–L29). The full file was read and the prose type claim itself is correct; this is not an additional behavior failure.

No concrete non-English product prose, internal AP/work-package instructions, chat prerequisite, or internal work-file link was encountered in either frozen page. Historical check dates and explicit local/live limits are evidence callouts, not a claim of current live validation. This is a source-role flag check, not controlled-language or formal ASD-STE100 certification.

## Actual read coverage: full files versus targeted regions

Full authored/contract files: both candidate pages, quality standard, acceptance contract. Catalogue and acceptance fixtures were read selectively by relevant records/fields, not claimed as full human semantic audits. Writer report was read fully as non-authoritative context.

Full relevant product files read: platform.ts and platform.schema.json; registry/configuration.ts and registry/schema.ts; engine-runtime.ts; engine-snapshots.ts; published-pair.ts; compact platform-config.ts and standard.json; SDK values.ts; observer config.ts and observer-support.ts; direct-command provider.js; approval config schema; Control control-config.ts; Prism native-worker.ts; project compiler.ts and recovery.ts; KubeClaw configmap-swarm-config.yaml; complete Prism workloads.yaml and _product-decisions.tpl; GitOps applications.yaml and values.yaml; Prism ci-values.yaml; platform contract check and project-recovery-version test. Full observer source modules executed are frozen; generated observer routing is resolved to the exact pinned routing.ts rather than missing build output.

Targeted product reads: KubeClaw deployment.yaml 1–48, 612–694, 1148–1165, 1278–1304, 1382–1398, 1438–1445, 1652–1664; values.yaml 459–478 and 514–524; helpers.tpl 1–90; Prism schema 1–295 (not the complete 531-line file); product-decisions.ts 1–125 (the entire file was displayed but only loader/actor/parser/signing semantics matter here); observer index.ts 175–245 plus pinned merge ranges; test resolver 285–440 and 480–590 plus all linked suite ranges; adapter-startup 1–110; stage-executor 60–82; approval.ts 50–90 plus constant line4; Buster entrypoint 170–190; project coverage 1–85; engine.ts 1–145; engine-run 17–77 and 90–168; native ownership 140–218 and native resource pool 1–75; isolation-session test 1–114. Native pool-policy.ts and routing.ts were displayed in full. Prism ingestion pull-secret receiver was located by source search; the complete ingestion template was not manually audited.

`source-linked-ranges.txt` retains the exact numbered linked ranges; `source-manifest.json` retains SHA-256 and line counts for linked sources plus additional authorities. A source file's presence in the archive/manifest does not imply every line was manually read. This review does not claim the entire deployment/schema/native subsystem or configuration universe was read.

## Commands, exits, and retained check evidence

Environment: Node v24.21.0, Helm v3.22.0+g144ca65, Python 3.14.8; YAML parser 2.9.0 from the installed workspace dependency. The parser is a tool dependency; product imports use frozen source. Kernel/platform and final main HEAD are in `environment.json`.

Executed from this evidence directory:

```sh
node --loader ./values-loader.mjs ./probe.mjs > checks.log 2>&1
node --loader ./values-loader.mjs ./compact-probe.mjs > compact-checks.log 2>&1
node --loader ./observer-loader.mjs ./observer-probe.mjs > observer-checks.log 2>&1
```

All three final commands exited zero. `checks/commands.json` records every exact Helm argv, cwd, expected and actual exit; each has separate stdout/stderr. The main probe independently implements the candidate examples and asserted 24 Helm cases: 10 success, 14 intended rejection. Cases cover base/empty/null, reverse order, nested map retention/whole-array replacement, repeated --set last winner, synthetic Secret selection without a generated Secret, URL and all three file fallbacks, Prism CI baseline, four images times empty/Always policies, empty pull-secret list, duplicate/101/enabled-empty operators, valid synthetic GitOps declaration, empty groups and branch revision. A nonzero negative case is accompanied by assertion of the named relevant diagnostic, not merely accepted as any failure.

Compact checks asserted four accepted overriding context fields, rejected unknown/mismatched targets, raw-root template substitution and missing-raw-root rejection. `observer-results.json` records 17 actual synthetic checks: absent host fallback, registration/service/hook conflict, undefined ignored, null/empty/whitespace normalization, explicit synthetic password/empty password precedence, TLS fallback, invalid port values and missing/null/empty/zero/over-limit event sizes.

Source link/byte checks used Python re extraction and `git show <pinned revision>:<path>`, compared to frozen ec2 bytes, and verified every line range against file length. The retained reproducible `python3 audit.py > audit.log 2>&1` exited zero and independently rechecked all 58 link rows and frozen input hashes. Initial/final `git status --short`, HEAD, version, source excerpts and candidate hash comparisons were read-only. Full command definitions for behavioral checks are retained in `probe.mjs`, `compact-probe.mjs`, loaders, and `observer-probe.mjs`; exact per-case Helm commands are retained in JSON. `artifacts-manifest.json` seals the report, probes, logs and candidate copies; the product archive has its separate SHA-256 file.

Two reviewer-harness setup failures are retained rather than hidden: the first direct probe invocation exited one because the archive lacks installed workspace alias resolution (`initial-module-resolution-failure.log`). A loader now resolves the two actual SDK value readers directly to frozen values.ts; no product function is mocked. The first observer over-limit assertion used 3 MiB plus one, below the actual 5 MiB absolute maximum, and exited one (`initial-observer-bound-assumption-failure.log`). Reading the actual constant and changing the negative input to 5 MiB plus one made the final independent check pass. A diagnostic git diff was initially run from the archive directory and reported a path error; it is not used as evidence of source agreement.

## Unexecuted checks and limits

No full Nova run/recovery under changed timeout values, isolation/native sandbox tests, actual direct-command adapter execution, Redis/Prism connection, host preparation, cgroup allocation, real image/Secret/Git-revision existence, admission, live controller/GitOps reconciliation, scheduling, pod rollout, PVC init execution, readiness/business operation, credential rotation, migration/backup/restore/rollback, or deployment was attempted. Source supports the receiver/load classifications; only the named Helm/compact/observer probes were executed.

No main generation, global docs build, freshness gate, mutation fixture, complete inventory/source-set closure, published renderer, network link check, or final clean-commit ledger verification ran in this role. Root must run those separate checks after concurrent edits settle. This report cannot close CFG-009 inventory, A98-10, whole A98-11, publication, or overall package gates.

A correction to either material finding invalidates this frozen candidate's affected path; obtain a new independent fresh-context source review with new candidate hashes. My initial read-only SOURCE role must not be reused for Reader/Quality acceptance.
