# Selected workload generator integration author candidate

Source base: `07b6a051854233eb63f659b7e9a74f2c2e02741f`. This candidate owns only the two source files in candidate-source-manifest.json. Their source bytes are retained separately under candidate-source/.

The v1 registry now includes the released Pod receiver records. Selected workload joins dispatch the existing exact-boundary factory only for matching Pod/v1, Job+CronJob/batch/v1, StatefulSet/apps/v1 and PodDisruptionBudget/policy/v1. Common TypeMeta/ObjectMeta delegation remains separate. A newly selected unqualified workload field throws rather than borrowing a Deployment route. The added test checks Pod-specific source authority, exact selector identity, wrong-version isolation and unknown-field rejection.

Focused author validation: api-reference 36/36 PASS, zero failures/skips/todo, explicit private genuine Go 1.26.3 override. This is author behavioral evidence, not independent SOURCE, reader, quality, publication, deployment or live acceptance. The public pinned toolchain obligation is not waived. Full source freeze and actual all-producer replay remain pending Root's integration commit, including the separate CronJob and cluster receiver owners. No main generated output, runtime/config edits, commits or pushes were performed.

Read the full quality standard, original frozen 2cf SOURCE report and original independent probe, and relevant acceptance obligations A98-02/06/10/11/13/14. The historical frozen failure remains FAIL. Discovery tests do not establish the full registered mutation catalogue or complete product configuration acceptance. Cilium's six varying Secret outputs require independent recipe classification; no byte reproduction PASS is claimed. Buster's own 150-boundary authority and unsupported Prism schema exclusion are unchanged.

Release: the two candidate files are released to Root for source commit. No further owned edits before Root's freeze release. Fresh mechanical replay evidence will be recorded separately against that exact commit, with before/after source dependency digests and context/selection/receiver joins.
