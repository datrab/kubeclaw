# LiteLLM selected-store authority author report

Role: documentation author. This is not a Source, Reader, Quality, or Astra review.
Repository: `/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04`. Current observed HEAD: `13bff0a18a64e74f2cbbaa1978e746fcdeff0c10`.
No commit, push, deployment, image execution, Docker activation, product change,
tool/generator change, or acceptance registry change was performed by this author.
All downloads and extracts are below this private evidence directory (mode 0700).

## Authored result

Only `docs/site/understand/data-and-state.md` and
`docs/site/understand/platform-and-operations.md` were edited.
The first page now binds the two selected OCI indexes to concrete upstream source
revisions, explains the relevant persisted rows, encryption key and algorithm
selection, pool inputs, startup migration behavior and failure handling, and the
safe isolated-restore/cutover boundary. The second page links that canonical
explanation without duplicating the OpenClaw client implementation.
The incorrect implication that STORE_MODEL_IN_DB alone controls virtual keys,
budgets, and all persistent records was narrowed to model configuration.

Full quality standard and AP09 acceptance A97-03/A97-06/A97-08/A97-11 were read.
Current DAT-006, INF-009 and INF-012 records/catalogue were inspected. The previous
full independent review and DAT-006 requirements record were read, including its
specific unresolved external OCI/source authority and execution limits.

Exact unchanged-section comparisons against current HEAD passed: Nova snapshot,
signal, administrative reopen, result/receipt and ownership sections; all content
following the old LiteLLM deployment-profile subsection; the complete OpenClaw
embedding-client section and all following platform content. Existing corrections
were preserved. Unrelated working-tree changes were not edited.

## Primary evidence and exact selection

The official GHCR repository `berriai/litellm` was accessed over inherited HTTPS
network configuration using an anonymous pull token kept only in process memory.
No credential was printed. Runtime skill was read; environment_status tooling
and /etc/codex/network-policy.json were absent in this executor. No network policy
or host setting was changed.

- Direct OCI index SHA-256: `690f24800e2208e4f31b01483b9d0521d79dc508c8191f1c0b2f21549400c580`.
  Official source revision reported in both platform configs and BuildKit
  provenance: `7d5b6456baaf8be6ac1a60db2b710566b5344adf`.
- GitOps OCI index SHA-256: `a79320760af8df488074ab3fbc830883856c7f952976aad00f039d3a43ffe4b2`.
  Official source revision reported in both platform configs and BuildKit
  provenance: `16f6d924530c1cf2dc94b3e83c86a4632aefb7c0`.
- The exact local manifest selection remains direct digest-only versus GitOps
  main-latest plus its distinct digest. No equivalence was inferred from a tag.
- The immutable index bytes matched each selected digest. Each amd64/arm64
  child manifest, configuration, attached attestation manifest and statement
  matched its referenced SHA-256. Provenance statement subjects match the exact
  platform manifests; vcs:revision agrees with configuration revision labels.
  These are digest-bound registry statements, not verified signatures.
- 24 selected compressed OCI layers (839739542 bytes)
  were downloaded and independently SHA-256 checked. tarfile read selected
  member bytes only; no executable was invoked, and no archive-wide extractall
  or filesystem mount was performed. Selected migration SQL members were read
  as data. File bytes were compared with the official commit-pinned GitHub tree's
  Git blob IDs. 1,412 selected occurrences match (690 direct, 722 GitOps,
  including both architectures and package/runtime copies). No mismatches.
- Four generated Prisma client schemas have no separate matching upstream path;
  each is byte-identical to the corresponding upstream root schema.prisma.
  They were checked separately and excluded from the 1,412 source-path matches.
- Upstream source files fetched through raw.githubusercontent.com were read at
  immutable revisions. API recursive trees were fetched through
  api.github.com/repos/BerriAI/litellm/git/trees/<commit>?recursive=1.
  Schema, encryption helpers, model management, proxy configuration, CLI,
  PrismaManager, ProxyExtrasDBManager and toolchain timeout source were inspected.
  Two relevant upstream test files were fetched/read for context, never run.

Exact URLs, SHA-256 hashes and file names are in `oci-fetch-records.json`,
`upstream-fetch-records.json`, `additional-source-fetch-records.json`,
`prisma-client-source-records.json`, `image-source-fetch-records.json`,
`index-source-bindings.json` and `image-source-comparisons.json`.
`artifact-hashes.json` records metadata, selected source, authored diff and report
hashes. Compressed layer hashes are in image-source-fetch-records.json; indexes
are also named by their content hashes above. No authentic missing attestation
was invented: the actual attached BuildKit statements were read.

## Commands and terminal results

- Initial metadata and pinned-source fetches: inline Python 3 using
  urllib.request.urlopen and json/pathlib/hashlib. Requests and written outputs
  are recorded in the fetch JSON files above; the exact initial inline script
  text was not retained as a standalone script. All calls ended exit 0.
- `python3 /home/node/Documents/Codex/a98-evidence/litellm-pinned-store-authority-author/fetch-image-source.py`: exit 0.
  Actual downloader command and complete source retained. Four download workers,
  selected tar member reads, digest verification; no execution of image content.
- Inline Python source-tree comparison and PrismaManager fetch/byte comparison:
  terminal exit 0. Comparisons persisted; an initial source-citation range check
  caught an off-by-one endpoint (968-993 on a 992-line file). Authored citation
  corrected to 968-992 before final verification.
- `node scripts/check-platform-specialist-guides.mjs`: exit 1, terminal.
  Existing hard-coded communication.md Ops workload citation expectation compares
  current 85925ff282d0483df57b69d20ea1bef230ccac00 with expected
  569f7b4933d4859cc67c80ddf40d5154ffd95ce5. Captured in platform-guides.log.
  This check did not reach new LiteLLM assertions and is not reported as PASS.
- `python3 /home/node/Documents/Codex/a98-evidence/litellm-pinned-store-authority-author/verify-author-evidence.py`: exit 0, terminal.
  Saved script and log. Rehashed registry chain, every retained compressed layer,
  every selected file and its official commit tree blob; checked provenance
  subjects/revision labels, generated-schema matches, all 17 added upstream
  citation ranges, two local anchors, unchanged protected sections, whitespace.
- `git diff --check -- docs/site/understand/data-and-state.md docs/site/understand/platform-and-operations.md`:
  exit 0, terminal; also invoked by the saved final verifier.
- `chmod 700 /home/node/Documents/Codex/a98-evidence/litellm-pinned-store-authority-author`: exit 0 (artifact directory only).

All issued process sessions were observed terminal. No process remains running.

## Authored file hashes

- data-and-state.md SHA-256: `bfae7ebffbd701d37d4a9788a4429bc0c88def889a575df0aee33fc788f25d80`.
- platform-and-operations.md SHA-256: `1b7404d3762acd6c687ee2330514ad40160c086cf09994a920151fd47a51345b`.

## Limits and continuation

No publisher signing identity, Sigstore/Rekor record or signature verification
was established. Matching selected source bytes establishes those bytes within
the fetched digest-bound layers; it is not an attestation of the whole executable
runtime, dependency set, deployed platform selection or effective Secret/stored
settings. Whole-image filesystem layers outside selected source layers were not
all downloaded. Encryption was inspected, not tested, and no application was
started. No migration, encryption round trip, PostgreSQL restore, live embedding,
outage exercise or provider credential/quota check was performed.

Actual source shows key fallback to the loaded master key, legacy/default and
versioned AES read paths, nonfatal helper decryption failures, default v1
migrate-deploy startup with possible drift/baseline writes, and possible startup
continuation after setup returns False unless enforcement is enabled. Effective
external Secret/stored-setting overrides remain an operator check. No historical
reason for the different image pins was inferred.

The previous NOT_CHECKED record remains tied to its previous reviewed revision.
This author's new artifacts offer concrete exact-digest source authority evidence
for a new independent review; they do not change DAT-006 or AP09.7 acceptance.
New complete independent Source, Reader, Quality and final reviews and required
publication/governance checks remain necessary. No acceptance state was updated.
