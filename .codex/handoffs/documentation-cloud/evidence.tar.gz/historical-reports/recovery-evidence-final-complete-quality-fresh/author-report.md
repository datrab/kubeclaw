# Complete recovery evidence-presentation correction batch

Owned write scope: `docs/site/use/recovery.md` only. HEAD `54a010ec5a337e5bbc4a08331510d2fe2d71c886`. Before page SHA-256 `a60c8ae63c96ebc4bae509c1301de96e6ad9aceb4209c3f74865817f7caef4bb`; stable after SHA-256 `944988014bbfecd79138d2180f47631218ecea38efef9ae4bc3239e4e76a1a52`. This is author correction of both collected evidence-presentation findings, not an acceptance result.

## Governing scope and complete findings read

Read the complete independent Quality report before changing the page. Its 49-artifact manifest was independently rehashed without mismatch. It retains two findings across the complete OPR-007 Quality partition: QF-01 lacks a linked test authority in the copied-group evidence callout; QF-02 lacks actual native-harness check status beside its assertions. The previous full-page Source and Reader PASS records belong to the old a60 candidate and are not transferred to this changed prose. The original group-selection finding remains a separate corrected facet; this batch adds no requested-group proof.

Quality standard 07 and A98-01/02/07/13 remain governing requirements. Current standards, contract, fixtures, OPR catalogue/task inventory and every linked primary authority were frozen before edits and rehashed after. No primary authority changed. Before/after complete-page snapshots are retained. The whole recovery task remains owned here; no other file or canonical task was moved or modified.

## Both corrections

QF-01: the copied-group callout now links the existing native test's exact assertions for backup verification, scheduled reuse, exclusion of secret/derived-key content and wrong-key rejection (postgresql-recovery-native.mts lines 110-117). The whole test source was read; the link uses the callout's fixed ebcc revision and equals current source bytes. Its evidence status is explicitly SOURCE ONLY; NOT EXECUTED, with no observed native result. Searching `tests` and `scripts` for the page-specific group/root identifiers and copy-selection phrases found no maintained test of this page's private-root guards; the callout states that absence. The only observed local successes named there are syntax and synthetic subprocess inheritance. They are explicitly not PostgreSQL archive verification. The actual complete offline check remains FAILED on BusyBox realpath/musl regex support; native media, live Job and transfer checks remain NOT EXECUTED.

QF-02: immediately beside the existing native-harness test links, the page now says SOURCE ONLY; NOT EXECUTED. It identifies the two externally supplied disposable PostgreSQL servers, selected PostgreSQL client directory and pinned LiteLLM crypto runtime as execution prerequisites, and stops before running the harness when they are absent. Test assertions describe what the harness attempts, not an actual execution result. The synthetic inheritance observations and failed offline check do not establish SQL, archive, decryption or application recovery. Existing application/image/API/model/budget/cutover/rollback exclusions remain unchanged.

Reader prose contains no internal package/review/handoff language, no private evidence prerequisite and no phrase that presents mere reading of test source as execution. No test success, historical reason, live operation or decryption result was invented.

## Checks performed and unchanged controls reused

- Quality provenance: all 49 manifest artifact hashes matched; `quality-integrity.json` and copied complete report retained.
- Source links: 29 narrow fixed-commit links now exist. Every target is a regular Git file; every complete linked file equals current source bytes; every valid line range is at most 60 lines. `source-links.json` records each actual check.
- Before/after primary guard: all captured implementation/test/standard/task inputs unchanged. `before-guard.json`, `after-guard.json`, `inputs/`.
- Executable examples: all 9 Bash blocks are byte-identical to the before page and to the previously sealed author controls. No executable code, export, object UID, backup identity, cleanup, latest selection or restore boundary was changed. `unchanged-controls.json` supplies exact block and prior control digests. Native/mock/script fixtures were not rerun for this prose-only change.
- Reused local controls retain their actual bounded scope: 13 mocked helper cases, 4 group comparator cases, source/destination and optional-salt native-shell subprocess inheritance with a synthetic child observer. They are not a native media verifier, SQL or Kubernetes result. The prior whole offline attempt remains FAILED; present-salt whole-block execution was not reached. No failed attempt was replaced by a success status.
- `git diff --check -- docs/site/use/recovery.md`: exit 0, retained in `diff-check.json`. `batch.diff` contains only these two evidence-location corrections.

No new SQL, real media, cluster/provider action, credentials, bootstrap, installation, native restore, application execution, transfer, cutover or rollback occurred. No chart, script, test tool, shared matrix, navigation, generated file, product implementation, commit or push was changed. No unrelated work was overwritten.

## Remaining review and evidence limits

The full offline verifier remains unverified in a compatible GNU/glibc environment; the native harness remains NOT EXECUTED. Product restore/access/host/application boundaries remain unchanged. This batch does not pass Source, Reader, Quality, OPR-007, any gate/package, publication or global acceptance. Fresh complete affected role reviews must assess the new page. Supporting diagnosis review may distinguish this two-location prose delta from its frozen recovery dependency rather than silently reusing that dependency hash.
