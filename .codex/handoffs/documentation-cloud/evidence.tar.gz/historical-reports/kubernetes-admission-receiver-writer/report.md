# Admission receiver contract author report

Released file: scripts/docs-kubernetes-admission-receiver-contracts.mjs.
Module SHA256: 63411d10aaecd9773fc341611ad0f49ce85fd529eca4e81befb20ddb671580ca.
Primary implementation: Kubernetes v1.35.0, commit 66452049f3d692768c39c797b21b793dce80314e.
Local deployment route sources: 6fa4830a48244d29655104a5be58957d5fa87d2f, checked with git show against current source bytes.

The module exports 132 unique spec receiver records: 69 ValidatingAdmissionPolicy and 63 ValidatingAdmissionPolicyBinding. The 16 assigned spec contexts correspond to the 18 original policy/binding contexts after excluding the two shared metadata contexts. All recursively selected and unselected spec alternatives are included. The private schema-path-discovery.json was derived solely through existing docs-api-schema-authorities. The module contains no imports, schema copies, root/CWD reads, network calls or generator writes. It exports static authored paths; missing new paths must fail the consumer coverage check. Maps use [<exact-key>] with a transparent ["*"] matcherAlias. authoritySelector supplies only the input needed for the existing schema emitter.

work-item-mapping.json maps all 59 named spec work items and 182 exposed boundary/scalar entries. Absent item/map schema boundaries stay explicit schema absence statements, not invented receiver objects. Shared object/envelope boundaries remain with their separate owner. Every named context work item maps to its descendant records and retains the actual route/ownership/live proof limits. No spec boundary is unmapped. This mapping is author's evidence, not independent acceptance.

The records explain typed decode versus nullable schema permission, defaulting, required lists, selectors and operators, all matching rule alternatives, parameter authorization/scope/lookup, actions, CEL environments/returns/budgets, create/update differences, recovery and informer change boundaries. Cases preserve implementation discrepancies: Unauthorized reason rejection; ineffective multiline-expression message requirement; trimmed static edge newlines and runtime dynamic CR/LF differences; variables excluded by stateless create match-condition compilation but included in runtime composition; old variable strings absent from the stored-expression collection; duplicate variable name overwrite; audit authorizer compilation without runtime authorizer binding; wildcard resource order checks; direct configuration/individual audit-error denial versus binding action mapping; per-result audit truncation versus joined values. These are source-derived outcomes, not executed API outcomes.

Actual executed checks:

- node --check scripts/docs-kubernetes-admission-receiver-contracts.mjs: exit 0.
- node /home/node/Documents/Codex/a98-evidence/kubernetes-admission-receiver-writer/check-contracts.mjs: exit 0. Verified all 132 paths against private existing-authority discovery, unique identities, required record structures, no copied schemaAuthority, 98 immutable source line ranges and 38 cached source hashes. Initial local line-range checks exposed out-of-bounds draft citations; these were corrected before the final passing check.
- python3 /home/node/Documents/Codex/a98-evidence/kubernetes-admission-receiver-writer/map-work-items.py: exit 0; all 59 named spec work items mapped, zero missing spec boundaries.
- Import from /tmp: same exported JSON SHA256 as repository import, 5f63c37ee05e0bed5ef7458d0f8c3092d8f450810bf5cb63b6205675855d1c6a. This checks deterministic export and absence of a CWD-dependent authority import.
- node tests/verification/contracts/check-buster-namespace-fence.mjs: exit 0, saved helm-render-check.log. Existing original Helm render contract checks two installation namespaces, identity/policy/binding alignment, Fail/Deny, CREATE/DELETE, prefix rendering and Kubernetes 1.29.9 rejection. This is Helm-render-only evidence, not CEL or admission execution.

Not executed: Go validator/defaulting/CEL receiver tests; Kubernetes API or admission requests; active cluster version/plugin checks; field-manager/apply conflict checks; whole generator or mutation suite; HTML rendering; fresh Source, Reader or Quality acceptance. No repository file outside the exclusive new module was edited by this writer; no commit, push, host change or cluster mutation was performed.

Remaining proof: root must integrate lookup and fail-closed coverage, resolve schema nodes from the selected root, generate and check the published output, and run fresh independent Source/Reader/Quality reviews. Actual cluster activation and raw baseline selection remain unobserved and are explicit in each record. This work closes no whole quality gate or CFG-009 acceptance by itself.
