# Fresh complete Source review, corrected version 2 — FAIL

Reviewer: `/root/python_scope_flow_qualified_complete_source_fresh`; independent Source role, fresh task context, repository read-only, no commits or source writes. Reviewed worktree based on `53d0a9063a63e3ec45748f6004056ef90928a492`, branch `docs/documentation-overhaul`. This is a candidate Source review, not a clean committed AP09 acceptance ledger. `git-before.txt` records pre-existing tracked/untracked changes; `git-after.txt` records the final state. Candidate qualification began only after root's explicit finalfreeze. The author and root test results were not used as review proof.

The whole assigned coupled Source scope receives **FAIL**. Current actual bootstrap discovery and both credential receiving contracts agree with the inspected implementation; protected producer-input graph qualification also passes the independently executed baseline and mutation suite. However, supported finite loop cases and executable direct literal inputs silently evade environment discovery. Passive shell examples are also incorrectly classified as live readers. These are material configuration maintenance findings, independently reproduced below.

## Authorities and requirements

Read `docs/blueprint/07-documentation-quality-standard.md`, `docs/blueprint/AP09-acceptance-contract.md`, the acceptance fixtures, and catalogue records CFG-011 (environment/Secret consumer matrix), CFG-013 (precedence/effective values), CFG-015 (configuration errors). Reviewed A98-10/11/14 at contract lines 288–292 and the config mutation registration in `AP09-acceptance-fixtures.json:410–421`. The registered environment mutation targets a chart env declaration; the additional Python/shell/YAML negative probes are independent Source probes, not fabricated successful runs of that registered fixture.

A98-10 requires recursive configuration Source coverage; A98-14 explicitly fails when a new environment input stays green. The quality standard's maintenance rule requires add/change/remove/rename detection. A98-11 and CFG-013/015 apply to the two credential contracts, including empty selectors/content, precedence, errors, earlier effects and retry boundaries. These narrowly inspected Source results do not decide the complete catalogue items or whole gates across other configuration families.

## Frozen bytes and custody

`before-source-manifest.json` and `after-source-manifest.json` preserve 20 actual files with byte counts and SHA-256, plus copies in `before/` and `after/`. All 20 hashes remained identical across this review.

- Scanner: `3f8718680012538b92cc516ac6aa57532f82bdb91ce4e43c2eb4c746dd331230`.
- Runtime contracts: `e92de825967a2d76f671145ab42e33a1367ed68e7a2c67427fc93ef86b6a0a6a`.
- Python discovery test: `334fc629ec8a042a927696050e15269d73a1372a3c933930dbdc5b0eabad4676`.
- API discovery: `59eb6e520764b276f0b172b3cffe39101d3fedf391f952a5cf6a38c916f5385d`.
- Producer registry: `55d8c745059f5cb051cb7eb878233c4385d07f1246247c8a60145a5fd2da96d3`.

`qualification-diff.txt` confirms that the integration changes only the docs-config recipe anchor, its exact Source digest, and the corpus native test's actual runtime-contract dependency digest. No authority guard was weakened; the capture test's existing qualification remained unchanged.

## Material findings

### F1 — Empty literal tuple loops destroy genuine reader state (FAIL)

Authority: `scripts/docs-configuration-inventory.mjs:5148–5152`, `verifyEnvironmentConsumerCoverage:6641–6659`. `visit_For` unconditionally binds the target and executes the body once statically, even for an empty literal iterable. Literal tuple loops are explicitly within the scanner's supported model at lines 5075–5078.

Appending each of these independently to the unchanged actual `ops/pod/bootstrap.py` in a private injected read fixture leaves the actual production coverage function green with seven names:

```python
reader = os.getenv
for reader in ():
    pass
reader('FRESH_EMPTY_TUPLE_REAL')
```

```python
KEY = 'FRESH_EMPTY_TUPLE_KEY_REAL'
for item in ():
    KEY = 'OPS_NAMESPACE'
os.getenv(KEY)
```

```python
for os in ():
    pass
os.getenv('FRESH_EMPTY_TUPLE_DIRECT_REAL')
```

Each program actually reads the new setting; the empty loop does not rebind or execute its body. `runtime-witnesses.jsonl` proves the expected calls using synthetic read recording. `source-mutations.jsonl` records the actual unchanged production verification result. A control direct `os.getenv('FRESH_DIRECT_NEW')` rejects with `CONFIG_SEMANTIC_GAP`, so this is scanner loss rather than blanket authority acceptance. Correct zero-iteration state and finite loop post-state handling; ensure real new names fail exact receiving-source qualification.

### F2 — Literal annotation reader is omitted when explicitly evaluated (FAIL; corrected boundary)

Authority: `visit_AnnAssign:5143–5146` and `visit_FunctionDef:5192–5198`. The visitor omits variable, argument and return annotation expressions. The original report incorrectly claimed that its declaration-only witness recorded three calls. That retained witness actually records `[]`; this correction preserves and supersedes the incorrect observation.

The actual interpreter is Python **3.14.8**. Ordinary function and module annotations are lazy: declaration alone produced no calls. Explicit function/module `__annotations__` access and `annotationlib.get_annotations(..., format=VALUE)` evaluated the annotation calls in the isolated native probes. A `from __future__ import annotations` function instead retained strings under ordinary access and `VALUE` retrieval; explicit `VALUE` retrieval with `eval_str=True` evaluated them. Function-local variable annotations remained passive in the tested function. Do not classify all annotations as eagerly executable, or turn local/postponed passive text into live inputs.

The [official Python annotation semantics](https://docs.python.org/3.14/library/annotationlib.html#annotation-semantics) distinguish eager defaults through 3.13, stringified future annotations, and lazy defaults from 3.14. Earlier eager semantics were checked against that authority, not run under an older native interpreter. Annotation introspection can execute expressions; even STRING retrieval in these isolated calls was observed to invoke the synthetic read recorder, so the format name does not establish a general no-effects guarantee.

A new, independent same-Source actual-bootstrap fixture makes evaluation explicit:

```python
def fresh_lazy_annotation(value: os.getenv('FRESH_LAZY_ACCESS_REAL')):
    pass
resolved_annotation = fresh_lazy_annotation.__annotations__
```

`source-annotation-access-v2.jsonl` proves the frozen production coverage function remains green with seven names, while execution of the complete preserved bootstrap plus this addition under synthetic KUBE_CONTEXT/OPS_NAMESPACE and a synthetic getenv recorder actually calls `FRESH_LAZY_ACCESS_REAL` (exit 0). No bootstrap operations or subprocesses are invoked; main is inactive. This proves a reachable literal reader at annotation access, **not execution at declaration**. Scanner omission remains a Source-drift issue for this explicit access case; any correction must preserve interpreter, eager/lazy/postponed and lexical evaluation boundaries.

`annotation-semantics-v3.py/.jsonl` is the corrected isolated native matrix (module objects, independently recreated for each access). The earlier `annotation-semantics-v2.py/.jsonl` is retained exploratory evidence, including its dict/module-target and synthetic return-string artifacts; v3 is the authoritative matrix for this addendum. Original declaration-only annotation mutation evidence remains honestly green without proving a read at declaration.

### F3 — Passive shell recipes become executable Python readers (FAIL)

Authority: `inlineProgramEnvironmentReads:5036–5068`, `embeddedPythonEnvironmentReads:5311–5350`, and their actual unmasked `text` callers at `environmentOccurrences:5445–5483`.

The real production `environmentOccurrences('fixture.sh', ...)` reports `SHELL_LITERAL_FAKE` for:

```sh
echo 'python3 -c "import os; os.getenv(\"SHELL_LITERAL_FAKE\")"'
```

It also reports `PASSIVE_HEREDOC_FAKE` at line 4 in a quoted `cat <<'EXAMPLE'` literal containing a nested Python heredoc recipe. Neither shell program invokes Python. The shell parameter scanner masks quoted heredocs separately, but the Python acquisition functions receive the original unmasked source and do not establish executable shell token custody. `additional-probes.jsonl` retains source and returned facts. Acquire only actual Python command/argv bodies and exclude surrounding passive string/heredoc contexts without losing genuinely executed quoted Python heredocs.

### F4 — Function reader resolution before a later ordinary global import loses a direct input (FAIL)

Authority: `Readers.role:5095–5104`, `enter_closure:5178–5189`, `visit_FunctionDef:5192–5198`. A function is scanned using the binding state at its definition, although its global names are looked up when called.

```python
def f():
    return os.getenv('LATE_IMPORT_DIRECT_REAL')
import os
f()
```

Discovery returns zero names; a synthetic runtime witness records the actual direct call. Conversely, a function-local assignment later in the body can produce an `UNBOUND_FAKE` reader before that assignment, and a global rebound after function definition retains a stale apparent reader. These are basic lexical/global binding boundary failures, not a claim that all Python call scheduling is statically solvable. Correct the claimed supported direct literal lexical cases or fail explicitly for unresolved binding authority; keep genuinely arbitrary runtime flow as a separately reviewed limit.

### F5 — An actual YAML Python `-c` argv shape is not acquired (FAIL)

Authority: `inlineProgramEnvironmentReads:5039–5040` expects whitespace-delimited shell commands, while the real `charts/ops-pod/templates/workload.yaml:80` uses `command: [python3, -c, "..."]` for the readiness probe.

The private fixture changes only this exact actual command-line program from `import json; ...` to `import os,json; os.getenv('FRESH_YAML_ARGV_REAL'); ...`. Production `environmentOccurrences` on the mutated exact line returns `[]`. The new supported runtime input therefore lacks its receiving-source qualification. The current unchanged readiness program has no environment read, so this is a proved future Source-drift blindspot on an actual runtime shape, not a missing current key. Acquire literal YAML command/args arrays and preserve their true source positions; distinguish passive YAML documentation fields.

## Whole-scope checks that passed

1. Independently ran `node --test scripts/tests/python-environment-discovery.test.mjs scripts/tests/ops-bootstrap-environment-contracts.test.mjs scripts/tests/api-output-publication.test.mjs` on frozen candidate Sources. Exit 0; **47 tests passed, 0 failed/skipped**. Full log: `focused-tests.txt`.
2. Independently ran actual `discoverScriptApiOutputs(process.cwd())`. Exit 0; **36 outputs**, zero from docs-config and zero from the corpus synthetic native test. Full log: `actual-discovery.txt`. YAML collection-key warnings are preserved in the log. This invokes the real authority checks; no global generator regeneration was run.
3. Reviewed all native operational `.py` acquisition sources listed in `actual-python-sources.json`; checked the actual key reads/aliases and the retained shell `-c`/heredoc and YAML shapes. Bootstrap has all seven expected actual keys, the passive Python adapter has zero executable environment reads, verification has its two actual OPS namespace inputs, the four platform inspection/migration readers use KUBE_CONTEXT, and supervisor's environment copy is not falsely turned into a literal direct environment reader. Product runtime operations were not executed.
4. Scanner tests independently verify native AST acquisition without imports/execution, passive Python constants/docstrings/raw recipe exclusions, formatted executable expressions, imported names/simple aliases/constant keys/multiline calls, UTF-8 to UTF-16 offsets, double-quoted shell decoding offsets, real Python heredoc source offsets including tabs/YAML indentation, function/lambda parameter shadows, class/comprehension boundaries and finite if/else branch unions. The novel failing cases above were additional probes; passing existing tests does not override them.
5. Both credential receiving contracts at `scripts/docs-runtime-consumer-contracts.mjs:116–140` agree with `ops/pod/bootstrap.py:56–78`, `scripts/deploy-ops-pod.sh:4–34`, and the GH_TOKEN/TS_AUTHKEY bindings at chart lines 59–62/124–127. Exact owner/source matching rejects another bootstrap path and unknown credential names. File selectors remain unchanged; empty/absent skips; contents use default decoding and strip; non-empty whitespace paths remain literal; GitHub precedes Tailscale; earlier bearer/pull/credential effects persist after later failure; kubectl diagnostic suppresses sensitive submitted-object stderr; existing selected credential Secrets are overwritten by applies rather than overriding input files. The isolated harness executes unchanged actual functions against synthetic files and mocked subprocess responses, and passed these positive/negative cases. Permission denial is an injected `Path.read_text` error, not an operating-system ACL proof. No downstream authentication is claimed.
6. Verified **12 protected module input recipes / 27 operations**, with docs-config's **6 module-import operations / 15 selected module paths**. Read the actual import consumers and guards; docs-config's finite selected paths remain those pinned in `boundary.json`. The independently executed production guard fixture suite rejects missing qualifications, Source/operation/digest-only refreshes, graph edge changes/removals/renames, direct/transitive/re-export/require public consumers, public package aliases/targets/invocations, symlink/canonical changes, dynamic public imports, unsupported helper/export/container custody, nested loader bindings, saved/awaited builtin Promise custody, CommonJS/ESM unknown input classes, selected bridges, cache hits/retargets, and newly discovered output publishers. No arbitrary helper/public-output custody was granted.
7. Synthetic corpus and capture boundaries bind actual complete Sources and actual package commands. Corpus also binds actual `scripts/docs-runtime-consumer-contracts.mjs`; it is a synthetic PostgreSQL test role, not permission for an arbitrary guarded production loader. Tests reject changed Source, caller, runtime contract, missing Source, direct/transitive/public symlink reachability, root package invocation/normalized invocation/export, and an unreviewed new native test. Source/caller identities were unchanged and were not executed as native PostgreSQL/Playwright product runs.

## Explicit limits and performed/not-performed status

Performed: complete assigned candidate Source scrutiny, actual production focused tests and authority discovery, exact receiving-source controls, private mutation/lexical/syntax probes, isolated unchanged-bootstrap contract harness, synthetic runtime witnesses, before/after byte custody and artifact manifest.

Not performed: complete package acceptance; clean Reader or controlled-language/Quality review; complete CFG catalogue/gate acceptance; publication/build/render/link acceptance; registered 84-mutation AP09 ledger execution; live cluster, credentials, deploy, native PostgreSQL corpus test, Playwright capture-retention test, downstream authentication or global regeneration. Root's separate 221-test suite result was not inherited as this review's evidence. No repository edits or commits were made.

The scanner correctly disclaims arbitrary-Python correctness at lines 5075–5080: reflection, runtime-computed keys, exception/global/nonlocal effects and arbitrary helper/control/data flow need separate Source review. The exploratory conditional-expression reader alias and walrus cases in `initial-probes.jsonl` also produce zero names; they are recorded as unqualified boundaries, not conflated with the material direct literal/declared finite-loop findings. This report makes no broader Python correctness claim. An honest arbitrary-flow limit cannot substitute for detection of executable direct literal inputs or the explicitly supported literal tuple loop domain.

Required correction owner: configuration discovery/tooling owner, with fresh independent Source rerun against new frozen bytes. Resolve F1–F5 together and preserve all existing exact input/producer and protected recipe custody guards. Whole assigned Source verdict remains FAIL until these material findings are corrected and independently retested. This report is terminal for the reviewed frozen candidate.

Replay note: the private probe scripts now resolve the preserved `before/` Sources, so later corrective repository edits cannot change their reviewed candidate inputs. The deployment script and actual YAML command source were additionally copied/hash-bound before the corrective writer changed those Sources.

## Version 2 correction custody

The original `report.md`, original `runtime-witnesses.jsonl`, and original 58-entry `artifact-manifest.json` remain unchanged by this correction. This `report-v2.md` supersedes only the incorrect F2 observation/boundary; F1/F3/F4/F5 and the whole candidate Source FAIL stand. Original terminal packaging milestones were 54 artifacts/18 snapshot files, then 58 artifacts/20 snapshot files after the deployment/YAML snapshot and frozen replay preparation. The final correction manifest `artifact-manifest-final-v2.json` records its actual expanded artifact count; it includes original manifests/reports for historical custody rather than asserting those earlier counts are current. No new repository Sources were used for corrected scanner probes; they replay `before/` frozen bytes. Native annotation probes use the same installed Python 3.14.8 recorded in `environment.txt`. No repository changes or commits were made during the correction.
