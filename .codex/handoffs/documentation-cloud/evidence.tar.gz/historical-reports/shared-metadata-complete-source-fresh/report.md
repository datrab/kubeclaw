# Independent SOURCE review: FAIL

Reviewed tracked revision: `61e45fbaaffd5153562efdc4a36a754160be4588`. Module SHA-256: `b6b5e44bcef780d56facb8e511b684a2bf5c2335c16465c9bc6a437d29fc818d`.
Reviewer: `/root/a98_shared_metadata_complete_source_fresh`, independent fresh SOURCE role, no prior authorship and no changes to the reviewed repository. Root continued writing independently; this review concerns only the private archive of the specified commit. Initial repository status was clean at that commit. Later parent commits are not reviewed.

The requested whole-scope acceptance is **FAIL**. Checked emitted statements have individual dispositions, but complete independent discovery of every Argo/Cilium metadata consumer was not finished. That dimension is explicitly `FAIL`, `reviewStatus: unreviewed`, for every affected reference record. This report grants no Reader, Quality, Astra, CFG-009, A98-10/A98-11, publication, live, or global acceptance.

## Independently derived scope

246 real schema records: Deployment102 (root34, Pod-template34, ephemeral PVC-template34); Ingress34; NetworkPolicy34; ValidatingAdmissionPolicy35; Binding35; Application3; AppProject3. The exported separate reference scope is136 obligations,34 for each of Application, AppProject, CiliumNetworkPolicy and CiliumClusterwideNetworkPolicy, plus4 descriptors. These are standard API receiving obligations. They must remain separate from the opaque CRD metadata schema, not inserted as invented schema children.

There are2553 emitted cases:1552 real-schema and1001 reference-only. There are171 unique exact URL+caption pairs,167 unique URLs and67 distinct cited primary files. Independent primary Git fetches succeeded at Kubernetes `66452049f3d692768c39c797b21b793dce80314e`, Argo `e258ee23c3e52266d407572f4bcdfe7d9ed36cb5`, and Cilium `7d68cfb394f2960e10aa72e76d0d51e66c1b2ebc`. Every cited file was fetched from those objects; local bytes were checked against its Git blob SHA-1 and SHA-256. No author source cache or author verdict established acceptance.

The pinned Kubernetes swagger bytes exactly match the independently fetched primary blob. Argo chart10.8.0 declares application version3.5.2; its rendered Application/AppProject schemas equal primary schemas. Application has empty subresources and AppProject no subresources. Both Cilium vendored CRDs byte-match primary source and declare status subresources. The server behavior authority is Kubernetes1.35.0; Argo client apimachinery0.36.1 and Cilium client0.36.3 are separate authorities. These comparisons prove the inspected distinction, not cross-version compatibility or deployment.

## Material findings

See findings.json for exact authored paths/lines, source paths and corrections.

- F1: Existing-object managedFields reset does not necessarily record the current update. The installed default skip wrapper sees empty ownership plus an existing UID and skips non-apply tracking. Subsequent Apply bootstraps before-first-apply ownership.
- F2: Full CRD body `managedFields:[]` is omitted during ObjectMeta-to-unstructured coercion, becoming absent before field management. `[{}]` survives. Their identical-reset claim is false in this scope.
- F3: Inventory imports only the246 real receiver records. The136 obligations/4 descriptors and canonicalReferenceId have no renderer/reference-resolution path. Required canonical reference integration and reader linkage are absent.
- F4: Pod-template creationTimestamp JSON-null text inherits root lifecycle default/preservation wording. Nested metadata has no such root lifecycle preparation and that member is not copied to the generated Pod.
- F5: NetworkPolicy unconditional-update caption ends at a comment on line98. The executable function/return true are99-101; the exact supplied range cannot prove its caption.
- F6: Generic protected-content-preservation captions overstate NetworkPolicy and PolicyBinding bodies that only compare spec and increment generation.
- F7: Force-only-when-explicitly-requested and unconditional no-force conflict claims omit the installed exact-manager `kubectl` last-applied wrapper. Covered valid same-version conflicts can cause an internal force=true retry; partially covered conflicts are filtered. This is materially different from request Force.

Default manager wrapper depth also requires source-bound explanations for full-GVK checking, strip-meta field exclusions, Update manager capping into versioned ancient-changes buckets, manager timestamp maintenance and last-applied annotation updating. Named wrapper evidence checked in this review is retained; a complete path-level account of every wrapper branch is not claimed.

## Mechanisms inspected

Typed and unstructured identity decoding, full-body coercion versus storage-codec malformed-field dropping/generation repair, create wiping/initialization, namespace normalization, resourceVersion parsing/preconditions/unconditional-update strategies, generation and status reset/callees, common metadata validation, deletion preconditions and finalizer irreversibility, GC graph/current UID/scope resolution and retry branches, and exact ownership authorization verb update on owner finalizers were inspected.

The managed-field raw trie decoder, manager identity version distinction, ownership fallback/reset, Apply conflict/force, strategy exclusions, and installed default wrappers were traced sufficiently to establish findings above. The record-specific strategies and installed/no-status distinctions were inspected separately.

Pod-template validators and GetPodFromTemplate confirm labels/annotations/finalizers copying, with other ObjectMeta members not copied; actual child creation is a separate API boundary. Ephemeral PVC allow-list compares reflected Go zero values, so nonnil empty disallowed slices and allocated zero pointers fail. Controller child identity, existing PVC ownership/collision checks, create failures and no existing-PVC patch path were inspected. Argo identity/RBAC/cache/finalization named claims and Cilium cached-same-generation early return before equality were checked. Named consumer inspection does not establish that every applicable consumer was discovered.

## Individual ledgers

record-ledger.json contains382 identities and per-record dispositions. dimension-ledger.json contains8623 scalar/condition/limit and applicability/completeness entries. case-ledger.json contains all2553 exact cases and individual dispositions. caption-ledger.json contains all171 exact captions and their independently verified source provenance. reference-ledger.json contains4 separate applicability/integration dispositions. original-operation-coverage.json retains create, replacement, installed status, Apply, DELETE and later-child boundaries per record.

Ledger PASS means checked emitted source claim only, not complete package acceptance. Source-backed dimensions can PASS while another dimension or the record fails. Final counts:150 record claims PASS/232 FAIL;2431 cases PASS/122 FAIL;168 captions PASS/3 FAIL. Every incomplete discovery dimension is explicitly unreviewed/FAIL; there is no PASS extrapolation from the schema join.

## Actual checks and end statuses

- Archive/freeze: git status --short and git rev-parse HEAD; clean61e45fba at start. git archive that commit into private frozen directory: exit0.
- Primary fetch: git init/private fetch --depth=1 --filter=blob:none of each exact commit: all exit0. Git show, rev-parse and recomputed blob hashes: all cited blobs resolved and ranges bounded.
- Module export counts and SHA: Node24.21.0, exit0. Private build-review-ledgers.py: exit0.
- Pure authority/receiver join for the13 actual API kinds:5698 paths, zero missing/extra, exit0. This is structural evidence only.
- Authority comparison: Helm3.22.0, tar and YAML parsing, exit0. No deployment/controller operation.
- `node scripts/docs-configuration-inventory.mjs --check`: exit1, DOC_DRIFT_CONFIG stale configuration-values.json and configuration-runtime-inputs.json.
- Original docs-generate --check attempt on archive: exit1 because Git objects unavailable. Second attempt with original read-only Git object metadata: exit1 old locked source revision mismatch. Frozen --revision attempt: exit1 dependency symlink treated as a source path. These environment-limited attempts are retained, not presented as product findings.
- Final private dependency directory plus read-only original Git object metadata, `node scripts/docs-generate.mjs --check --allow-detached-source-root --revision61e45fbaaffd5153562efdc4a36a754160be4588` (the actual command used a space after --revision): exit1 API_REFERENCE_INVENTORY_MISSING at docs-api-reference.mjs:16 via docs-generate.mjs:343. Frozen generated configuration-values inventory contains no apiResources. Log generate-frozen-deps-check.log retains this actual renderer-path failure.

No inventory generation, docs generation/write mode, commit, push, deployment, live API request, admission, status/SSA/DELETE execution, GC/controller cleanup exercise, browser/publication output, mutation suite, clean Reader task, Quality review or complete package test suite ran. Static/source examples are not live outcomes. Dependencies were selected from the existing workspace solely for read-only checks; no clean dependency installation was proved.

## Remaining review boundary

The full quality standard and AP09 acceptance contract were read; fixtures and CFG-009/A98-10/A98-11 bindings were inspected. The canonical target remains docs/site/reference/helm-values.md. The standard requires recursive receiving meaning, every consumer and separate evidence classes. Source gaps cannot be waived as optional reader integration or hidden by reducing scope. Finish exhaustive independent Argo/Cilium consumer discovery, correct findings, integrate canonical references, regenerate appropriate inventory/site output separately, and obtain a fresh affected-scope SOURCE re-review. Actual publication and Reader/Quality acceptance remain separate tasks.
