# Fresh independent Source review: AP09.7 requirement-to-contract mapping

Reviewed HEAD at start: `51975b92ed5154b76c65793e55933b4d8659d05d`. Reviewer: `/root/ap097_all_requirement_mapping_source_fresh`, actual Source mapping role; fresh independent context, repository read-only. Only private evidence is written. Catalogue/current matrix scopes were read individually; no previous acceptance conclusions were adopted.

**FAIL mapping only:** 28 requirement mappings need additions; 25 mappings PASS within the declared scope. These are neither content nor whole requirement acceptance results.

Full quality standard and acceptance contract were read, including governance/product boundary, individual-findings distinction, role separation and evidence classes. Execution-plan governance/result requirements and AP09.7 scope were read. The stable authority copies and 53-row freeze are in this bundle. Catalogue findings define row scope, not evidence of current failure or correctness.

A mapped acceptance ID means this requirement contributes the named applicable facet to that gate. It does not mean each contributing row independently proves the entire gate, nor that a sibling row can silently waive this row's facet. For example, planned Git Mirror may contribute current Git-origin/fallback truth to A97-02/05/10 but must not fabricate a current mirror store. A97-07 on Echo concerns observer/telemetry signals, not review certification truth. Generic packageGateCandidates are candidate enumeration, not the individual acceptance mapping.

All 12 gate IDs are present in the current union, every assignment is an exact known ID, 53 catalogue metadata rows match, and no row blindly maps all gates. A97-11 is present on all 53. Nevertheless, union coverage does not fix missing row-specific obligations. A97-12 appears on 44 current rows; the other nine require it for their listed surface classes.

A97-11 remains a complete independent Source + Reader obligation: every dependency requires diagnosis and safe-recovery selection from canonical reader documentation, and every matrix must be compared completely against current Sources. This report satisfies neither substantive review. Source/Reader/Quality identities remain separate; author self-checks, prior bounded reviews, link checks, sampling and this mapping report cannot close the gate.

A97-12 remains automated surface discovery and negative mutation coverage for endpoint, store, event, secret, runtime-service and Ops-MCP-tool classes. Optional/conditional selected product surfaces remain in scope. The product boundary additionally preserves add/change/remove/rename detection. No checker, fixture execution, generator migration, publication, content, live deployment, product operation, Reader/Quality/Astra or package acceptance was performed or claimed. A current green check or pinning evidence alone cannot fulfill drift.

For excluded gates, apply the row-specific reason below together with this exact exclusion policy: an unrelated named dependency group (02), LiteLLM gateway (03), optional Argo/CNI/monitoring layers (04), distinct specialist (09), or separate full connection/store/signal/trust/failure inventory (05–08/10) is not assigned solely because the row shares a page or source directory. General correctness/depth/evidence/manual review and package-level duties still apply. Unsupported planned infrastructure is described truthfully instead of invented as current. Unused general upstream field expansion is excluded, but actual selections, supported overrides/branches and relevant omissions/defaults are preserved.

| Requirement | Current A97 suffixes | Required A97 suffixes | Mapping verdict | Individual reason / correction | Excluded gate suffixes |
|---|---|---|---|---|---|
| SPC-004 | 05,06,08,09,11 | 05,06,08,09,11,12 | FAIL | Forge dispatch endpoint and workspace-store surfaces need unmapped-addition detection; current 05/06/08/09 correctly cover request, state, grants and specialist role. | 01,02,03,04,07,10 |
| SPC-005 | 05,07,08,09,11 | 05,07,08,09,11,12 | FAIL | Echo request/result and observer-event surfaces remain drift-controlled; 07 contributes observer signals only, not certification truth. | 01,02,03,04,06,10 |
| SPC-006 | 05,07,08,09,11 | 05,07,08,09,11,12 | FAIL | OpenClaw hooks/tools produce event/request surfaces; their discovery/activation cannot be excluded from drift because this is a host integration. | 01,02,03,04,06,10 |
| SPC-007 | 01,05,08,09,11 | 01,05,08,09,11,12 | FAIL | The Ops skill exposes MCP-tool/service surfaces, so Tool/MCP dependency coverage must participate in A97-12. | 02,03,04,06,07,10 |
| SPC-009 | 01,05,08,09,11,12 | 01,05,08,09,11,12 | PASS | Service/tools, protocol, limits, identity and dependencies directly support 01/05/08/09/11/12. | 02,03,04,06,07,10 |
| SPC-010 | 01,05,08,09,11 | 01,05,08,09,11,12 | FAIL | Archviewer is explicitly a current sidecar service with URL/health endpoint; drift on its runtime-service/endpoint cannot be excluded. | 02,03,04,06,07,10 |
| COM-001 | 05,10,11,12 | 05,08,10,11,12 | FAIL | The complete connection matrix explicitly includes authentication and authorization across every connection; these are also identity/network trust-matrix facets. | 01,02,03,04,06,07,09 |
| COM-002 | 05,10,11,12 | 05,06,08,10,11,12 | FAIL | The scope explicitly includes Store Records and Source Snapshot/result Attestation: map store-authority facets to 06 and identity/artifact-trust facets to 08. | 01,02,03,04,07,09 |
| COM-003 | 05,10,11,12 | 05,06,08,10,11,12 | FAIL | Operation Store/restart reconciliation and exact identities are explicit scope: their store and trust-boundary facets require 06/08. | 01,02,03,04,07,09 |
| COM-004 | 05,09,11,12 | 05,09,11,12 | PASS | Forge/Echo communication and host/result import support 05/09; drift and complete independent matrix review are retained. | 01,02,03,04,06,07,08,10 |
| COM-005 | 05,07,11,12 | 05,07,11,12 | PASS | Stage/adapter/observer requests and delivery include 05/07. This is not a named infrastructure, store-inventory or security-policy requirement. | 01,02,03,04,06,08,09,10 |
| COM-006 | 05,08,11,12 | 05,08,11,12 | PASS | Native channel messages/framing/identity support 05/08, including fresh matrix review and endpoint drift. | 01,02,03,04,06,07,09,10 |
| COM-007 | 02,05,10,11,12 | 02,05,06,10,11,12 | FAIL | Redis Streams/keys, Dedup-TTL, MAXLEN, replay/migration are explicitly store/data lifecycle surfaces, not only communications. | 01,03,04,07,08,09 |
| COM-008 | 05,11,12 | 05,11,12 | PASS | HTTP service method/path/auth/limits/timeout are endpoint-inventory scope under 05; 11/12 preserve full source comparison and endpoint discovery. | 01,02,03,04,06,07,08,09,10 |
| COM-009 | 02,05,08,10,11,12 | 02,05,08,10,11,12 | PASS | Tailscale dependency, routes/ACL/identity and exposure cleanup correctly support 02/05/08/10; 11/12 remain obligations. | 01,03,04,06,07,09 |
| COM-010 | 02,05,08,10,11,12 | 02,05,06,08,10,11,12 | FAIL | Cache/mirror rules and digest-bound Git/OCI data paths include store lifecycle: cache authority, retention and recovery belong to 06 as well as data transport. | 01,03,04,07,09 |
| COM-011 | 05,08,11,12 | 05,08,11,12 | PASS | SPIFFE IDs, listeners, issuer/peer allowlists and rotation are 05/08 matrix facets, with full independent review and drift. | 01,02,03,04,06,07,09,10 |
| COM-012 | 05,10,11,12 | 05,10,11,12 | PASS | Per-connection timeout/retry/ordering/backpressure and stopping the run support 05/10. Telemetry-specific sampling/redaction is not the stated scope. | 01,02,03,04,06,07,08,09 |
| DAT-001 | 06,10,11,12 | 06,08,10,11,12 | FAIL | The full persistence matrix explicitly includes encryption; storage trust/credential/security boundary facets require 08 alongside 06. | 01,02,03,04,05,07,09 |
| DAT-002 | 06,11,12 | 06,11,12 | PASS | Journal/snapshot/hash-chain/locks/corruption/retention are store authority under 06. Integrity here is not an independent credential/supply-chain matrix. | 01,02,03,04,05,07,08,09,10 |
| DAT-003 | 06,11,12 | 06,11,12 | PASS | Worker journals/ownership/spools/resource records/sealed results support 06; no separate endpoint, dependency or security-policy inventory is required by this row. | 01,02,03,04,05,07,08,09,10 |
| DAT-004 | 06,11,12 | 06,08,11,12 | FAIL | The scope explicitly includes Result Signing, hence artifact/result identity and signing trust are security-matrix facets under 08. | 01,02,03,04,05,07,09,10 |
| DAT-005 | 02,06,10,11,12 | 02,06,10,11,12 | PASS | Prism PostgreSQL and matched backup/migrations support named PostgreSQL dependency 02, store 06 and PostgreSQL failure/recovery 10. | 01,03,04,05,07,08,09 |
| DAT-006 | 02,03,06,10,11,12 | 02,03,06,08,10,11,12 | FAIL | Credentials are explicit in the LiteLLM PostgreSQL scope, so credential source/authority and rotation must also feed the secret/identity matrix 08. | 01,04,05,07,09 |
| DAT-007 | 02,05,06,10,11,12 | 02,05,06,10,11,12 | PASS | Redis streams/keys/writers/dedup/TTL/AOF/replay cover named dependency, communications, stores and failure recovery 02/05/06/10. | 01,03,04,07,08,09 |
| DAT-008 | 06,08,11,12 | 06,08,11,12 | PASS | Artifact namespace/digest/encoding/visibility/collision lifecycle supports 06/08. Transport itself is not this row's inventory. | 01,02,03,04,05,07,09,10 |
| DAT-009 | 02,06,10,11,12 | 02,06,10,11,12 | PASS | Backupgroup/fence/order/independent target and named dependency recovery support 02/06/10. No successful live restore is inferred. | 01,03,04,05,07,08,09 |
| TEL-001 | 07,11,12 | 05,07,11,12 | FAIL | The scope explicitly traces producer to adapter/transport/sink/query: active event/stream communication paths are also A97-05 facets. | 01,02,03,04,06,08,09,10 |
| TEL-002 | 05,07,11,12 | 05,07,11,12 | PASS | Active-event/schema/version and retained-v1 status correctly support 05/07/11/12. An inactive asset must not be invented as an active service. | 01,02,03,04,06,08,09,10 |
| TEL-003 | 05,07,11,12 | 05,07,11,12 | PASS | Each producer/subscriber/filter/delivery/sink association is communication and telemetry inventory 05/07. | 01,02,03,04,06,08,09,10 |
| TEL-004 | 07,08,11,12 | 05,07,08,11,12 | FAIL | Event identity, at-least-once and per-run ordering are active event-path semantics; also map the communication facet 05, preserving 07/08. | 01,02,03,04,06,09,10 |
| TEL-005 | 05,07,11,12 | 05,07,11,12 | PASS | Observer delivery/checkpoint/retry/restart support 05/07. A97-10 is specific to the six named dependency failures, not any retry. | 01,02,03,04,06,08,09,10 |
| TEL-006 | 06,07,11,12 | 06,07,11,12 | PASS | Evidence/store authority versus Redis/log/projection monitoring supports 06/07. The distinction itself is not a new trust-policy inventory. | 01,02,03,04,05,08,09,10 |
| TEL-007 | 07,11,12 | 05,06,07,11,12 | FAIL | Queue/payload/producer pressure and telemetry retention/retirement/deletion cover active communication limits and telemetry-store capacity/lifecycle: map 05/06. | 01,02,03,04,08,09,10 |
| INF-001 | 01,11 | 01,11,12 | FAIL | Current K3s/runtime-service dependency discovery must reject a newly selected undocumented service; absent empty-host automation does not waive this. | 02,03,04,05,06,07,08,09,10 |
| INF-002 | 01,06,11 | 01,05,06,11,12 | FAIL | DNS is a client/service communication path and storage/DNS implementations include selected runtime services/stores; retain their communication and surface-drift obligations. | 02,03,04,07,08,09,10 |
| INF-003 | 01,04,08,11 | 01,04,05,08,11,12 | FAIL | CNI traffic boundaries and positive/negative paths are communication facets; current Flannel and supported Cilium runtime-service/endpoint discovery remain drift-controlled. | 02,03,06,07,09,10 |
| INF-004 | 01,04,08,11 | 01,04,05,08,11,12 | FAIL | Argo Git desired-state path and exclusive ownership operate over active service/request paths; optional Argo runtime-service/endpoints still require drift detection. | 02,03,06,07,09,10 |
| INF-005 | 01,02,05,10,11,12 | 01,02,05,06,08,10,11,12 | FAIL | BuildKit cache/shutdown/recovery and credentials/rootless boundary are explicit: add cache store lifecycle 06 and credential/least-privilege facets 08. | 03,04,07,09 |
| INF-006 | 01,02,05,08,10,11,12 | 01,02,05,06,08,10,11,12 | FAIL | Current registry Storage, GC, Backup and recovery are explicit store-lifecycle obligations; 02/05/08 do not replace 06. | 03,04,07,09 |
| INF-007 | 01,02,05,08,10,11,12 | 01,02,05,06,08,10,11,12 | FAIL | OCI mirror owns a volume/cache with TTL/capacity/GC/corruption/backup: store inventory 06 is directly applicable. | 03,04,07,09 |
| INF-008 | 01,02,05,08,10,11,12 | 01,02,05,08,10,11,12 | PASS | Git Mirror is planned and unsupported; current Git-origin exact-revision/fallback contributes 02/05/08/10. Do not invent an implemented mirror Store to add 06. | 03,04,06,07,09 |
| INF-009 | 01,02,05,06,10,11,12 | 01,02,05,06,10,11,12 | PASS | Named Redis/PostgreSQL/Tailscale dependency, protocol/store/route recovery map directly to 01/02/05/06/10/11/12. | 03,04,07,08,09 |
| INF-010 | 01,04,07,11,12 | 01,04,05,06,07,08,11,12 | FAIL | Monitoring scope explicitly names NodePort, Storage/15-/30-day Retention, absent Loki auth and privileged log access: add endpoint 05, stores 06, security 08. | 02,03,09,10 |
| INF-011 | 01,08,09,11,12 | 01,05,08,09,11,12 | FAIL | Ops Pod explicitly hosts MCP service/tool requests; service communication belongs to 05 alongside dependency, grants/security and specialist role. | 02,03,04,06,07,10 |
| INF-012 | 01,03,05,06,08,10,11,12 | 01,03,05,06,08,10,11,12 | PASS | LiteLLM gateway models/embeddings, PostgreSQL, credentials, routes, limits and failure boundaries support 01/03/05/06/08/10/11/12. | 02,04,07,09 |
| SEC-001 | 08,11,12 | 08,11,12 | PASS | Threat/control/entry-point/residual-risk matrix supports 08. 12 attaches drift of security-related endpoint/secret surfaces; no whole upstream threat schema required. | 01,02,03,04,05,06,07,09,10 |
| SEC-002 | 08,11,12 | 05,08,11,12 | FAIL | Login/issuer/token/certificate/session flows are explicit active request/identity paths, requiring communication facet 05 alongside identity matrix 08. | 01,02,03,04,06,07,09,10 |
| SEC-003 | 05,08,11,12 | 05,08,11,12 | PASS | SPIRE registration, listener/SAN/peer and rotation paths support communication and security matrices 05/08. | 01,02,03,04,06,07,09,10 |
| SEC-004 | 08,11,12 | 05,08,11,12 | FAIL | Secret resolution via Mount/Env/API and namespace copying includes active resolver/API communication paths; add 05 to secret-matrix 08 and secret drift 12. | 01,02,03,04,06,07,09,10 |
| SEC-005 | 04,05,08,11,12 | 04,05,08,11,12 | PASS | Cilium optionality and all chart connection allowlists/service/SVID/negative paths support 04/05/08, full reviews and drift. | 01,02,03,06,07,09,10 |
| SEC-006 | 02,08,11,12 | 02,05,08,11,12 | FAIL | The explicit source-to-build-to-image-to-deploy provenance path is also Git/OCI/build/deployment communication: add 05 while keeping 02/08. | 01,03,04,06,07,09,10 |
| SEC-007 | 08,11,12 | 08,11,12 | PASS | Permission/grant/RBAC/peer/filesystem/process matrix supports 08. It is an authorization inventory, not a separate whole transport/store/dependency explanation. | 01,02,03,04,05,06,07,09,10 |

Every A97 table point is checked below for requirement coverage only. PASS on these rows means the mapping preserves its stated obligation; it does not accept the gate.

| Contract ID / line | Mapping verdict | Reason |
|---|---|---|
| A97-01 / 259 | PASS | Applicable contributing rows are assigned; complete gate evidence still pending. |
| A97-02 / 260 | PASS | Applicable contributing rows are assigned; complete gate evidence still pending. |
| A97-03 / 261 | PASS | Applicable contributing rows are assigned; complete gate evidence still pending. |
| A97-04 / 262 | PASS | Applicable contributing rows are assigned; complete gate evidence still pending. |
| A97-05 / 263 | FAIL | Missing contributing facets on TEL-001, TEL-004, TEL-007, INF-002, INF-003, INF-004, INF-010, INF-011, SEC-002, SEC-004, SEC-006. |
| A97-06 / 264 | FAIL | Missing contributing facets on COM-002, COM-003, COM-007, COM-010, TEL-007, INF-005, INF-006, INF-007, INF-010. |
| A97-07 / 265 | PASS | Applicable contributing rows are assigned; complete gate evidence still pending. |
| A97-08 / 266 | FAIL | Missing contributing facets on COM-001, COM-002, COM-003, DAT-001, DAT-004, DAT-006, INF-005, INF-010. |
| A97-09 / 267 | PASS | Applicable contributing rows are assigned; complete gate evidence still pending. |
| A97-10 / 268 | PASS | Applicable contributing rows are assigned; complete gate evidence still pending. |
| A97-11 / 269 | PASS | Applicable contributing rows are assigned; complete gate evidence still pending. |
| A97-12 / 270 | FAIL | Missing contributing facets on SPC-004, SPC-005, SPC-006, SPC-007, SPC-010, INF-001, INF-002, INF-003, INF-004. |

Required integration: root adds the exact requiredAdditions from individual-results.json, records per-row facet/exclusion rationale, keeps all state/evidence acceptance boundaries pending, and commissions fresh independent validation of the changed mappings. This reviewer did not alter any shared file.

Checks actually run: Python JSON parse and exact 53-ID membership/catalogue metadata comparison; ID-validity/distinctness; all pending/not-accepted status; no-all-gates scan; all-12 union and inverse frequency; A97-11 completeness; authority/matrix freeze hashes and end stability. Shell reads used git rev-parse/status, rg --files for instruction discovery, full quality/contract reads and applicable execution-plan sections. No product tests/Live actions and no acceptance-contract execution were run. Repository had unrelated modifications; clean-checkout acceptance is explicitly not established.

See stability.json for before/end scope hashes and current git status. Relevant rows must remain identical; unrelated matrix changes are permitted. Manifest inventories every private artifact except manifest.json and seal.json; seal.json hashes that manifest and report.
