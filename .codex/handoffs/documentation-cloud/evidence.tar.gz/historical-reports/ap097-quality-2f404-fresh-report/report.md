# Independent AP09.7 quality report

QUALITY verdict: **FAIL** for reviewed revision `2f404b02baae29d3b6c5422f7d61481127da1382`. This is an independent quality assessment, not package, Source, Reader or Astra acceptance.

Reviewer: `/root/ap097_full_quality_2f404_fresh`. Fresh context, no documentation authorship, initial and continuing read-only access to `/home/node/Documents/Codex/a98-evidence/ap097-quality-2f404b02`. Parent corrections on a moving main were not overlaid or accepted. Model name is not exposed through this subagent interface; identity is the actual task identity above. Review artifacts are external to the repo.

Dynamically enumerated scope: all **53** current AP09.7 catalogue requirements, with **43 quality PASS / 10 quality FAIL**, and all **12** A97-01–A97-12 quality facets, with **6 quality PASS / 6 quality FAIL**. A PASS is limited to inspected explanatory quality, not exhaustive Source correctness or practical Reader execution. Individual observations, evidence lines and fixes are retained in `requirements.json` and `gates.json`; there are no sampled or blanket grouped requirement verdicts.

The four findings remain open at this immutable revision. They concern incorrect authentication/signature properties, author correction history in reader prose, and a linked current-CNI contradiction. Correct statements elsewhere do not resolve those conflicts.

## QF-01: Resume input is incorrectly labelled authenticated

The store identity row calls signals.jsonl authenticated resume inputs. The same page explains that issuer matching does not authenticate the caller. ResumeSignal contains issuer fields without a signature or nonce, and validateSignal checks equality and freshness only. This contradicts the necessary CLI/filesystem authority boundary.

Evidence: docs/site/understand/data-and-state.md:118; docs/site/understand/data-and-state.md:340; skills/common/plugin-runtime/sdk/src/generated/contracts.ts:543; skills/nova/core/execution/engine-snapshots.ts:137.

Fix: Describe persisted validated resume inputs and state that authentication/authorization depends on controlled CLI/filesystem access; issuer fields alone do not authenticate the caller.

## QF-02: Result digest and receipt are described as a Buster result signature

Data calls the imported Buster result signed, telemetry repeats Signed Buster remote result, and the components comparison assumes Buster has an Ed25519 artifact signature. The source snapshot has Ed25519 attestation; RemotePlanResult has a resultDigest and receipt. Result and receipt digest calculations do not constitute a result signature. Correct nearby prose does not remove the cross-page ambiguity about trusted evidence.

Evidence: docs/site/understand/data-and-state.md:439; docs/site/understand/telemetry.md:555; docs/site/understand/components-and-authority.md:214; docs/site/understand/data-and-state.md:49; contracts/pipeline-test-gate/v1/src/types.ts:383; contracts/pipeline-test-gate/v1/src/remote.ts:61.

Fix: Use digest-bound remote result and receipt for result import. Reserve signed/Ed25519 for the independently verified source snapshot attestation. Remove the incorrect Buster artifact-signature comparison and explain imported byte/digest/receipt verification accurately.

## QF-03: Reader prose retains correction history

The contract guide discusses the original and corrected observer command. The gateway evidence says no client/deployed test was run for this correction. These phrases require readers to understand author correction history, contrary to the reader-page quality standard. The technical evidence limits themselves are useful.

Evidence: docs/site/extend/contracts.md:347; docs/site/understand/platform-and-operations.md:571.

Fix: State the current observer command scope and separate recovery check directly. Keep the accurate unexecuted-test boundary while removing for this correction and other internal editing history.

## QF-04: Linked acceptance page contradicts current CNI status

The acceptance page says Cilium must be accepted separately from the current Flannel deployment. The canonical architecture explains the selected Cilium profile and that a secured Flannel fallback is not implemented. The linked reader path gives conflicting current/future status.

Evidence: docs/site/status/acceptance.md:182; docs/site/understand/platform-and-operations.md:164.

Fix: Describe acceptance of the selected Cilium profile and the separately planned secured Flannel alternative without claiming a current supported Flannel deployment.

## Inspection method and useful limits

Read the complete handoff from the original read-only working location, the documentation quality standard, acceptance contract and applicable execution plan; enumerated catalogue entries and readerDelivery/READER-PLATFORM-01 contract. Followed the site start and architecture navigation to communication, stores, telemetry, deployment/trust, infrastructure and security, all six specialist pages, diagnosis/recovery and all six controlled dependency exercises. The success and Redis-failure trace JSON files are contract examples, explicitly not observed executions. Full generated table rows were loaded and their explanation destinations audited; identities and statuses were read in bounded/reduced outputs. Required independent Source exhaustiveness was not substituted with that parse.

Controlled-English inspection considered clear active sentences, defined specialized terms, explicit actors and authority, separation of identity/authentication/authorization and evidence, short recoverable actions, useful failure branches and concrete stop conditions. No formal ASD-STE100 certification is claimed. Mechanisms, concurrency/fences, immutable identity, failure/recovery and meaningful rationale were inspected across the full canonical scope. Significant choices commonly distinguish recorded reason from explicit historical unknown and present-day inference, with costs and reconsideration conditions. Missing product capabilities (e.g. secure Flannel fallback, Archviewer publisher, Git mirror, complete Redis retirement/restore and isolated LiteLLM restore) are not treated as documentation failures where precisely disclosed with safe stop and later acceptance conditions.

All 1,215 local Markdown link targets and 1,454 source target files in the selected21-page audit exist. This validates filesystem paths only. It does not prove real rendered anchors, publication allowlist inclusion, source commit fidelity, live routes or independent Source completeness. An engine-snapshots historical citation extends beyond the current file length; this is recorded as a diagnostic, not falsely called invalid without examining that historic object.

No exercise command, live dependency failure, host activation, network request, install, documentation generator, drift mutation, test or renderer/browser probe was executed. READER-PLATFORM-01 task execution, full Source role acceptance and published rendering remain **NOT_CHECKED**. Read-only inspection of command examples is not execution proof. The broader acceptance gates remain NOT_CHECKED even where their quality facet passed.

Tracked-file SHA256 manifests before and after and Git status are retained. See verification.json for actual equality/status results. Exact tool/environment metadata and command recording limits appear in environment.json and command-history.md. Artifact-manifest.json contains each report artifact's bytes and SHA256; artifact-manifest.sha256 seals that manifest. Neither manifest hashes itself.

## Requirement verdicts

| ID | Quality verdict | Observation |
| --- | --- | --- |
| SPC-004 | PASS | Dispatch identity, prompt/owned worktree, commit selection and merge, conflict/uncertain push, cancellation, capability grants and extension boundaries form a coherent Forge path. |
| SPC-005 | PASS | Echo binds a fixed review subject, separates findings from policy/certification authority, explains repair/revalidation and stale subject recovery, and supplies a bounded extension route. |
| SPC-006 | PASS | Host plugin installation/discovery/allowlist activation is separated from Nova runtime dispatch. Prism job claim/fence, OpenClaw process/session budgets, observer persistence limits and removal/diagnosis are explicit. |
| SPC-007 | PASS | Codex packages expose skills and tool access without pipeline authority. Installation, credentials, Ops MCP dependency, persisted host config precedence, workspace/network boundaries and update/removal limits are understandable. |
| SPC-009 | PASS | Eight tool methods, parameters, namespace enum, bearer/origin checks, HTTP session behavior, Kubernetes/Hubble limits and failure recovery are explained. Full scan aggregate limits are honestly absent; stop/narrow-query decisions are actionable. |
| SPC-010 | PASS | Archviewer route, shared workspace, basic auth and health exception, Cilium/Tailscale selection, and lifecycle are explicit. Missing supported producer/publisher is labelled and leads to a safe stop rather than fabricated publication. |
| COM-001 | PASS | The authored matrix binds producer/consumer, identity, transport, deadline/byte/order/retry/persistence semantics and failure to generated discovery rows; dynamic families have additional treatment. |
| COM-002 | PASS | Nova-to-Buster immutable request, source attestation, admission/status/result import and uncertainty identity are explained coherently here. Result-signature contradictions in downstream evidence pages are recorded separately. |
| COM-003 | PASS | The Prism topology distinguishes bridge, Control, Worker, Studio, PostgreSQL and archive import; job/dispatch identities and ordering are joined to the dynamic route families and failure checks. |
| COM-004 | PASS | Forge/Echo runtime targets carry bound subjects and attempts; adapter deadline and uncertain response decisions preserve Nova authority. Detailed specialist guides expand the matrix meaning. |
| COM-005 | PASS | In-process and isolated plugin paths, context/effect/grant authority, stage/adaptor/observer results, deadlines and delivery failures are separated rather than conflated with network services. |
| COM-006 | PASS | Worker native channel is a bounded framed control path distinct from protected HTTP admission, with identity, attempt ownership, byte budgets and error containment described. |
| COM-007 | PASS | Redis key/stream/dedup identities, RESP boundaries, deadlines and replay limits are tied to owning adapters; absence of a generic active consumer or durable host replay is explicit. |
| COM-008 | PASS | The endpoint catalogue provides method, listener, route family, access, limits and failure meaning and links generated inventory; endpoint presence is not presented as live route acceptance. |
| COM-009 | PASS | Platform private access and generation-bound Buster fixture exposure have different owners and release semantics; ACL/TLS/route readiness and uncertain cleanup do not authorize replacement leases. |
| COM-010 | PASS | Exact Git revision, writable OCI store versus pull-through cache, local rootless BuildKit socket and digest verification are distinguished; uncertain push requires inspection before rebuild. |
| COM-011 | PASS | SPIFFE identity, Envoy mTLS hops, loopback forwarded identity and application peer checks are separate from packet reachability, with failure-closed behavior and rotation links. |
| COM-012 | PASS | Connection-specific limits/retry owners appear in the matrix and transport details. Global retry rules prohibit replay of uncertain external effects and preserve identities rather than restarting blindly. |
| DAT-001 | FAIL | The store matrix and alias operating contracts cover writers/readers, location, schema, consistency, locks, growth and truthful missing restore/retirement. Incorrect authenticated-signal and signed-result labels prevent acceptance. |
| DAT-002 | FAIL | Nova immutable inputs, journal commit chain, effects/results, wait projections and administrative decisions are explained with locks and failure boundaries; resume authentication label conflicts with its actual validation boundary. |
| DAT-003 | PASS | Worker journal, owner records, outputs and sealed completion relate admission to process quiescence; unknown resource ownership prevents cleanup and does not become a successful terminal result. |
| DAT-004 | FAIL | Buster durable jobs/plans/attempts/evidence/report stores and import/cleanup lifecycle are substantial. The signed-result wording invents an integrity property absent from the result contract. |
| DAT-005 | PASS | Prism transaction state, immutable artifacts, revisions, approval, quarantine acquisition and matched database/artifact groups define separate authorities and restart/restore dependencies. |
| DAT-006 | PASS | LiteLLM schema/image ownership, credential/salt domain and migrations are distinct from Prism. Direct versus GitOps capacities and the unimplemented isolated restore target are explicit and safely blocked. |
| DAT-007 | PASS | Redis retains delivery/deduplication records while Nova/Buster remain canonical authorities; AOF/volume/trim/TTL boundaries and missing full owned restore procedure are explicit. |
| DAT-008 | FAIL | Artifact identity, byte encoding/digest verification, size and collision/visibility/retirement limits are explained across store families; result-signature claims create an incorrect trust property. |
| DAT-009 | PASS | Matched backup groups and writer fencing, independent restore targets, owner-specific ordering and corruption checks are practical. Missing Redis/LiteLLM complete restore tooling is explicitly a stop condition. |
| TEL-001 | FAIL | Both active Nova observation and host ingress paths follow signal through storage/sink and missing consumers. Canonical versus projection authority is clear except the incorrect signed-result authority table. |
| TEL-002 | PASS | Retained telemetry v1 schemas are not advertised as active producers. Active v2 lifecycle/domain events and host agent-observability v1 are differentiated by schema and execution status. |
| TEL-003 | PASS | Event producers, committed lifecycle owner, registration subscribers, filters and sinks are mapped, including inactive retained contracts and absence of a shipped host-ingress consumer. |
| TEL-004 | PASS | Per-run sequence, attempt/event/delivery correlation, at-least-once deduplication and sink-specific sensitive fields are explicit. Redaction is not falsely asserted for raw payloads or unconfigured logs. |
| TEL-005 | FAIL | Delivery journal, checkpoint-after-success, required/best-effort policy and restart/retry semantics are useful; current check instructions retain internal command correction history. |
| TEL-006 | FAIL | Deployment observability correctly distinguishes durable lifecycle/effect/artifact authority from projections, but the linked telemetry evidence table mislabels Buster result authority as signed. |
| TEL-007 | PASS | Retention and capacity matrix explains trim/TTL, disk growth, backpressure propagation, drop/block and connected-retirement gaps. Failure recovery does not reconstruct authority from missing telemetry. |
| INF-001 | PASS | Host prerequisites and failure domain precede K3s; missing empty-host automation and independent administration are explicit. Manual host responsibility is not passed off as a supported bootstrap command. |
| INF-002 | PASS | DNS, selected storage/CSI, scheduling/topology/capacity and prerequisites are product bounded with linked operations; upstream general fields are appropriately referenced rather than invented. |
| INF-003 | FAIL | Canonical CNI ownership, secured Cilium profile, unsupported secured Flannel fallback, migration rollback and live positive/negative proof boundaries are clear; linked acceptance prose still calls Flannel current. |
| INF-004 | PASS | Argo versus direct Helm ownership is exclusive. Reconciliation/self-heal/prune, desired commit, project scopes and handover/failure costs explain when to stop before competing writers. |
| INF-005 | PASS | Rootless BuildKit socket, host/cgroup prerequisites, cache/credential consumers, worker limits, ordering and uncertain push recovery are operationally meaningful and separate from pipeline authority. |
| INF-006 | PASS | Lab anonymous HTTP registry has declared residual risk, volume/capacity/GC boundary and immutable digest acceptance. Production TLS/auth/rotation/recovery replacement remains planned. |
| INF-007 | PASS | Docker Hub mirror is a separately owned cache with cold-miss/upstream dependency, selected consumer configuration, corruption/capacity and GC limits; it is not a writable production registry. |
| INF-008 | PASS | No supported Git mirror is claimed; exact source revision remains required, with future mirror freshness/integrity/failback conditions and no invented cache fallback. |
| INF-009 | PASS | Redis, separate PostgreSQL owners and two Tailscale functions are joined to protocol/credentials/storage/route contracts and failure order. Recovery preserves owned authority and identity. |
| INF-010 | PASS | Prometheus/Grafana/Loki/Alloy data paths, retention and exposure/privilege limits are non-authoritative and optional. Missing joined tracing/live monitoring proof is stated. |
| INF-011 | PASS | Ops Pod tool read policy is separated from the shared Kubernetes credential and default pods/exec authority. In-cluster observation does not replace independent failed-cluster recovery access. |
| INF-012 | FAIL | Embedding-only LiteLLM route, Vertex identity, memory consumer, config precedence, readiness versus result, recursive splitting/retries/timeouts and recovery are deep; correction-history wording violates reader prose rules. |
| SEC-001 | PASS | Assets and independent process/network/storage/caller boundaries produce concrete threats and mitigations. Residual authority and open enforcement evidence are kept visible. |
| SEC-002 | PASS | Human sessions, workload SVID, bearer/Secret and source/artifact identities are distinct. Keycloak is unimplemented; current application session authorization and credential lifecycle are explained. |
| SEC-003 | PASS | SPIRE registration and CSI/SDS to Envoy and exact application peer checks distinguish authentication from authorization; single key/rotation/failure boundaries and live issuance limitations are explicit. |
| SEC-004 | PASS | Secret ownership/producer/consumer and mount/env resolution are mapped, partial helper versus full inventory distinguished, and rotation/revocation/compromise actions preserve authority without displaying values. |
| SEC-005 | PASS | Service/policy/identity matrix describes caller, ports, ingress/egress and negative expectations; render/source evidence does not assert live enforcement, and secured Flannel replacement remains absent. |
| SEC-006 | FAIL | Source attestation, package digests, selected image/registry provenance and missing complete scan/SBOM policy are distinguished. Linked component/data/telemetry signed-result claims undermine the otherwise correct trust model. |
| SEC-007 | PASS | RBAC, workload peers, network routes, plugin grants, filesystem/process/external authority remain separate. Shared Ops exec credential and mutable privileged boundaries are disclosed rather than labelled least privilege by tool annotations. |

## Gate quality facets

| Gate | Quality facet | Reason |
| --- | --- | --- |
| A97-01 | PASS | Inventory presentation separates mandatory deployed showcase dependencies from portable pipeline dependencies, optional profiles and planned systems; generated rows join readable explanation. Discovery exhaustiveness is reserved to Source review. |
| A97-02 | PASS | Required dependency contracts name owner, purpose, consumers, protocol, endpoint/identity, config/default precedence, health, failure, safe stop and recovery, with separate database and Tailscale domains. |
| A97-03 | FAIL | LiteLLM route/model/embedding/credential clients, current image/source evidence limits, effective retries and recursive split costs, readiness and stop/recovery are explained. Internal correction wording remains. |
| A97-04 | FAIL | Optional Argo/monitoring and selected Cilium extra capabilities are clear, while a secured Flannel alternative is honestly absent canonically. Linked acceptance prose contradicts the current CNI status. |
| A97-05 | PASS | Communication matrices, dynamic HTTP families, worker control, Redis streams, provider paths and detailed limits supply decisions and failure semantics; quality inspection does not claim a full independent source discovery proof. |
| A97-06 | FAIL | Store matrices and detailed aliases include authority, schema, writers/readers, consistency/fencing, growth/retention, backup, restore/corruption/loss/retirement and unavailable operations. Authentication/signature contradictions remain material. |
| A97-07 | FAIL | Signal-to-storage-to-use paths, active/retained status, correlation, labels, selection/redaction, pressure/retention, failure and absent joined execution are explicit; signed-result authority and correction-history text remain. |
| A97-08 | FAIL | Identity/secrets/network/supply-chain layers, compromise/rotation and negative expectations distinguish source/render/live. Incorrect signal/result trust labels elsewhere in the same architecture reader path remain. |
| A97-09 | PASS | All six specialists supply coherent purpose, input/request/data/error, config, operation, recovery and extension boundaries, with recorded versus inferred/unknown rationale and reconsideration cost. No exhaustive upstream encyclopaedia demanded. |
| A97-10 | PASS | 20-step success reference and six controlled dependency failure exercises reach concrete safe decisions and owner-bound recovery/cleanup. Fixtures are explicitly contract examples; no live successes inferred. |
| A97-11 | FAIL | Quality diagnosis/recovery selection is supported by clear owner-bound procedures and safe stops, but conflicting authentication/signature/CNI status obstruct a consistent fresh-reader decision. Required independent Source and Reader executions were not performed by this reviewer. |
| A97-12 | PASS | Drift mutation design has dynamically counted add/change/remove variants for endpoints, dependencies/services, stores, events, secrets and Ops tools with specific failure diagnostics and a temp-copy mutation boundary. Mutation execution remains NOT_CHECKED. |
