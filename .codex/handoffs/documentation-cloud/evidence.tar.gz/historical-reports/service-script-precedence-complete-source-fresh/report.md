# Independent fresh SOURCE review — Service script precedence

Frozen repository: `46177330100bf1c5309296e19e822a5aed16fef1`; tree `89dac97afbf2530137ed8b6dc2fda3cfede31645`. This is a bounded source review, not global Core, CFG-009 or AP09 acceptance. Repository remained read-only. Work and isolated artifacts are in this private directory. No author report or prior reviewer conclusion was used as proof.

Result: **FAIL — one material namespace authority defect with two independently reproduced cases remains.** The changed Service prose accurately warns that workspace selection can replace the initialized namespace. Its linked canonical environment reference still supplies a contradictory winner and empty-input contract. A reader cannot consistently derive the actual LiteLLM/registry target namespace from those published authorities.

## Applicable contract and scope

Read the complete quality standard, AP09 acceptance contract and fixture catalogue; CFG-009 is the Helm/GitOps/infrastructure requirement whose canonical target is helm-values.md. Applied the owner-approved product boundary: include actual local producer branches, supported ClusterIP/NodePort/LoadBalancer choices, script loaders and defaults/omissions; general unused upstream alternatives may remain upstream links. Retained claims still must be correct. A98-02 requires prerequisites/location/authority; A98-06 observable distinguishing diagnosis and uncertain results; A98-10 recursive inputs; A98-11 complete precedence plus empty/conflict/invalid cases; A98-13 reader independence. No applicable AGENTS.md exists in the repository or inspected ancestor directories; `.agents` contains marketplace configuration, not additional instructions.

Read service-routing.md in full, its canonical diagnosis entry (`use/diagnose.md:207`), exposure-change entry (`configuration-change-impact.md:442–450`), environment rows and producer/receiver authorities. Exported all **92** Service receiver records, including metadata/status, evidence and limits, as service-records.json. Captured all five raw Service document records and complete field authorities as affected-service-documents.json. Chart templates, helper selectors, workloads, values and overlays were inspected separately because their unrendered templates are not those five raw records.

## Individual bounded criteria

| Criterion | Result | Evidence and limit |
| --- | --- | --- |
| A98-02: read-only Service inspection prerequisite/location/authority contract | PASS | service-routing.md identifies workstation, POSIX shell/kubectl/jq, compatible versions, approved context, named RBAC access and owner-supplied proxy/DNS identities. Commands are observations; absence/access denial are not success. No live execution inferred. |
| A98-06: actual Service symptom route and distinguishing stages | PASS | diagnose.md:207 links the real inspection anchor; page distinguishes missing stored object/allocation, namespace/labels, readiness/named port/Slices, forwarding, DNS/cache, listener, policy and external provider. Interrupted writes require object/UID/port reads, pending LB status is not connectivity. |
| A98-10: selected local Service producer/default/omission account | PASS, bounded | Main/dedicated extra routes, Prism conditional trust/ingestion/database, demo-ready, Nova-only archviewer, Ops headless, raw/GitOps LiteLLM/registries and conditional external Prometheus values are represented. This does not accept the entire recursive configuration inventory or external-chart families. |
| A98-11: effective namespace input precedence, empty/conflict cases | FAIL | F01 below. Published environment authority contradicts executable deploy resolver in a supported forced-prompt case and misstates explicitly empty input. |
| A98-11: LiteLLM environment/default/range/render/patch chain | PASS, bounded | deploy.sh:91,1166–1180; renderer preserves Service omission; later merge patch replaces the ports list using resolved value. Script range is distinct from actual allocator availability/range. New Service can remain initially allocated if patch fails; unknown result needs stored reads. No API operation performed. |
| A98-13: Service read-only diagnosis complete enough for source-level reader | PASS, bounded | Required identities, expected distinguishing observations, stops, owner boundaries, evidence protection, read-only cleanup and lack of rollback are stated. Actual namespace-selection subtask remains FAIL under F01, so this is not an acceptance of the broader operator workflow. |
| CFG-009 Service subset | FAIL | Same unresolved namespace authority affects the supported deployment of LiteLLM and selected raw registries. No global CFG-009 verdict. |

## F01 — namespace winner and explicitly-empty handling are wrong in canonical generated authority

Authority to fix: `scripts/docs-configuration-inventory.mjs:779` (NAMESPACE), `:776` (KUBECLAW_WORKSPACE_NAMESPACE_FILE), and the generated `docs/site/reference/environment-variables.md:219–220,234`. The NAMESPACE consumer contract says: “An explicitly set process value wins; otherwise deployment can use the saved workspace file or prompt”. The saved-file contract says explicit NAMESPACE wins. These are false as unconditional winner statements.

Source proof:

* `scripts/deploy.sh:81–82` captures **presence** with `${NAMESPACE+x}` independently of the nonempty/default expansion `${NAMESPACE:-kubeclaw}`.
* `:679–684` reads a saved namespace only when NAMESPACE_WAS_SET is empty.
* `:697–700` skips prompting for an explicit environment value only in **auto** mode.
* `:716–720` in supported true/interactive mode reads a valid entered value and replaces NAMESPACE, including a previously explicit nonempty environment value.

Actual isolated reproduction: exact frozen resolver function extracted into namespace-harness.sh, with no-op message functions, a valid namespace predicate and fake interactive read. Under an allocated PTY, `NAMESPACE=environment-selected`, `NAMESPACE_WAS_SET=x`, `KUBECLAW_WORKSPACE_PROMPT=true` ends as **operator-selected**. No cluster command exists in the harness. Exit 0.

Second actual case: an explicitly present empty NAMESPACE sets NAMESPACE_WAS_SET=x and initialization selects kubeclaw. In auto mode a valid saved file is then ignored and prompting bypassed, so effective value is **kubeclaw**, not the generally described “default or workspace selection path.” The harness reproduces that result, exit 0. See namespace-harness.log.

Impact: a supported forced-prompt deployment can target another namespace than a reader expecting explicit NAMESPACE to win. Explicit-empty and absent environment are not interchangeable for workspace selection. LiteLLM apply/patch and selected registry apply use that final namespace; the page's accurate local paragraph cannot repair a conflicting canonical field authority.

Required correction: describe deployment-specific stages and presence/nonempty distinction. Absent environment permits saved-file selection; explicitly empty initializes kubeclaw but suppresses saved-file/auto selection; auto skips for any present environment; false returns after saved-file stage; true requires TTY and entered valid namespace wins regardless of initial explicit value. Do not transplant deploy workspace semantics into setup-secrets/policy-migration consumers, which have their own scripts. Regenerate maintained reference outputs, add meaningful isolated empty/absent/auto/false/true tests, then independently re-review. No repository fix made by this reviewer.

## Producer and receiver findings

Independent raw source search found the local Service template/raw producers listed by the page. Main kubeclaw release selector includes name+instance and no role/component; deployment declares gateway/bridge named ports. Prism dispatch overlay changes gateway mapping and disables bridge; Buster plan mapping is sidecar-backed. NodePort branch emits positive fixed gateway/bridge ports; LB ignores those main fixed inputs; a non-NodePort extra route emits a dedicated NodePort in addition to the main route. Nova example's nodePort with default ClusterIP is inactive. All of these are intent, not a bound application listener.

Prism Services use release namespace and exact app selectors; worker-trust is conditional; PostgreSQL target defaults from numeric port. Demo-ready readiness/broker/Buster conditions and narrower component selector are distinct from broad main release selection. Archviewer fails non-Nova and rejects legacy extra-port collision. Ops health mapping does not expose the explicit ops-mcp 127.0.0.1 listener; StatefulSet serviceName supplies headless identity.

GitOps LiteLLM and registry-local have explicit kubeclaw namespace and fixed NodePorts. Raw LiteLLM omits namespace/nodePort; direct apply context is a separate authority from script request scope and later patch. Raw registries are ClusterIP. LiteLLM renderer reads selected config/deployment and does not add the fixed nodePort. On an existing object, apply/field ownership and retained allocation still require stored-object inspection; no fresh-create assertion was treated as universal update precedence.

Independently downloaded **61 immutable original files** from exact GitHub commit URLs, including the linked product sources and all unique evidence files referenced by exported Service records. originals-provenance.json records URLs, local bytes, SHA256 and size. Read relevant original defaults, validation, allocation, EndpointSlice namespace/port/readiness conversion and named regular/restartable-init resolution, conditional CoreDNS headless/ClusterIP query selection and default-cloud-controller cleanup/publication paths. **2,732 evidence references** have valid line bounds (line-range-check.json); bounds alone are not semantic proof.

Defaults/intent are correctly separated from allocator family/range availability and reconciliation. Nil selectors do not trigger automatic EndpointSlice reconciliation; empty map can select namespace-local Pods, so command stops on empty selection instead of listing all Pods. Unresolved named targets omit ports; declaration does not start a listener. Headless is not VIP forwarding. Cilium configured replacement=false is not proof of an installed dataplane; modes/DNS remain owner-qualified. No installed provider, ServiceLB or DNS version is assumed. LB deletion calls provider only after exists=true, tolerates ImplementedElsewhere and then attempts finalizer removal; API finalizer removal does not prove erasure. Completed provider ensure work can coexist with stale status publication. No additional material finding identified in these selected producer/receiver clauses.

## Actual checks and explicit non-executions

Actual: frozen `git archive` outside repository; import of receiver module and complete record capture; pinned upstream download; SHA256 original provenance; 2,732 line-bound checks; LiteLLM offline renderer; Helm v3.22.0 offline renders for default, NodePort fixed gateway, LB with fixed main port ignored plus dedicated extra NodePort, and explicit-empty service.type; parsed Service results in render-results.json; exact resolver isolated PTY harness with two counterexamples. All successful executions exited 0. Node v24.21.0. A preliminary Python YAML result reader failed because PyYAML is not installed; corrected to existing js-yaml, with no dependency installation. Initial raw-record extraction required resource.kind rather than document.kind; final captured data is correct.

Not executed: any live kubectl, Secrets read, deployment/apply/patch, policy mutation, pod creation/exec, DNS/network probe, allocator transaction, controller reconciliation, kernel rules, external provider operations, live allowed/denied connectivity, publication/server/browser reader test, full mutation suite or global generator/acceptance gate. Export/import is not a cluster or complete acceptance test. General unrelated upstream metadata/GC/status family qualification is not accepted by this Service subset review merely because complete records were captured.

No global Core/AP09 acceptance is granted. F01 remains material until canonical authorities and meaningful tests are corrected at a new frozen revision.
