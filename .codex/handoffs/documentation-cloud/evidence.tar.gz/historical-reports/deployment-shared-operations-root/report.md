# Root-authored update-operation corrections

AUTHOR candidate only. No independent Source, Reader, Quality, Astra or package acceptance.

Deployment metadata and identity contracts now distinguish authored client-side apply, retained current-only fields under a retained parent, and conditionally selected Argo server-side apply. The helper is shared by the two identity rows and 102 metadata rows. Existing record identities and cases were preserved by the earlier preservation comparison; 208 conditional cases were added. This full upstream registry is internal authoring material. Product-scoped publication is being implemented separately; these counts are not usability or completeness proof.

The canonical API-object update explanation now supplies exact Argo option names, migration default, source-manager override and final manager. Root downloaded the two constant files anew and verified their Git blob identities against the pinned Argo tree, then read the constants and independently previously downloaded controller and engine selection code. The literal disabling migration option is ClientSideApplyMigration=false. No live option selection or API effect is claimed.

The shared replacement ownership caption was corrected: update.go159–166 supports the normal enabled/disabled transform, while229–235 supports clearing managedFields, disabling its update and retrying after an object-size rejection before storage commit. Root freshly downloaded and verified the source blob and read both exact ranges.

The sealed Core Source report is not accepted wholesale: its current-selection prose incorrectly says five Prism/Ops templates emit an empty StorageClass. Root independently compared their frozen07d bytes with current files and read the conditional if blocks; they omit storageClassName for empty values. This correction is recorded separately without modifying or retroactively passing the original reviewer report.

Observed checks: 12 focused API coverage/reference tests passed, terminal exit0 (session72468; tests are renderer/contract checks, not API or source-semantic acceptance). Actual repository reference check passed, terminal exit0(session54991), raw log retained. It reports4909local links,2803anchors,7607repository paths and28313pinned source links. Other agent drafts existed during these checks; this is not final clean-checkout acceptance. The focused tests subsequently changed as part of scoped generation authoring, so this observation is not a verdict on those later edits.

Generator migration, selected receiver Source reviews, Reader/Quality/Astra and final current mutation suite remain open. No product runtime code, deployment or deletion was changed.
