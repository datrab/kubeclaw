# Independent Cilium Source review — FAIL

Reviewed immutable subject: `807ff6f5ee952ce6b24711f0f7f803832cb91fc9`. Reviewer identity: `cilium-complete-source-fresh`, independently dispatched with fresh context and read-only subject access. Private evidence location is this directory. The writer's report and artifacts were not used to establish source truth. No original repository mutation, commit, push, documentation generation, deployment or live operation occurred.

The requested complete source acceptance is **FAIL**. Material source defects were found, and this review does **not** claim exhaustive manual qualification of all 294 captions, all 8,722 cases or a fully independent Go type graph. The full registry and every declared dimension/case have individual ledger entries, but an uncompleted qualification remains FAIL rather than becoming PASS from an inventory count. This report is a bounded source finding and continuation artifact, not a complete successful review. There is no Reader, Quality, Astra, AP8, global or live approval.

## Independent provenance and mechanical closure

The subject came from `git archive` of the full frozen revision, not the changing working tree. Its Cilium receiver module SHA-256 is `884d370fda451704c73520a66e40326b70e2b9123f78b38fbb9440f79c9efe14`.

Primary Cilium sources were independently fetched from codeload at `7d68cfb394f2960e10aa72e76d0d51e66c1b2ebc`. The release ref and annotated tag object independently bind `v1.20.1` through tag object `2428bc06f693c9ccde087c8901ebd291941262b6` to that commit. Source tar SHA-256: `3aa3bfcd2451dd75f64b5978d36ff2a878e3a2f0d4bed5fc13cce0fde1313bdb`.

The independently downloaded actual chart archive has SHA-256 `06210eef7c23d15f7699c79e2fe3a1ec9c389024c5c5c006ea04022d322449a2`, exactly matching the lock. Its actual Chart.yaml declares both version and appVersion `1.20.1`. Independent recursive traversal found 858 locked CRD nodes for each policy kind. Both locked decompressed CRDs match the pinned Cilium full-tree source bytes exactly. Each kind has zero missing/extra registry paths. These observations prove schema/path closure only.

Registry capture found 1,716 records, 8,722 named cases and 294 distinct source windows. Every unique window's source bytes, SHA-256, actual excerpt, attached captions and affected records are saved. Fetch success, valid bounds and hashes do not qualify captions semantically.

Cilium's actual go.mod declares `go 1.26.0` and `k8s.io/apimachinery v0.36.3`. Its vendored client metadata declarations are distinct from the separately locked server schema authority Kubernetes `v1.35.0`; compatibility and server receiving behavior cannot be inferred from the client pin. Generic decoder source was independently fetched at full Go revision `2dc996f71b0ebafb77e64433e58333e049488a3c`; decode.go SHA-256 is `a91535f18f9a2c8380448b1c84c4c2017dbe3d530a10faf8babf03494042da48`. The decoder reference does not prove a deployed compiler.

## Material findings

Exact original wording, original locations, receiving-source locations and corrections are in `findings.json`.

1. **Empty peer collections can discard another family and widen to wildcard.** Module line 97 says empty families contribute no peers. Actual `mergeEndpointSelectors` returns nil immediately for any explicit empty endpoints/nodes/entities/direct-CIDR/CIDRSet collection. A nonempty other family can pass length-based Sanitize but then disappear from translation; L4 consumes nil peers as wildcard. The omission/[] cross-field consequence is absent.
2. **Named-port range behavior differs by path.** Module line 152 universally states named-port ranges are unsupported. Sanitizer/CRD do not reject named port plus endPort; initial ingress map construction resolves the name and passes endPort to keysForRange. Egress and incremental named-port updates construct single-port keys. This is a source-inferred asymmetry, not proof of supported range behavior or observed traffic.
3. **Extended protocol numeric-port check precedes normalization.** Module line 151's universal numeric nonzero rejection omits that exact-case extended-protocol checking occurs before uppercase normalization, and only in the numeric branch. Typed `port:"80", protocol:"gre"` bypasses that check before becoming GRE. The CRD's earlier uppercase-only enum is a different boundary.
4. **Empty header-value behavior depends on mismatch action.** Module line 170 equates absent Secret/Value with header presence. The actual translator creates PresentMatch only for FAIL_ON_MISMATCH; other actions create a HeaderMatch with empty Value.
5. **Status errors include an explicit success exit for NotFound.** Module line 49 says UpdateStatus errors return to the handler. CNP and CCNP handlers suppress IsNotFound and return nil. The attached CNP/CCNP evidence windows also end before these exception branches.
6. **Implicit ObjectMeta obligation remains open.** Module line 69 explicitly leaves field-specific admission, ownership, concurrency and lifecycle proof unresolved. The bare CRD metadata node does not remove those public inputs. This is a shared source obligation, distinct from Cilium-owned rule semantics.
7. **Renderer exclusion misses the open metadata label.** The source-control regex at `scripts/docs-api-reference.mjs:60` does not match `OPEN SHARED METADATA PROOF`; unresolved authoring obligations can reach reader prose despite the renderer's stated exclusion rule.
8. **CIDR declaration evidence cites a different package's type.** Module line 257 binds policy `api.CIDR` through a declaration of `v2.CIDR` in cegp_types.go. Correct source is `pkg/policy/api/cidr.go:16`. Equivalent underlying strings do not make the declarations interchangeable as actual type provenance.
9. **ICMP maximum-count caption exceeds its narrow evidence.** Module line 194 cites 644–651 for both maximum count and family validation, but the count check is at 640–642 outside the window.
10. **HTTP Path regex caption omits its condition/compiler.** Module line 169 cites http.go 124–154; the Path condition and regexp.Compile are at 122–123. Widen the evidence to the actual beginning of Sanitize or narrow the caption.
11. **FQDN expiry/persistence/recovery mechanisms are missing.** Module line 146 mentions expiry generically but does not explain available-source TTL/overlimit eviction, connection-tracking liveness and DNS zombies, aggregate cache rebuilding, stale metadata cleanup, endpoint restoration and the bad-precache log-and-continue branch in namemanager/gc.go.

## Actual checked scope and remaining work

Manual source scrutiny continued after the first FAIL and included fresh JSON decode mechanics, the CNP/CCNP Parse and Sanitize paths, spec/specs composition and null rule panic inference, zero direction checks, allow/deny translation, default posture and repository replacement, selector presence/custom decode/cache leads, node gates, CIDR/common-family checks, numeric/named ports and range paths, HTTP/DNS union and empty-list/item behavior, TLS local/SDS/API precedence, header fallback/mismatch branches, custom listener scopes, ICMP decoder and nil inference, authentication registration/validation leads, service selector/name precedence and updates, AWS provider union/no-op configuration branches, FQDN registration/release and GC/restoration, operator status construction and error branches, and derivative status declarations plus full-tree production-callsite discovery.

The full-tree SetDerivedPolicyStatus search finds only declaration/comment occurrences in CNP and CCNP. This supports the stated absence of an active production caller; historical status comments do not prove an active status producer. Operator validation and the agent repository are separate consumers. Parse/UpdatePolicy submission and DoneChan insertion revision do not prove endpoint/proxy/datapath convergence.

The shared schema authority, version-bound registry, coverage join and renderer source controls were read at the frozen revision. Schema traversal and required registry presence are separate from technical correctness. The renderer independently rechecks authority/schema identity, but its current unresolved-proof text match is incomplete. Raw Helm CNP inputs in archviewer and ops-pod templates were inspected; no chart rendering or publication output was executed. Full publication/source-context and all raw/rendered object exercises remain unproved here.

The documentation quality standard was read. The relevant acceptance contract requirements, CFG-009 and A98-10/A98-11 were inspected. Fixtures were captured/parsed, but their full unrelated task prose was not independently audited as part of this bounded source review. No reader exercise or quality review is claimed. Remaining scope includes full independently derived Go type/embedded-field closure, individual semantic qualification of every still-unqualified dimension/case/caption, deeper production caller and convergence/recovery closure, and every required frozen raw/rendered context. This limitation must remain visible if these artifacts are used in an aggregate review.

## Artifacts and execution

- `record-ledger.json`: individual verdict for all 1,716 records, with evidence and operation context.
- `dimension-ledger.json`: individual field/dimension entries; only mechanically proved schema identity has broad PASS.
- `case-ledger.json`: every one of the 8,722 cases individually recorded. Selected exact source branches have bounded source PASS; uncaptured semantic qualification is FAIL. These PASS entries never constitute full record acceptance.
- `independent-source-windows.json`: every distinct URL, all attached captions, immutable source hash and actual excerpt. Window capture/bounds are not semantic PASS.
- `independent-schema-inventory.json`, `independent-declaration-inventory.json`, `independent-objectmeta-public-fields.json`: independent CRD traversal, complete authored declaration capture with actual source excerpts, and client metadata field discovery. Authored declaration capture is not a complete independently derived Go graph.
- `primary-source-manifest.json`, `frozen-subject-manifest.json`, `seal-manifest.json`: primary source and frozen subject/artifact hashes.
- `execution.json`: actual source-only commands and explicit nonexecuted checks.

No Go, unit, contract, live, admission, proxy, traffic, renderer, browser or mutation test ran. The independent Node traversal was an evidence inventory and byte comparison, not a behavioral test. A failed optional PyYAML import and an unsuccessful intermediate patch attempt produced no source mutation; the successful independent harness uses the installed yaml package for parsing. The original checkout changed concurrently during this review; its later HEAD and local edits are outside this immutable subject. All review files and corrections remain exclusive private evidence.
