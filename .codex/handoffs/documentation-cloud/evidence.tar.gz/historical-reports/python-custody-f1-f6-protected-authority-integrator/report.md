# F1–F6 protected authority author integration

Author integration only, not independent Source acceptance. Historical complete executable Python custody Source FAIL and earlier scope-flow FAIL stay attached to their original bytes. No Reader, Quality, package/global, publication or live acceptance is claimed. Shared HEAD is 8c 22254ea 6cc 3f 6e 98e 3e 453f 2ff 91c 8ec4eba32, with existing dirty changes; no clean-worktree claim.

Root explicitly authorized integration only after writer FINAL FREEZE: complete scanner b 8cb 884c 85e 364ccf 99c 46d 1ca 8044a 94b 6e 0532b 657cccab 7bffdffe30855f4 (828468 bytes), test 6d 33b 6d 3746b 0b 38512b 65e 373f 44cb 3e 20fdf 6181b 95763d 743b 62bef2e0d14 (25881 bytes). Prior qualified full scanner 3b 24338343cea 73f 8818ea 919ee 43e 7fa 3c 50be 2aeaf 27674c 04d 389fca2f74a was preserved and compared completely. The initial private before snapshot caught an interim scanner and labels that fact; those interim bytes were never qualified.

## Exact frozen changes

Only scripts/docs-api-output-discovery.mjs and scripts/docs-api-producer-adapter-authorities.json were edited. Registry updates the existing scanner sourceSha256 from 3b 24338343cea 73f 8818ea 919ee 43e 7fa 3c 50be 2aeaf 27674c 04d 389fca2f74a to b 8cb 884c 85e 364ccf 99c 46d 1ca 8044a 94b 6e 0532b 657cccab 7bffdffe30855f4. Discovery changes its corresponding exact reviewed Source recipe digest from 9a 307a 7329ce 39f 26f 92e 24f 9f 436eed 7eddbebce 2d 712963eb 5d 0824a27b9d2 to 0cebf 713ab 9c 242fd 68a 9e 76643c 022be 9d 67dabe 95c 4b 4690ce 59f 386277ab1. Exact single substitutions reproduce both final files; all other owned bytes are unchanged.

Final discovery 94d 4b 14992087d 5dcebe 766d 5b 194b 779dbea 80f 63c 43742227f 3685036abcdc (341826 bytes); registry a 6f 9f 0b 13bbc 8c 1e 22340ba 23e 44324a 6347e 89b 113a 6488f 8e 131db 27d210e7 (2699859 bytes). Both are frozen. No scanner/test/product/docs/matrix/generated edits, commits, pushes or generation were made by this integrator.

## Complete Source assessment

F1 explicit known function annotation access now visits its AST against current invocation bindings before later rebinding. Lazy final potential-reader analysis remains conservative; this is no declaration-time execution claim. F2 nonfuture eval_str=True evaluated strings reject with annotation source/line; future explicitly quoted strings remain passive for one evaluation and function-local annotations remain passive. Dynamic eval_str and format/namespace overrides reject. F3 direct selected class method calls analyze their AST with current globals; this is finite named selection, not universal method dispatch. F4 AugAssign recognizes the read of an environment subscript Store target and retains its real position.

F5 finite backtick substitutions recursively acquire command code and retain offsets. Finite env -i/--ignore-environment and -u/--unset wrappers are recognized; unknown options and Python here-strings reject. F6 distinguishes actual Python -c mode, stdin no-argument/'-' mode and passive script/module command data; only fd0 winning stdin heredoc gets code custody. Other descriptors and overridden bodies stay passive.

The additional actual filesystem acquisition is ops/pod/test-image.sh line 26 selecting ops/pod/test/app_server_smoke.py (a 283df 5cd 2bf 4208cf 762d 25c 293207d 39862f 475f 82e 1ad 46cdccae 5e137361). It is text input, not a new Node module operation or public output. The full Source anchor binds the finite selection algorithm: winning fd0 plus selected interpreter stdin mode, absolute repository-contained literal or exact dirname/BASH_SOURCE[0] expression, existing regular canonical file and equality of realpath. Relative cwd-dependent, missing, escaping, symlink and unresolved paths reject. Current selected target has no readers and is parsed rather than excluded. New target readers fail closed with target path/name/line; they receive no fabricated shell position. No broad filesystem or helper exemption was added. This finite file dependency was examined and captured separately, not inserted into the modulePaths recipe as if it were an executable Node input. Root was notified of this actual dependency before integration; module inventory remained unchanged.

The native parser remains fixed literal python3 -I -c, source only on stdin, UTF-8, 10-second timeout and 8-MiB output bound; ast.parse and finite AST/literal inspection never import/eval/execute inspected source. No new launcher was added. General reflection, dispatch, shell evaluation and external-reader publication remain outside this finite custody model.

All six actual scanner imports and containing-operation hashes were extracted from final TypeScript AST and matched the existing recipe before modification. Actual graph assertion and complete audits retain 12 recipes,27 unresolved operations, six scanner imports and 15 selected module paths. All caller/schema source hashes and canonical identities are checked. Corpus/capture complete test Source/package/contract roles and pure helper/public consumer custody remain byte-identical;58 unrelated captured baseline inputs remain unchanged. All 65 complete end input hashes match.

## Executed terminal checks

Focused production api-output-publication.test.mjs: terminal0,25 PASS,0 FAIL,0 SKIP. Existing Source/operation/digest repair, helper aliases/public/canonical/capability, native synthetic test roles and producer/PV controls stay enforced.

Actual operation-owner audit: terminal0,27/27. Complete recipe/source/caller canonical audit: terminal0,12/12. Actual complete protected graph assertion: terminal0,12/27. Five operation-only/source-only/caller-only/selected-input-extension/unsupported-custody repair probes all reject using the current production function.

Private actual scanner authority controls: terminal0,9/9. Final source and six actual operations accept; changed complete source, JSON-only refresh, new operation, changed containing operation, unsupported custody, missing selected module and canonical retarget to qualified PV metadata reject. Changed selected module bytes change the authority key; that is cache binding, not standalone semantic rejection of every selected-byte change. Private actual provider-child caller controls: terminal0,4/4; actual caller accepts, changed caller bytes, JSON-only caller refresh and canonical caller retarget reject.

Current production external-stdin custody test selected by name: terminal0,1 PASS,0 FAIL,0 SKIP. This executes the current scanner declarations against the current actual no-reader target plus synthetic new target reader/missing/canonical-escape/dynamic-path controls; no inspected target executes. Other27-test writer observations remain writer evidence, not inherited runs here.

Actual checkout script and shell discovery: terminal0,36 script outputs,111 shell outputs, zero false PV helper outputs, one real selected PersistentVolume PATCH and all seven receiver fields. YAML collection-key warnings retained. These counts are observations, not completeness bounds.

Quality standard, AP09 acceptance contract, CFG-011/013/015 and A98-10/11/14 were read. Required add/change/remove detection cannot be replaced by fixed counts or current green output. No full root suite, all 84 acceptance mutations, global generator, publication, cluster, credentials against services, corpus PostgreSQL run or capture-retention runtime ran here. Fresh independent complete Source review and root stable suite remain required. The evidence records author integration, not a new independent acceptance verdict.

## Custody

Private before inputs, prior qualified scanner, complete reviewed diff, integration script/delta, exact byte proof,65 complete current inputs, production extraction harnesses, actual terminal outputs and frozen owned files are retained. Artifact manifest hashes every artifact except itself/seal; seal binds report and manifest by exact SHA256/bytes. No earlier sealed evidence was overwritten.
