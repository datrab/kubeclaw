# Complete late-PV identity/disposition correction: author evidence

Author correction only; no independent Source, Reader, Quality, package/global, deployment or live approval. Read both complete fresh FAIL reports and their manifests. Only `docs/site/use/install.md` was edited. Worker Trust remains frozen at `a70940e54909612ecc41246e7900c3c4e910119ee09e12b83b3eda1255168315`; maintenance remains unchanged. No product/runtime/shared-generator change, commit, push, host install, actual cluster/provider operation, or key-file access occurred.

## Whole affected family

Every nonempty post-delete named PV UID now must equal `PREFLIGHT_PV_UID`. The first differing UID prints a retained-resource/owner-reconciliation stop and exits nonzero before any later poll or disposition write. The approved original UID remains unchanged. A replacement that disappears later cannot erase the identity violation. The original and replacement receipts, original owner-shaped approval and command exits remain retained. Reconciliation and restored externally enforced exclusion are required before further action; no automatic new baseline or adoption is provided.

A new cleanup-local `probe_disposition_uid` distinguishes empty successful named-read output from malformed/incomplete nonempty JSON. A nonempty response must be the expected v1 kind/name/namespace with a nonempty string UID. Deleting original objects remain observable while polling. Both the namespace-after and PV-after paths use this strict parser. A present/replaced namespace, denied read, malformed/incomplete/wrong-kind response, retained local error or exhausted 60-observation loop stops without successful disposition. A recorded PV name requires a known recorded UID before DELETE; a missing PV name requires no recorded UID. Existing creating provenance, recapture, owner/provider clearance, immutable binding and UID-preconditioned DELETE gates remain intact.

The final marker now describes only the recorded API reads: namespace absent in its recorded read; recorded PV absent or **no PV binding recorded**; provider proof still required. It does not imply no intermediate unseen binding, continuous absence or no provider allocation. The required independent provider lookup/reconciliation, provisioning quiescence, authenticated owner approval and whole-lifetime exclusion remain explicit. No PV deletion, finalizer stripping or forced retry was added.

## Fresh complete affected execution

`run.py` freshly extracts the final complete observation/parser/capture helpers and cleanup fence. It substitutes synthetic API responses, owner-clearance shape, initial known identities and polling sleep only. Each tool implementation ran 22 cases, **44 total**, to terminal status. Actual native BusyBox host tools and the prior privately extracted native GNU coreutils 9.1 cp/mv were used; GNU is not a model or inferred from BusyBox. Exact executable/wrapper inputs are byte-bound through the guarded prior artifact manifest and reused proof. GNU 9.4/Ubuntu execution is not claimed.

Successful cases for each tool: original PV UID twice then API absence (three polls), immediate API absence, and no recorded PV binding with an independent synthetic provider-reconciliation clearance. The latter issues no PV read; its marker still requires provider proof.

Failure cases for each tool: replacement on poll one then scripted later absence (stops at **one** poll); original UID on poll one, replacement on poll two then scripted later absence (stops at **two** polls); denied PV read; malformed PV JSON; incomplete `{}` PV JSON; wrong-kind PV JSON; original UID still present for all **60** observations; replacement namespace; original namespace still present; denied namespace read; malformed namespace JSON; incomplete `{}` namespace JSON; DELETE wait timeout; unknown namespace/Pod/PVC/recorded-PV UID; missing provider asset clearance; local post-delete retention failure. Every failure exits nonzero and creates no disposition marker. Unknown identity/provider-clearance cases issue no DELETE.

Each attempt retains actual raw stdout/stderr and wrapper exit in `receipts.json` and paired log files. Historical API receipts remain sealed; denied calls preserve actual exit37 and `Forbidden`, while the timeout preserves actual wait exit38. Malformed-response reads retain API exit0 separately from the subsequent parse failure. The local-retention case retains its actual API exit separately from the local failure. No remote success or later absence is promoted to cleanup success after a violation. These are shell/mock ownership and API observations, not authenticated real owners, Kubernetes admission/UID enforcement or backing-provider results.

## Bound reuse and applicable checks

`reuse-proof.json` rehashes **all 17479** prior author artifacts (including link targets and native GNU package/executable/library/wrapper bytes) and **all 47** prior input authorities with zero differences. Twenty-three Bash fence bodies remain exactly unchanged, including all creating/provenance, observation retention, writable publication, prior denial repair and trust procedures. The complete helper body is byte-identical. Their previous real native tool executions are explicitly reused as bounded unchanged-body proof. The changed cleanup fence is freshly executed here; the older whole-page/whole-seal approval is not reused or claimed. Historical Source/Reader FAIL reports and old author bundles are preserved untouched.

Fresh checks at final source:

- 24 exact Bash fences and six Node heredoc bodies passed syntax checks.
- 57 pinned references passed complete Git-file byte equality and range bounds.
- 53 scoped local links/routes/anchors passed the repository shared Markdown parser/anchor implementation.
- `npm run verify:worker-core:trust` exited0; `npm run docs:operator-tasks:check` exited0. Logs and terminal timestamps/exits are retained.
- Scoped `git diff --check` exited0.
- Actual publication check exited1 for other-page/generated-catalogue findings; neither assigned page has a finding. Global FAIL remains FAIL.

Project language review used direct sentences, explicit stop conditions, exact technical terminology, the actual publication findings and comparison with the complete approved ownership/provider boundaries. No formal ASD-STE100 certification is claimed.

## Remaining limits

No live installation, DNS/storage/provider operation, externally enforced exclusion, actual owner authentication/provider disposition, production signing or unit receipt, live receiver-denial/positive control, release promotion, upgrade/rotation/retirement, restored application, browser/publication build, registered deployment exercise or independent Source/Reader/Quality acceptance ran here. Missing implementation and runtime-selection stops remain intact. The parent must obtain new distinct fresh complete affected Source/Reader/Quality review after integration; this author report cannot approve those facets.

`manifest.json` binds final sources, exact current inputs, immutable old report/manifest authorities, reuse proof, test controls/raw receipts and all current artifacts. Final source copies are retained under `final-source/`. Older FAILs remain tied to their original frozen hashes.
