# Author handoff: actual OpenClaw memory consumer

Exclusive release write: docs/site/use/diagnose.md. No other repository file was edited by this author. No commit or push.

Frozen document SHA-256: f84611c3db5daf111338cba475084e166dfba9d0efa8020278649a2d1241415b
Repository HEAD at author check: c978d34cf6949c0dcc49569e0a587d128851633d
Pinned OpenClaw source: 3a9d69db306cd7f081e06254cb89c4bcc14a7107.

Changed the LiteLLM fault section only. Direct fetch probes are explicitly route-only. Added supported memory CLI baseline, SecretRef/gateway requirements, synthetic-note indexing and query, bounded observer, actual consumer fault mapping, query/index retry and cancellation boundary, consumer recovery and narrow cleanup. CLI does not serialize internal error code; observable error remains preserved message plus exit 1. A fast connection rejection does not prove the registered timeout; text requires elapsed timeout evidence. Document does not waive A97-10/EXEC-FAIL-LITELLM, claim live success, or claim that index cancellation propagates a caller signal.

Author checks: git diff --check passed; 7 Bash and 10 inline Node syntax checks passed; 14 selected upstream links have valid line ranges and matching pinned Git blob identity. All private downloaded source files were checked against the pinned upstream tree. See checks.json. Read and verified selected adapter/retry/query sources from earlier author's private source bytes, not author summary. No live cluster, selected image execution, or semantic query result was executed. Full reference check exited 1 with no diagnose finding. Unrelated findings: three missing helm-values anchors in buster-namespace-controller.md; maintenance.md remove-qdrant.sh L57-L78 exceeds 77-line pinned source; prism-studio.md missing approval-notification open-issue anchor.

Reader-site boundary check has no diagnose finding. Overall exit 1 remains for unrelated helm-values.md lines 1824, 1925, and 3869 (source-inspection bookkeeping).

Independent Source, Reader, and Quality review required. This is author evidence only. Please inspect logging/output behavior in the selected image and run the real reader task before claiming operational evidence. The controlled upstream timeout scenario needs a timed-out call, not only the route observer's 70-second abort.
