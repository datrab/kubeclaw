# Independent source review: pipeline platform configuration

Reviewed candidate: `371b84654b877ec11a6b04d43f74e17e2e04edb3`, branch `docs/documentation-overhaul`.
Reviewer: `/root/a98_platform_activation_source_fresh`, Source role only, fresh context, initially and throughout read-only for the main repository. I did not author this page, perform its Reader or Quality review, consult an author summary, inherit a previous review verdict, or create subagents. The prior precedence/timer report was named as context but was not read or used as a verdict.

Canonical candidate page: `docs/site/reference/pipeline-platform.md`, lines 1–216, regular Git mode `100644`, blob `b08fca45e01ddb4aa71ac5fdd02c0ff7f719060b`, SHA-256 `aac193ffa6f1728170573d92d88a82823305d100db7ba2e7d1430b7c2e8bb71d`. Candidate source/documentation files were extracted with `git archive` into private `source/`. `archive-inventory.json` verifies every tracked archive entry against its candidate Git blob; no tracked source was rewritten. Supplemental dependency selectors under private `source/node_modules` and explicitly synthetic inputs under private `fixtures/` are outside candidate source authority.

## Separate scoped decisions

| ID | Assigned Source partition | Verdict | Reason |
| --- | --- | --- | --- |
| CFG-002 | Complete authored `pipeline-platform.v2` reference | FAIL | The page still conflates configured and selected providers and omits material trust-key, external-execution, and runtime-validation conditions detailed below. |
| A98-10 | Platform source-field semantics, constraints, defaults, ownership and consumers | FAIL | Findings S1–S4 prevent a complete field/consumer explanation. This is not a decision on the full recursive generated inventory or other configuration families. |
| A98-11 | Platform input-to-runtime precedence and capture paths | FAIL | S1 and S2 leave a policy winner/selection boundary unexplained; S3 leaves the external consumer boundary incomplete. Corrected adapter closure and timer/capture explanations are supported but cannot compensate for these failures. |

Reader and Quality decisions, recursive generated inventory, all global gates, full mutation suites, publication/rendered output and live operation remain UNPROVEN by this review. These scoped decisions are not full gate-ledger acceptance records.

## Material findings and required corrections

### S1 — Configured provider policy is not the selected-provider set

Page line 35 says capability resolution selects a provider “for each keyed capability.” The implementation validates every configured provider policy entry, but selects and enables a provider only when an enabled registration requires that capability. With a plain stage and only a valid `state.read` policy entry, original `prepareRuntime` returned an empty selected-provider map and no activated adapters. An invalid unused provider entry still failed with `REGISTRY_CAPABILITY_PROVIDER_INVALID`.

Authority: [global provider-policy validation](https://github.com/datrab/kubeclaw/blob/371b84654b877ec11a6b04d43f74e17e2e04edb3/skills/common/plugin-runtime/foundation/registry/capabilities.ts#L75-L94), [required-provider closure](https://github.com/datrab/kubeclaw/blob/371b84654b877ec11a6b04d43f74e17e2e04edb3/skills/common/plugin-runtime/foundation/registry/capabilities.ts#L149-L159), [separate validation and selection](https://github.com/datrab/kubeclaw/blob/371b84654b877ec11a6b04d43f74e17e2e04edb3/skills/common/plugin-runtime/foundation/registry/capabilities.ts#L176-L196).

Required correction: state that `providers` is an exact capability-to-adapter selection policy; every keyed entry must name a known capability and an installed adapter declaring it, including unused entries. Explain that only required selections enter the effective provider/enabled set. A mapping alone does not start the adapter. Give the exact missing/ambiguous/invalid selection distinctions or link the canonical explanation beside the field. Retain the corrected recursive activation section.

Proof: `probe-first-run.log`, case `configured-provider-is-validated-but-unused-provider-is-not-selected`; `recursive-provider-adapters-start-with-empty-activeAdapters` supplies the positive required-provider path.

### S2 — The external source key and trust precedence are absent

Page lines 47–56 give digest-map shape, but line 51 calls the key an “external source ID” without its implemented form. Discovery looks up exactly `local:<canonical package root>`, not a package/registration ID, installation-root string or arbitrary publisher identifier. A schema-valid allowlist keyed by `fresh.probe` was rejected as untrusted; the identical digest under the canonical `local:` key was admitted. Built-in root membership wins before either external map; source-digest approval then wins before an attestation mapping. Both external paths retain `isolated_external` trust scope.

Authority: [trust reference, precedence and scopes](https://github.com/datrab/kubeclaw/blob/371b84654b877ec11a6b04d43f74e17e2e04edb3/skills/common/plugin-runtime/foundation/registry/discovery.ts#L77-L103), [canonical package root before trust lookup](https://github.com/datrab/kubeclaw/blob/371b84654b877ec11a6b04d43f74e17e2e04edb3/skills/common/plugin-runtime/foundation/registry/discovery.ts#L119-L136), [digest input](https://github.com/datrab/kubeclaw/blob/371b84654b877ec11a6b04d43f74e17e2e04edb3/skills/common/plugin-runtime/foundation/registry/digest.ts#L6-L27).

Required correction: explain the exact canonical `local:` key, what bytes the approved digest identifies, lookup order and resulting trust scope, with narrow discovery/digest authority. Explain that relocation changes this source reference and that listing a root as built-in bypasses the external-map decision. Keep approval origin as operator-owned; do not present this lookup as cryptographic verification of a newly supplied attestation.

Proof: `probe-first-run.log`, case `external-trust-exact-canonical-source-key-and-adapter-boundary`, including digest, exact source key, untrusted negative and successful digest/attestation paths.

### S3 — External trust admission does not make external adapters executable; optional isolation is conditional

Page lines 34, 40, 54–56 and 132–149 do not state the current execution restriction. An admitted external adapter still fails activation with `REGISTRY_ACTIVATION_FAILED` because a persistent isolated adapter runtime is unavailable. External stages/observers receive a wrapper at preparation; actual invocation requires a bounded context and a delegated cgroup root. Omitting `isolation` is schema-valid, but the cgroup consumer rejects its absence with `ISOLATION_CGROUP_REQUIRED`. Preparation of an external plain stage succeeded without invoking it; this was not evidence of external execution.

Authority: [external adapter rejection and stage/observer wrapper](https://github.com/datrab/kubeclaw/blob/371b84654b877ec11a6b04d43f74e17e2e04edb3/skills/common/plugin-runtime/foundation/registry/activation.ts#L55-L86), [invocation-time cgroup creation](https://github.com/datrab/kubeclaw/blob/371b84654b877ec11a6b04d43f74e17e2e04edb3/skills/common/plugin-runtime/foundation/isolation/runner.ts#L36-L40), [required root and delegation checks](https://github.com/datrab/kubeclaw/blob/371b84654b877ec11a6b04d43f74e17e2e04edb3/skills/common/plugin-runtime/foundation/isolation/cgroup.ts#L18-L25).

Required correction: describe these conditions beside `externalTrust`/`isolation` and link the existing canonical external execution/host-prerequisite explanation in `understand/plugin-runtime.md`. Give the stop rule: do not bypass isolation by adding external code to trusted built-in roots or importing it directly. State the unavailable external-adapter boundary, owner and later acceptance condition for the persistent isolated runtime. Distinguish admission/preparation from invocation and host readiness.

Proof: original `prepareRuntime` rejected the admitted synthetic external adapter; original `IsolationCgroup.create(undefined, 16777216)` rejected before filesystem mutation. Actual external invocation/cgroup enforcement was not run.

### S4 — Runtime conditions beyond the open platform envelope need an explicit path

Page lines 32–36, 91–101 and 184–196 omit concrete runtime conditions needed by a complete configuration reference. Distinct schema-valid root strings that resolve to the same directory fail discovery with `REGISTRY_PACKAGE_DUPLICATE`; a missing root fails `REGISTRY_ROOT_INVALID`. Grant policy cannot retain an entry for a disabled registration, even an empty entry: resolution fails `REGISTRY_CAPABILITY_UNREQUESTED`. Capability-specific constraints are checked as exact closed shapes by the consumer, despite the open platform grant envelope. An empty required constraint list fails `REGISTRY_CAPABILITY_CONSTRAINT_INVALID`.

Authority: [canonical root checks](https://github.com/datrab/kubeclaw/blob/371b84654b877ec11a6b04d43f74e17e2e04edb3/skills/common/plugin-runtime/foundation/registry/discovery.ts#L13-L23), [canonical alias rejection](https://github.com/datrab/kubeclaw/blob/371b84654b877ec11a6b04d43f74e17e2e04edb3/skills/common/plugin-runtime/foundation/registry/discovery.ts#L39-L55), [requested and disabled grant rejection](https://github.com/datrab/kubeclaw/blob/371b84654b877ec11a6b04d43f74e17e2e04edb3/skills/common/plugin-runtime/foundation/registry/capabilities.ts#L163-L201), [exact constraint keys and non-empty unique lists](https://github.com/datrab/kubeclaw/blob/371b84654b877ec11a6b04d43f74e17e2e04edb3/skills/common/plugin-runtime/foundation/registry/capability-vocabulary.ts#L128-L140).

Required correction: add the canonical-root condition and exact error/safe action, and distinguish open envelope from closed capability consumer validation. Link the capability catalogue and canonical grant validation rules beside `grants`; explain removal of grants together with actual disablement. These links can delegate detail without creating a second manual grant inventory.

Proof: `path-proof-first-run.log` and `probe-first-run.log` case `provider-grant-negatives-and-disabled-grant-rejection`.

## What the remainder of the page actually established

The source/schema review covered every platform property and its nested fixed structure; map families remain registration/capability-owned and do not imply that every possible installed plugin schema was reviewed.

| Page fields/claims | Independent result and boundary |
| --- | --- |
| Root closed object, required fields, version, strings, arrays, uniqueness | Matched exact platform schema; each required field was independently removed in a negative loader check. Closed-object, empty, duplicate and type/boundary negatives rejected. S4 adds runtime root constraints. |
| `externalTrust.allowedSourceDigests` and `verifiedAttestations` shape | Schema constraints are correct, including lowercase exact-length digests and non-empty unique allowlist arrays. S2/S3 concern interpretation and execution, not this shape. |
| `providers`, `grants` | Envelope types are correct. S1/S4 concern resolution and consumer constraints. |
| `adapters`, `activeAdapters`, `observers` | Corrected section lines 58–89 matches original preparation, closure, installed configuration validation, activation and startup. Supplying config alone does not enable; all configured IDs must exist; only enabled adapter configs are schema-checked. Known invalid disabled config remained latent; enabling it rejected. Observer config enabled its observer and recursively required adapters. No schema defaults were inserted into adapter configuration. |
| `isolation.cgroupRoot` and path resolution | Loader resolves it from the canonical platform filename, just like other path fields; deep freeze and filename symlink behavior were checked. S3 concerns invocation prerequisites. |
| `storageRoot` | Loader resolves one store root; `run-root.ts` selects run directories below `runs`; effects use run-local journals and global `resource-locks`; observer checkpoint/delivery records are run-local. No data move is implemented by loading a changed path. Durability/readiness and migration were not executed. |
| `shutdownTimeoutMs` | Required integer ≥1, no schema maximum; no fallback. Boundary and overflow accepted by loader. Original runtime overflow shutdown rejected after approximately 1.1 ms with Node's explicit 1 ms overflow warning. This does not measure the full 2,147,483,647 ms delay or prove work stopped. |
| Failed-start and invocation cleanup | The linked change-impact explanation agrees with original code. Failed-readiness teardown stayed pending after its abort signal until the injected shutdown was released; original failure then surfaced. Invocation cleanup rejected at its deadline while ignored work remained pending and was separately released. |
| `effectLockTtlMs` | Optional 60,000–86,400,000; absent loader result remains absent. Original `createAdapterRuntime`/coordinator/file-lock path captured 300,000 by default, retained it after a file edit and captured 60,000 after consumer recreation. Supplementary fixture dependency and first failure are disclosed below. Long-term renewal behavior/concurrency/recovery were not proven. |
| Issuer fields | Scalar/array/closed-object schema is accurate. `wait-request.ts` puts `orchestratorIssuerId` into core orchestrator wait `authorizedIssuer`; `validateSignal` checks that type/id. Administrative first admission authenticates and compares actor and the allowlist; exact already-recorded replay skips reauthentication. This was source inspection, not a full administrative/replay execution. |
| Recovery subset and capture | Original snapshot writer/package verifier preserved only providers/grants/adapters/activeAdapters/observers/optional isolation. Changed timeouts and issuer fields did not trigger that configuration comparison; changing even disabled adapter configuration did. The page's enumerated compared subset is accurate. Full recover/resume execution under changed inputs was not performed. |
| Minimal JSON example | Structurally complete against the exact schema. Its explicit assumptions prevent a general activation claim; no clean-reader/full-pipeline execution of this example was performed. |
| Sensitive values | Runtime-recorded config is not redacted; using secret references and avoiding raw credentials is supported. The recorded subset is not a complete copy of the platform file. No live secret resolution/redaction proof was claimed. |
| Remaining error rows and operation limits | Schema/config/stage-owner/recovery mismatch families match source. JSON parse/read/realpath failures occur before schema wrapping, and readiness/dependency/live effects remain distinct. S1–S4 require additional precise conditions. |

## Source pins, source freshness and historical executions

`source-link-audit.json` resolves every GitHub blob/range in the reviewed page. Every target is a regular Git blob, every range is ascending/in-bounds, and every linked source file has identical whole bytes at its historical linked revision and at candidate `371b846…`. None of these page source links uses the candidate revision itself. Byte equivalence supports the current source comparison; it does not change the revision of a historical execution or satisfy the final ledger's exact `reviewed_revision` link requirement by itself.

Page line 212 honestly labels its historical contract execution at `c8987b18b450bc27571d5037cb6ce3fb26e0cbd0`; this report does not relabel it as candidate execution. This reviewer separately executed the unchanged contract at the archive candidate and separately recorded its output. A final evidence ledger must use independently resolved candidate links and the actual new execution artifacts, while preserving historical execution identity in prose.

## Read scope

Fully read: `docs/blueprint/07-documentation-quality-standard.md` (entire standard), `docs/blueprint/AP09-acceptance-contract.md` (entire contract, including no averaging, exact evidence/reviewer requirements and all package gates); all of the candidate platform page; the complete platform schema and loader; registry `capabilities.ts`, `configuration.ts`, `activation.ts`, `discovery.ts`, `schema.ts`, `capability-vocabulary.ts`; `engine-runtime.ts`, `adapters.ts`, `adapter-startup.ts`, `adapter-support.ts`, `adapter-invocation-phase.ts`, `engine-snapshots.ts`, `effects/coordinator.ts`, `effects/durable-invocation.ts`, `telemetry/observers.ts`, `cli.ts`, `run-root.ts`, `lifecycle/wait-request.ts`, and `state/file-mutex.ts`; the existing platform configuration contract check.

Contextual reads: `configuration-precedence.md` lines 1–70 and 407–471; `configuration-change-impact.md` lines 1–175; relevant execution/recovery portions of `engine-run.ts` lines 1–100, administrative execution/authentication code in `engine-admin.ts`, invocation-time isolation `runner.ts` and `cgroup.ts`; manifest/stage/observer/adapter/pipeline definition schema regions; existing registry contract fixture construction; `plugin-runtime.md` trust/selection/grants/snapshot/external-activation sections and the capability catalogue introduction. Some wide investigation outputs were truncated; those were not counted as complete reads unless the file was fully available or the missing relevant tail was explicitly reread.

Catalogue context: exact CFG-002 entry from `docs/blueprint/generated/ap09-catalogue.json`: Owner `configuration owners`, target `docs/site/reference/pipeline-platform.md`, package AP09.8. Fixture context: the A98 gate table, static/execution binding search across `AP09-acceptance-fixtures.json` and config mutation constructor definitions. No static Reader/execution fixture in that file binds A98-10 or A98-11; their required primary verification does not become a general Reader task. This source proof is neither one of the full registered mutations nor a duplicate full mutation suite.

## Execution, failures and cleanup

Environment: Node `v24.21.0`, npm `11.19.0`; exact recorded dependency versions/selector paths in `environment.json` and `dependency-setup.json`. Workspace package selectors point to this archive's modules; existing third-party dependencies were selected read-only. No install, generation, main edit, commit, push, network connection or live cluster operation occurred.

| Actual command | Exit | Saved output and limit |
| --- | --- | --- |
| `git archive 371b84654b877ec11a6b04d43f74e17e2e04edb3 \| tar -x -C <private>/source` | 0 | Full archive extraction; subsequent `archive-inventory.json` validates original Git bytes. Not a generator or clean-install proof. |
| `node tests/verification/contracts/check-plugin-system-v2-platform-config.mjs` from private `source/` | 0 | `platform-contract.log`: `ok:true`. Local contract only. |
| `node probe.mjs` from private review directory | 0 | `probe-first-run.log`, `probe-results.json`: positive/negative original loader, prepareRuntime, AdapterRuntime, snapshot and cleanup observations. Synthetic packages and fault-injected adapter functions; no product-source replacement. |
| `node capture.mjs` | 1 | Preserved first failure in `capture-first-run.log`: original FileMutex calls hard-coded `/usr/bin/flock` with GNU `--timeout`; this environment's BusyBox flock rejects it. This is a real undeclared tool compatibility boundary for this attempted source proof. |
| `node flock-fixture-runner.mjs` | 0 | `capture-fixture-dependency-run.log`: explicit in-process child-process dependency translation from the exact GNU call to BusyBox exclusive nonblocking fd-3 lock, used only on isolated uncontended synthetic files. Original product files and constructors remained unchanged. This does not repair the product, implement GNU timeouts, or prove competing-lock behavior. |
| `node path-proof.mjs` | 0 | `path-proof-first-run.log`: canonical alias and missing-root negatives. |
| Python Git blob/range/byte verification | 0 | `source-link-audit.json`, `candidate-identity.json`, `archive-inventory.json`. Source proof only; no publication/renderer claims. |

Exploratory reads/searches also returned expected non-zero statuses when guessed filenames did not exist (`adapter-timeouts.ts`, registry `trust.ts`, lifecycle `decision-wait.ts`, execution `decision-recorder.ts`, a misplaced catalogue path), and when checking missing private archive dependencies before setup. The actual files were found and read; these were investigation failures, not suppressed successful checks or product tests.

All injected pending activation/shutdown/cleanup operations in completed probes were released. Original runtime/cleanup `finally` paths cleared their timers; original durable invocation cleared its renewal interval and released locks. The dependency instrumentation was restored in `finally`. No long timer, background operation or external effect is intentionally left active. Synthetic fixture files and immutable logs remain as evidence.

Not executed: full pipeline, full recover/resume/reopen, deployment/live adapters, external sandbox/cgroup enforcement, external service effects, long timer duration, real credential resolution, drift generators, recursive whole-inventory acceptance, global gates, registered mutation suite, publication build/render/layout/link/Reader/Quality checks. No probe or file count is used as acceptance evidence.

## Freeze release

The reviewed platform page remained byte-identical to candidate throughout this review. The unrelated in-progress root/API generator and generated inventory edits are not part of the candidate and were neither edited nor accepted. This report releases this Source review's page freeze after the report and artifact manifest are saved. Required corrections remain author work, followed by a new fresh-context Source review on the corrected immutable candidate; this reviewer does not self-accept those changes.
