# Independent complete Tool Source review — current known-reader binding

**Verdict: FAIL — two material findings, one coherent correction batch.** Reviewer `/root/known_reader_binding_complete_tool_source_fresh`; configured model `gpt-6.1-sol`, reasoning `medium`, explicit `fork_turns=none`. Configuration was communicated by the spawning parent; no separate backend attestation is claimed. This reviewer was neither correction author, Reader, Quality reviewer nor execution participant in a reader task. Repository access was read-only. All new writes are private evidence or synthetic fixtures; no inspected product program, generator, deployment, installation or publication was executed.

Repository `/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04`, observed final HEAD `ad312e3e4f15223809fadef90bd90e1f689ce941`, dirty controlled sources. All eight assigned byte sequences match `superseding-known-reader-key-source-qualification/freeze.json` before and after the independent checks. This is an exact working-tree Source decision, not a clean-commit or whole-checkout claim. Administrative matrix work and the separately owned developer handbook/fixture are outside this Tool review. No SourceDoc, ReaderDoc, Quality, AP98/package/global or complete AP09.7 approval is granted.

## Material findings

### R1 — recognizable executable wrappers still lose Python source

Owner: `scripts/docs-configuration-inventory.mjs:5057` (`pythonInterpreterIndex`), `:5072` (`pythonShellPrograms`), `:5235` (`pythonYamlPrograms`); actual receiver `charts/ops-pod/templates/workload.yaml:80`.

The wrapper selector recognizes only the exact tokens `env` and `sudo`. An executable absolute wrapper `/usr/bin/env` therefore does not reach the selected shell branch. Separately, `pythonShellPrograms` acquires Python commands but silently ignores a recognizable `sh -c` command whose literal body contains Python. YAML's outer shell branch passes that body to the shell parser, where its next shell invocation disappears.

Independent executable argv witnesses are retained without illustrative quoting ambiguity in `countercheck-results.json` and their complete YAML artifacts:

```text
/usr/bin/env sh -c <literal python3 -c body>
env sh -c <literal sh -c body containing python3 -c>
env sh -c <literal env sh -c body containing python3 -c>
```

All three actual synthetic native processes exit **0**, print `independent-observed`, and read `INDEPENDENT_WRAPPER_KEY`; the current production acquisition returns **[]** for each. The adjacent direct `env sh -c <Python body>` exits 0 natively and correctly discovers the exact key and YAML offset.

The independent read-only overlay replaces precisely the original readiness command in the entire actual workload source. The real command `node scripts/docs-configuration-inventory.mjs --check-environment-coverage-only` returns **0 / GREEN436** for all three hidden-reader mutations. Baseline and restored source also return 0/GREEN436. The direct supported wrapper sensitivity returns **1**, with `CONFIG_SEMANTIC_GAP`, the new key and actual workload source identity. These are complete actual receiving-source decisions, not parser-only results. Original session57755 was observed terminal0 after all six decisions.

Evidence: `counterchecks.mjs`, `countercheck-results.json`, three `*-full-workload.yaml` files, `receiving-overlay.mjs`, `run-receiving.mjs`, `receiving-results.json`, individual `receiving-*.log` files. Initial malformed private shell quoting produced native NameError and is preserved separately in `countercheck-initial-invalid-quoting.json`; it is excluded from semantic proof. The corrected literal argv executes successfully.

Necessary correction: preserve finite wrapper identity for recognizable absolute env/sudo commands and nested literal shell command bodies, or reject their unsupported custody explicitly at the receiving Source. No universal shell interpreter is requested. Keep script/module operands, passive recipe text, winning stdin and decoded offsets distinct.

### R2 — named-expression global/nonlocal writes erase known capability custody

Owner: `scripts/docs-configuration-inventory.mjs:5754` (`reject_external_capability_write`), `:5872` (`visit_NamedExpr`), with `:6029` (`analyze_function`) restoring the caller state. Actual receiver: complete `ops/pod/bootstrap.py`.

`visit_Assign` and `visit_AnnAssign` reject a known capability written through a global/nonlocal name. `visit_NamedExpr` visits and binds its value but omits that guard. A finite helper can therefore change the runtime module/closure getter while static helper analysis restores the old passive binding. The later known reader or annotation getter has no retained role and produces an empty inventory.

The minimal function-getter witness is legal Python:

```python
import os, annotationlib
getter = None
def setup():
    global getter
    (getter := annotationlib.get_annotations)
setup()
def f(x: "print(os.getenv('INDEPENDENT_WRAPPER_KEY'))"): pass
getter(f, eval_str=True)
```

Six independent native witnesses cover global getter transfer followed by function, class and method annotation evaluation; global direct getenv transfer; global environ mapping transfer; and nonlocal getter transfer in an active closure. Every native process exits **0**, prints `independent-observed`, and the production scanner returns **[]**. Their complete synthetic sources are retained. The adjacent ordinary assignment to the global getter executes the same native read and correctly rejects with `global or nonlocal environment authority write`.

Each of the six hidden-reader payloads is appended separately to the complete current bootstrap source through a read-only overlay. All six actual coverage gates return **0 / GREEN436**. The ordinary-assignment sensitivity returns **1**, with the intended external-write diagnostic and bootstrap source identity. Both original receiving sessions65433 and64407 were observed terminal0, with baseline/restored controls. All seven complete bootstrap copies compile legally under Python3.14; compile-only results are separate from synthetic native execution. No complete product bootstrap was executed.

Evidence: `python-countercheck-results.json`, seven synthetic `.py` files, seven `*-full-bootstrap.py` files, `independent-full-source-legality.json`, `python-receiving-overlay.mjs`, two driver files, `python-receiving-results.json`, `python-expanded-receiving-results.json`, individual receiving logs.

Necessary correction: subject named-expression writes to the same generic known-capability global/nonlocal guard before binding, including reader, mapping, annotation-reader and other transferred capabilities. Explicit rejection is sufficient; interprocedural mutation interpretation is unnecessary. Preserve ordinary local named expressions and passive foreign values.

## Individual F1–F10 decisions

The entire affected Python evaluator, YAML/argv/shell acquisition bodies and canonical module graph/qualification bodies were read. Changed classifier cycle handling and actual downstream receiving, provenance, normalization, selection and citation paths were assessed. Unchanged narrow claims use exact complete-body and dependency evidence, not former whole verdicts.

| Family | Verdict | Current complete assigned Source finding |
| --- | --- | --- |
| F1 function annotation identity/timing | FAIL | Original defining-module/active-closure, aliases, timing and direct getter evaluation retain their controls. R2 transfers the known getter through a global write and hides actual function string evaluation. |
| F2 class annotations/class-owned namespace | FAIL | Class bindings, base/metaclass protocols, future evaluation, metadata mutation and namespace constraints retain their individual behavior. R2 hides actual class getter evaluation. |
| F3 method annotation identity/timing | FAIL | Method identity/class-owned namespace and caller-shadow rules retain their controls. R2 hides actual method getter evaluation. |
| F4 Python argv mode | PASS | Finite admitted flags select the first real mode; script/module trailing operands remain passive, unknown modes reject. R1 concerns wrapper acquisition before this parser. |
| F5 executable YAML acquisition | FAIL | Original env-to-shell correction, command/args ancestry and decoded positions work. R1 leaves three actual executable wrapper forms undiscovered and unrejected. |
| F6 recognizable acquisition/capability boundaries | FAIL | Known reader/getter `__call__`, mapping protocols, kwargs missing-key and reflected dunder/namespace paths now discover or reject. R2 still erases a recognizable known capability through an external named-expression write. |
| F7 os star imports | PASS | Explicit receiving rejection remains in the entire current evaluator; independent retained control passes. |
| F8 returned/passed/default/container capability custody | FAIL | Known getter is now included in transferred/callable roles; helper return/argument/default/container escapes reject. R2 loses the same known getter at a global/nonlocal mutation boundary. |
| F9 immutable static receiving Source/public caller authority | PASS | Complete PV Source anchor, independent recipe anchor and same graph for ordinary/PV callers remain enforced. Current intrinsic/self-export public acquisitions all reject unqualified PV callers. |
| F10 exact captured Codex bearer authority | PASS | Exact complete shell, selected Codex container, unique readOnly bearer mount, volume/Secret/mode, bootstrap producer, deploy caller and Docker COPY remain bound. Independent eleven scoped controls pass; no live credential/authentication approval. |

## Every assigned receiving/default/consumer/qualification facet

| Facet | Verdict | Evidence and practical boundary |
| --- | --- | --- |
| Syntax-only parsing/passive text/source coordinates | PASS | Actual AST parser uses isolated Python and maps UTF-8 columns to UTF-16. Native witnesses execute separate synthetic programs. Comments, strings, docstrings, Unicode and foreign objects retain controls. |
| Imports/aliases/static keys/finite joins | PASS | Whole evaluator and independent39 controls retain finite bindings, unresolved alternatives, rebindings, empty/nonempty loops and shadows. R2 external writes are separately failed. |
| Owning-module and active-closure namespaces | FAIL | Ordinary callee lexical ownership remains correct; R2 loses actual external mutation in both module and nonlocal closure states. |
| Direct annotation evaluation/metadata mutation | PASS | Existing direct function/class/method/getter rules, future/string distinction, class protocols, mutations and unresolved namespace/format rejection remain valid individually. Whole getter-custody family fails under R2. |
| Known reflected/protocol acquisitions/kwargs | PASS | Whole new predicates and actual current author27 negatives cover globals/dictionary/protocol/reflected-getter and missing-key kwargs; finite explicit keys remain supported. R2 is a separate write path. |
| Helper capability mutation/transfer | FAIL | R2; ordinary return/argument/default/container paths reject but NamedExpr external writes do not. |
| Exact subprocess snapshot producer and forwarding | PASS | Whole lexical receiver proof, unconditional imports, global/nonlocal writes, parameters, opaque/decorated/bound receivers, writes/deletes/joins and exact env keyword slot retain Source semantics; current snapshot-positive receiver and independent controls pass. |
| Shell/YAML argv, wrappers, heredoc/stdin/passive operands | FAIL | R1. Original mode, winning fd0, redirection, quoted/unexpanded heredoc, regular repository stdin and passive operands remain narrow valid facts. |
| Ordinary unqualified CommonJS closure | PASS | Current direct/literal/alias/computed/bind/call/apply forms enter canonical closure independently of metadata. Runtime operands, foreign receiver, unknown member, container/helper escapes reject. Foreign module bindings/passive exports remain data. Independent four tests execute61 native observations and actual API/role/product consumers. |
| Own package exact root/subpath/scoped exports | PASS | Exact declared exports canonically resolve; retarget/removal/cache/containment bind package bytes. Native conditional/array/wildcard acquisitions explicitly reject. No general Node resolver claim. |
| Canonical public entry/emitter/caller reachability/cache | PASS | Complete graph and public context bodies preserve canonical relative imports, current bridge bytes, alias paths and entry digest; actual selection re-discovers outputs and checks reachability. Unchanged reference/product bodies and current Root consumers bind their evidence. |
| Non-alias shape/recursive selected product scope/defaults | PASS | Provenance is conditional and resets before owned schema fallback. Recursive authored fields, product-owned contracts, selected receiver omissions/default materialization and symbolic inherited fields remain preserved. Unused upstream alternatives are not expanded. |
| Actual reference citation provenance | PASS | Renderer validates current contexts/selection and cites canonical actual emitter line while displaying public entry. Exact unchanged complete file plus current Root citation consumers; no symlink blob citation claim. |
| Immutable PV static Source qualification | PASS | Exact complete body remains `02d9af…`; mutable Source/hash/recipe repair cannot extend it. Native ten PV acquisitions in independent current tests encounter the real public-caller rejection. |
| Finite unresolved semantic recipes/source binding | PASS | Current independent actual qualification:56 Sources,27 operations,841 canonical closure Sources,837 executable Sources,1720 edges; full facts including inputKey/dependencies equal the current sealed graph. Current/withdrawn/new-publisher/restored source-binding controls are rehashed actual author evidence, not independent execution. |
| Diagnostic three sinks/full producer Source anchor | PASS | Entire current checker input/error-collection/loop/sink body read; exact complete Source guard and current independent9 controls reject changed collection/publisher/refreshed tuple/line/facts/sink while discovering ordinary new outputs. |
| Native corpus/capture role exclusions | PASS | Two exact native tests, package commands and full Source/caller dependencies remain pinned; qualification denies public reachability. Only exact reviewed authorities are excluded. No real PostgreSQL/browser suite execution. |
| OPS bootstrap precedence/file decoding/order/partial effects | PASS | Complete bootstrap and deploy caller read. Nonempty untrimmed path selector, Path.read_text decoding, strip-only credential content, empty/missing/unreadable/invalid path behavior, fixed names/keys, bearer/pull before GitHub before Tailscale and earlier effects match Source and Root OPS9 contract execution. |
| Supervisor child forwarding and shell semantics | PASS | Whole supervisor copies env and strips token, length-checks and forwards exact subprocess env; shell command substitution removes trailing newlines then length-checks/exports. kubectl exec has separate environment. Captured Source authority is exact. |
| Whole Secret object copies/grants/projections | PASS | Actual provider normalization/request, runtime allowlist/manifest/lease path, controller copySecrets/sanitizeSecret and separate ensureNamespaceAccess read. Copies retain approved Secret object data with metadata sanitation; grants and admitted manifest projections are separate permissions. Exact dependencies unchanged. |
| Current test-corpus retention | PASS | Actual current Root285 terminal0 and37 before/after/current inputs/log digest independently verified. Current author63/125 native observations and27 receiving decisions have complete terminal receipts. These are retention evidence, not semantic approval. |
| New recognizable receiving consumers must discover or reject | FAIL | Nine actual receiving mutations remain GREEN436 under R1/R2. Green corpus totals cannot offset these failures. |

## Individual catalogue/gate Tool Source facets

Quality07, the AP09 contract, execution plan, preregistered fixtures and assigned catalogue records govern this decision. The rows are assigned Tool Source facets only; none accepts the full page, reader task, package or gate.

| ID | Verdict | Assigned Source reason |
| --- | --- | --- |
| CFG-010 | FAIL | Codex/OPS actual readiness acquisition remains incomplete under R1; actual getter effective-value custody under R2. |
| CFG-011 | FAIL | New environment consumers vanish under R1/R2. |
| CFG-013 | FAIL | Actual getter/module/closure effective value is lost under R2. |
| CFG-015 | FAIL | Recognizable wrapper/external capability paths receive no required diagnostic. |
| CFG-018 | FAIL | Supported receiving/search-space completeness fails under R1/R2; selected API/default scope separately passes. |
| OPR-003 | PASS | Assigned OPS deploy/bootstrap ordering and validation-before-effects Source facet; no full install/live acceptance. |
| OPR-006 | PASS | Assigned diagnostic Source and three-sink exclusion remains qualified. |
| OPR-008 | PASS | Assigned credential selector/decoding/update/ordering/partial-effects Source facet. |
| REF-003 | FAIL | Environment/configuration acquisition under R1/R2. |
| REF-004 | PASS | Assigned canonical API producer/schema/default/consumer discovery; intrinsic and self-reference corrections now retain ordinary outputs or reject unsupported acquisition. |
| REF-012 | FAIL | Assigned environment/Secret receiving completeness under R1/R2; object-copy/grant distinctions remain valid. |
| A98-10 | FAIL | Recursive configuration Source discovery hides actual new environment consumers. |
| A98-11 | FAIL | Actual getter/module/closure custody is incomplete. |
| A98-14 | FAIL | New environment mutations remain green at actual receivers; full preregistered84 mutation package was not run. |
| A911-01 | FAIL | Declared executable/known-capability parser domain silently drops recognizable Sources. |
| A911-02 | FAIL | Environment consumer/Source completeness fails; recursive selected API facets pass individually. |
| A911-08 | PASS | Assigned read-only coverage mode leaves product Sources unchanged; no generator determinism/clean-checkout approval. |
| A911-12 | FAIL | Independent complete assigned Source review finds two material gaps; no maintainer/global reproduction approval. |
| A912-01 | PASS | Assigned internal diagnostic output Source boundary only; publication content/Reader acceptance remains separate. |

## Evidence attribution, exact reuse and limits

Independently executed current evidence:

- Eleven new separate synthetic native observations, all exit0: four wrapper argv observations and seven Python capability-write observations. Nine expose hidden readers; two are adjacent sensitivity controls.
- Seventeen actual complete receiving decisions: nine false GREEN436, two intended Source-identity negatives, six complete baseline/restored positives. Three original driver handles were observed to terminal. Seven full Python copies compile legally without executing the product program.
- Thirty-nine retained finite semantic controls, eleven captured-bearer controls and nine full diagnostic controls, all matching expected outcomes and terminal0. They were copied into this new evidence directory; no previous immutable artifact was overwritten.
- Four current production publication tests, terminal0,4 PASS/zero fail/skip, with61 actual synthetic native Node observations, all exit0. Actual ordinary API/role/product consumers and protected PV callers are asserted in these tests. This is independent execution of existing tests, not authorship or whole acceptance.
- Independent current canonical graph/qualification observation and exact complete comparison against the current author graph, not only matching counts.

Read and independently rehashed retained evidence: prior complete FAIL5 bundle94 artifacts; current scanner author241; current superseding API rebind32; historical API author49. All416 regular artifacts match their immutable manifests. Their historical outcomes retain original inputs. The old fdb Root284 and former38/legalfuture2 receipts are not promoted to current whole approval. The two illegal future placements remain parse-only historical failures. Current author63 unit tests contain125 native observations:124 exit0 and one retained classmethod exit1 whose read occurs before its expected failure. Current author27 actual receivers have observed terminal0:7 positives including4 complete/restored436,20 intended negatives. All21 complete Python sources have legal compile-only receipts. The newly found counterexamples supersede any inference of complete receiving approval.

Current Root full eleven-suite execution has actual end receipt `2026-10-12T10:34:19.798Z`, exit0,285 PASS/zero fail/skip. ResultSHA `1f838977c6a168263e5fd4afeec03b91ca23fb9ad8c3a2bff411e1dd4d2379a8`; logSHA `6187dd10929ffc0e3e1bed38956ce13cdacc6822c5d248507d1352203d8cef5b`. The37 recorded inputs are identical before/after/current. This remains Root execution evidence. No green total replaces R1/R2 semantic receiving failures.

Exact difference proof: current933 sealed author inputs match; comparison of the prior5774 existing inputs changes precisely six tool/test files plus the administrative matrix. This comparison does not prove absence of newly added unrelated files. Of185 complete named scanner/discovery functions previously individually assessed,182 are byte-identical; precisely pythonYamlPrograms, pythonEnvironmentReads and documentationModuleGraph changed, and their complete current bodies were read. The classifier reconstructs exactly to its prior complete Source by removing only the klassOf cycle guard; its changed complete function/callers were assessed. Product-scope and reference files remain whole-byte-identical to the previous independently reviewed complete bodies; their actual current downstream consumer/citation paths were read. Unchanged native/shell/Helm/Go/transformed/infrastructure/external facts are reused only with complete-body and dependency equality. No former whole PASS or FAIL is inherited as the current decision.

Linux workspace; Node24.21.0/Python3.14.8. Existing private Go path was supplied only for gate compatibility; no installation occurred. A private evidence-status extraction initially assumed every native group had a `results` key and exited1; corrected recursive extraction records actual125/124/1. This setup failure is not counted as a successful semantic check. The current unused historical non-API registry operation audit failure remains its separately scoped housekeeping result; no repair or blanket role exemption was introduced.

Not executed: generators/build/publication/install, full preregistered mutation package, real target-image/cluster/deployment/authentication, PostgreSQL/browser/cgroup/Tailscale/SPIFFE or live product acceptance. No arbitrary universal interpreter/resolver is required or certified. R1/R2 need one coherent correction batch, exact Source qualification and fresh complete independent review. The final input guard and artifact manifest seal this report and every retained private artifact.

**Final complete assigned Tool Source verdict: FAIL.**
