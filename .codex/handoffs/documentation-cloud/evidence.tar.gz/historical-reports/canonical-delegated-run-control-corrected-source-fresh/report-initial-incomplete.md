# Independent fresh Source review — canonical run-control family

Verdict: **FAIL for the assigned frozen five-page family.** One concrete command-location defect is confirmed. The canonical raw-preservation, signal/recovery storage-order and retention correction passes the bounded Source claims inspected below. **Complete five-page semantic closure has not been established**: generated dependency-owner assertions and non-run-control diagnosis/deployment claims remain explicitly incomplete. This report must not be used as complete OPR-004, A98-02, A98-05, A98-13, Reader, Quality, deployment, package, references or global acceptance.

Reviewer: `/root/canonical_delegated_run_control_corrected_source_fresh`, independently assigned fresh read-only Source reviewer. No author changes, repository edits, installations, live pipelines, mutable real journals, cluster commands, database connections, image launches, destructive operations, communication outside the review team or generator writes occurred. Private safe fixtures and retained outputs were created here. The cloud runtime skill was read; no callable environment-status tool was available. No managed-network work occurred.

Requested starting HEAD: `b9f0228a44fc7ac71d90747bed9bb4cefdf83381`, branch `docs/documentation-overhaul`. Before/after guards cover 5,594 tracked regular files. Final guard observed root's concurrent HEAD `8f39cf5a881e458173690e82b0b99b141fc70ef0`; only `docs/blueprint/documentation-completion-matrix.json` changed bytes during this review. All five frozen pages and implementation/generator authority files used here remained identical. The existing dirty install/worker-trust/scanner/API inventory work is outside the frozen reviewed candidate and earns no verdict. See `guard-before.json` and `guard-after.json`.

## Frozen subject

| Page | SHA-256 |
| --- | --- |
| docs/site/use/operate.md | aa713a0462cf8b4781831c2021f3f96fa4e4a263806c27350247d7aa5366f745 |
| docs/site/use/recovery.md | c026a1c3acc992c12ae8e5351aee22c87cdba2a56087496ed423a13c027243fb |
| docs/site/use/diagnose.md | 5437f53eb5ed3c1ff1911efe33fc37da82f4a6af4374b51fabffe30e9a0e10d8 |
| docs/site/use/plugins.md | 1d931d0bd9eb5b9d32a331f8e6a9727b17518c68717002232fe7c3d5765205ea |
| docs/site/use/workflows/buster-suite.md | 719d6506e157a1509776bbd27ea530b16e961f25b18f46ee9dabb16a8954b101 |

The task's shortened workflows path resolves to `docs/site/use/workflows/buster-suite.md`; there is no `docs/site/workflows/buster-suite.md`.

## Material finding BUST-SRC-01 — FAIL

Published location: **docs/site/use/workflows/buster-suite.md:184–190**. The production procedure says to start `npm run pipeline` **from the project repository**. The supported project descriptor can select a separate project repository, which need not contain the Nova npm script. This conflicts with the page's earlier production-location boundary and the real command owner.

Authority: `package.json:42` defines `pipeline` as `node skills/nova/pipeline.ts`; `skills/nova/pipeline.ts:1–14` loads the Nova project dispatcher; `skills/nova/project/cli.ts:47–50` separately checks the descriptor's arbitrary `project.repositoryRoot` using `git -C`. The npm script belongs to the original Nova/KubeClaw checkout. Checking the selected project's clean HEAD does not make that project's directory the command location.

Safe private reproduction: a separate project package with no pipeline script ran the exact npm command shape and exited 1 with `Missing script: "pipeline"`, before any dispatcher or platform/journal access. `project-location-negative.json` records the actual output and status. This is an execution-location Source contradiction, not a deployed task result.

Corrective action: say to run compile/start/audit/recovery commands from the original Nova repository/installation; separately require the selected project repository's committed HEAD to equal baseRevision and its worktree to be clean. Do not require every arbitrary project to add a Nova npm script. Recheck the corrected complete family at its new frozen bytes. Owner: Buster workflow/documentation and Nova CLI maintainers. Applicable facets: A98-02 execution location and exact action; A98-13 discoverable prerequisites/commands. This family contribution to OPR-004 is FAIL; it does not imply that cancellation documentation failed.

## Applicable requirement and facet decisions

The documentation quality standard's Operate contract, Source-evidence rules and truthful-status boundary were read. AP09 acceptance contract A98-02/05/13 and OPR-004/005 catalogue/matrix entries were inspected; fixtures identify the required deployment trio separately. No claim of a complete semantic reading of every unrelated execution-plan/catalogue/fixture requirement is made.

| Domain or facet | Source result | Exact proof / limit |
| --- | --- | --- |
| OPR-004 canonical CLI forms and run identity | PASS, bounded | Core/project dispatcher bodies read; project compile refuses overwrite; project signal derives original identity; explicit graph signal needs run-id; recover/signal conflicts and succeeded-only zero exits match. Buster execution-location contribution fails separately. |
| OPR-004 original identity and fresh captures before audit/recover/resume, including wrong/repeated signals | PASS, bounded | operate Inspect/Approve/Recover/Safe Retry sections explicitly require original platform/run/project/graph/package/configuration, stopped writers, new run+owned adapter copies, strict copied-journal parsing and stop on unknown ownership/outcome. |
| OPR-004 after each accepted/rejected/failed/lost-response result before next audit | PASS, bounded | operate:573–598 and recovery after-attempt sequence require renewed ownership/adapter fence, new captures, retained actual output/exit or `not observed`, and final correlated audit; previous capture cannot authorize later audit. |
| OPR-004 strict-copy failure and original bytes before authorized repair | PASS, bounded | Exact helper writes verified manifest before parsing; retains partial/corrupt bytes on rejection; stop precedes ordinary audit. Owner repair requires original raw evidence, external-effect reconciliation and actual-change record. |
| OPR-004 durable owner-selected evidence/retention | PASS, bounded | Existing private durable RUN_CONTROL_EVIDENCE_ROOT outside stores is a mandatory owner prerequisite; no automatic/tmp fallback; digest cannot authorize deletion, protected captures retain exact signal and raw bytes through recorded final disposition. |
| A98-05 closed envelope/authority/replay/order | PASS, bounded | engine-run:82–121, engine-snapshots validateSignal, schema and pure validator probes: envelope validation precedes accepted signal/wait.resolved, but run-lock/admin/event FileJournal effects precede rejection. Unsigned issuer is self-asserted. Identical signal storage is a no-op; ordinary post-resolution replay is stale/terminal before storage no-op. |
| A98-05 restart and effect safety | PASS, bounded | recoverPipeline opens journals/verifies graph/packages, rejects terminal/wait/cooldown; effect-recovery prevents accepted unresolved effects and interrupted external continuation; source error strings/table prefixes agree. Observer reconciliation can precede blocked return. |
| OPR-005 cancellation boundary | PASS, bounded Source | Neither CLI exposes cancel. Internal runner abort is separate; process containment cannot assert durable cancelled. No active audit/non-mutating live CLI is invented. Complete deployment cancellation proof absent. |
| A98-02/13 plugin activation/drain run-control entries | PASS, bounded | Current starter admits dependency ordering; failed-readiness cleanup can remain pending before outer rollback; drain keeps plugin/dependencies until terminal pinned runs. Active/unknown ownership stops audit. |
| A98-02/13 Pipeline State Recovery entry | PASS, bounded | Complete restore point, writer fence, new raw run+adapter copies, strict inspection, reconciliation, canonical recovery/final audit and retained repair changes agree. |
| A98-02/13 diagnosis run-control entries | PASS, bounded | Durable Run Inspection, Redis before/after audits and Git fault/success audits use canonical helper/copies/strict stop. These reads do not approve all diagnosis fault/consumer semantics. |
| A98-02/13 Buster healthy terminal-before-audit | PASS, bounded | Deployment exercise requires returned terminal succeeded before capture; no synthetic wait signal/active interruption replaces healthy proof; adapter/ownership failure leaves exercise incomplete. |
| A98-02 family command location | FAIL | BUST-SRC-01 above. |
| Generated operator matrix mechanical enumeration/joins | PASS, mechanical only | 51 actual manifests, 70 actual registrations, host/role inclusion/required/provided facts independently joined; every registration present once; zero generator diagnostics; output equals frozen block after only revision-link normalization. |
| Generated matrix exhaustive independent semantic owner/endpoint/secret/failure/preflight claims | FAIL — incomplete proof | Generator and qualification algorithms inspected, but zero diagnostics and tokens/source pins do not prove every rendered claim. See remaining domain MATRIX-SEM below. |
| Current LiteLLM recovery/native boundaries | PASS, carried scoped Source evidence plus direct source inspection | Exact unchanged recovery prefix and independently sealed prior proof inspected; no native media PASS or isolated app recovery invented. |
| Current Prism group/latest/proof boundary | PASS, bounded direct source inspection | prism-backup.sh full body and backup chart read: DB first then immutable artifact superset, latest independently selected, per-command shared lock, same-server temporary DB proof prints DB not group, no external restore/cutover claim. Live/native success remains unexecuted. |
| Whole OPR-004 | FAIL / not closed | Concrete family defect and incomplete semantic domains. |
| Whole OPR-005 | Not globally awarded | Bounded cancellation Source claims pass; this report is not a full-catalogue or deployment review. |
| Whole A98-02 / A98-13 | FAIL / not closed | Family command-location defect and incomplete complete-family review. |
| Whole A98-05 | Not awarded | Bounded Source signal/recovery claims pass; complete assigned-family proof and independent required deployment receipts absent. |

## Checks actually performed

`exact-helper.bash` contains the unchanged published Bash function. It was executed only against new private fixture stores with no external writers. `helper-results.json`: valid complete copy exit0; second invocation produces a different capture directory; partial final record exit1 after retaining exact raw bytes+manifest; corrupt sequence record exit1 after retaining raw bytes+manifest; symlink exit1; absent evidence-root exit1 without fallback. Source bytes unchanged for every case. Copies are consistency proof only under the required writer-fence precondition; they do not prove external receipts.

`source-semantics-results.json`: pure parser rejects incomplete/empty/sequence/previous-hash/hash cases; exact source validateSignal accepts one schema-valid matching signal and rejects unknown extra field, wrong issuer, stale issue time, wrong type and expiry. No durable signal/recovery execution was performed by these pure tests.

A private actual FileJournal physical-mutation experiment stopped at **FILE_MUTEX_ACQUIRE_FAILED**, because `/usr/bin/flock` here is BusyBox and rejects GNU `--timeout`. The constructor had created its private append-lock before that failure. No physical tail-repair result is claimed; source inspection proves ordering, and operate's GNU flock precondition is truthful. No system flock replacement or translated fake was used to turn that environment failure into a product PASS.

Read-only generator commands `operator-matrix` and `dependency-report` were inspected before execution and wrote stdout only here; no `generate`, `build` or repository mutation command ran. `independent-matrix-joins.json` independently discovers the actual manifests/role files, compares required/provided capabilities, exact registration identities/counts and host/role membership. `matrix-normalized.diff` is empty: only historical/current link revision text differs. Currentness and mechanical rows are not full semantic approval.

## Existing independent proof inspected and scoped reuse

The fresh readonly LiteLLM review's actual report's scoped conclusions and claim table, described probe limits, input hashes and seal were inspected. Report SHA matches its seal. 27/31 recorded repository inputs remain identical; changed recovery/install/task records cannot inherit blanket PASS. **The entire current recovery prefix before Pipeline State Recovery exactly equals that review's frozen prefix**, SHA-256 `07020c76809baa44320e34ef04546421bcf6f8d2d45a6c924dc4d45e17ba985c`. Current postgresql-recovery.sh and Prism backup/chart bodies were read directly. Prior guard probes remain synthetic; the actual native-copy attempt was BLOCKED by worker tools. That BLOCKED result remains BLOCKED, never native media acceptance.

The memory-state fresh independent report's report's current-claim table excerpt, described probe limits, input hashes and seal were inspected. Report SHA matches its seal. 19/21 repository inputs remain identical; diagnose/install changed. The **entire LiteLLM Upstream Timeout section** exactly equals its frozen reviewed section, SHA-256 `9d1f2b75038c231d3432520dc8819a3b289f5028f34221bfa2b01af617dcbea1`. Scoped unchanged Source conclusions are supported by that independent report's inspected scope and byte equality; its whole proof was not independently rerun here; changed general/run-control sections were re-inspected here, and moving install remains outside this acceptance. Details: `prior-review-reuse.json`, `prior-input-current-comparisons.json`.

The older selected-database report remains historical FAIL for its universal no-retention-scheduler claim; the later retention report and readonly review explicitly supersede only their own corrected inspected claim scope. Old status alone was never reused. No global DAT-006/INF-012 gate is awarded.

## Incomplete semantic domains and exact remaining proof

**MATRIX-SEM:** independently evaluate all 70 rendered registration rows' actual service, selected endpoint/config branch, secret/env projection and precedence, data-owner/lifetime, preflight/failure/timeout/cancellation claims against their actual invocation closure and qualified runtime owners. Unique owner groups include Buster HTTP/registry-health, build/container registry, fixture/runtime-security controller, exposure/Tailscale, command/sandbox, Axe/visual/Lighthouse/Playwright, security scanner/cache/auth, host Ops MCP, OpenClaw tool/hooks/diagnostics, local tokenizer/YAML, Git/lint and shared durable-store/secret/adapters. The direct manifests and role/capability joins have been checked; they cannot substitute for these assertions. Configuration semantic inventory joins/conditional consumer prose also need independent claim-level approval. Existing evidence is `dependency-facts-current.json`, generator/qualification sources and exact normalized block; owner: plugin/runtime maintainers and independent Source reviewer. No full matrix PASS is issued.

**DIAG-FAMILY-SEM:** full end-consumer/owner/rollback/cleanup semantic review of diagnosis controlled Prism/LiteLLM database, registry/BuildKit, Tailscale and Git failure procedures, including their deployed preflight producers, is not complete here. The entire unchanged LiteLLM memory section carries inspected independent Source proof; run-control audit-entry portions were inspected directly. Remaining producer/controller/actual fault-source claims need complete proof, not only Bash syntax or code/link presence. Owner: corresponding component maintainers and independent Source reviewer.

**BUSTER-FAMILY-SEM:** besides confirmed location failure and inspected terminal/audit boundary, entire suite decision/evidence-import, provider chain, cleanup/retention and large-result authority claims require complete independent source closure. No local vertical proof was run and no live result is claimed. Owner: Buster/Nova maintainers and independent Source reviewer.

**CONTRACT-FULLREAD:** relevant quality/AP09/catalogue facets were derived and inspected, but complete execution-plan and acceptance-fixture source reading plus every applicable mapped facet has not been proved by this report. No full-assignment PASS may be inferred from its bounded facet table.

Required deployment evidence stays separately open: **EXEC-WAIT-RESUME**, **EXEC-CANCELLATION**, **EXEC-RESTART-RECOVERY** require registered deployment inputs, actual output/status, before/after original identities and raw captures, causal lifecycle/effect/receipt evidence, and final retained decision. Pure validators/helper tests are not deployment receipts. Neither the recommended-live-execution documentation policy nor a local fixture waives this registered execution trio's evidence class.

Full-reference check's three missing generated Helm API anchors remain open per the parent scope; no full refs check or reference acceptance was claimed here. Reader/Quality and dirty installation/worker-trust/scanner/global scopes are excluded. This report therefore gives a material FAIL and precise unfinished proof domains, not an abbreviated all-assignment PASS.
