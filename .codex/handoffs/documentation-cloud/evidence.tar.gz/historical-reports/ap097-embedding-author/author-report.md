# Embedding documentation author report

Role: author, not independent reviewer. Repository revision at report: ade38433f2a35ba19d95faf83d29ccd20221799d.
Authorized edits: platform-and-operations.md and directly related embedding/trace prose in communication.md. Root's existing shared Ops token-volume correction is preserved in the latter diff; this author did not originate it. No commits, pushes, product changes, or files outside this authorized documentation scope were changed by this author in the repository.

Read: complete documentation quality standard; A97-03 acceptance contract; all 53 AP09.7 catalogue entries; both affected page mechanisms; chart gateway settings, selected model configuration, runtime image pins, actual pinned OpenClaw adapter, memory-manager retry/timeout/index paths, HTTP/vector readers. Official raw files independently downloaded where needed; remote-http.ts and provider-http-errors.ts additionally inspected from reviewer's frozen cache and copied into this evidence directory. Source commit: 3a9d69db306cd7f081e06254cb89c4bcc14a7107. Source hashes: source-hashes.sha256.

Changes: replaces unknown-client boundary with selected OpenAI-compatible POST/auth shape; input estimate versus body ceiling distinction; 16 MiB response and 30-second body-idle ceiling; 8 KiB/1000-character error preview; vector count, coordinate, and index validation; 60-second query and 10-minute inline document watchdogs; per-query/index retry budgets and error-message classification; query cancellation versus index retry cancellation limitation; recursive splitting and disabled provider batch-job distinction; terminal memory error versus owner authority; operator recovery proof and explicit source/live/image attestation limits. Communication matrix points to canonical section and gives the selected bounds. Showcase wording now says the reference describes dependencies, without implying an executed trace.

Checks: git diff --check PASS. Local Markdown target/heading checks PASS (platform 9, communication 4). All 23 new pinned upstream file/line ranges checked against full fixed-commit tree and local source lengths. Semantic line ranges manually inspected. No broad tool suite, upstream runtime tests, live provider request, outage exercise, joined harness, or renderer build run. An initial line-range check caught a chunk-limit citation past EOF; corrected to L18-L54 and repeated successfully. One initial diff-check invocation ran from the environment CWD outside the repository; rerun from the repository passed.

Controlled-language method: project STE principles, manual author edit; preserves identifiers, defines embedding/watchdog/jitter, separates source mechanisms from operator instructions. No formal ASD-STE100 certification claim.

Remaining gaps: independent full-scope source/readability review; provider deployment and authenticated route proof; exact image/source attestation; live timeout/cancellation/error/recovery checks; external provider quotas and gateways' own selected-image limits remain outside this client-source inspection. No A97-03 or package acceptance claimed.

File hashes:
- /home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04/docs/site/understand/platform-and-operations.md: `78e82acb5ddaa68ec22a9fdc6cb9829009238615e3f801c1a7490541e88903be`
- /home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04/docs/site/understand/communication.md: `2268c1f4784d8685e385df225c5234e8556986f65f8b2cf1a7dd003aae9971c6`
