# Recovery page author report

Owned write scope: `docs/site/use/recovery.md` only. Private evidence files are outside the repository. No commit, push, generation, installation, cluster command, provider action, or credential access was performed. Other writers' changes were left untouched.

Initial source/documentation HEAD: `8f10f6c8d1ae274efc1493cba739bec95fe833a1`. Final guard HEAD: `4d3068465a2e202d2d5073b77e9273c308497995` (concurrent parent change). Final page SHA-256: `9f0652adb9c2219b5f36f30e7d841cac32a481165fe7712c05f8d05e212754b1`.

## Scope examined

The whole canonical recovery page was read, including backup inventory and RPO/RTO, routine six-step backup, Prism group mechanism, single-service qualification, LiteLLM backup/export/offline verifier/native boundary, Prism latest selection and database smoke, Nova raw preservation and interruption recovery, host/cluster loss, administrative access, application verification, failures, rollback and retained evidence. Quality standard 07, the acceptance contract (especially A98-01/02/07/13), OPR-007 catalogue record and operator fixtures 02/03 were examined. This is author work for that page, not independent acceptance or a global documentation verdict.

Primary authorities inspected: complete Prism backup script/chart/defaults/test and artifact store; PostgreSQL recovery script/render/native harness; Prism PVC declarations and service accounts; install cluster-binding and authority procedures; data-and-state backup ownership boundaries; operate raw preservation/recovery path; Nova journal constructor/lifecycle/project recovery code. The canonical `backup-restore` task remains on this page; no task matrix or navigation was changed.

## Original finding already corrected

A98-READER-BACKUP-GROUP is already corrected in the before page. Prism Restore explains that verify and database-proof independently select lexical latest; the PVC lock is per invocation, and CronJob concurrency is per CronJob. The backup/verify log comparator rejects mismatched, missing or duplicate group paths. Database smoke prints the temporary database name, not its group. The text expressly says not to attribute even a successful smoke to the matched backup/verify group and says requested-group native restore is NOT PROVEN. That explanation and the comparator's semantics were preserved. Script lines 119-154 and 156-169, plus chart lines 9-29, support this proof boundary. Newer-group, absent-path and duplicate-path comparator negatives were exercised locally.

## Material corrections made

1. Existing LiteLLM create-then-get UID adoption and name-based cleanup did not preserve the original CREATE identity or enforce deletion against it. Prism Jobs also lacked original CREATE and owned-Pod provenance. Shared helpers now retain and validate CREATE JSON, derive the Job UID from that response, select exactly one succeeded Pod with that Job UID as controller owner, recheck Job/Pod UIDs, and capture that exact container's log. Invalid or denied CREATE never grants cleanup ownership. Uncertain CREATE requires owner reconciliation, with no name-based UID adoption or automatic retry.
2. Cluster identity bound kube-system UID and namespace names but did not bind the existing application/Prism namespace objects. Recovery now requires independently supplied expected namespace UIDs, freezes supplied values, checks the used namespace, handles shared-namespace UID equality, and requires owner exclusion of namespace/Job/Pod replacement during evidence and cleanup. Comparisons are explicitly not represented as enforcement of exclusion.
3. Manual Job deletion now sends the original Job UID in server-side DeleteOptions, preserves its response, waits at most 120 seconds, and requires a successful empty named read. Failed reads, conflict, timeout and present Jobs are not absence. Cleanup is confined to successfully owned manual Jobs after Pod evidence capture; media, scheduled history and PVCs remain retained.
4. Fixed 1860-second waits conflicted with deployed duration settings, including Prism's default 3630-second Job deadline. Shared capture derives its wait from the successful CREATE's positive activeDeadlineSeconds plus 30 seconds. It rejects missing deadlines and unsuccessful/ambiguous Pod ownership instead of assuming a fresh successful Job.
5. Prism now explicitly requires an owned, versioned, read-only access/export and encrypted independent-copy method before Job creation; no finished Pod is assumed to provide PVC access. The destination check binds the exact group from both logs, complete manifests and artifact bytes, with PVC/destination/key/retention identities and a verified fence-release boundary. No generic media-access Pod or transfer command was invented.
6. Prism retention now distinguishes total/group capacity, incomplete retained attempts, absent automatic expiry, UTC/random group identity, nonblocking lock failure, owner-approved external retention and Job-history limits. Deployed values must be inspected; defaults are not asserted as RPO or retention proof.
7. The generic version section now stops before restore when compatibility is undeclared instead of directing an unsupported isolated restore. Generic independent copy uses copy/replicate, preserving source media. The native LiteLLM harness is described as checks, not fresh successful execution. Existing isolated application, host and independent-access product boundaries remain visible with linked owners/closure conditions.
8. Narrow current-source links were added for artifact publication, backup consistency precondition, PVC keep/prune/delete policies and retention settings. The verification date now names only the actual local checks.

## Checks and evidence

- `before.md`, `after.md`, `page.diff`: exact page snapshots and focused diff.
- `before-authorities/`, `before-source-guard.json`: original page's 22 linked primary authorities, with whole-file equality against their pinned commits and range checks.
- `after-authorities/`, `after-source-guard.json`: final 28 links; every target is a regular Git file, each whole file equals the current source bytes, and every valid range is at most 60 lines.
- `check-snippets.py`, `helpers.bash`, `block-*.bash`, `snippet-results.json`, `case-*/`: 9 Bash syntax blocks and 13 mocked cases (positive, namespace mismatch, denied/invalid CREATE, failed wait, foreign owner, failed phase, multiple Pods, replaced Job/Pod, delete conflict, denied post-delete read and still-present Job). Early identity/ownership failures produce no mock DELETE. This is local fixture evidence only.
- `group-comparator.cjs`, `group-*.result.json`: existing comparator accepts equal paths and rejects newer/missing/duplicate paths. No database restore is simulated as native proof.
- `check-links.py`, `local-link-check.json`: 30 Markdown source-level local path/heading links checked. This does not establish publication routes or rendered anchors.
- `git diff --check -- docs/site/use/recovery.md`: exit 0.
- `seal.json`: final page/source revision and digest.

One test rerun initially reused its deliberately exclusive private CREATE response file and correctly failed. The fixture runner was changed to reset only its own private case directories before independent runs. Final recorded cases all reached their expected success or failure result. One newly added PVC link initially exceeded the 74-line file and was corrected before the final guard. The local link scanner initially parsed a Bash expression as a link and was corrected to exclude fenced code. These were author check corrections, not product execution failures.

## Remaining boundaries and review

No live Job, deployed-media verification, encrypted transfer, native PostgreSQL restore, original application reader, Prism external restore, LiteLLM isolated application launch, cutover/rollback, complete host restore, or independent management recovery was executed. Existing unsupported capabilities remain product/validation work; the page does not close them. No source/reader/quality acceptance is claimed. Independent reviewers must evaluate the complete stable page and its actual local test limits, including the new shared identity/cleanup helper. No known material page finding was intentionally left uncorrected by this author; this statement is not a reviewer verdict.
