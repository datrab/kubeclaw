# Actual whole receiving supplement — terminal failure

Original process PID365763/session77555 completed with exit1. All21 actual decisions finished:20 passed, one failed. This is a failed correction-author receiving gate; no independent or global approval is granted.

The separate immutable22-artifact source/unit/native author seal remains unchanged at `/home/node/Documents/Codex/a98-evidence/absolute-nested-wrapper-named-write-batch-writer`. Its NOT RUN receiving status remains historically accurate. This supplement records actual new execution against scanner726faf/testseec7, semantically rebound discoveryda5713/registry4a4f and four unchanged API authorities, plus publication libraryc930b8 and current classification5a7be4. All nine Source authorities and the additional classification guard match before/copied/after. No source/test/API/registry/product files in the shared repository were mutated.

Two independent temporary complete repository copies received the complete bootstrap or workload mutations. Node executed only the read-only inventory CLI. Every complete mutated Python source compiled legally without execution. All full mutated sources and actual stdout/stderr/exit/timestamps/source identities are retained. Two baselines and two restored copies each discovered exactly436 names. All five local/passive positive cases also retained436.

All nine report counterexamples and the direct-wrapper/ordinary-assignment sensitivities rejected with their required source identity/key or reason. Native attribution is reused only through exact SHA/byte references to the immutable current author native evidence:12 new actual observed reads and137 full observations with previous expected-failure distinctions preserved. No new native execution is claimed by this supplement.

**Open finding:** `nested-inherited-stdin-rejected` exits1 with `PYTHON_ENVIRONMENT_SHELL_UNSUPPORTED: unresolved nested shell stdin custody`, but its actual raw assertion stack names the scanner and omits `charts/ops-pod/templates/workload.yaml`. The gate correctly fails its source-identity requirement. The checked full source is legal YAML and the corresponding native witness previously observed its real read. This is an explicit rejection diagnostic gap; no silently GREEN reader is shown by this case. It must be corrected and actually rechecked before a fully passing author candidate is claimed.

| Decision | Actual exit | Gate |
|---|---:|---|
| baseline-0 | 0 | PASS |
| absolute-env-shell | 1 | PASS |
| nested-env-shell | 1 | PASS |
| nested-inherited-stdin-rejected | 1 | FAIL |
| global-class-getter | 1 | PASS |
| global-reader | 1 | PASS |
| nonlocal-active-getter | 1 | PASS |
| local-named-reader | 0 | PASS |
| passive-wrapper-recipe | 0 | PASS |
| passive-wrapper-module | 0 | PASS |
| restored-0 | 0 | PASS |
| baseline-1 | 0 | PASS |
| nested-shell | 1 | PASS |
| direct-env-shell | 1 | PASS |
| global-function-getter | 1 | PASS |
| global-method-getter | 1 | PASS |
| global-mapping | 1 | PASS |
| ordinary-assignment-sensitivity | 1 | PASS |
| passive-external-named | 0 | PASS |
| passive-wrapper-script | 0 | PASS |
| restored-1 | 0 | PASS |

The original terminal log, atomic partition receipts, aggregate21 results, original harness/case inputs, complete mutated sources, terminal error traceback, terminal receipt and exact source-equality seal are retained. The failed assertion is not retried or relabelled. Root integrated287/independent Source/API qualification facts are separately owned and do not override this failed gate. Prepared owning65 tests were not rerun. No generator/install/deployment/commit/push was performed.
