# Independent SOURCE review of AP09.7 applicability mapping

Mapping-only verdict: **FAIL — 48 row PASS, 5 row FAIL; 631 decision PASS, 5 decision FAIL of 636.**

Initial HEAD `bcf1d131242913f98427dcb7e01050a7529139a2`; final HEAD `57c98bf720efde1f4694c68ab03c83da48a7588f`. The root committed the initially uncommitted matrix while this read-only review ran. All 53 complete row objects and catalogue entries remained byte-equivalent under canonical JSON comparison; blueprint and separately recorded primary authorities remained unchanged. Unrelated metadata and other working-tree edits are outside this review. This is not a clean-checkout content acceptance.

Fresh-context Source role; no inherited prior verdict. The four changed facets were independently inspected and remain PASS at mapping scope: COM-008/A97-08, DAT-006/A97-05, TEL-005/A97-06, INF-009/A97-08. Their pass does not accept content or gate execution.

Scope interpretation: each assigned gate is a narrow contribution to its actual catalogue duty, not a claim to pass a whole gate. Store contributions are real even when an adapter owns physical storage or a publisher is unimplemented. Conversely memory-only queues, correlation IDs, hash integrity, permissions over a workspace and planned-only mirrors do not automatically become new persistent stores or complete infrastructure inventories. Product-selected DNS/storage/CNI and supported options stay in scope; unused general Kubernetes schemas do not.

All twelve facets were considered against every row. Expected assignment/exclusion sets and one decision per pair are recorded in row-verdicts.json and applicability-decisions.json. The human semantic notes are row-specific; machine assertions only verify structure and freeze stability, not truth.

A97-11 is assigned on all53 and preserves both independent duties: a Reader must select diagnosis/safe recovery for EVERY dependency; another Source reviewer must compare ALL matrices to current Sources. This review compares applicability, not all content of those matrices and not Reader recovery execution. A97-12 is assigned on all53 and preserves real discovery/red-on-undocumented-addition plus change/removal/rename under quality-standard lines68–75. No existing checker name, pinned reference, count or green baseline proves it. No package gate is waived by a row exclusion.

Material findings:

## SOURCE-MAP-01: SPC-005 lacks A97-06

Matrix: docs/blueprint/documentation-completion-matrix.json:2191 (assignment), :2227 (exclusion). Catalogue: docs/blueprint/AP09-completeness-audit.md#L174.

Evidence and certification cannot omit immutable evidence-store authority. Required reports/bundles are stored, identity/digest checked and retained as artifacts; this is not merely an event signal.

Primary authority: skills/nova/plugins/review/src/review-report-storage.ts#L67-L110; skills/nova/plugins/review/src/review-report-flow.ts#L46-L68. Contract: docs/blueprint/AP09-acceptance-contract.md#L264.

Correction: Add A97-06; remove it from exclusions; describe report/bundle store schema, writer/reader, consistency, lifetime/recovery and honest missing lifecycle capabilities. Existing sourceDependencies already contains the review/src authority.

## SOURCE-MAP-02: SPC-006 lacks A97-06

Matrix: docs/blueprint/documentation-completion-matrix.json:2264 (assignment), :2300 (exclusion). Catalogue: docs/blueprint/AP09-completeness-audit.md#L175.

The catalogue explicitly requires State and removal in one host operating architecture. Accepted Redis stream/dead-letter records outlive host teardown, and Prism tool effects reconcile against durable fenced job state. In-memory queues do not erase the actual stored side.

Primary authority: skills/common/plugins/openclaw-agent-observer/src/redis-writer.ts#L226-L250; skills/prism/control/agent-jobs.ts#L84-L101; skills/prism/openclaw-plugin/index.mjs#L51-L52. Contract: docs/blueprint/AP09-acceptance-contract.md#L264.

Correction: Add A97-06; remove it from exclusions; explain host queue versus retained Redis/Prism authority and remaining data. Add skills/prism/control/agent-jobs.ts (and its schema/storage authority) to sourceDependencies for the durable result/recovery contribution.

## SOURCE-MAP-03: SPC-010 lacks A97-06

Matrix: docs/blueprint/documentation-completion-matrix.json:2521 (assignment), :2557 (exclusion). Catalogue: docs/blueprint/AP09-completeness-audit.md#L179.

Design input/publication and lifecycle consume the existing Nova workspace directory. Read-only service ownership and absent publisher are a store boundary, not absence of a store. Omitting 06 hides real Reader, writer-unknown, persistence/remaining-data and loss/restore limits.

Primary authority: my-values/nova-values.yaml#L151-L169; docker/archviewer.nginx.conf#L6-L7; charts/kubeclaw/templates/deployment.yaml#L417-L430. Contract: docs/blueprint/AP09-acceptance-contract.md#L264.

Correction: Add A97-06; remove it from exclusions; record the existing design tree/PVC Reader and lifetime/backup/restore boundaries, explicitly unknown/unimplemented writer contract; add my-values/nova-values.yaml and charts/kubeclaw/templates/deployment.yaml to sourceDependencies.

## SOURCE-MAP-04: COM-004 lacks A97-08

Matrix: docs/blueprint/documentation-completion-matrix.json:3381 (assignment), :3415 (exclusion). Catalogue: docs/blueprint/AP09-completeness-audit.md#L207.

The scoped Forge/Echo transport crosses granted runtime target, confidential secret resolution and authenticated external dispatch boundaries. Covering endpoint authentication under 05 does not substitute for the credential/trust contribution of 08.

Primary authority: skills/common/plugins/runtime-dispatch/src/adapter.ts#L69-L79; skills/common/plugins/runtime-dispatch/src/adapter.ts#L115-L135; skills/common/plugins/runtime-dispatch/src/dispatch-adapter.ts#L26-L35. Contract: docs/blueprint/AP09-acceptance-contract.md#L266.

Correction: Add A97-08; remove it from exclusions; record runtime target grant, secret source, HMAC versus SPIFFE-proxy constraints and negative access. Add skills/common/plugins/runtime-dispatch to sourceDependencies, which currently omit this primary adapter.

## SOURCE-MAP-05: COM-005 lacks A97-08

Matrix: docs/blueprint/documentation-completion-matrix.json:3458 (assignment), :3492 (exclusion). Catalogue: docs/blueprint/AP09-completeness-audit.md#L208.

Catalogue explicitly calls out Invocation Authority and Context. Current core contexts reject absent grants, invalid resource scope and wrong event namespace/run identity under revocable leases. These are direct trust and least-privilege boundaries, not just request schemas or observer signals.

Primary authority: skills/nova/core/execution/context.ts#L44-L71; skills/nova/core/execution/stage-executor.ts#L58-L64; skills/nova/core/execution/authorization.ts#L121-L133. Contract: docs/blueprint/AP09-acceptance-contract.md#L266.

Correction: Add A97-08; remove it from exclusions; replace the claim that this is not a security-policy requirement with scoped lease/grant/resource/event access boundaries and negative access. Core sourceDependencies already contains these authorities.

## Individual row results

| ID | Mapping verdict | Expected assigned facets | Expected excluded facets |
| --- | --- | --- | --- |
| SPC-004 | PASS | 05, 06, 08, 09, 11, 12 | 01, 02, 03, 04, 07, 10 |
| SPC-005 | FAIL | 05, 06, 07, 08, 09, 11, 12 | 01, 02, 03, 04, 10 |
| SPC-006 | FAIL | 05, 06, 07, 08, 09, 11, 12 | 01, 02, 03, 04, 10 |
| SPC-007 | PASS | 01, 05, 08, 09, 11, 12 | 02, 03, 04, 06, 07, 10 |
| SPC-009 | PASS | 01, 05, 08, 09, 11, 12 | 02, 03, 04, 06, 07, 10 |
| SPC-010 | FAIL | 01, 05, 06, 08, 09, 11, 12 | 02, 03, 04, 07, 10 |
| COM-001 | PASS | 05, 08, 10, 11, 12 | 01, 02, 03, 04, 06, 07, 09 |
| COM-002 | PASS | 05, 06, 08, 10, 11, 12 | 01, 02, 03, 04, 07, 09 |
| COM-003 | PASS | 05, 06, 08, 10, 11, 12 | 01, 02, 03, 04, 07, 09 |
| COM-004 | FAIL | 05, 08, 09, 11, 12 | 01, 02, 03, 04, 06, 07, 10 |
| COM-005 | FAIL | 05, 07, 08, 11, 12 | 01, 02, 03, 04, 06, 09, 10 |
| COM-006 | PASS | 05, 08, 11, 12 | 01, 02, 03, 04, 06, 07, 09, 10 |
| COM-007 | PASS | 02, 05, 06, 10, 11, 12 | 01, 03, 04, 07, 08, 09 |
| COM-008 | PASS | 05, 08, 11, 12 | 01, 02, 03, 04, 06, 07, 09, 10 |
| COM-009 | PASS | 02, 05, 08, 10, 11, 12 | 01, 03, 04, 06, 07, 09 |
| COM-010 | PASS | 02, 05, 06, 08, 10, 11, 12 | 01, 03, 04, 07, 09 |
| COM-011 | PASS | 05, 08, 11, 12 | 01, 02, 03, 04, 06, 07, 09, 10 |
| COM-012 | PASS | 05, 10, 11, 12 | 01, 02, 03, 04, 06, 07, 08, 09 |
| DAT-001 | PASS | 06, 08, 10, 11, 12 | 01, 02, 03, 04, 05, 07, 09 |
| DAT-002 | PASS | 06, 11, 12 | 01, 02, 03, 04, 05, 07, 08, 09, 10 |
| DAT-003 | PASS | 06, 11, 12 | 01, 02, 03, 04, 05, 07, 08, 09, 10 |
| DAT-004 | PASS | 06, 08, 11, 12 | 01, 02, 03, 04, 05, 07, 09, 10 |
| DAT-005 | PASS | 02, 06, 10, 11, 12 | 01, 03, 04, 05, 07, 08, 09 |
| DAT-006 | PASS | 02, 03, 05, 06, 08, 10, 11, 12 | 01, 04, 07, 09 |
| DAT-007 | PASS | 02, 05, 06, 10, 11, 12 | 01, 03, 04, 07, 08, 09 |
| DAT-008 | PASS | 06, 08, 11, 12 | 01, 02, 03, 04, 05, 07, 09, 10 |
| DAT-009 | PASS | 02, 06, 10, 11, 12 | 01, 03, 04, 05, 07, 08, 09 |
| TEL-001 | PASS | 05, 07, 11, 12 | 01, 02, 03, 04, 06, 08, 09, 10 |
| TEL-002 | PASS | 05, 07, 11, 12 | 01, 02, 03, 04, 06, 08, 09, 10 |
| TEL-003 | PASS | 05, 07, 11, 12 | 01, 02, 03, 04, 06, 08, 09, 10 |
| TEL-004 | PASS | 05, 07, 08, 11, 12 | 01, 02, 03, 04, 06, 09, 10 |
| TEL-005 | PASS | 05, 06, 07, 11, 12 | 01, 02, 03, 04, 08, 09, 10 |
| TEL-006 | PASS | 06, 07, 11, 12 | 01, 02, 03, 04, 05, 08, 09, 10 |
| TEL-007 | PASS | 05, 06, 07, 11, 12 | 01, 02, 03, 04, 08, 09, 10 |
| INF-001 | PASS | 01, 11, 12 | 02, 03, 04, 05, 06, 07, 08, 09, 10 |
| INF-002 | PASS | 01, 05, 06, 11, 12 | 02, 03, 04, 07, 08, 09, 10 |
| INF-003 | PASS | 01, 04, 05, 08, 11, 12 | 02, 03, 06, 07, 09, 10 |
| INF-004 | PASS | 01, 04, 05, 08, 11, 12 | 02, 03, 06, 07, 09, 10 |
| INF-005 | PASS | 01, 02, 05, 06, 08, 10, 11, 12 | 03, 04, 07, 09 |
| INF-006 | PASS | 01, 02, 05, 06, 08, 10, 11, 12 | 03, 04, 07, 09 |
| INF-007 | PASS | 01, 02, 05, 06, 08, 10, 11, 12 | 03, 04, 07, 09 |
| INF-008 | PASS | 01, 02, 05, 08, 10, 11, 12 | 03, 04, 06, 07, 09 |
| INF-009 | PASS | 01, 02, 05, 06, 08, 10, 11, 12 | 03, 04, 07, 09 |
| INF-010 | PASS | 01, 04, 05, 06, 07, 08, 11, 12 | 02, 03, 09, 10 |
| INF-011 | PASS | 01, 05, 08, 09, 11, 12 | 02, 03, 04, 06, 07, 10 |
| INF-012 | PASS | 01, 03, 05, 06, 08, 10, 11, 12 | 02, 04, 07, 09 |
| SEC-001 | PASS | 08, 11, 12 | 01, 02, 03, 04, 05, 06, 07, 09, 10 |
| SEC-002 | PASS | 05, 08, 11, 12 | 01, 02, 03, 04, 06, 07, 09, 10 |
| SEC-003 | PASS | 05, 08, 11, 12 | 01, 02, 03, 04, 06, 07, 09, 10 |
| SEC-004 | PASS | 05, 08, 11, 12 | 01, 02, 03, 04, 06, 07, 09, 10 |
| SEC-005 | PASS | 04, 05, 08, 11, 12 | 01, 02, 03, 06, 07, 09, 10 |
| SEC-006 | PASS | 02, 05, 08, 11, 12 | 01, 03, 04, 06, 07, 09, 10 |
| SEC-007 | PASS | 08, 11, 12 | 01, 02, 03, 04, 05, 06, 07, 09, 10 |

## Checks and limits

Performed: read and compared the quality standard, contract, all53 AP09.7 catalogue entries, complete row mapping records and applicable plan sections; inspected primary runtime, observer, Redis, store, host, sidecar, service, RBAC, network, deployment and selected infrastructure authorities. Used read-only git, rg, cat/sed/nl and Python JSON/hash assertions. Output truncation from broad source reads was followed by focused line/function inspection for findings. Authority freeze and full row comparison assertions exit0. No repository file, commit, product behavior or shared generated output was written by this reviewer. Evidence files only were written in this reviewer’s assigned directory.

Not performed: clean-reader diagnosis/recovery exercises, full semantic content acceptance of every matrix cell/page, product tests, deployment/live enforcement, required mutation executions, publication/build/route acceptance, controlled-language acceptance or package/global acceptance. The applicable plans are historical work records, not proof that content passed. No test suite was run. One attempted read used a nonexistent monitoring path; the actual gitops/platform/values/prometheus.yaml was then read. Environment runtime skill was read; no managed-environment status tool was exposed.

Primary authority before hashes were recorded during source inspection after the initial row/blueprint freeze; unchanged before/after is bounded to that interval. All material source findings cite paths that remained unchanged and are outside the root’s unrelated uncommitted edits.

Fix the five omitted contribution facets and source dependencies, then repeat a fresh independent whole-set applicability review. This report supplies no self-acceptance and no package/content completion claim.
