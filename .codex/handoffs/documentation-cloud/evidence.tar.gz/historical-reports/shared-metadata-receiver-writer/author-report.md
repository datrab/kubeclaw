# Shared metadata receiving contracts — author handoff

Exclusive repository file: `scripts/docs-kubernetes-metadata-receiver-contracts.mjs`. Authoring is complete and ownership is released to the root integrator. No other repository edits, generation, commit or push performed by this author.

`receiverContracts` joins all 246 actual baseline missing paths after wildcard matcher normalization, with no duplicates or extra schema paths. Counts: {'Deployment': 102, 'Ingress': 34, 'NetworkPolicy': 34, 'ValidatingAdmissionPolicy': 35, 'ValidatingAdmissionPolicyBinding': 35, 'Application': 3, 'AppProject': 3}. Deployment includes 34 ordinary root, 34 Pod-template and 34 ephemeral PVC-template boundaries. The ten previously integrated builtin identity rows are excluded. Argo existing root `$` records are excluded.

`implicitKubernetesObjectMetaContracts` contains 136 reference-only obligations (34 each for Application, AppProject, CNP and CCNP). `implicitKubernetesObjectMetaReferences` has four descriptors with exact API version, kind, bare metadata linkage and namespace/cluster scope. Stable IDs are `kubernetes-objectmeta:<apiVersion>:<kind>`. These do not invent CRD schema properties. Argo bare metadata rows link their canonical reference ID; Cilium integration is root-owned.

Contracts distinguish ordinary typed API routes, unstructured CRD request/schema coercion, storage codec repair, status/reset/field-manager routes, Pod-template and ephemeral PVC-template consumption. Source-qualified cases include omitted/null/empty/incompatible tokens, map membership and keys, owner authorization and UID graph lifetime, deletion/finalizer retention, unconditional-update strategy differences, Apply manager identity, field trie decoding, Argo RBAC/cache/refresh/finalization and Cilium cached-generation filtering. Kubernetes v1.35 server source is distinct from Argo apimachinery v0.36.1 and Cilium v0.36.3 client sources.

Important actual source distinctions: GetPodFromTemplate copies finalizers as well as labels and annotations. PVC-template forbidden fields must equal Go zero values; a nonnil empty slice is not nil. Admission policy/binding and CRDs reject unconditional replacement updates. Argo Application/AppProject have no status subresource in both pinned upstream originals and chart archive; Cilium has status. Cilium onUpsert can ignore a metadata-only edit with unchanged cached generation before comparing metadata. Apply manager identifiers exclude apiVersion. Removing the final finalizer can trigger deletion when old grace is nil or zero, not through a wall-clock expiration check.

Author checks passed: 246 schema rows, 136 implicit rows, 4 descriptors, 2553 concrete source cases; 171 unique narrow evidence captions across 67 original files. Checks cover exact full-path join, required strings/lists/cases, independently downloaded pinned original hashes and range existence. No API/controller/GC/live exercise, Source approval, Reader approval or Quality acceptance is claimed. Captions remain author claims requiring independent review.

Hashes:
- module SHA-256: `b6b5e44bcef780d56facb8e511b684a2bf5c2335c16465c9bc6a437d29fc818d`
- schema export JSON SHA-256: `323b32227a56a6465e09db3ef25df3be4fdeeade956a0311cecaebcc11b74479`
- implicit export JSON SHA-256: `f5359f1114a748b25ef2f42cc6d1d76cf78f2c5c3c83dc23ccb3ee38464f6ac4`
- reference descriptor export JSON SHA-256: `84d195c421d28f9be84007af85a8122f5919f5e14260d86bcd8f92bd23c7e07b`

Evidence artifacts in this directory: `original-manifest.json` records independently fetched original URLs, pinned revisions, SHA-256, Git blob SHA-1 and line counts; `source-range-excerpts.json` joins every caption/range to those original bytes; `full-path-join.json` records all schema matches; `contracts.json` captures exports; `author-check-result.json` records deterministic checks; `chart-crd-operation-scope.json` checks the unchanged chart archive hash and member scope/subresource bytes. `remaining-proof-obligations.json` separates independent review/integration obligations from source lookup leads. The one failed obsolete Cilium watcher-path lookup was replaced by the available actual `pkg/policy/k8s/cilium_network_policy.go` original and is not a source-unavailability waiver.

No unresolved available-original lookup gaps are asserted in this new scope. Existing registered core-module proof gaps remain the root integrator's scope and are not accepted by this author report.
