# Corrected AP09.7 full mapping Source review

Verdict: **FAIL**, mapping only. 49 individual mapping PASS, 4 individual mapping FAIL; all 53 rows and all 636 row/facet decisions recorded.

Reviewed revision: `bcf1d131242913f98427dcb7e01050a7529139a2`. Reviewer: `/root/ap097_corrected_all_mapping_source_fresh`, independent fresh task, read-only throughout. This is neither content acceptance nor Source/Reader/Quality package acceptance. Overall state remains not accepted.

The corrected mapping retains complete Source/Reader and drift duties on every row. A97-11 complete current-Source matrix comparison and fresh-reader safe recovery remain open. A97-12 actual-discovery and negative addition evidence remain open; quality scope also retains change/remove/rename detection. Mapping PASS cannot waive any of these duties.

## Material findings

- **COM-008 → A97-08**: Peer Identity and Auth explicitly belong to the endpoint catalogue. Corrected COM-001 includes 08 for authentication/authorization, so excluding the same peer/auth facet here is incoherent. Matrix `docs/blueprint/documentation-completion-matrix.json:3664`, catalogue `docs/blueprint/generated/ap09-catalogue.json:1172` / `docs/blueprint/AP09-completeness-audit.md#L211`, contract `docs/blueprint/AP09-acceptance-contract.md:266`. Fix: Add A97-08; remove it from exclusions; identify HTTP peer/auth trust-boundary contribution without claiming whole security gate acceptance.

- **DAT-006 → A97-05**: Connection Pool is expressly in this client/database scope. A97-05 includes active Store paths and limits, not only HTTP endpoints. Pool/client startup and DATABASE_URL are concrete communication semantics. Matrix `docs/blueprint/documentation-completion-matrix.json:4434`, catalogue `docs/blueprint/generated/ap09-catalogue.json:1302` / `docs/blueprint/AP09-completeness-audit.md#L221`, contract `docs/blueprint/AP09-acceptance-contract.md:263`. Fix: Add A97-05 for the LiteLLM-to-PostgreSQL client/store path, connection limits/startup/failure; remove exclusion while preserving 03/06/08 duties.

- **TEL-005 → A97-06**: Delivery Journal, success checkpoints, Recovery State and restart are explicit durable store authority. Current source options contain FileJournal events/checkpoints/deliveries; records are appended, checkpoints transact, and recovery reads them. 05/07 do not replace store authority. Matrix `docs/blueprint/documentation-completion-matrix.json:5075`, catalogue `docs/blueprint/generated/ap09-catalogue.json:1406` / `docs/blueprint/AP09-completeness-audit.md#L229`, contract `docs/blueprint/AP09-acceptance-contract.md:264`. Fix: Add A97-06 for delivery/checkpoint journal schemas, writer/reader, commit/replay/corruption/retention/capacity/restore limits; remove exclusion.

- **INF-009 → A97-08**: Catalogue expressly includes Credentials for Redis/PostgreSQL/Tailscale. Credential sources and route trust are A97-08 duties; named dependency identity under 02 does not substitute for security-matrix contribution. Matrix `docs/blueprint/documentation-completion-matrix.json:5890`, catalogue `docs/blueprint/generated/ap09-catalogue.json:1549` / `docs/blueprint/AP09-completeness-audit.md#L245`, contract `docs/blueprint/AP09-acceptance-contract.md:266`. Fix: Add A97-08; remove exclusion; preserve credential authority/rotation/negative-access facets distinct from service connectivity and store recovery.

TEL-005 source confirmation: `skills/nova/core/telemetry/observers.ts:22` defines FileJournal event/checkpoint/delivery stores; `:43` appends delivery records; `:56` transacts checkpoints. `skills/nova/core/telemetry/observer-recovery.ts:14` rebuilds recovery from event/checkpoint/delivery records, with identity/order/corruption checks. INF-009 credential confirmation: `gitops/platform/values/redis.yaml:10`, `gitops/platform/values/postgresql.yaml:12`, and `my-values/infra/tailscale-operator-values.yaml:4` select credential authorities. DAT-006 concrete client endpoint/credential/runtime authority is recorded in `docs/site/understand/platform-and-operations.md:267`; the catalogue explicitly requires Connection Pool. These reads confirm mapping scope, not acceptance of published content.

## Critical exclusion decisions

Hash-chain integrity in DAT-002 and sealed lifecycle state in DAT-003 do not automatically create a credential/signing matrix. Explicit Result Signing in DAT-004 does require A97-08; artifact identity/visibility in DAT-008 also contributes. Unsupported Git Mirror in INF-008 does not create an implemented mirror store. Retained inactive v1 telemetry in TEL-002 must not become an invented active service. Local observer retry in TEL-005 does not require the full six-dependency A97-10 journey; its durable journal still requires A97-06. COM-001 authentication and COM-008 Peer Identity/Auth require coherent A97-08 handling. Every included and excluded gate has an individual row/facet decision and explanation in individual-results.json; exclusions never remove package-wide gates.

## Per-row results

| ID | Mapping verdict | Missing contribution |
| --- | --- | --- |
| SPC-004 | PASS | — |
| SPC-005 | PASS | — |
| SPC-006 | PASS | — |
| SPC-007 | PASS | — |
| SPC-009 | PASS | — |
| SPC-010 | PASS | — |
| COM-001 | PASS | — |
| COM-002 | PASS | — |
| COM-003 | PASS | — |
| COM-004 | PASS | — |
| COM-005 | PASS | — |
| COM-006 | PASS | — |
| COM-007 | PASS | — |
| COM-008 | FAIL | A97-08 |
| COM-009 | PASS | — |
| COM-010 | PASS | — |
| COM-011 | PASS | — |
| COM-012 | PASS | — |
| DAT-001 | PASS | — |
| DAT-002 | PASS | — |
| DAT-003 | PASS | — |
| DAT-004 | PASS | — |
| DAT-005 | PASS | — |
| DAT-006 | FAIL | A97-05 |
| DAT-007 | PASS | — |
| DAT-008 | PASS | — |
| DAT-009 | PASS | — |
| TEL-001 | PASS | — |
| TEL-002 | PASS | — |
| TEL-003 | PASS | — |
| TEL-004 | PASS | — |
| TEL-005 | FAIL | A97-06 |
| TEL-006 | PASS | — |
| TEL-007 | PASS | — |
| INF-001 | PASS | — |
| INF-002 | PASS | — |
| INF-003 | PASS | — |
| INF-004 | PASS | — |
| INF-005 | PASS | — |
| INF-006 | PASS | — |
| INF-007 | PASS | — |
| INF-008 | PASS | — |
| INF-009 | FAIL | A97-08 |
| INF-010 | PASS | — |
| INF-011 | PASS | — |
| INF-012 | PASS | — |
| SEC-001 | PASS | — |
| SEC-002 | PASS | — |
| SEC-003 | PASS | — |
| SEC-004 | PASS | — |
| SEC-005 | PASS | — |
| SEC-006 | PASS | — |
| SEC-007 | PASS | — |

## Method, checks, limits and freeze

Read the full quality standard and full acceptance contract, all 53 generated catalogue records, their mapping records/reasons/exclusions, and execution-plan scope/governance. Independently wrote expected contribution assignments before comparing them in private review.py. No prior review conclusions were used. Per-row scope plus each specific gate was evaluated; generic shared-path overlap alone did not add gates.

Own Python checks completed with exit 0: exact 53 coverage, 636 decisions, owner/target parity, mapped/excluded disjoint and total coverage; relevant mapping projection before/end equality; catalogue/contract/quality/execution SHA-256 before/end equality; HEAD identity. Structural checks do not prove the semantic decisions, which are the reviewer's manual work.

Shared worktree already contains unrelated changes; this report does not call it clean. The complete row snapshot is retained, while the protected projection excludes unrelated root review metadata. No shared file, product, live environment, commit, push, publication, Source content review, Reader exercise, Quality review or Astra acceptance was changed or executed. Actual gate tests and mutation proofs remain not run here by scope. The manual Source confirmation is narrow and cannot establish full matrix content completeness.

Artifacts: individual-results.json contains actual individual 53 verdicts and 12 facet applicability/exclusion/reason decisions per row. contract-facet-results.json contains all 12 aggregate mapping assessments with individual contributors/exclusions. checks.json and before/end projections/freezes record bounded checks. SHA256SUMS seals report, runner and artifacts.
