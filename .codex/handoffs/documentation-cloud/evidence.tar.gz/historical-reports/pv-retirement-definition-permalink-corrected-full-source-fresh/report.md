# Independent full Source review: former Qdrant retirement

Verdict: **PASS** for the complete assigned bounded Source scope. No material documentation finding remains in that scope. This is not whole OPR-001/008 acceptance, a global AP09 gate verdict, a SourceGraph audit, live retirement validation, or generated-reference publication acceptance.

Reviewer: `pv_retirement_definition_permalink_corrected_full_source_fresh`; fresh-context independent Source role, read-only product access, neither author nor prior reviewer. Reviewed repository HEAD `0403b262df2dba24747a19d1f8f42ef3334ef779`, with the targeted current working files frozen before review and independently compared afterward. The current maintenance file includes the later helper citation refresh; see both input receipts for exact Git status. Other concurrent ledger changes do not enter this verdict. No repository edits, real cluster calls, product mutations, generated runs, or commits were made.

## Governing scope and evidence

Read the full documentation quality standard and AP09 acceptance contract, OPR-001 (operator lifecycle; canonical Use index), OPR-008 (maintenance; canonical maintenance page), and EXEC-DECOMMISSION fixture. The relevant bounded duties are A98-06 diagnosis, A98-09 safe ordered removal and retained evidence, A98-10 selected configurations, A98-11 effective precedence, and A98-13 a self-contained operator procedure. This report does not substitute private fixtures for the registered deployment-class EXEC-DECOMMISSION scenario. That scenario was not performed.

Frozen primary authored inputs:

| Input | SHA-256 | Bytes |
| --- | --- | ---: |
| `docs/site/use/maintenance.md` | `ba7eb39fb5159ba9621c13e50b328b15147e585f086c714a53f9309ec0d4d25b` | 67853 |
| `scripts/docs-kubernetes-pv-selected-receiver-contracts.mjs` | `02d9af8019e1300767aa0ca507607004aa6ee6e107fb455da3579af46e551f51` | 22644 |
| `scripts/remove-qdrant.sh` | `330e52e17f4a4c3d3cc49b4faf8fa4ea50ca067c84be5bac0d08d40a992c4a45` | 3291 |

Also froze the renderer, complete reader-language test, governing documents, fixture/catalogue, and linked cluster-binding procedure. Read the complete current former-Qdrant procedure (maintenance lines 127–523), all seven receiver records and shared conditions/evidence/limits, actual product script, applicable renderer/link enforcement and full language/navigation tests. Prior author and reviewer artifacts were used only as locators and verified cached primary byte sources; no prior verdict was inherited.

Cached immutable upstream authorities were freshly hashed against their immutable provenance manifest; metadata bytes were separately checked against metadata-primary.json. The retained v1.35.0 tag object resolves to Kubernetes commit `66452049f3d692768c39c797b21b793dce80314e`. Primary bytes include metadata/core types, exact bundled JSON Patch library, API patch handler, PV strategy/validation, controller, and kubectl delete/wait. Their SHA/byte inventory is in primary-provenance.json and metadata-primary-verification.json. Independently read each cited behavior-bearing range, including surrounding controller and wait paths. `citation-checks.json` contains 46 independently verified narrow sources, complete blob hashes and actual excerpts. Product cited blobs at `8ef721...`, `51975b...`, and the helper at `0403b...` match current targeted bytes exactly. Every cited line range exists.

## Complete bounded claim assessment

| Facet | Verdict | Independent assessment and authority |
| --- | --- | --- |
| Scope, prerequisites, binding and privileges | PASS | Maintenance 127–165 restricts this to former kubeclaw/qdrant, independent administration and accepted actual versions. Linked install 156–216 establishes set -euo pipefail, dedicated read-only KUBECONFIG and repeated identity checks. PVC get/list/watch/delete and cluster PV get/list/watch/patch plus release/workload/discovery/diagnostic permissions are explicit. No namespace-scoped PV authority is implied; PV strategy 49–51 confirms cluster scope. |
| External concurrency exclusion | PASS | Maintenance 166–192 requires owners to exclude claim replacement, PV recreation/rebinding/policy edits and maintain exclusion through uncertainty. Script 35–43 and 57–77 test only claimRef triplet; no PV UID/version/prior-policy guard or PVC deletion UID precondition exists. Text describes the cost and exact limits, rather than claiming atomicity. |
| Selector and original inventory | PASS | Script 20–30 selects two known names OR instance=qdrant AND name=qdrant; legacy app is fallback only when modern name is absent. Maintenance 194–337 captures exact PVC/PV names, UIDs, object versions, bound name, reference triplet, original policy presence/value, class/source/driver/handle and deletion/finalizer state; compares before/current and resolves any version change. Unbound, non-CSI, unknown ownership, deleting, empty selection and missing-class paths are explicit. |
| Private capture and sanitation | PASS | Fresh published capture selected exactly five fixture claims (four bound and one unbound), excluded empty/null/other modern labels despite legacy qdrant, omitted seeded annotation and CSI volume-attribute credential sentinels, kept files 0600 and captured before/current without overwriting. Original backing handle remains intentionally private. No Secret or kubeconfig contents are requested by the capture. |
| Ordered producer and receiver sequence | PASS | Script prechecks all bound references before Helm/resource removal; later each row sends three ordered tests then add Delete, deletes PVC by name, waits PVC and bound PV. Exact transmitted patch and branch counts were checked in fresh private runs. JSON Patch library 342–395, 524–541, 653–702, 807–838 confirms existing parents, equality, replacement/add and failure-before-later-operation. Handler 323–340/403–417/691–705 confirms encode/apply/decode, error classes and subsequent admission/update. |
| Discovery failure and denied waits | PASS | Fresh actual-script discovery-denied run exited 0, skipped Cilium deletion and performed four patches/five PVC deletes. Maintenance 364–387 explicitly says no automatic interruption prevents later writes and mandates complete read-back. Wait delete.go 45–51/79–89 gets then lists/watches present named objects; command delete.go 460–477 tolerates Forbidden/MethodNotSupported wait. Text therefore correctly rejects exit status as proof of absence. |
| Partial/uncertain effects and read-back | PASS | Maintenance 389–475 uses every original row and UID, successful named reads, events, Pods, attachments/class/driver/controller observations and owner backend lookup. Distinguishes rejection, denial, lost patch response, lost delete response, replacement identity, timeout, finalizer/in-use/controller/backend paths. Fresh scripted rejection/lost-response/denied-wait/timeout scenarios matched the documented sequence and retained preceding effects. |
| Controller and backend separation | PASS | Controller 576–602/642–689/1178–1215/1321–1437/1495–1540 confirms unused/reserved/released paths, migration handoff, separate deletion, recheck, retry and possible finalizer/API failure after backend deletion. Text requires owner observations of original handle and retained snapshots/replicas/exports/backups, never equates API absence, wait or patch success with erasure. |
| Recovery, rollback limits, retention and cleanup | PASS | Maintenance 448–500 stops further operator writes, keeps exclusion, distinguishes controller retries from operator authorization and requires exact owner continuation. Policy reversal cannot restore erased data. Backup/restore proof, owner-specific unsupported disposal/restore boundaries, evidence retention end date, temporary admin disposal and script inventory cleanup are stated. No generic resume/backend/restore command or recovery success is invented. |
| Seven actual navigation targets | PASS | Each current record emits `../use/maintenance.md#retire-the-former-qdrant-installation`. Four current test cases pass, including resolution from actual helm-values location, bad-path/missing-anchor rejection, finite canonical cross-directory target and hostile syntax/label checks. Fresh private full-boundary composition emitted all seven actual links. Actual generated-reference publication remains pending. |
| Rationale and truthful evidence | PASS | Maintenance source callout labels current inference and unknown historic incomplete-guard rationale; reassessment owner and costs are visible. All seven records separate source expectations from actual authorization/admission/controller/driver/erasure/recovery. Private tests are not reported as live success. |

## Seven receiver records

All seven were individually reviewed, including every purpose, omitted/null/empty/invalid/change case, six case entries, shared conditions, evidence and limits. `claim-matrix.json` records each outcome separately.

| Selected path | Verdict | Result |
| --- | --- | --- |
| `$` | PASS | Existing-PV ordered JSON Patch, not CREATE; malformed/null/empty request and target cases are correctly separated. |
| `$.spec` | PASS | Existing parent traversal; missing/null/wrong shape fails guards; unmentioned fields remain at patch application, with later server stages separate. |
| `$.spec.claimRef` | PASS | Current reference is guarded, not assigned; absent/null/empty/wrong-shaped references do not authorize deletion. |
| `$.spec.claimRef.name` | PASS | Nonempty captured name must match actual JSON; no conversion/default/substitution. |
| `$.spec.claimRef.namespace` | PASS | Exact kubeclaw string must match, independent of namespace request scope. |
| `$.spec.claimRef.uid` | PASS | Captured PVC lifetime must match; same-name replacement is distinguished. |
| `$.spec.persistentVolumeReclaimPolicy` | PASS | Always add Delete; replaces present values or adds absent member after guards; prior policy is unguarded; storage effect remains separately reconciled. |

The helper's typed field/schema references are complete-object authorities, not evidence that malformed stored objects exist or that partial PATCH must supply creation siblings. All relevant options and boundaries remain accurately constrained.

## Corrected definition and committed permalink

Current maintenance 133–134 says resourceVersion is an opaque version of the object. Kubernetes metadata types 161–172 directly defines the opaque internal object version, used for change/concurrency/watch operations. The helper 21 similarly says API object version. Neither says API version. No remaining correction is required for this facet.

Maintenance 507 now cites the committed helper at `0403b262df2dba24747a19d1f8f42ef3334ef779`, lines 13–29. Independent git show verified the complete blob equals current helper bytes; the retained excerpt contains all seven selected paths plus ordered patch scope, missing guards, discovery failure, reconciliation/backend limits and rationale. Its range supports the claimed behavior. This was checked alongside the complete procedure, not treated as a two-change-only review.

## Executed checks and limits

Ran `python3 independent-checks.py` (exit 0): ten fresh actual frozen-script executions using private kubectl/Helm substitutes. Success and tolerated PVC wait denial exit 0; discovery denial exits 0 with later storage writes; initial mismatch, patch rejection, stored-patch response loss, denied PVC delete, accepted-delete response loss, denied PV wait and timeout exit 1 with recorded calls/state. These prove script branching, transmitted patch and ordering only. Denied wait tolerance was modeled by the substitute and independently confirmed from pinned real kubectl source; this review did not run a real kubectl permission-denial client scenario.

Executed all nine freshly extracted Bash blocks through bash -n. Ran the published read-only capture against independent synthetic fixtures, checked exact selection, private modes, sanitized fields, before/current equality and binding refusal (126 before capture). The binding function in this local capture was deliberately substituted; no live cluster-binding claim follows. Ran `node --test scripts/tests/api-reference-reader-language.test.mjs` (exit 0, 4 PASS), saved terminal output. Ran current renderer with all 245 PV boundaries, seven actual contracts and 238 explicitly synthetic unused boundaries to retain private emitted link evidence. An initial seven-row-only private composition was rejected by the renderer's required-boundary count; it was corrected to the full required shape. This was a reviewer fixture construction error, not a product finding.

Before/after checks found no targeted input changes. Environment, raw call traces, transmitted patches, fixture data, script outputs, captured inventories, navigation output, immutable sources and exact source excerpts are retained with SHA-256/bytes in artifact-manifest.json. The author harness was not reused. Root's broader 199-test result was not rerun or adopted as this verdict.

Not performed: live cluster/RBAC/admission requests, actual storage/controller operations, disposal/restore, deployment-class EXEC-DECOMMISSION, full generated-reference publication, browser rendering, whole configuration inventory, drift mutations, SourceGraph/global catalogue acceptance, Clean Reader or Quality role acceptance. Their absence does not become a PASS in this report. Bounded A98-06/09/10/11/13 Source facets are PASS; complete gates require their own remaining scope and evidence. Remaining material findings in the assigned Source scope: **none**.
