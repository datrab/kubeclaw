# LiteLLM retention correction — author report

Role: documentation writer, not independent reviewer. Base revision `ebcc04066d42c94b4a4e0fc85e3393dae3d61f78`, branch `docs/documentation-overhaul`. Exclusive repository edit: `docs/site/understand/data-and-state.md`. No commit, push, product changes, generator run, recovery-page edit, deployment, or external application write.

Frozen output: 111,499 bytes, SHA-256 `299d74919979e78dfa76e963f092ab4dc7c02448f037f57841b336944db8de52`. `frozen-data-and-state.md` equals the current repository page. Shared concurrent changes exist in other paths; `git-status-observed.txt` records the observation. Global clean-tree acceptance is not claimed.

## Exact changes

- S15 at line 195 replaces the false universal scheduler absence with the checked-in YAML omission, conditional effective application cleanup, and a link to the canonical row-retention explanation.
- Lines 543–544 make the existing no-deletion/off-node-upload statement explicitly apply to completed recovery backup groups.
- Lines 559–580 add the bounded retention explanation: both selected implementations can clean spend logs (request-cost records), autorouter sessions (request-routing sessions), and health-check records; stored settings can reschedule the job; check mounted and stored period values. Aged diagnostic/accounting rows can be absent from a later backup while an earlier retained dump still has them. Preserve dumps and determine the effective policy before diagnosing corruption. No common model/key/budget expiry or backup-group deletion is inferred.
- Line 677 extends the existing migration-attempt/baseline citation from 1130 through 1137. The primary branch invokes baseline creation, resolution, and returns success within that complete range.
- Line 794 clarifies the backup table's former `no automatic cleanup` as `no automatic backup-group deletion`, so the backup limit cannot contradict conditional application row cleanup.

The full detailed schema, encryption, pool, startup, image/provenance, capacity, migration and proof-limit explanations remain. The detailed selected-source section is byte-preserved except the intended 1137 citation extension. No isolated executable application restore or successful runtime check was invented.

## Primary authority read

Full project quality standard and acceptance contract were read, along with DAT-006 in the catalogue and the relevant page and selected YAML/deployment configurations. Completed Source and Reader reports were discovery inputs. The correction uses actual primary code, not their verdict as authority.

Five primary files were fetched anew from official commit-pinned `raw.githubusercontent.com/BerriAI/litellm` paths. Their full bytes equal the independently saved Source snapshots. `primary-source-hashes.json` records exact authoritative fetch URLs, full byte counts, SHA-256, and local artifacts. `citation-checks.json` records the eight added/updated public GitHub URLs, SHA-256/bytes, and exact line spans. Narrow source reads covered:

- Direct `proxy_server.py`: 9588–9629 initial conditional scheduling; 6805–6825 stored-setting application; additional 6638–6718 rescheduling and 6931–6976 DB configuration loading read for context.
- GitOps `proxy_server.py`: 10008–10049 initial conditional scheduling; 7162–7182 stored-setting application.
- Direct and GitOps `spend_log_cleanup.py`: 308–336 bounded SQL row deletion, 456–505 table identities, and 586–655 effective family selection. Both full cleanup files have identical verified bytes.
- Direct extras `utils.py`: baseline branch through 1137, within corrected 1018–1137 citation.
- Repository YAML at base: `my-values/infra/litellm-config.yaml:1–14`, no retention settings. GitOps `resources.yaml:1–65` mounts the externally managed ConfigMap; it does not prove the deployed configuration's contents.
- Current recovery script was read for completed-backup behavior; no expiry/upload mechanism was added or claimed.

## Checks performed and limits

`python3 .../litellm-retention-correction-writer/check.py` exited 0. Eight added/updated primary citation spans exist and are ordered within their complete fetched or Git-read file. Repository YAML citation bytes equal working input. Local `#litellm-row-retention` anchor has exactly one matching heading. The false sentence is absent. Detailed selected-source section preservation assertion passed. Frozen output equals current page.

`git diff --check` over the current shared repository exited 0, with no diagnostics; saved in `diff-check.txt`. `page.diff` saves the focused change. Read-only Git status, HEAD and branch checks completed. No full generator was run against concurrent moving inputs.

No publication renderer or built-output link test, upstream tests, selected-image execution, encryption round trip, deployed mounted/stored-policy inspection, native database test, isolated restore, live cutover, or independent Source/Reader/Quality acceptance was performed. These author checks do not close DAT-006 or AP09 acceptance. Fresh independent review must assess the frozen correction.

## Evidence sealing

`input-hashes.json` records scoped pre-edit repository inputs and discovery-report input hashes. `primary-source-hashes.json` records fresh authority bytes. `output-hashes.json` records frozen output. `artifact-hashes.json` binds every saved artifact except the manifest itself. Private artifacts remain outside the repository/publication tree. No further page edits follow this freeze.
