# Independent SOURCE review: configuration precedence and change impact

Reviewer: `/root/a98_precedence_composition_source_fresh`. Fresh-context,
independent SOURCE role, initially and throughout read-only with respect to the
product and canonical pages. I am not their author, Clean-Reader, or Quality
reviewer. No sub-agent was used. Review date: 2026-10-10.

**Verdict: FAIL for this two-page SOURCE partition. One new material finding is
open: schema-valid platform shutdown timeouts can overflow the actual Node
timers and become 1 ms, but the effective-value and safe-change boundary omits
this behavior.** All other specifically reviewed family/composition rules below
agree with the original sources and bounded probes. This is not full acceptance
of A98-10, A98-11, A98, publication, or any live procedure.

## Exact candidate identity

Review input is the full immutable Git archive of
`6426d88697e238231b76c4680abbe8cb4619f43a`, plus exactly two canonical-page
overlays copied immediately from the main checkout and hash-verified before
review. I did not substitute the mutable main product, generated exports, or
later overall commits. The parent reported a later publication commit
`ab4a6ef3`; that is context only and is not the reviewed identity.

| Input | SHA-256 |
| --- | --- |
| `base.tar` | `7745d1d6996a85e64fcbd81ea1ec3cd76c078c6b5c060d9e7e42f4fdea3459c1` |
| `docs/site/reference/configuration-precedence.md` | `729ab6b6d3c4b1a9d6e3d8b5349a85db417fb75aac6394ddd059b3480ca056f1` |
| `docs/site/reference/configuration-change-impact.md` | `212fad85100cd942269f054c656458f37f3dcad11d60050ffa82af1e0440a8e5` |
| `full-candidate-manifest.json` | `b29f5096417494ff46e3dd553b8948f9dec4c555e48bd73e7361a6f2c2c99985` |

The private full candidate is `candidate/` in this evidence directory. Its 5,522
files have recorded byte lengths and SHA-256 hashes; their product/documentation
bytes were checked again after probes and remained unchanged. Files were made
read-only. It is a Git archive, not a mutable Git working tree; the two page
differences are the explicitly supplied overlays, not an unexplained dirty
checkout. Probe scripts, copied third-party dependencies, generated probe data,
logs, and reports reside outside `candidate/`. No main files, commits,
generators, publication, push, or cluster resources were changed by this reviewer.

## Individual assigned results

| Assigned item | SOURCE verdict | Concrete reason |
| --- | --- | --- |
| CFG-013 — Precedence and Effective Values | FAIL | The merge/selection rules and ordinary defaults pass the reviewed source checks, but the complete path from schema-valid platform input to actual timer-consumed duration omits F-01. A recorded or captured value of 2,147,483,648 ms is not the effective timer duration. |
| CFG-014 — Change impact | FAIL | F-01 leaves a material safe-change boundary missing: increasing the shutdown allowance beyond the Node timer range can make it approximately 1 ms after the loader accepts it. |
| A98-11 — assigned two-page SOURCE partition only | FAIL | F-01 prevents complete authored-input-to-actual-consumer explanation for the explicitly covered platform timeout family. Independent negative and conflict checks for the other named paths pass as recorded below. |
| A98-10 — named source-behavior subset only | FAIL | For the covered `shutdownTimeoutMs` field, schema acceptance and effective timer bounds are not separated. This does not evaluate recursive field inventory completeness. |
| CFG-009 — contextual Helm catalogue entry | UNPROVEN as a whole | The named Helm merge/schema/receiver checks pass; the complete Helm/GitOps/infrastructure inventory is outside this assignment. |
| Whole A98-10, whole A98-11, Reader and Quality gates | UNPROVEN | No complete recursive inventory, all-family field inventory, publication/browser exercise, independent Reader task, Quality review, full mutation suite, or live acceptance was performed here. |

## F-01 — accepted shutdown timeout overflows into a 1 ms deadline

Severity: material documentation defect. Status: OPEN. Finding is independent;
it was discovered from the current original timer consumers and reproduced with
the unchanged original loader and AdapterRuntime. The prior deadline report was
not used as proof or as the implementation of this probe.

Exact authored locations:

- `docs/site/reference/configuration-change-impact.md:55` lists the accepted
  shutdown value as a required integer of at least 1 ms and describes it as
  setting the activation/readiness, invocation-cleanup, and shutdown allowance.
- `docs/site/reference/configuration-change-impact.md:100` begins the change
  validation sequence; it does not give an effective Node timer upper bound or
  a stop condition for a schema-valid overflow value.
- `docs/site/reference/configuration-precedence.md:30` describes platform
  required values and the effect-lock fallback, while the governing sequence at
  lines 21–24 ends at the loaded effective value. The two-page reference needs
  to carry the later timer-normalization boundary into this family explanation.

Current source chain, all byte-identical to the candidate and resolved at the
documented `fe426bd75db277b04cf405cc2057063b75fa0a1d` pin:

- `skills/common/plugin-runtime/foundation/config/platform.schema.json:95`
  specifies `type: integer`, `minimum: 1`, and no upper bound.
- `skills/common/plugin-runtime/foundation/config/platform.ts:63` loads and
  validates the file; path resolution/freeze preserves the authored timeout.
- `skills/nova/core/execution/engine-runtime.ts:84` passes the loaded shutdown
  value into AdapterRuntime.
- `skills/nova/core/execution/adapters.ts:79` passes that value directly to
  `setTimeout`; lines 78–82 race shutdown against its rejection.
- `skills/nova/core/execution/adapter-support.ts:17` and `:21`,
  `adapter-startup.ts:153` and `:162`, and
  `adapter-invocation-phase.ts:41` also use the captured duration in Node timers.
  Their different rejection/abort-only outcomes remain as documented; overflow
  changes the timer delay, not those distinct cleanup semantics.

Independent executed proof:

1. `node overflow-probe.mjs` supplied a complete platform JSON with
   `shutdownTimeoutMs: 2147483648` and omitted optional `effectLockTtlMs`.
2. The unchanged `loadPlatformConfig` accepted it and returned exactly
   `2147483648`. This was schema acceptance, not a bypass.
3. A synthetic local adapter became ready. Its shutdown promise deliberately
   remained pending and ignored its signal so the original normal shutdown
   deadline was observable.
4. Original `AdapterRuntime.shutdown()` rejected
   `ADAPTER_SHUTDOWN_TIMEOUT` after approximately **1.86 ms**. Node 24.21.0
   emitted `TimeoutOverflowWarning` and `Timeout duration was set to 1.`
5. The synthetic shutdown promise was released after observation. There was no
   external operation, pipeline recovery, unbounded wait, or live adapter.
6. A boundary check loaded `2147483647` and passed it to the original startup
   timeout helper. A synthetic readiness operation released after 5 ms completed
   before that timer; the long timer was cleared. The full 24-day duration was
   not awaited or claimed to have been measured.

Evidence: `overflow-probe.mjs`, `overflow-probe.log`,
`overflow-probe.execution.json`, `overflow-probe.boundaries.log`, and
`overflow-probe.boundaries.execution.json`. Both probes exited zero because
their assertions correctly detect the original behavior; the documentation
verdict is FAIL because this behavior is missing from the page. This is not a
proxy acceptance based on the number of passing assertions.

Required correction, without changing product behavior:

- Separate **schema acceptance** from **effective timer range**. Do not claim
  that the present JSON schema already enforces a maximum.
- State the current supported operational delay range for these Node timers as
  1–2,147,483,647 ms. Explain that larger schema-valid values are converted to
  a 1 ms timer in the checked Node 24.21.0 runtime and can sharply shorten waits,
  shutdown, or abort signaling.
- Add a pre-recreation stop condition for out-of-range shutdown durations and
  link the platform family/effective-value explanation to it. Capturing or
  recording the raw number does not verify the timer's actual delay.
- Preserve the separate effect-lock bounds/fallback, recovery-subset exception,
  and rejection-versus-abort-only cleanup explanation. Documenting this limit
  does not prove full recovery or repair the implementation schema.
- Treat any future loader/consumer guard as product work owned by runtime and
  platform configuration maintainers. Closure requires fresh-source review of
  the corrected pages, positive boundary and negative overflow evidence, and
  current source pins; no product schema fix was made in this review.

## Complete reviewed family and boundary results

These PASS results are individual source-behavior conclusions. They do not
cancel F-01 or convert the assigned catalogue/gate verdicts into PASS.

| Reviewed path | Result and supporting work |
| --- | --- |
| Single platform file, canonical-directory paths and frozen load | PASS: original loader and schema inspected; original platform contract passed; authority probes exercised preserved values and invalid timeout bounds. No second file/project merge was inferred. |
| Explicit graph and stage configuration | PASS: schema validation preserves values; stage-executor passes `definition.config` and `definition.input`; graph snapshot comparison rejects a changed stage execution timeout. No inheritance from project configuration is implemented. |
| Nova project | PASS: full compiler, project CLI, source binding and recovery compiler read. Stable topological order with ID ordering, materialized source/repository bindings, sequential project graph, compile artifact reporting, and whole-graph recovery verification agree with these pages. No project or full CLI run was executed. |
| Suite overrides | PASS: `uses` cannot be overridden; selected template configuration recursively merges objects and replaces arrays/scalars; evidence outcome settings merge separately. Actual resolver probe confirms the provider remains unchanged and defaults preserve explicit empty strings. |
| Suite additions and direct nodes | PASS: suite add rejects any template ID even after exclusion; direct scope declarations reject selected-ID reuse; distinct IDs compose. Actual original resolver probes and the full original suite contract cover these paths. Duplicate-ID rejection has no precedence winner. |
| Matrix/provider defaults/policy ceilings | PASS: matrix object values deep-merge into prior node config; provider schema resolution clones and inserts defaults for absent fields. Timeout and resource requests above policy maxima reject, rather than clamp. Suite concurrency uses the minimum request; direct scope concurrency can narrow it and rejects widening. Explicit policy concurrency overflow rejects. |
| Coupled `.swarm` authority | PASS from full source: committed current pointer selects the pair; present damaged publication does not fall back; materialized copies must agree; publication commits through one pointer after generation/member and materialization work. No new pair publication, native locking, corruption exercise, or concurrent writer was executed. |
| Compact expander | PASS: complete helper and standard profile read plus caller sections. Context/webhook insertion precedes override validation; known-path recursive objects and array/null replacement work; placeholders use raw input `repo_root`; caller normalization, run ID reassignment, environment webhook choice and scenario changes follow. Probe checks example result, absent target, malformed compact inputs and exact noncompact pass-through. It proves no downstream path, credential or complete run-builder behavior. |
| Helm list/map/scalar composition | PASS: executed ordered-file examples, reversed order, nested map preservation, array replacement, map `{}` preservation, bounded map `null` removal, and repeated same-kind CLI scalar selection. No mixed-option or upgrade-reuse order was generalized. |
| Whole Prism collections and image policy | PASS: schema/template sources read; local baseline plus all four empty/Always image-policy failures, empty pull-secrets, duplicate/over-100 operators and enabled empty operators produce expected schema exits. Enabled authority settings and template guards are separate from a valid list. |
| Helm receiver/fallback/Secret boundaries | PASS: actual selected environment, selector, resources, URL fallback, three file payload fallbacks and synthetic Secret name/key asserted from rendered YAML. Original templates/checksums and init actions inspected. Rendering does not establish Secret existence, credentials, admission or runtime consumption. |
| Startup webhook and persistent policies | PASS from source: authored webhook is removed from persistent copied source; runtime copy inserts it only from nonempty environment. Semgrep/ESLint files are preserved unless absent or override enabled. Pod-template checksum changes do not by themselves prove a persistent policy was replaced. No init pod or volume was executed. |
| GitOps | PASS: full template read and synthetic complete-revision/group/destination render selected Application fields; empty groups and branch revision reject. Reconciliation and availability of the synthetic Git revision were not inferred. |
| Kubernetes environment and startup capture | PASS from consumer/template sources: loader-specific `||` versus `??` behavior and startup capture matter; rendered/Secret-backed environment changes need replacement consumers. No hot reload or live credential-rotation claim was accepted. |
| Plugin registry versus consumer defaults | PASS: full registry validation/default resolver inspected. Stages/observers/adapters do not insert schema defaults; test-provider values are cloned/defaulted. Human approval parser supplies its own 60-minute fallback. Direct-command absent/empty collections still yield CI environment, and the shipped common command-runner rejects that payload. Successful execution through that incompatible boundary was not claimed. |
| Observer precedence | PASS from source plus actual merge helper: registration/service/hook order ignores undefined keys, preserves later null/empty values; defined config beats environment before normalization. Empty host does not retry the environment fallback. Full resolver execution was NOT RUN because the archive lacks its generated agent-observability binding; no mutable main generated export was used. Authoritative normalizer source was also read. |
| Buster empty-value fallback | PASS from actual entrypoint: absent/empty string selects 2 via `||`; nonempty `"0"` becomes numeric zero. This is value selection, not a claim that downstream runtime admission accepts zero. |
| Prism startup and native pool | PASS from full Control composition/product loader/native configuration and worker policy/resource-pool/readiness sources: startup snapshot captured before signing-key I/O; root-owned pool authority determines aggregate bounds; environment does not alter actual cgroup limits. Readiness verifies the actual pool. No root host preparation, launcher, cgroup mutation or worker readiness run was executed. |
| Platform timeout recovery subset | PASS except F-01 effective timer bound: actual `prepareRuntime`/snapshot authority probes show the subset excludes both fields; changed shutdown/lock/both/absent lock pass package/config/graph comparisons without stored rewrite; stage timeout and adapter config differences reject at their own pins. Full recovery handoff/retained run ID checked from source only. No `recoverPipeline` or `resumePipeline` was executed. |
| Timeout cleanup distinctions | PASS: actual isolated AdapterRuntime/phase/helper probes distinguish rejecting normal shutdown/invocation cleanup from readiness teardown/startup rollback/late cleanup that await an ignored abort. Activation deadline rejects before background late cleanup completes. All deliberately pending synthetic operations were released. |
| Effective inspection, safe change and rollback | FAIL only for F-01 in reviewed scope: consumer/artifact/digest/reference evidence is preferable to secret values; run graph/config/package pins, data-format and external-effect uncertainty remain explicit. Preserving configuration is necessary but not sufficient for rollback. Live rollback and a complete recovery are not established. |

## Read scope and source revision verification

Read in full: `docs/blueprint/07-documentation-quality-standard.md`, the complete
`AP09-acceptance-contract.md`, and both complete frozen canonical pages.
CFG-013 and CFG-014 catalogue objects and CFG-009 contextual object were read
from the archived catalogue. Fixture structure, A98-10/A98-11 binding searches,
and the contextual configuration mutation variants were inspected from
`AP09-acceptance-fixtures.json`. This archive has no specifically bound static
Reader or execution scenario for the named two-page partition; that absence
does not waive either full gate's requirements or make local probes full gate
evidence. No fixture or mutation constructor was rewritten.

`read-scope-linked-ranges.md` records the actual linked source scope: 98 links
in 42 distinct files. Every documented `d57ac3568d29ae757173d15499ce48549c22eb4f`,
`fe426bd75db277b04cf405cc2057063b75fa0a1d`,
`ec2a42ed215a2fa7dbd3172ef70ef446084963a9`, and older pin resolves to a regular
Git blob of mode 100644 or 100755. All requested ascending ranges are within
their files. All linked full-file bytes match the archive candidate; the pins
therefore are not stale for these linked files. This was verified with Git
object reads, not network existence or author assurance. The ledger
`source-links.json` saves revision, path, range, mode, Git blob ID, current-byte
match and SHA-256 for each link. I read the linked content and material current
caller/consumer logic independently; link resolution alone is not the verdict.

Additional current material source read beyond those snippets includes full
`skills/nova/project/{compiler,cli,source,recovery}.ts`, registry activation,
the original complete suite-resolver contract, native pool policy and resource
pool, native ownership/readiness sections, Prism host/server composition and
the agent-observability authoritative normalizer. The complete resolver,
compact helper, platform/runtime/snapshot/run control, adapter deadline paths,
effect coordinator and durable invocation sources were read, not just the last
reported finding. Narrow chart excerpts were read with whole relevant helpers,
Prism schema condition blocks and whole GitOps/configmap templates.

I did not adopt prior `precedence-source-deadlines-fresh/report.md` conclusions
as proof. I did not run or inspect mutable main generator exports or accept
author check counts, page hashes or successful builds as substantive acceptance.
Historical execution claims printed on the pages are not independently
authenticated by this source review; current executed records below establish
their specifically checked behavior only.

## Executions, preserved initial failures and limitations

Environment: Linux 6.8 x86_64/musl, Node `v24.21.0`, Helm
`v3.22.0+g144ca65`. External npm dependencies were privately copied with versions
recorded in `environment.json`; workspace package links resolve exclusively to
the private archive candidate. No credentials were used or printed.

| Command | Actual exit and evidence |
| --- | --- |
| `node tests/verification/contracts/check-plugin-system-v2-platform-config.mjs` from candidate | 0; `contract-0.log` and `contract-executions.json` |
| `node tests/verification/contracts/check-pipeline-test-suite-resolver.mts` from candidate | 0; `contract-1.log` and `contract-executions.json` |
| `node source-probes.mjs` first attempt | 1; genuine reviewer probe syntax error, preserved in `source-probes.initial.log` |
| `node source-probes.mjs` second attempt | 1; immutable archive lacks generated observer contract binding, preserved in `source-probes.second.log` |
| `node source-probes.mjs` after syntax correction and explicit removal of blocked observer-execution cases | 0; 19 named behavioral scenarios passed; `source-probes.third.log`. The omitted observer execution remains explicitly NOT RUN/source-only. |
| `node authority-probes.mjs` | 0; 13 named actual preparation/snapshot authority cases; `authority-probes.initial.log` |
| `node helm-probes.mjs` initial attempt | 1; reviewer's synthetic GitOps baseline omitted required repository/project/root fields. Twenty-one preceding render outcomes and the failing input/error are preserved in `helm-initial/` and `helm-probes.initial.log`. This was not a product defect. |
| `node helm-probes.mjs` corrected synthetic baseline | 0; 24 actual render cases with their expected zero/one exits; `helm-probes.corrected.log` and each command/render/error in `helm/executions.json` and `helm/`. |
| `node overflow-probe.mjs` | 0; original loader accepts overflow, actual shutdown deadline falls to 1 ms and rejects as expected. First and boundary-enhanced results both retained. The documentation finding is F-01. |

Not executed or not established: a complete pipeline run or recovery/resume with
changed platform timing; durable effect/lock acquisition or renewal; a live
adapter's stop behavior; deployed observer Redis connectivity; native sandbox
build/session execution; real cgroup/host readiness; Kubernetes admission,
controller reconciliation, capacity, image/Secret existence, pod rollout,
persistent-volume init, credential rotation, drain, rollback, or data migration.
Original historic recovery-version/isolation-session test outcomes were not
re-run here. No browser/download, full mutation duplicate, publication gate or
live-cluster operation was performed.

These explicit unexecuted limits remain UNPROVEN; preparation/snapshot checks
are not represented as actual recovery, local render is not deployment, and
synthetic pending promises are not live cleanup proof. One must still correct
F-01 and perform the applicable independent fresh re-review; no catalogue,
whole gate or parent package can be accepted from author/hash/check-count alone.

**Freeze release:** This review is complete against the exact two supplied page
hashes and base archive identity above. I explicitly release the parent's freeze
on both canonical page contents. Any correction is a new candidate and requires
fresh review of the affected authored-input-to-timer/safe-change path. The
immutable private evidence remains retained; no correction or product edit was
performed by this reviewer.
