# Independent bounded SOURCE review — Argo CD and Cilium

Reviewed revision: f68a7294abf0928c1aabf290c6a7e486c651a808. Role: fresh-context read-only SOURCE reviewer. No main-tree edit, commit, push, deployment or live acceptance. This is a bounded CFG-009 / A98-10 / A98-11 source partition, not an A98 or Sol approval.

Verdict: FAIL. The full semantic source-proof obligation remains incomplete. The ledger explicitly distinguishes concrete documentation failure from UNPROVEN; neither permits acceptance.

## Scope and inputs

The original Git archive is in source/. Captured generated inventories and the page are in captured/. All 35 captured files were compared with the immutable archive: 31 equal; 4 generated outputs differ (configuration-values.json, configuration-schemas.json, documentation-source-revision.json, helm-values.md). Those four are explicitly the supplied captured generated acceptance inputs, never current mutable output. No current HEAD4da producer/output is used. Capture equivalence is saved separately.

Contexts are kind plus field path with actual array indices normalized to []. The frozen scope contains 77 contexts: 28 Argo and 49 Cilium, 661 collection occurrences and 687 scalar occurrences. Independent recursive schema expansion yields 1550 unique schema boundary records. Counts include metadata and conditional alternatives, and are computed, not fixed acceptance thresholds. Every actual occurrence is attached individually. Exact schema fragments, pointer/line locations when available, origins, missing children and corrections are preserved. Recursive definitions are deduplicated without removing their originating obligations.

Primary fetched bytes were copied only after verifying every pinned manifest SHA-256 and byte count (29 successful sources). Three compressed API authorities and two chart archives also pass independent compressed/uncompressed/size checks. Argo rendered CRDs come from the digest-pinned chart10.8.0; controller Go authority is e258ee23c3e52266d407572f4bcdfe7d9ed36cb5 /3.5.2. Cilium controller sources are tag1.20.1 with frozen source hashes; published prose links use7d68cfb394f2960e10aa72e76d0d51e66c1b2ebc. Chart identity and controller identity remain separate.

The complete quality standard and acceptance contract were read, with the relevant catalogue CFG-009 and registered config/secret mutation variants. The latter require the original pre-registered root mutation run; this reviewer does not substitute an invented mutation or repeat that active run.

## Material findings

F1 — Recursive exposure is shallow, not a complete qualified public contract. The original helper intentionally resolves only the requested node/direct children and strips properties/items from child fragments (source/scripts/docs-api-schema-authorities.mjs:308-339). Application.spec exposes sourceHydrator, info and nested generator branches; Application source Helm exposes parameters/fileParameters and other options; Cilium direction items expose additional CIDR/FQDN/ICMP/L7/authentication/TLS branches. These public child collections have no separate canonical row or independently established full validation/default/consumer/secret/change/recovery route. Contexts containing them receive FAIL with exact missing boundary keys. A schema description is retained as schema evidence, not treated as receiving implementation proof. No sample is extrapolated to PASS.

F2 — Application.syncPolicy.syncOptions fails scalar meaning depth. Actual authored values FailOnSharedResource=true, ServerSideApply=true and RespectIgnoreDifferences=true all have the same generic adds-one-option meaning. The canonical row says exact names decide behavior but does not qualify each option's evaluator, resource-annotation precedence, SSA field ownership/migration/replace interaction, shared-resource stop condition, or RespectIgnoreDifferences prepatch condition. See captured scalar occurrence records and captured/docs/site/reference/helm-values.md rows for gitops/platform/bootstrap/alloy.yaml and spire.yaml. Frozen source contracts in primary/argo-types.go define only string slices, not these runtime effects. Correct with pinned controller and actual gitops-engine consumer evidence, then repeat source review.

F3 — Remaining leaf/context contracts are UNPROVEN, never waived. Source-schema equality is established for all77 contexts, but it is not complete accepted/default/null/conflict/controller/secret/recovery proof. Every unresolved boundary and every scalar occurrence is explicitly recorded. The full receiving implementation of all1550 recursive boundaries was NOT independently established. This report must not be presented as a completed exhaustive semantic review or acceptance.

## Confirmed source facts and truthful product boundary

The Cilium zero-direction-rule limitation is truthful Source-only product evidence. primary/cilium-validation.go:42-46 rejects all four empty direction lists. Lines47-64 prove feature-dependent default-deny overrides; lines66-85 prove root endpoint/node selector mutual exclusion. primary/cilium-cnp_types.go:191-201 and cilium-ccnp_types.go:97-107 call Sanitize. Captured rows state effect, safe stop, owner and later parser/traffic verification conditions without claiming a live execution. This product limitation does not itself cause FAIL and does not require an invented live result.

AppProject nil-versus-empty namespaced whitelist distinction matches primary/argo-project.go:399-418. Repository/destination iteration and negative pattern behavior are in458-530. Cilium explicit empty selector/entity handling is in primary/cilium-utils-parserules.go:149-166; zero L4 with nonempty L3 yields broad transport allowance in primary/cilium-policy-rule.go:356-413. Omitted/empty protocol and extended protocol conditions are in primary/cilium-ports.go:43-83 and cilium-validation.go:607-637. These concrete confirmations remain bounded and do not waive unselected children or actual version/effect routing.

## Executed and not executed

Executed: immutable Git archive extraction; captured-to-archive byte comparison; independent vendor/primary SHA-256/byte validation; digest-pinned Argo chart CRD rendering with helm template api-authority --include-crds --set crds.install=true (exit0); independent recursive schema inventory (exit0); original immutable helper comparison against every77 captured contracts (all equal, exit0); unknown-field input negative control (API_SCHEMA_FIELD_MISSING as expected, exit0). Source helper calls use frozen original code and normal installed YAML dependency; no inventory producer was called.

Not executed: original registered mutations (root runs these), full per-boundary controller semantic qualification, full scalar-effect qualification, unit/controller code execution, API admission, synchronization, deployment, live parsing/enforcement, traffic/recovery or clean-reader exercises. The unknown-field check is a bounded input negative control, not a registered mutation result. No fabricated success output or Source-to-Live promotion.

## Integration condition

Fix explicit FAILs and establish every UNPROVEN obligation before promoting this partition. Main-tree changes require reviewed-source equivalence or fresh changed-scope review against the final immutable commit. A98-10/A98-11 remain FAIL in this partition; A98-14 original mutation execution remains outside this report and pending root evidence. No overall A98 claim is authorized by this report.

Computed context verdicts: {"PASS": 0, "FAIL": 39, "UNPROVEN": 38}
