# Fresh SOURCE review: configuration precedence and change impact

Reviewer: `a98_precedence_source_deadlines_fresh` (`/root/a98_precedence_source_deadlines_fresh`). Role: SOURCE only. Fresh context and initial read-only product mode confirmed. I did not author either page, act as the Reader or Quality reviewer, or delegate review work.

Result: **CFG-013 FAIL; CFG-014 PASS; A98-11 two-page SOURCE partition FAIL.** One new material finding remains in the family table's description of test-node composition. Successful compact, Helm, timeout, and startup checks do not close that finding. This report gives no global A98-10, A98-11, AP09.8, or documentation acceptance.

## Frozen candidate and authority

- Product archive revision: `d57ac3568d29ae757173d15499ce48549c22eb4f`, obtained through `git archive` from the designated repository's immutable Git objects.
- Main repository: `/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04`; designated branch `docs/documentation-overhaul` confirmed.
- Candidate: the complete archived base plus exactly the two frozen authored-page overlays. It is not described as an already committed, clean full documentation revision. The parent may have committed identical pages while keeping this freeze.
- Private archive: `base.tar`, 141711360 bytes, SHA-256 `28bb520284212decec8d975bb78beacb0f39341242f9e4776dbce840ecb1cdbd`.
- Frozen precedence page: `pages/configuration-precedence.md`, SHA-256 `f53780959590fa0600918a14e39636dcf431dd7209c13712dac9062336cb7762`.
- Frozen impact page: `pages/configuration-change-impact.md`, SHA-256 `212fad85100cd942269f054c656458f37f3dcad11d60050ffa82af1e0440a8e5`.
- The same pages are overlaid at their canonical paths in `source/docs/site/reference/`. All archived regular files were compared byte-for-byte, allowing only those two exact overlays: no unexpected tracked differences (`candidate-verification.json`). Product source files and page copies are read-only on disk.
- All 88 source links from the complete pages were inspected for Git mode, range, and byte equality: every target is mode `100644` or `100755`, every range exists, and every linked file is byte-identical to the base. This includes all `fe426bd75db277b04cf405cc2057063b75fa0a1d` and `ec2a42ed215a2fa7dbd3172ef70ef446084963a9` runtime/chart references, as well as older family evidence pins. Exact hashes, paths and ranges are in `pin-verification.json`.
- Main's unrelated generated-inventory changes are recorded in `main-status.log`. I did not write generators, fixes, commits, deployment state or exports in main, and did not use mutable product exports as code authority.

## Contract and catalogue scope

I read the complete archived `docs/blueprint/07-documentation-quality-standard.md` and `docs/blueprint/AP09-acceptance-contract.md`, both complete frozen pages, and CFG-013/014 with CFG-009 context in `docs/blueprint/generated/ap09-catalogue.json`. Relevant fixtures were read from `docs/blueprint/AP09-acceptance-fixtures.json`.

CFG-013's canonical target is the precedence page and asks for the shared pipeline, host, Helm, GitOps, environment and Secret model plus safe effective-value inspection. CFG-014's canonical target is the change-impact page and asks for a change matrix. CFG-009 supplies Helm/GitOps recursive-inventory context; its complete inventory is outside this assignment.

The fixtures assign no static reader task or explicit additional execution scenario to A98-10/A98-11. The contract still requires their PRIMARY gates for integrated acceptance. This SOURCE report does not fabricate those integrated runs. Config add/change/remove mutations and other partitions belong to separate evidence; I did not repeat a full mutation package.

| Requirement / assigned partition | Verdict | Reason and boundary |
| --- | --- | --- |
| CFG-013 SOURCE | FAIL | R1 presents composition as a strict precedence ladder, implying direct nodes supersede suite nodes. The actual resolver rejects conflicting identities. Other reviewed families agree with source. |
| CFG-014 SOURCE | PASS | The complete change matrix and explanations distinguish captured consumers, persisted recovery authority, pod-template effects, startup-file preservation, external-effect uncertainty and rollback boundaries accurately. Local proofs remain explicitly below full runtime/recovery/cluster proof. |
| A98-11 two-page SOURCE partition | FAIL | R1 leaves the conflict rule incorrect/incomplete in the common model. Checked compact/Helm/timeout paths agree with source, but cannot compensate for this failure. |
| A98-10 two-page source-behavior support subset | PASS | The named setting types, defaults, bounds, owners/consumers and receiver boundaries on these two pages match their sources. This is not acceptance of the recursive full inventory or CFG-009; no full A98-10 verdict is issued. |

## R1 — Direct test nodes are additions, not a higher-precedence layer

- Finding location: `docs/site/reference/configuration-precedence.md:28` and `:33` in the frozen page.
- Text: the column is headed “Lowest to highest precedence”; the `.swarm/pipeline.json` row lists “Suite template → suite exclusion/override/add → direct scope nodes → matrix values → provider schema defaults → resolver policy defaults/caps”.
- Material problem: this treats direct scope declarations and `add` as higher-priority replacement layers. A direct `tests["selected/node"]` declaration cannot replace the selected suite's `node`. The resolver rejects `TEST_PLAN_NODE_DUPLICATE:selected/node`; neither declaration wins. Likewise suite `add.node` cannot replace a template node, including a template ID that was excluded. The page's later implemented-merges callout links real code but does not state this conflict rule or correct the table.
- Source: `skills/nova/core/test-gates/resolver.ts:328-331` (`addNode` duplicate guard), `:370-375` (known-target override validation and selected-template insertion), `:377-380` (add collision guard), `:384-389` (direct declarations added through the same guard), and `:236-243` (`mergeNode`). These bytes are equal at base and the page's `10e95ee97567cd42357e95d2a443aee4732b359c` pin.
- Narrow source links: [duplicate guard](https://github.com/datrab/kubeclaw/blob/d57ac3568d29ae757173d15499ce48549c22eb4f/skills/nova/core/test-gates/resolver.ts#L328-L331), [selected suites and additions](https://github.com/datrab/kubeclaw/blob/d57ac3568d29ae757173d15499ce48549c22eb4f/skills/nova/core/test-gates/resolver.ts#L370-L380), [direct declarations](https://github.com/datrab/kubeclaw/blob/d57ac3568d29ae757173d15499ce48549c22eb4f/skills/nova/core/test-gates/resolver.ts#L384-L389), [actual suite merge](https://github.com/datrab/kubeclaw/blob/d57ac3568d29ae757173d15499ce48549c22eb4f/skills/nova/core/test-gates/resolver.ts#L236-L243).
- Independent negative proof: `node collision-probes.mjs`, exit 0, records two asserted expected rejections in `collision-probes.log`: a direct/suite ID conflict and a suite-add/template ID conflict. Both reject before provider resolution. The probe supplies synthetic inputs, not a live provider or pipeline.
- Required correction: distinguish composition/resolution order from precedence in the table heading and row. Explain that `suites.<instance>.overrides.<node>` modifies an existing template node, `uses` remains fixed, `add` and direct nodes add distinct IDs, and conflicts reject rather than select a winner. Keep matrix configuration merge, default insertion and guard evaluation separate. Preserve this negative behavior in the corrected explanation and rerun an independent complete SOURCE review of both pages.
- Acceptance impact: CFG-013 and the assigned A98-11 SOURCE partition fail. CFG-014's correct timeout/Helm content does not compensate.

## Full table and explanations rechecked after R1

I re-read the entire table and its associated explanations, then traced the actual resolver from declaration parsing through final validation and freezing. The distinction below is essential to the correction.

| Family | Source check |
| --- | --- |
| Pipeline platform | One canonical file; schema validates without default insertion; canonical parent directory resolves installation/trust/storage/isolation paths; deeply frozen load. Required shutdown and optional effect-lock fallback agree. |
| Explicit pipeline graph | Stage configuration and input pass through unchanged; registration validation does not insert schema defaults. Stage-owned defaults are conditional consumer decisions, not universal higher-priority layers. |
| Nova project | Compiler constructs a distinct graph and source binding; stable topological module order uses sorted IDs and rejects unknown/cyclic dependencies. It does not merge platform authority. |
| Test nodes | The table has R1. Parsing fixes known fields and `uses` for overrides. `mergeNode` recursively merges only configuration objects, replaces arrays/scalars, and merges evidence outcomes separately. Selected-template/add/direct IDs are composed with rejection on collisions. Matrix keys must be allowed; Cartesian variants recursively merge into the selected node configuration. Schema defaults insert only absent values in a clone. Timeout/limit/concurrency policy maxima reject excessive requests; they do not clamp them. Suite concurrency uses the minimum across selected suite requests; direct scope limits may lower a suite ceiling and reject widening. Provider-plan output remains resolved data. |
| Coupled `.swarm` files | Present publication metadata commits one generation; loose current copies must match; damage rejects without loose-file fallback. Publication materializes both members before committing the pointer. |
| Helm | Ordered files and same-kind repeated scalar options checked; arrays replace, maps merge recursively, empty maps retain prior entries, tested null removal is bounded to nodeSelector. Prism collection/image schemas and GitOps guards precede successful render. |
| Kubernetes environment | Template value/Secret reference and each loader's specific empty-value condition are distinct. Environment capture is a startup boundary; a reference render does not validate Secret contents/existence or establish hot reload. |
| Compact expander | Profile clone → supplied context/webhook → known-path validation → recursive object merge or replacement → raw-root placeholder traversal. Caller normalization/run-ID/webhook/scenario changes follow expansion. Noncompact inputs pass through unchanged. |
| Prism | Composition captures one environment snapshot and signing key; root-owned pool policy supplies actual aggregate limits. SPIFFE mode switches credential authority. Chart render does not prove native capacity/readiness. |
| Plugin configuration | Registry stage/observer/adapter validators preserve authored values; provider schema resolver clones/defaults; approval and direct-command consumers own fallback rules. OpenClaw observer defined-key merge is registration → service → hook, then environment fallback per undefined key, then normalization. Null/empty values remain explicit before normalization. |

I also checked the remaining complete-page statements: safe redacted effective-value inspection, absence/empty/null/false distinctions, direct-command environment incompatibility, Buster's empty-string numeric fallback, graph/package/configuration change classes, Secret rotation/capture, startup ConfigMap handling, policy-file persistence, checksum selection, source revision limits, and rollback/external-effect uncertainty. No additional material SOURCE finding was found. This is not a language, architecture-quality or Reader acceptance.

## Executed checks and evidence

Environment: Linux container; shell `sh`; Node.js `v24.21.0`; Helm `v3.22.0+g144ca65`; execution date 2026-10-10 UTC. Product workspace packages resolve exclusively to archived private source through private `node_modules/@kubeclaw` links. Only third-party dependency links refer to the existing dependency installation; no mutable main product package is imported.

| Actual command/check | Exit/result | Artifact and scope |
| --- | --- | --- |
| `git archive d57ac3568d29ae757173d15499ce48549c22eb4f` plus immediate authored-page copy and `sha256sum` | 0; both assigned hashes match | `base.tar`, `candidate-verification.json`, frozen pages. Full archived regular files checked against base plus exact overlays. |
| `python3 verify-pins.py`; regular-mode and full-candidate verification | 0; 88 links, zero invalid ranges/unequal source files; zero unexpected tracked differences | `pin-verification.json`, `candidate-verification.json`. Not publication/browser proof. |
| `node probes.mjs` | 0; 11 assertion groups | `probes.log`. Compact context/raw-root/shape/invalid input and six deadline/cleanup paths, plus frozen platform loader/bounds. Multiple assertions per group; not the author's original 17/11 harness. |
| `node snapshot-probes.mjs` | 0; 6 scenario groups | `snapshot-probes.log`. Actual `prepareRuntime`, writer and package/graph verifiers: four timeout-only changes permitted without snapshot rewrite; adapter config and stage deadline drift rejected. No pipeline or recovery executed. |
| `node helm-probes.mjs` | 0; 25 local renders: 11 success, 14 expected exit 1 | `helm-probes.log`, `helm-artifacts/*`. Private equivalent JSON overlays and actual charts: base/empty/remove/reverse, nested map, array replacement, repeated scalar, URL/file fallbacks, selected Secret pair/no generated Secret, Prism baseline and fourteen schema/template failures across Prism/GitOps. This is a separate independent SOURCE probe, not a Reader execution of the authored commands or the author's 24-check harness. |
| `node startup-probes.mjs` | 0; 5 groups | `startup-probes.log`, `startup-policy-excerpt.sh`. Exact pinned Node normalization/composition statements and policy-copy shell blocks, changing literal filesystem paths to private fixture paths. Empty/nonempty webhook, policy preservation/override/absent-file copy. Not complete init/PVC/pod execution. Swarm ConfigMap copy and runtime policy-copy statements also traced directly in source. |
| `node collision-probes.mjs` | 0; 2 expected duplicate-ID rejections | `collision-probes.log`. Direct/suite and add/template collisions reject as above. |
| From `source/`: `node tests/verification/contracts/check-plugin-system-v2-platform-config.mjs` | 0; `ok: true` | `platform-contract.log`. Existing local platform authority contract. |
| From `source/`: `node tests/verification/contracts/check-pipeline-test-suite-resolver.mts` | 0; nodes 10, links 2, digest `sha256:3bdbfe8cf273589f5c48222f5601015d0c072228ed74a99a5efd0a04af42b55a` | `suite-contract.log`. Existing complete suite resolver contract including negative cases, schema default behavior and policy/concurrency checks. |

Every deliberately pending promise in the deadline probes was released in `finally` and then awaited. The three abort-only cleanup probes asserted that the caller remained pending after its signal aborted, released their synthetic shutdown promise, and awaited the final result. Normal shutdown and invocation-cleanup probes likewise release underlying work after observing deadline rejection. No deliberately pending operation or live resource is left by this review.

## Genuine harness failures retained separately

These are reviewer-harness failures, not product/documentation failures, and do not count as passed checks:

1. `probes.initial-harness.mjs`: exit 1 (`probes.initial-harness-failure.log`). I initially expected a raw-root guard without supplying any referenced placeholder. Source only requires the guard when a placeholder is actually present. Added an explicit `${repo_root}` replacement in the synthetic input; corrected harness passes.
2. `startup-probes.initial-harness.mjs`: exit 1; its shell subcommand exited 2 (`startup-probes.initial-harness-failure.log`). The selected policy excerpt omitted the final outer `fi`. Extended only the extraction range through source line 649; corrected harness passes.
3. `snapshot-probes.initial-harness.mjs`: exit 1 (`snapshot-probes.initial-harness-failure.log`). The synthetic adapter illegally provided zero capabilities. The original manifest schema rejects this.
4. `snapshot-probes.second-harness.mjs`: exit 1 (`snapshot-probes.second-harness-failure.log`). The synthetic adapter provided an unknown capability. Replaced that fixture declaration with known `artifacts.read`; corrected harness passes. Product code was never patched.

Read/discovery attempts also encountered absent guessed source paths, absent Python PyYAML, and an initially doubled `source/source` dependency path. These were not verification successes and did not lead to installation, mutable-product fallback, or hidden code generation. YAML parsing for the successful Helm probe uses the installed Node `yaml` library. The initial shell that ran the first helper harness and then printed its log returned the log-printing command's zero exit; the retained Node exception is the actual failed helper outcome, not a pass.

## Unexecuted limits

- No complete pipeline execution, changed-timeout resume/recovery, active-effect drain, effect-lock acquisition/renewal with a real adapter, or external operation was performed. Actual lock acquisition/renewal TTL capture and renewal interval were read in coordinator/durable-invocation source.
- No Kubernetes API admission, Argo CD reconciliation, scheduling, pod replacement, persistent-volume init execution, readiness, credential rotation, cluster rollback, host/cgroup setup, target-image execution or live enforcement was attempted.
- No full mutation duplicate, generator regeneration, recursive CFG-009 inventory audit, full A98-10 gate, Reader task, language/quality gate, browser/publication render or global evidence ledger was executed.
- The pages' recorded earlier test results are their historical evidence claims. This review supplies separate independent checks and does not claim to have rerun every original authored harness or both earlier reliability suites. The pinned implementations/tests were inspected and bytes compared.
- Read the cloud runtime skill at start. Its environment-status tool was unavailable in the active tool catalogue. No network, Docker, VPN, remote credential or deployment action was needed or performed.

Only R1 prevents the assigned SOURCE partition from passing. The required next action is to correct its composition/conflict explanation, then obtain a new independent complete two-page SOURCE review. All other evidence classes retain the limits above.

## Freeze release

This SOURCE review is complete. I explicitly release the parent's content freeze on both main authored pages. The reviewed copies and evidence remain fixed in this private directory. Subsequent page edits are a new candidate and are not covered by this report's verdicts.
