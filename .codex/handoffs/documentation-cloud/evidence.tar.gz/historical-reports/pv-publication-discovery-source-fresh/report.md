# Independent Source review: FAIL

Scope: generic script API publication discovery correction only. This is not global A98 acceptance. Read-only repository review at HEAD `4a381a370e4ca90bdae53f27bfee759704f1300c`, with uncommitted frozen discovery SHA256 `62f1f6ece0ee2c9a0d9fff6500ef750c81df34fc360068e9e233862f4afc634e` and author tests SHA256 `89bef769780732176dbaf66e984e8baf4d750a36fc2dab5368bb2b082830ad8c`. Full correction versus HEAD read, actual serialized output role classifier read, quality standard read, and relevant A98-10/A98-14 discovery/drift requirements read. Author evidence directory located only; its reports/logs were not used as proof. No source edits, full configuration gate, Go invocation, publication, or live validation performed.

## Blocking findings

1. **Exported returned projection silently disappears (detection cut).** `export function build(){const record={body:{apiVersion:'v1',kind:'ConfigMap',metadata:{name:'projected'},immutable:true}};return record.body}` produces `[]`. Independent `assertProductApiContexts([],root)` then passes. An API resource actually returned by an exported builder can be added without drift detection. The new `nested` branch requires a role `api` and a role line matching each publication. The actual classifier registers exported returns only for selected serialized/raw text forms; a plain resource return has no role. Previously this nested constructor was retained. See discovery lines 698–711 and classifier lines 187–188/571. This violates requested preservation of returned/exported builders and the maintenance boundary.

2. **Returned List child is removed.** `export function build(){return {apiVersion:'v1',kind:'List',items:[{apiVersion:'v1',kind:'ConfigMap',metadata:{name:'child'},immutable:true}]}}` inventories only `List`, whereas an exported returned array inventories its ConfigMap child. Nested List items encounter the same role gate; the List itself remains through the legacy nonnested constructor path. The child remains as a JavaScript value inside the List output, but no independent ConfigMap output/context is produced. Generic API-kind field joins cannot be assumed to reconstruct it. Requested discovery of actual List children is not preserved.

3. **Metadata classification depends on syntax instead of publication root.** `const authoritySelector={apiVersion:'v1',kind:'PersistentVolume',fieldPath:'$.spec'};const record={authoritySelector};console.log(JSON.stringify(record));` still inventories a PV containing `fieldPath`, although only the native record is serialized. The original inline form now returns `[]`; the separately bound equivalent does not. The correction scans AST nesting only for some constructors, while all nonnested constructors retain legacy unconditional discovery. No name/file exemption was added, but actual root semantics are incomplete.

## Independent observations

The frozen author suite was executed directly: six tests PASS. It demonstrates that the actual PV receiver source and the inline returned/serialized native envelopes no longer create false PV outputs. It also demonstrates direct projected publication, terminal changed fields, serialized arrays/Lists, direct exported API builder, opaque spread rejection, and changed multiple publications. These passes do not cover the blocking counterexamples above.

Fifteen additional independent fixture cases were executed; full inputs/results are in `probes.mjs` and `probes.json`:

- Plain returned native nested record: no API discovery, as required.
- Projected `console.log(JSON.stringify(record.body))` with terminal `immutable=true`: discovers terminal value.
- Projected unknown spread: rejects `API_PRODUCT_SCRIPT_NESTED_OUTPUT_UNQUALIFIED`.
- Two projected publications separated by a mutation: rejects `API_PRODUCT_SCRIPT_MULTIPLE_OUTPUT_VARIANTS_UNQUALIFIED`.
- Unknown scalar keeps `__docsDynamicExpression` provenance rather than inventing its value. Downstream schema qualification for this case was not executed.
- Projected alias writer, `console.info`, asynchronous file writer, and known spread copy: reject `API_PRODUCT_SCRIPT_OUTPUT_IDENTITY_UNQUALIFIED`. They remain fail closed, but this correction does not support these valid output forms.
- Projected identity deletion before serialization also rejects `API_PRODUCT_SCRIPT_OUTPUT_IDENTITY_UNQUALIFIED`; terminal native conversion is not accepted for this nested form.
- An opaque unused native sibling causes nested output spread rejection even when the selected body is completely known. Opaque state is collected while evaluating the entire envelope rather than just the selected resource. This is conservative rejection, not silent acceptance.

The role classifier qualifies broader actual output capabilities than `serializedPublications`, which only collects selected direct sinks plus return statements. The correction maps roles using only a line number and selects roots by evaluated object-origin identity. Conservative rejection of other forms does not repair the silent exported-return omission. WeakMap origins are assigned to object literals, not all composed values; root-based interpretation must account for copying/projection without accepting unresolved shapes. Input/source/output digests are emitted for retained outputs; missing outputs naturally have no provenance and therefore cannot be recovered by digest checks.

## Evidence and limitations

`drift-probe.log` records the observed acceptance of an empty inventory for the exported projected builder. `author-tests-independent.log` records the six observed author-test passes. `frozen-discovery.patch`, `frozen-discovery.mjs`, and `frozen-author-tests.mjs` preserve the reviewed revision. `input-sha256.txt` identifies inspected inputs; `artifact-sha256.txt` seals review artifacts.

PASS is withheld for this generic publication correction. Fixes must independently prove exported plain returns/projected builders, returned List children, and separately bound native selector metadata, while preserving opaque/multiple-variant rejection and changed-field detection. No conclusion is made about unrelated PV receivers, generated documentation correctness, full repository configuration discovery, or overall A98 completion.
