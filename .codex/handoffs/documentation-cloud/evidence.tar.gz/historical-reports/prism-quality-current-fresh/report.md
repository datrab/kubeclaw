# Fresh Prism QUALITY review

Verdict: **FAIL for the assigned Prism QUALITY partition**. This report does not accept AP09.8, the Source role, the Reader role, or the complete documentation package.

Reviewer identity: `a98_prism_quality_current_fresh`; role: `quality`; fresh context: yes; initially and throughout read-only with respect to the repository, product and candidate documentation. No author summary or prior review result was used as proof.

Reviewed immutable candidate: `82049ca0c5b02c264805205220cdcc035641f955`.
Candidate Git tree: `e10cf6c2f90c27895a8709e4ddc1b15fc2137fd5`.
Product pin: `ec2a42ed215a2fa7dbd3172ef70ef446084963a9`.
Product Git tree: `a3bb6c84e500080353c3dd75f1d5b6b2d7f9ee54`.

Both trees were extracted with `git archive` into this evidence directory's separate `candidate/` and `product/` directories. No commands in the operator procedures were executed. No commit, push, product edit, main-checkout generation, dependency deletion, installation or browser download occurred.

The shared main checkout is not clean: its observed `git status --short` contains three modified generated inventory files (`configuration-runtime-inputs.json`, `configuration-schemas.json`, `configuration-values.json`). These files were not used as this candidate's authority and were not modified by this reviewer. The immutable archive, not that working tree, is the review subject. Do not use this review as proof of a clean main working tree.

## Assigned decisions

Each verdict below applies only to the Prism QUALITY portion of the named gate. It does not decide the other operator procedures or Demo Delivery.

| Criterion / partition | Verdict | Evidence and limit |
| --- | --- | --- |
| A98-02 — Prism procedures satisfy the Operate writing contract | FAIL | The worker diagnosis procedure gives names of checks without the commands and discriminating observations needed to perform them (Q3). Necessary trust/result terms remain undefined at operational use (Q2). Deployment start state, location, authority, original identities, impact and retention are otherwise explicit at lines 20–87, 145–159, 422–553 and 1150–1177. |
| A98-04 — Prism readiness distinctions | PASS | Lines 521–553 distinguish worker process liveness, native initialization, HMAC nonce-database readiness, SPIFFE-mode readiness and an authenticated functional attempt. Control `SELECT 1` and `pg_isready` are explicitly insufficient for a complete Studio journey. These distinctions match product `worker-service.ts:72–105`, `worker-readiness.ts:8–10`, `control-server.ts:143–147`, and `deploy.sh:1802–1811`. This is a quality decision on the explanation; no installed release, service reachability or live functional readiness was established. Q3 concerns execution of diagnosis, not conflation of the explained meanings. |
| A98-06 — Prism symptom-to-check-to-safe-recovery path | FAIL | The revision-conflict shortcut assumes concurrency and omits the uncertainty condition; generic resume rejection leads directly to correction without first separating stale/terminal outcomes (Q1). Worker diagnosis lacks executable distinguishing checks (Q3). Most other symptom rows correctly stop and preserve original identities. |
| A98-12 — Prism intended journey and truthful capability boundaries | PASS | Lines 22–36 separate deployment from original dispatch and subsequent wait creation. Lines 563–575 label each journey step's implementation and verification class. Lines 980–1119 separate human approval, publication, unsigned CLI signal and verified import. Lines 1150–1177 explain unsupported whole-journey cancellation, wait containment and non-destructive cleanup. Lines 1186–1399 identify per-operation recovery limitations, owners and closure conditions. Lines 1567–1650 name the browser prerequisite boundary and its measurable repair conditions. No mock, source inspection, embedded database, browser preparation or script existence is claimed as a live journey. The fixture explicitly places `EXEC-PRISM-JOURNEY` after documentation acceptance. This is not a live product PASS and does not cover Demo Delivery. |
| A98-13 — Fresh-context technical reader can identify complete procedure requirements from text | FAIL | Q1–Q3 leave contradictory shortcut instructions, undefined terms that determine trust/readiness decisions, and missing command-level worker diagnosis. This is a static QUALITY finding about the reader contract, not an execution participant or Reader-role verdict. The page's explicit lack of live success is accurate and is not itself a failure. |
| OPR-010 — Prism/Studio journey, QUALITY aspect | FAIL | The complete page covers project admission, exactly three directions, selection, edits, history, preview, exact-revision evaluation/approval, publication/export, Nova import, concurrent/stale responses, interruption and cleanup. Its assigned quality obligations remain failed for Q1–Q3. Source completeness and actual Reader exercise are not accepted here. |

## Findings requiring correction

### Q1 — Diagnosis shortcuts omit the required uncertainty decision

Location: `docs/site/use/prism-studio.md:1450` and `:1459`, **Diagnosis Map**.

Reader task: diagnose a revision conflict or rejected Nova resume and choose the safe next action without duplicating an uncertain committed operation or changing a stale wait identity.

At line 1450, the map presents a revision conflict as a concurrent document change and directs the reader to reload, compare and author a new operation. The detailed procedure at lines 1282–1289 correctly explains the second possibility: the reader's original operation already committed before its response disappeared. It requires resolving that outcome before authoring another operation. The index is an incident entry point; its actionable row must carry this prerequisite instead of requiring a reader to discover the omitted stop elsewhere.

At line 1459, the unqualified symptom "Nova rejects resume" leads to correcting the signal. The listed boundary includes the wait itself. A resolved wait or terminal run is not corrected by changing signal content. Lines 1383–1394 correctly require auditing the original run and keeping identities unchanged; `operate.md:303–362` and `:387–388` also require an active wait and stop on stale/expired signals.

Authority: quality standard `07-documentation-quality-standard.md:147–164` (symptom index, visible required actions, discriminating diagnosis, uncertainty before retry); acceptance contract `AP09-acceptance-contract.md:261` and `:268` (A98-06/A98-13). Product confirmation at `ec2a42ed…`: `skills/prism/domain/index.ts:104–109` rejects an old base even after a previous successful increment; `skills/prism/storage/index.ts:267–291` commits revisions and updates the current pointer; `skills/nova/core/execution/engine-run.ts:84–113` checks recoverable/active wait state before signal recording and rejects an unknown/stale wait, then deduplicates only exact signal content.

Necessary correction: make the revision-conflict row say to stop, reconcile the original outcome through current content/history, follow **Revision conflict** / **Typed edit or restore interrupted**, and author new work only after that uncertainty is resolved. Make the Nova-resume row first inspect the original audit and exact error, distinguish malformed/mismatched active-wait input from expired/resolved/terminal outcomes, and link the existing resume-response-loss procedure. Permit correction/submission only for the verified active wait under the canonical run-control conditions. Preserve the instruction that issuer matching is not identity authentication.

### Q2 — Necessary operational terms are not defined when the reader needs them

Location: `docs/site/use/prism-studio.md:527` (HMAC and nonce table, **Verify status and smoke behavior**), `:598` / `:684–687` (CSRF, **Interruption and retry boundaries** / **Open Studio**), `:714` (job fence, **Wait for exactly three directions**), `:916` / `:1010` (ARIA snapshot, **Test the preview** / **Approve and publish**).

Reader task: understand which readiness dependency and session protection apply, which agent claim may commit results, and what accessibility evidence publication must retain.

The text correctly uses these names, but does not explain their meanings in ordinary words or link the operational use to a definition. HMAC determines which database check is necessary; a nonce explains why that extra state exists. CSRF is required for session writes and must be excluded from retained evidence. A job fence determines which worker is still allowed to commit a direction result. An ARIA snapshot is required publication evidence and differs from a screenshot. These are necessary reader concepts, not optional vocabulary decoration.

The shared `docs/site/reference/glossary.md` has SPIFFE/SPIRE, idempotency and reconciliation definitions, but does not define HMAC, nonce, CSRF, job fence or ARIA. The linked runtime route/trust section uses HMAC and nonce without supplying plain definitions. Idempotency and reconciliation, by contrast, are defined explicitly on this page at lines 584–586; export is clarified at lines 1013–1016.

Authority: quality standard `07-documentation-quality-standard.md:7–16` (practical IT reader, no assumed project/academic knowledge) and `:38–43` (one term, definitions at first use, ordinary explanation of identifiers, shared technical vocabulary); acceptance contract `:78–86`, A98-02/A98-13, and the bounded controlled-language aspect of A913-06.

Necessary correction: define these terms briefly at first operational use and add their shared glossary entries. Explain HMAC as shared-secret message authentication, a nonce as a one-use request value retained to prevent replay, CSRF as the separate browser-request protection token, a fence as the durable claim identity that must still match before result commit, and an ARIA snapshot as the recorded accessibility tree for the rendered view. Preserve exact API/key names and the separation of identity verification, application permission and evidence. Do not label all other difficult prose as technical vocabulary to avoid review.

### Q3 — "Worker not ready" is a checklist rather than an executable diagnosis procedure

Location: `docs/site/use/prism-studio.md:1401–1413`, **Worker not ready**; related **Diagnosis Map** symptom row `:1461`.

Reader task: distinguish worker process liveness, unresolved native ownership and HMAC nonce-database failure, retain their exact observations, and choose an owned repair or a safe stop.

The first action is to check `/health`, `/bootstrap` and `/ready` separately, but the procedure supplies no bound command that reaches the selected worker and records its status/body. Subsequent actions say to inspect reconciliation diagnostics and verify policy, cgroup, ownership store, journal and migration state without supplying the observable check sequence or explicitly stopping at a missing operator recovery surface. The linked `docs/site/understand/prism-runtime.md:433–451` explains the endpoints but supplies no diagnostic command. The canonical smoke command checks only `/ready` and discards its body, so it cannot perform the three requested checks or produce the discriminating evidence required by this procedure. `docs/site/use/diagnose.md:1504–1517` is another checklist and does not fill this gap.

Authority: quality standard `07-documentation-quality-standard.md:151–167`; acceptance contract A98-02/A98-06/A98-13 (`:257`, `:261`, `:268`). Actual available distinctions at product pin: `skills/prism/server/worker-service.ts:72–85` returns `PRISM_NATIVE_RECONCILIATION_REQUIRED` or `PRISM_NONCE_DATABASE_UNAVAILABLE`; `:95–103` supplies process/native health; `worker-readiness.ts:12–29`, `:41–56`, `:59–95` records event/phase/code/counters that separate admission, connection, SQL and cancellation; `scripts/deploy.sh:1802–1811` shows the smoke command's narrower request and discarded output.

Necessary correction: provide read-only, context/namespace-bound commands to query all three endpoints on the selected worker and capture HTTP status and sanitized JSON, followed by the exact worker log/diagnostic retrieval command. Explain the two error branches and relevant diagnostic phases/codes without exposing connection credentials. State required inspect/exec/log permissions and the expected success observations. Link an owned native-reconciliation or database-repair procedure if one exists; otherwise name the exact unsupported repair step, stop and owner rather than implying the operator can complete it from this checklist. End with repeated readiness checks, the separate functional-attempt boundary, retained evidence and cleanup of any temporary inspection connection/resource. A documentation change must not invent native repair commands or claim native execution.

## Controlled-language method and vocabulary

This was a project controlled-language review, not certified ASD-STE100 compliance. The licensed complete dictionary/writing rules were not available in the supplied environment. The repository's declared Issue 9 principles and its explicit project rules were applied manually to every line of the canonical page, not inferred from a readability score or linter.

Review questions: Is the actor named? Is an instruction separated from its explanation? Do conditions precede the action? Does the same term have the same meaning? Are necessary terms explained? Does simplifying the sentence preserve identity, concurrency, uncertainty, failure and recovery conditions? Does the symptom shortcut retain the full procedure's stop rule?

Technical vocabulary reviewed included: Prism Control, Studio, Nova Prism stage, Design Document, direction, design round/generation, revision, approval, publication/export, Baseline Bundle, artifact/content digest, immutable/canonical/durable state, idempotency key, reconciliation, uncertain result, request/job/attempt receipt, native ownership, HMAC, nonce, SPIFFE/SPIRE/CSI, CSRF, job fence, cgroup, ARIA snapshot, warning/finding and embedded versus internal document identity. Terms with useful explicit explanations include idempotency/reconciliation, uncertain result, export, human approval versus publication, and the two document identities. Q2 records the unresolved vocabulary findings; this report does not claim they were fixed.

The page is English, has one descriptive H1 and retains exact identifiers. The page contains no AP-number, migration-progress or internal review instructions as reader prerequisites. References to spike test packages are real repository verification surfaces. The dense tables largely preserve necessary depth. The main readability problems are the diagnosis shortcuts and unexplained operational terms, not page length.

## Other bounded quality conclusions

| Aspect | Result | Scope / excluded proof |
| --- | --- | --- |
| Entry navigation | PASS | `docs/site/README.md` directly links **Operate Prism and Studio**; `docs/site/use/README.md` directly links its canonical procedure; `docs/site/understand/prism.md:22–30` routes operator and developer tasks separately. This meets the bounded Markdown navigation part of A912-02 within one choice from home or role entry. Rendered navigation, search ranking and browser interaction remain UNPROVEN. |
| Reader boundary and internal language | PASS | No required Package README, review folder, migration note or chat source appears in the canonical page's task path. The explicit canonical backup, maintenance, cluster-binding and run-control links keep ownership visible. This is the content aspect only, not a publication-manifest/injection proof for A912-01. |
| Truthful result classes | PASS | The page separates source inspection, historical local/embedded checks, unexecuted browser/native/deployment/live results, absent selected release and fixed browser-path prerequisite. Historical executed results are attributed to their execution revision. This review did not reproduce those prior executions and does not certify their stored evidence. |
| Reasons and consequences | PASS, bounded | The operator page explains separation of automated proposal from human authority, immutable restore, configuration precedence, atomic Helm/database limits, identity retention and replay risks. Secret non-rotation explicitly marks its historical reason unknown, current explanation as inference, cost and reconsideration condition (`:404–412`). This is not acceptance of every historical decision on linked architecture/decision pages or the entire A913-07 gate. |
| Project controlled-language content | FAIL | Q2 remains unresolved; Q1 also violates explicit conditions and visible required actions. This is the bounded language aspect, not whole A913-06 acceptance. |
| Source ranges / local Markdown links / shell syntax | PASS, static only | 155 pinned source links have existing regular targets, valid line ranges and candidate bytes equal to product pin; 39 local paths/heading targets resolve; 11 Bash blocks pass `bash -n`. These checks do not prove all source semantics, rendered routes or executable examples. |

Other A98 gates (task-inventory completeness, whole installation/preflight, complete wait contract, full backup/restore, complete upgrade/retirement, recursive configuration/precedence, mutation protection) are **UNPROVEN by this QUALITY assignment**. Their routing and limits were inspected where the Prism page depends on them; no whole-gate PASS is inferred.

## Full inspected scope

Read in full: `docs/blueprint/07-documentation-quality-standard.md` (257 lines); `docs/blueprint/AP09-acceptance-contract.md` (466 lines); `docs/site/use/prism-studio.md` (all 1–1759); `docs/site/README.md`; `docs/site/use/README.md`; `docs/site/understand/prism.md`; `docs/site/reference/glossary.md`.

Relevant immutable fixture content read: fixture metadata and `postDocumentationProductValidation`; `READER-OPERATOR-01` through `-04`; `READER-QUALITY-01`; `EXEC-PRISM-JOURNEY`, `EXEC-DEMO-JOURNEY`, `EXEC-FAIL-POSTGRESQL`; Prism endpoint/runtime-service mutation entries. There are no Prism-specific search or render-scenario entries selected by the independent fixture scan. No fixture was changed, run or reinterpreted as a result.

Catalogue entries read in full: `OPR-010` (assigned content), `SPC-002`, `SPC-003`, `CDV-009` (context only). The catalogue identifies OPR-010's canonical target and Prism-maintainer ownership. SPC/CDV were not accepted.

Essential linked reader sections inspected: install `1–285`, especially the complete cluster-authority binding and version boundary; Worker Trust `1–125`; operate `1–260` and `300–455`, especially canonical run control, readiness and signal/recovery; quickstart `1–180`, especially locked dependency installation; recovery `26–67` and `369–505`, including complete Prism-restore boundary; maintenance `28–65`, `108–133`, `349–391`, `620–691`; diagnose `1504–1519`; Prism runtime `390–500`, including worker endpoints. Local link destinations' Markdown headings were independently checked mechanically. Huge recursive configuration references and the full linked architecture/developer/decision pages were not reviewed as separate package scopes.

Product semantics inspected independently at `ec2a42ed…`: worker-service `1–107`; worker-readiness `1–107`; Studio app `97–183`, `232–442`, `491–499`; Nova Prism stage in full; deploy `1593–1618`, `1748–1815`; revision storage `211–330`; native-operation-store `1–68`; Nova engine-run `84–122`; mobile, preview-isolation and Studio Playwright configs in full; Control routes `108–240`, `521–629`, `693–797`; migration `001_prism.sql:29–70`; domain `67–113`; round client, agent-revision client, agent-job-runner and agent-admission in full. The last four were read from the candidate archive and their exact bytes were independently compared to the product pin by the source-link audit. Source scope is material semantic support for QUALITY findings, not exhaustive Source-role acceptance.

## Checks, reproducibility and evidence

Environment: Linux `6.8.0-139-generic x86_64`; Node.js `v24.21.0`; npm `11.19.0`; GNU Bash `5.3.9` (Alpine/musl). The cloud-runtime skill was read; no callable environment-status tool was available in this review context. No network action was needed.

Executed:

1. `git archive <candidate> | tar -x -C <evidence>/candidate` and the equivalent product-pin archive: exit 0. `git rev-parse <candidate>^{tree} <pin>^{tree}`: exit 0, identities above.
2. Independent `cat`, `nl -ba`/`sed -n` reads and targeted `rg` searches over the specified archived files. Exploratory searches for absent path globs and `docs/site/use/worker-core.md` returned exit 2; these did not establish any acceptance result. The unexpectedly broad exploratory publication search was truncated and was not used as completeness proof.
3. `python3 <evidence>/audit.py`: exit 0, output: 155 source links, 39 local links, 11 shell blocks, no link/range/byte errors and no shell syntax failures. The script and full per-link/per-command JSON are retained. Each extracted Bash block was checked with `bash -n <evidence>/shell-block-NN.bash`: all exit 0; no block executed.
4. Read-only identity/environment commands retained in `mechanical-audit.json`; hashes retained in `evidence-hashes.json`.

Unexecuted: all cluster mutations/probes; live or native worker attempts; browser tests and downloads; deployment; human Studio-to-Nova journey; operator live fixtures; package/SDK build or test gates; restore/upgrade/decommission operations; full mutations; actual publication renderer/route checks; responsive/accessibility/keyboard/screen-reader checks; search fixtures; exhaustive recursive configuration and complete Source claim audit. These are UNPROVEN, not PASS. No Source, Unit, Contract, Render, Native, Deployment or Live execution class is promoted from static quality review.

Durable artifacts: this report, `audit.py`, `mechanical-audit.json`, extracted syntax-only shell blocks, `source-excerpts.txt`, `scope.json`, and `evidence-hashes.json`. The latter binds report/authority/source/scope/evidence bytes to SHA-256. The archive is the immutable review input, not a generated reader deliverable.

Release: review complete; read-only role released. Correct Q1–Q3 and obtain a new independent QUALITY review of the affected text and paths. No file in main or either product/documentation archive was edited by this reviewer.
