# Author correction report: Buster command location and visual redirect qualification

Author: /root/buster_visual_source_findings_complete_writer. This is an author report, not independent acceptance. Final observed HEAD: `63fe81768c0c922ad0a9a2bf68981d7fa1c38cc1`, branch `docs/documentation-overhaul`. Assigned files are frozen at the bytes in `final-source-manifest.json`. No commits or pushes performed by this author.

## Inputs and applicability

Read the complete independent report, complete quality standard, complete AP09 acceptance contract and execution plan, OPR-004/005 catalogue entries, and the relevant reader/execution fixtures. Read the complete Buster workflow and dependency-boundary generator; inspect the real project/core dispatchers, package script, visual provider/runtime, Axe redirect handling, and retained matched-version Playwright primary evidence. The available cloud runtime skill was read; no environment_status tool was available and no network or container action was needed.

A98-02 applies to command location, selected-source prerequisites, exact actions, stop conditions and dependency limitations. A98-05 applies to the preserved cancellation/restart/signal authority boundary; this edit does not introduce a cancellation CLI or alter durable lifecycle semantics. A98-13 applies to discoverable execution location, explicit unsupported containment, owner/safe action, and truthful executed/unexecuted claims. OPR-004's assigned Buster contribution includes compile/start/audit/recovery. OPR-005 retains process interruption versus durable cancellation and its existing canonical link. This report awards none of these requirement IDs independently.

## BUST-SRC-01 correction

The complete procedure now runs production compile, start, audit and recovery from the original KubeClaw checkout that owns the npm pipeline script. The descriptor's repositoryRoot separately selects an arbitrary Git source repository, which need not provide a Nova npm script. Absolute input/output paths avoid changing meaning when the two repositories differ. Source links identify the npm script, Nova dispatcher and git -C checks. package.json links to current HEAD because its historical whole-file bytes changed; pipeline.ts and project CLI still equal their pinned historical authority bytes.

The healthy exercise explicitly selects/canonicalizes NOVA_REPOSITORY and changes to it before commands. It checks descriptor.baseRevision against RELEASE_COMMIT before compilation, requires clean selected-project HEAD, and repeats HEAD/clean checks after dependency preflights before starting. Evidence stays outside both repositories. The same shell stays in the original checkout through preservation/audit. Recovery retains the original project/platform/graph/package/run identity. Existing stopped-writer preservation, strict copied-journal inspection, uncertain-effect reconciliation, bounded cleanup/retention and terminal-success requirements remain intact.

## MATRIX-SRC-02 correction

The generator's visual endpoint qualification now says that capture checks the original routed URL and calls route.continue(). Playwright continues redirected requests without invoking that handler; an admitted resource can redirect to another origin. The text expressly denies an inference of network containment. Before relying on containment, the Buster runtime owner must verify independent browser egress denial for cross-origin redirects, or correct the runtime and prove redirect denial; capture stops where containment is required until proof exists. Documentation changes do not implement either protection.

The shared Axe branch describes its actual maxRedirects:0 and explicit Location handling, keeping it distinct from visual capture. Visual compare remains local caller-supplied PNG/pixelmatch work with its existing decoded/input/result bounds and no separate computation timeout. Browser/application readiness, credentials, owners, cleanup and limits remain stated. The additional visual source guard covers the complete actual route.continue handler. No product code changed.

The installed and locked Playwright/playwright-core versions both equal 1.62.1. The installed coreBundle SHA-256 equals the independently retained digest `9393fa79e1c67c74edc26b610d65a4f7ed73d345a762465cc88340a33a2454ac`. The retained official v1.62.1 Chromium source continues redirectedFrom without a RouteImpl. The official routing rule corroborates original-request-only handling. These are source facts; no browser was launched.

## Actual checks

- `node --check scripts/plugin-dependency-boundaries.mjs`: exit 0.
- `git diff --check -- <two assigned files>`: exit 0.
- `node --test scripts/tests/plugin-dependency-boundaries.test.mjs`: final exit 0, 14 passed, 0 failed/skipped. It includes existing source-guard/unknown-operation negative cases and the stdout-only dependency-report path. A repeat followed final Axe wording correction; both retained logs distinguish executions.
- `node scripts/docs-publication.mjs operator-matrix` and `dependency-report`: exit 0, stdout redirected only to private evidence. Final candidate artifacts contain the corrected qualification; generated shared tables were not changed. These outputs retain the configured inventory source revision and are not final post-source-commit publication/currentness evidence.
- `check-candidate.py`: final exit 0, 22 scoped records. Bash syntax only for all 13 final Bash/text command blocks; full byte checks for the three new pinned authorities; installed/locked version and retained-bundle equality; exact published prestart HEAD/clean checks executed against a private separate Git project without a pipeline script. Clean baseline exits 0, dirty tree exits 1, moved committed HEAD exits 1. These are source preconditions, not a production run.
- `location-family-probe.py`: final exit 0 as a probe harness. Actual compile/start/audit/recovery commands each exit 1 in both locations. From original KubeClaw they reach the real Nova loader and stop at intentionally absent private project/platform files. From the separate project they fail npm script lookup (non-silent forms retain Missing script; the exact silent audit form produces no terminal text). No compiled file appears. These are negative command-location/entrypoint checks, not successful operation, admission, audit or recovery.

The first candidate checker exited 1 on package.json historical whole-file inequality; `initial-check-failure.txt` records the failure and source-link correction. Neither a failed probe nor a source check is upgraded to live success. Inputs, final sources, scripts, logs, copied snippets and candidates have byte counts/SHA-256 in the manifests. Input snapshot presence does not itself approve semantics.

## Nonexecutions and remaining work

No successful pipeline compile/start/audit/recovery, real journal opener, preserve_run_state invocation, browser launch, cluster preflight/deployment, external service call, live cancellation/wait/resume/restart, database operation, destructive cleanup, global generate/build or shared matrix edit occurred. The npm negative probes use absent inputs and stop before runtime/storage authority. The private Git fixture is retained under evidence; its local commits are fixture preparation, not repository commits. No source fetch or project remote fetch occurred.

Root owns committing corrected sources and subsequent shared operator-matrix regeneration/currentness. Fresh independent Source review must recheck corrected final bytes; Reader/Quality and global acceptance remain unawarded. EXEC-WAIT-RESUME, EXEC-CANCELLATION and EXEC-RESTART-RECOVERY deployment receipts remain missing. The full-reference domain retains its three unresolved generated Helm anchors. MATRIX-SRC-03 is owned by another writer. No outside-domain finding was closed by this edit.

Author language method: direct English statements with actor, condition, consequence and safe action; exact terms preserved include repositoryRoot, baseRevision, route.continue, maxRedirects, Location, capture, compare and egress. No formal ASD-STE100 compliance or independent language approval claimed. The candidate preserves technical mechanisms rather than reducing procedures to short commands.
