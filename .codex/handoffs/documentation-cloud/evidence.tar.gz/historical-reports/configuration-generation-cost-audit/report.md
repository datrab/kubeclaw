# Configuration-generation cost audit

Revision audited: `8ef721ea0f41e4666a50740caa0616819306e97e` on `docs/documentation-overhaul`, 2026-10-11. Repository: `/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04`.

This is a read-only performance audit, not package or documentation acceptance. It follows `docs/blueprint/07-documentation-quality-standard.md`: preserve actual public-source discovery, all supported conditional inputs, source-bound authorities, recursive product contracts, and add/change/remove/rename drift detection. No scope reduction, parser replacement, invented metadata, skipped checks, or weakened failures is proposed. The active generator process/session supplied by the parent was not stopped, attached, restarted, inspected, or duplicated. No full discovery/generator or product/host change was executed. All writes are in this evidence directory.

## Main finding: subprocess work happens before cache hits

- `scripts/docs-configuration-inventory.mjs:2772–2782`: discovers contexts, groups by API identity, then calls `apiProductSelection` for each resource identity with all of its contexts.
- `scripts/docs-api-product-scope.mjs:504–515`: for **each context**, reads/checks source digest, calls the relevant complete producer discovery, searches its outputs, and compares the complete output context. Initial producer discovery also occurs at `:290`.
- `scripts/docs-api-output-discovery.mjs:1994`: rebuilds `installerShell` for every one of four selected external installer recipes; two recipes use `scripts/deploy.sh`. `:2012` rebuilds it once again for each of three distinct source paths. `:2002–2005` tokenizes repository commands separately. This is seven installerShell builds per external discovery call before its result cache lookup.
- `:1795–1818`: `installerShell` rereads source/defaults; `tokens` launches the unchanged Python `shlex.split` parser at `:1813` for every matching command. There is no token cache.
- `:2015–2016`: **only then** constructs the result cache key and checks `externalOutputCache`. A result cache hit avoids Helm rendering, but not any of the preceding shell tokenization, GitOps YAML parsing, input/manifest/archive reads and hashing. Thus cached external output can still trigger dozens of Python children for every external resource context.
- `:1854–1884`: infrastructure discovery has the same late-hit pattern: parse installer first, loop three locked charts, retokenize *all* matching command substitutions for each chart (`:1859`), launch `stageInfrastructureChart` for each (`:1866`), read/hash staged archives and broad dependency files, then check result cache (`:1884`). The token-only witness does **not** execute stage processes or archive work.

This source path specifically explains repeated `python3 -c ... shlex.split(...)` children reported by the parent. It does not establish how much of the active run's total time these consume. The distinct punctuation-aware shlex lexer at `:138` is another parser path; the proposed change does not touch it.

## Bounded measured evidence

`tokenization-probe.cjs` extracts only the real `installerShell` function into a private VM context. It reproduces the external call-site pattern twice, followed by infrastructure tokenization once. It never imports the discovery module, invokes Helm/staging, or runs the generator. It compares the serialized argv results produced by original versus the actual proposed function excerpt.

| Bounded operation | Original Python launches | Proposed successful-token cache |
| --- | ---: | ---: |
| External pre-cache installer pattern, first pass | 31 | 13 |
| Same pattern, second unchanged pass | 31 | 0 |
| Infrastructure pre-cache tokenization pattern, 3 charts | 22 | 5 |
| Total | 84 | 18 |

Only 18 unique input strings were present. Original local elapsed time was 2513 ms, of which 2463 ms was inside Python spawning; proposed excerpt took 561 ms, including 486 ms spawning. These are bounded fixture measurements on one shared host, not an end-to-end speed claim. All 84 original launches and all 18 proposed launches used Python shlex. Their selected external argv outputs were byte-equivalent after JSON serialization.

Artifacts: `tokenization-probe.json`, `successful-token-mutations.json`, proposed diff, extracted proposed function, and both rerunnable probes. An initial fixture comparison used deepStrictEqual across separate VM realms and failed on realm prototypes despite matching structures; the harness now compares serialized argv values. That was a private harness issue, not a generator outcome.

## Smallest candidate: successful raw-token memoization

`successful-token-memoization.proposed.diff` is an **unapplied** proposal stored here, outside the repository. It changes only the installer tokenization helper:

1. Preserve exactly the existing `python3` executable name, Python program, spawn options, exit-code assertion, and JSON decoding.
2. Cache only successfully parsed raw token strings, never expanded variables, mutable shell state, a failure, result metadata or discovery assertions.
3. Use the exact text plus inherited working directory and complete inherited environment in the SHA256 key. This includes PATH and Python environment inputs without publishing them.
4. Store a private copy and return a fresh shallow copy on every hit. Tokens are strings, so shallow array copying suffices.
5. Still reread source/default assignments and rerun every producer/recipe/source-digest/archive/selected-chart assertion exactly where the current implementation runs them.

This isolates Python startup duplication while preserving the source-specific failure path and expansion/quoting semantics. It also handles duplicated token strings within one discovery pass; unlike sharing an installerShell object it cannot leak `variables[binding.variable]` mutations between callers. It does not address staging subprocesses, archive hashing, AST rebuilding or broad tree hashing.

Toolchain assumption to review: replacing Python or an imported Python standard library at the same pathname, with identical cwd/environment, within one Node invocation is not fingerprinted by this proposal. Existing full-output caches similarly do not guarantee such hot replacement detection. If that is in the required same-process mutation contract, add executable/library identity to the key or a documented invocation-level toolchain snapshot before integration. Do not describe token tests as proof of that case. No current tool executable was changed.

## Other source-supported repeated work

- `docs-api-output-discovery.mjs:363–373,430`: local Helm uses one shared `cache` for both product-output and schema-authority modes, but every miss calls `cache.clear()`. `docs-api-schema-authorities.mjs:161,172` performs external then schema-only local discovery on lazy custom schema loading (`:104–107`); product discovery happens at product-scope `:290`. Alternating product → schema-authority → product invalidates the other **mode's entry**, even if source bytes are unchanged. Both keys encode the mode already. Keeping one latest entry per resolved root and mode is a separate small candidate; require mode-order tests and unchanged source witness. This is source-demonstrated eviction behavior, not evidence of unbounded alternating renders in the active run. Custom schemas themselves are lazily loaded once.
- Script discovery (`output-discovery:440–444`) walks and hashes every accepted product file before a hit. Shell (`:1621–1629`), Go (`:749–755`), transformed (`:1713–1717`) and local Helm (`:364–373`) also validate source trees before returning cached results. Per-context reentry multiplies these costs. A persistent cache keyed only by source filename, mtime or context totals would weaken add/remove/rename/content discovery and is not safe.
- `docs-api-product-scope.mjs:495` recalculates complete schema field boundaries for each resource identity, while selected field schema lookup repeats during field traversal. `docs-api-schema-authorities.mjs:424–484` recursively rebuilds boundary records, contract projection and JSONPath ordering. No boundary-result cache exists. Lower-confidence relative cost than Python spawn fan-out; do not change without profiling a completed run.
- `docs-api-output-role-classification.mjs:151–164` creates TS AST/module cache, native-operation fact cache, registry and dependency state **per classifier instance**. Output discovery creates classifiers at `:501`, `:776` and `:952`. The module AST cache is effective inside one instance but not across those distinct classifications. `discoverScriptOutputRoleClassifications(:773–777)` always constructs a new classifier; broader memoization must key universe/import/dependency state and avoid sharing parameterBindings/mutations blindly. Native-tee cache at `:950–969` already guards source/dependency digests and must remain intact.

A larger later batching candidate is to build and authenticate one complete producer snapshot per explicit inventory traversal, index it by producer/path/document/profile, then use that same snapshot to compare each context. Preserve the current complete-context deep equality and every source digest check. Declare the snapshot lifetime; re-discover at the next traversal and fail if sources change inside a traversal. This can remove repeated tree/archive hashing but needs broader mutations than the token helper. It is not included in the proposed diff.

## Mutation proof and remaining checks

`successful-token-mutations.cjs` ran nine real Python launches and passed these focused same-process checks against the proposed helper:

- Exact unchanged input avoids a second launch; quoting, JSON payload boundaries and escaped Helm key text remain intact.
- Returned array is modified and extended by a caller; another source's cache hit still gets original argv.
- Changed raw command text performs a fresh Python parse.
- Three malformed-input requests (two source paths) each perform a new failed parse and report the correct source-specific `API_PRODUCT_INSTALLER_PARSE_FAILED`.
- Rebuilding installerShell rereads changed source; added/renamed invocation text tokenizes anew, removed invocation disappears.
- Changed inherited environment or cwd selects a fresh token cache key.

These do not substitute for full source-bound drift checks. Before integrating/relying on the change, run the existing complete configuration/API-output maintenance gates in the isolated environment required by the project. Inspect `scripts/check-configuration-drift-mutations.mjs:638–715` for chart/authority, archive, template and API mutations and preserve their failures. Include same-process warm-cache scenarios for: assignment-only default changes (tokens unchanged, expansion changes), added/removed/renamed installer invocations, alias/version/repository changes, newly selected value files and missing-file behavior, changed values/archives/manifest/authority bytes, changed raw flags and malformed quoting. Unknown variables, unknown flags, unregistered selected charts and authority mismatches must still fail closed. Restore baseline after each mutation and retain all produced contexts, exact source/output/dependency digests, install/upgrade branches and rejection evidence.

For any separate Helm-mode cache fix: warm product and schema modes in both orders, assert no cross-mode rerender on unchanged sources, mutate/add/remove/rename a chart/template/values input and require fresh applicable discovery and preserved rejected-profile/branch checks. For producer batching: repeat these plus imports, public writer additions, source removals/renames, wrapper changes and same-process warm-cache source dependency mutations; cold versus batched outputs and diagnostics must be equivalent.

No full-generator PASS, coverage closure, independent acceptance, active-run completion, or speedup of the actual generator is claimed by this audit. The parent owns the existing run's observed outcome.
