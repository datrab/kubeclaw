# Selected CRD metadata correction: author handoff

Started against root commit `96757c00fa7f3364f527d1a2056a3d1da5bf65bd`; root advanced the shared checkout to `2cfab37c9b121d64427475e8d86abc7e41771527` during this author task. This is an author correction and bounded verification record, not independent Source/Reader/Quality acceptance, complete supported-product discovery, or live acceptance.

## Owned changes

Changed only `scripts/docs-kubernetes-metadata-receiver-contracts.mjs` and `scripts/docs-cilium-receiver-contracts.mjs`. The exclusively allowed Argo receiver module is unchanged. No product/runtime files, generated outputs, completion matrix or commits were changed by this writer.

The selected metadata envelope/identity/map clauses now distinguish their actual KubeClaw producers and named receiving paths. Added exact-source explanations for SPIRE's ServerSideDiff annotation, platform ignore-healthcheck and observed health annotations, AppProject/Application sync waves, bootstrap ownership labels and namespace-claim JSON, chart release context, and conditional chart/recovery CNP metadata. Added Application informer queue identity and conditional Cilium operator validation/status-write paths. Corrected the Cilium metadata wrapper to state the preceding same-generation cached-policy return explicitly.

The previous obligation to discover every upstream Argo/Cilium controller/server/helper/cache/event consumer remains unreviewed at its original all-upstream scope in `metadataDiscoveryObligations.generalUpstream`, and remains explicit on unused general contracts. It was not treated as a product limitation or converted into a PASS. Only the positively source-qualified product metadata candidates replace that old blanket publication marker. `supportedOutputs` remains `discovery-incomplete` internally. Receiver IDs and canonical links remain intact. Existing ApplicationSet preservation/deletion, manifest path and finalization clauses remain intact; all pre-existing implicit metadata conditions/cases/evidence are retained. The built-in/Core/Deployment metadata receiver exports are byte-equivalent as values to their initial root revision, including the Deployment operation helper and GC behavior.

## Fresh source and checks

Independent reparse of tracked product YAML under gitops/my-values/examples found all 45 actual raw CRD source contexts in the provided inventory: the metadata objects, source document indexes and SHA-256 digests match the selected resources. There are four selected CRD kinds and 15 selected implicit metadata clauses in this raw boundary. This confirms the raw boundary, not all supported outputs.

`fresh-git-provenance.json` and `caption-ledger.json` retain original pinned Git blobs and 154 citation ranges from 61 files. Each original was freshly read with `git show revision:path`, checked against its Git blob OID, stored separately and range checked. Original Go decoder bytes were freshly fetched from the pinned raw source and verified against the GitHub contents API blob OID (`go-fresh-provenance.json`). Pins: Kubernetes 66452049, Argo e258ee23, Cilium 7d68cfb3, KubeClaw producer files 96757c00, Go 2dc996f7. Earlier private Root evidence was used for navigation, not as the final authority.

`verify.mjs`: passed raw source digest/context checks; all selected metadata markers; original-condition/case/evidence preservation; exact unchanged non-CRD metadata exports; retained original all-upstream obligation. Final log: 45 contexts, 15 implicit records, four parent records, 61 pinned files, 154 citation ranges.

`node --test scripts/tests/api-receiver-coverage.test.mjs scripts/tests/api-reference.test.mjs`: 16/16 passed, zero skips. `git diff --check` passed. `render-metadata.mjs` successfully serialized the 15 selected implicit clauses and four correctly linked parent metadata clauses without internal proof-work prose. Its private markdown is diagnostic output, not a published API reference.

The full raw source selection renderer remains blocked on the authentic next selected proof gap: `API_REFERENCE_UNRESOLVED_PROOF: argoproj.io/v1alpha1/Application $.spec`. `render.log` retains that failure. The metadata correction did not suppress the Argo module's blanket `OPEN DOCUMENTATION PROOF` requirement or claim a successful full API/publication check. Fresh integrated generation must use current modules, not the frozen inventory's previous receiver objects.

## Supported producer outputs still missing from raw discovery

- `charts/gitops/templates/applications.yaml:6–14,31–42`: AppProject root label/sync wave; Application project label/sync wave and JSON helm-releases. Project orphanedResources.warn is also a supported-output schema obligation, independently noted by Root's Source reviewer; this metadata writer did not change schema coverage.
- `scripts/gitops.mjs:74–95,109–119,145–156`: generated root AppProject/Application identities, root labels, runtime-namespaces JSON; preflight identity and ownership checks. `scripts/gitops-owner.mjs:7–12` validates and reads namespace claims.
- `charts/kubeclaw/templates/archviewer.yaml:1–10,35–42`: conditional Archviewer CNP (`archviewer.enabled`, Nova-only), fullname-derived bounded policy name, omitted namespace supplied by the selected namespaced deployment request.
- `charts/ops-pod/templates/network.yaml:1–3,37–50`: conditional CNP (`networkPolicy.enabled` and `networkPolicy.cilium`), required API-server CIDRs in the outer branch, release-derived name and omitted namespace.
- `scripts/render-postgresql-recovery.mjs:86–96,112–119`: two generated CNPs with explicit namespace and metadata management labels `app` and `app.kubernetes.io/managed-by`; spec endpoint/peer selectors separately select workloads.
- `scripts/argocd-self-management.mjs` and `scripts/platform-services.mjs` generate the maintained raw platform documents. Their current generated raw values are present; automatic add/change/remove detection of the producer-output relationship and conditional branches remains a separate discovery obligation.

These actual supported paths must be part of the next generator-author pass. A default render alone cannot close their conditional scope, and the 349 raw selected rows/65 overall raw contexts must not be reported as full supported-product coverage. Root separately retains selected omission-discovery work for Deployment progress/revision defaults and Pod DNS/restart/grace/volume modes. This author did not change generator ownership or classify those gaps as passed.

Actual deployed server/client/controller versions, enabled admission/operator configuration, namespace permissions, cache propagation, policy status, endpoint enforcement, workload health and destructive cleanup remain environment-dependent checks. No live policy, API, synchronization, deployment or recovery check ran.

Final release: repository writes stopped after sealing the two corrected and one unchanged owned modules. Root may integrate and start fresh Source/Reader/Quality/Astra review; this author does not supply those verdicts.
