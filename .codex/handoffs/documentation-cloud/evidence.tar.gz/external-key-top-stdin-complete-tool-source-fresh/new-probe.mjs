import fs from 'node:fs';import path from 'node:path';import vm from 'node:vm';import assert from 'node:assert/strict';import {spawnSync} from 'node:child_process';import {createRequire} from 'node:module';
const root='/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04',evidence='/home/node/Documents/Codex/a98-evidence/external-key-top-stdin-complete-tool-source-fresh';const require=createRequire(root+'/package.json');const source=fs.readFileSync(root+'/scripts/docs-configuration-inventory.mjs','utf8');const box={fs,path,assert,Buffer,spawnSync,root,YAML:require('yaml')};vm.createContext(box);for(const name of ['lineAt','pythonEnvironmentReads','pythonArgvMode','pythonInterpreterIndex','pythonShellPrograms','pythonYamlPrograms','acquiredPythonEnvironmentReads']){const start=source.indexOf('function '+name+'('),end=source.indexOf('\n}\n',start)+2;vm.runInContext(source.slice(start,end),box)}
const cases=[];
function py(name,code){cases.push({name,kind:'python',code})}
for(const [name,getter] of [['call-alias','os.getenv.__call__'],['getitem-alias','os.environ.__getitem__'],['mapping-call-alias','os.environ.get.__call__'],['setdefault-alias','os.environ.setdefault']]) py(name,`import os\nkey='KUBE_CONTEXT'\ngetter=${getter}\ndef change():\n global key\n key='GLOBAL_KEY_NEW'\nchange()\nchosen=key\nprint(getter(chosen${name==='setdefault-alias'?", 'fallback'":''}))\n`);
py('nonlocal-call-alias',`import os\ndef outer():\n key='KUBE_CONTEXT'\n getter=os.getenv.__call__\n def change():\n  nonlocal key\n  key='GLOBAL_KEY_NEW'\n change()\n chosen=key\n print(getter(chosen))\nouter()\n`);
py('namedexpr-getter-alias',`import os\nkey='KUBE_CONTEXT'\n(getter := os.getenv)\ndef change():\n global key\n key='GLOBAL_KEY_NEW'\nchange()\nchosen=key\nprint(getter(chosen))\n`);
for (const variant of ['function','class','method']) {
 const definition=variant==='function'?`def f(x: getter(chosen)): pass\nprint(annotationlib.get_annotations(f))\n`:variant==='class'?`class C:\n x: getter(chosen)\nprint(annotationlib.get_annotations(C))\n`:`class C:\n def f(self,x: getter(chosen)): pass\nprint(annotationlib.get_annotations(C.f))\n`;
 py(variant+'-protocol-annotation',`import os, annotationlib\nkey='KUBE_CONTEXT'\ngetter=os.getenv.__call__\ndef change():\n global key\n key='GLOBAL_KEY_NEW'\nchange()\nchosen=key\n${definition}`);
}
py('module-protocol-sensitivity',`import os\ngetter=os.getenv.__call__\nkey='GLOBAL_KEY_NEW'\nchosen=key\nprint(getter(chosen))\n`);
py('foreign-passive',`key='KUBE_CONTEXT'\ndef change():\n global key\n key='GLOBAL_KEY_NEW'\nchange()\nclass Foreign:\n def get(self,key): return 'foreign-observed'\nprint(Foreign().get(key))\n`);
for (const [name,tail] of [['semicolon',';'],['pipe',' | cat'],['and',' && true'],['plain','']]) {
 const code=`python3 - <<'PY'${tail}\nimport os\nprint(os.getenv("HEREDOC_KEY_NEW"))\nPY\n`;
 cases.push({name:'heredoc-'+name,kind:'shell',code});
 cases.push({name:'yaml-heredoc-'+name,kind:'yaml',code});
}
for (const kind of ['shell','yaml']) cases.push({name:kind+'-heredoc-data-passive',kind,code:`cat <<'PY';\nimport os\nprint(os.getenv("HEREDOC_KEY_NEW"))\nPY\n`});
const results=[];
for(const row of cases){let names,error;const input=row.kind==='yaml'?`exec:\n command: [sh, -c, ${JSON.stringify(row.code)}]\n`:row.code;
try{names=Array.from(row.kind==='python'?box.pythonEnvironmentReads(input,'ops/pod/bootstrap.py'):box.acquiredPythonEnvironmentReads(row.kind==='yaml'?'charts/ops-pod/templates/workload.yaml':'ops/pod/shell.sh',input),r=>r.name)}catch(e){error=e.message};
const native=spawnSync(row.kind==='python'?'python3':'/bin/sh',row.kind==='python'?['-I','-c',row.code]:['-c',row.code],{encoding:'utf8',env:{...process.env,GLOBAL_KEY_NEW:'new-observed',KUBE_CONTEXT:'old-observed',HEREDOC_KEY_NEW:'here-observed'}});
results.push({...row,names,error,native:{exit:native.status,stdout:native.stdout,stderr:native.stderr}})}
fs.writeFileSync(evidence+'/new-results.json',JSON.stringify(results,null,2));console.log(JSON.stringify(results.map(({name,names,error,native})=>({name,names,error,native})),null,2));