import fs from 'node:fs';import path from 'node:path';import vm from 'node:vm';import assert from 'node:assert/strict';import {spawnSync} from 'node:child_process';import {createRequire} from 'node:module';
const root='/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04',evidence='/home/node/Documents/Codex/a98-evidence/dependent-key-yaml-file-complete-tool-source-fresh';const require=createRequire(root+'/package.json');const source=fs.readFileSync(root+'/scripts/docs-configuration-inventory.mjs','utf8');const box={fs,path,assert,Buffer,spawnSync,root,YAML:require('yaml')};vm.createContext(box);for(const name of ['lineAt','pythonEnvironmentReads','pythonArgvMode','pythonInterpreterIndex','pythonShellPrograms','pythonYamlPrograms','acquiredPythonEnvironmentReads']){const start=source.indexOf('function '+name+'('),end=source.indexOf('\n}\n',start)+2;vm.runInContext(source.slice(start,end),box)}
const codes={
'global-comprehension-dependent-key':`import os
key='KUBE_CONTEXT'
def change():
 global key
 [(key := 'GLOBAL_KEY_NEW') for _ in [1]]
change()
chosen=key
print(os.getenv(chosen))
`,
'global-direct-dependent-key':`import os
key='KUBE_CONTEXT'
def change():
 global key
 key='GLOBAL_KEY_NEW'
change()
chosen=key
print(os.getenv(chosen))
`,
'nonlocal-dependent-key':`import os
def outer():
 key='KUBE_CONTEXT'
 def change():
  nonlocal key
  [(key := 'GLOBAL_KEY_NEW') for _ in [1]]
 change()
 chosen=key
 print(os.getenv(chosen))
outer()
`,
};const results=[];for(const[name,code]of Object.entries(codes)){let names,error;try{names=Array.from(box.pythonEnvironmentReads(code,'ops/pod/bootstrap.py'),r=>r.name)}catch(e){error=e.stack};const native=spawnSync('python3',['-I','-c',code],{encoding:'utf8',env:{...process.env,GLOBAL_KEY_NEW:'new-observed',KUBE_CONTEXT:'old-observed'}});results.push({name,code,names,error,native:{exit:native.status,stdout:native.stdout,stderr:native.stderr}})}fs.writeFileSync(evidence+'/new-probe-results.json',JSON.stringify(results,null,2));console.log(JSON.stringify(results,null,2));