from pathlib import Path
import json,subprocess,shutil,tempfile,datetime
R=Path('/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04'); E=Path(__file__).parent
rows=json.loads((E/'new-results.json').read_text());results=[]
with tempfile.TemporaryDirectory(prefix='protocol-heredoc-independent-receiver-') as temp:
 C=Path(temp)/'repo';shutil.copytree(R,C,symlinks=True,ignore=shutil.ignore_patterns('.git','node_modules'));(C/'node_modules').symlink_to(R/'node_modules',target_is_directory=True)
 def gate(name):
  p=subprocess.run(['node','scripts/docs-configuration-inventory.mjs','--check-environment-coverage-only'],cwd=C,capture_output=True,text=True,timeout=180);(E/(name+'.log')).write_text(p.stdout+p.stderr);results.append({'name':name,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'time':datetime.datetime.now(datetime.timezone.utc).isoformat()});(E/'receiving-results.json').write_text(json.dumps(results,indent=2));print(name,p.returncode,flush=True)
 gate('baseline')
 for row in rows:
  name=row['name'];f='ops/pod/bootstrap.py' if row['kind']=='python' else 'ops/pod/shell.sh' if row['kind']=='shell' else 'charts/ops-pod/templates/workload.yaml';p=C/f;before=p.read_bytes()
  if row['kind']=='yaml':
   original=before.decode(); start=original.index('            command:',original.index('        readinessProbe:')); end=original.index('\n',start); mut=(original[:start]+'            command: '+json.dumps(['sh','-c',row['code']])+original[end:]).encode()
  else: mut=before+b'\n'+row['code'].encode()
  if row['kind']=='python':compile(mut,f,'exec')
  (E/(name+'-full-source'+Path(f).suffix)).write_bytes(mut)
  try:p.write_bytes(mut);gate(name)
  finally:p.write_bytes(before)
 gate('restored')
