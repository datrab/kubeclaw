# Fresh independent complete assigned Tool Source review

**COMPLETE FAIL — two material findings collected across the whole assigned Source scope before one correction request.**

Reviewer `/root/external_key_top_stdin_complete_tool_source_fresh` is distinct from the scanner/API authors, Reader and Quality. Parent explicitly configured gpt-6.1-sol/medium/fork-none; this records configuration, not backend certification. Repository `/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04`, initial HEAD54a010ec5a337e5bbc4a08331510d2fe2d71c886; final supporting-docs-only HEAD3c7b0b3ad9ddaa72bbbbddb5e12c24cee19f437a supplied by Root. All nine Tool authorities remain unchanged across that metadata transition. Authority is the guarded dirty working-tree candidate. This is no clean-commit, package, global, Reader, Quality or live approval. Shared Source remained read-only; synthetic/native and complete receiver changes are private evidence/private complete checkouts only. No product bootstrap/shell, provider, credentials, deployment, install, host or cluster execution occurred.

The whole prior dependent-key-yaml-file-complete-tool-source-fresh/report.md COMPLETE FAIL2 was read as leads, including all families, facets, individual IDs, failures and limits, not as inherited approval. Quality07, AP09 contract, the execution-plan obligations, relevant immutable fixture constructors and all eleven assigned catalogue records govern the decisions below. They require recursive actual consumer coverage, useful Source boundaries and truthful evidence classes. Root295/63 and author73/182 totals are real bounded evidence, not completeness proxies.

Current nine primary authorities remain exact before/after. Scanner cd8cf10e70f0b2e8469ecddd72a174e4fdd45f2d03bb3fd35ffc5d882fe7acb7; tests8e63984d65b95d37bbd2ea560c1e593406c31329a91e55aaf3e22572e2a90028; discoveryc42e52597d30bed84a2a4d7e165bc09f988a25270cc3feb4ab2b2a122bcddd0d; registry18d5d88ed58b2508bebfe20abeb0f98dacae609ca3b7d7f02f7275cd682b8dc2. Independent recipe71f620ed039164298091a44147e13f9199f6a116740f345a79ada585ac4ac380 and publication libraryc930b8710a03c58f61b2fab0beda06a7d12dd0fde456ea4d1507c586bf458f65 remain bound. All four other API bodies remain unchanged.

## R1 — recognized getter aliases do not receive external finite-key sensitivity

Owner: scripts/docs-configuration-inventory.mjs:5484–5501 acquisition/alias census and :5522–5533 external recognized-reader census; actual reader semantics :5606–5610 and :6305–6310; external guard :5713–5722/:5817–5821; helper state restoration :6103–6134. Actual complete receiving identity: ops/pod/bootstrap.py. Authority: quality07 Product scope, Maintenance, Correctness; AP09 recursive Source/consumer boundary, CFG010/011/013/015/018, REF003/012, A98-10/11/14, A911-01/02/12.

The correction supports direct protocol calls, but not simple aliases of those same supported getters. acquisition() admits only getenv/environ/get attributes, and its alias loop excludes NamedExpr. role() nevertheless preserves readers from __call__/__getitem__/setdefault and NamedExpr. Consequently external_key_names sees no recognized reader when the final call uses that alias. The supported finite chosen=key dependency never becomes sensitive, and analyze_function restores the old outer key.

```python
import os
key = 'KUBE_CONTEXT'
getter = os.getenv.__call__
def change():
    global key
    key = 'GLOBAL_KEY_NEW'
change()
chosen = key
print(getter(chosen))
```

Current production discovery reports KUBE_CONTEXT. Separate native Python3.14 exits0 and prints new-observed from GLOBAL_KEY_NEW. The exact legal payload appended to the complete actual bootstrap gives **false GREEN436/exit0** in the actual private receiver. Nine complete bootstrap mutants demonstrate this same custody failure: aliases of os.getenv.__call__, os.environ.__getitem__, os.environ.get.__call__, legal os.environ.setdefault(chosen,'fallback'), a nonlocal alias variant, a NamedExpr getter alias, and actual function/class/method annotation evaluations through annotationlib.get_annotations. All nine current native witnesses exit0 with the new value; all complete Python sources compile legally. The annotations are evaluated natively, not inferred from annotation spelling.

Adjacent direct module-key mutation using the same protocol getter discovers GLOBAL_KEY_NEW and the complete receiver exits1 with CONFIG_SEMANTIC_GAP, the key and ops/pod/bootstrap.py. A foreign get method remains passive/GREEN436. The old six scalar-key mutations now correctly reject in current Root63; that does not cover these nine new recognized aliases. No arbitrary helper-return or runtime dependency evaluator is needed: these getters, simple aliases, finite keys and helper invocations already have production semantics.

Necessary fix: make the external finite-key census consistent with the actual admitted reader/protocol/alias forms, including supported NamedExpr acquisition, or use a conservative actual-Source boundary before stale helper restoration. Preserve direct known resets, foreign/pure/unused controls, capability/getter protection and definition/annotation ownership. Current direct protocol assertions do not prove alias custody.

Evidence: new-probe.mjs/new-results.json, all nine retained *-full-source.py, receiving.py/receiving-results.json and exact logs; module-protocol-sensitivity and foreign-passive controls. Original97769 reached terminal0 and retains the observed failures rather than mislabelling the driver's exit0 as acceptance.

## R2 — a command separator discards pending heredoc ownership

Owner: scripts/docs-configuration-inventory.mjs:5123–5128 selects the winning fd0 redirect and clears redirects; :5135–5162 consumes only the current newline flush's heredocs; :5167 calls flush at ;/|/&/parentheses and discards its returned redirect records. YAML calls this same owner at :5333 and forwards records at :5335–5337. Actual complete receiving identities: ops/pod/shell.sh and charts/ops-pod/templates/workload.yaml:80. Same recursive environment/source Authorities as R1, with F5 executable fd0/heredoc acquisition.

```sh
python3 - <<'PY';
import os
print(os.getenv("HEREDOC_KEY_NEW"))
PY
```

Separate native /bin/sh exits0 and prints here-observed. Current shell and literal sh/-c YAML acquisition both return[]. The separator flush sees a winning heredoc, so no unresolvedStdin marker is set, but the record is discarded before the newline consumes its body. The new top-level marker checks cannot reject this loss. The exact complete shell and workload readiness mutations return **false GREEN436/exit0**. The same failure occurs with `| cat` and `&& true` before the newline: six complete shell/YAML false greens, with six native0 records (paired observations of three shell programs).

Removing only the separator preserves the plain heredoc: current shell/YAML discovery finds HEREDOC_KEY_NEW and both complete receivers exit1 with CONFIG_SEMANTIC_GAP, the key and actual receiving Source. Data heredocs to cat remain passive with simple Python-text content. A stronger passive recipe exposes the inverse ownership loss:

```sh
cat <<'DATA';
python3 -c 'import os; print(os.getenv("PASSIVE_KEY_NEW"))'
DATA
```

Native cat only prints that literal recipe, exit0. The current scanner instead acquires PASSIVE_KEY_NEW; the complete shell receiver falsely exits1 with CONFIG_SEMANTIC_GAP and ops/pod/shell.sh. The otherwise byte-adjacent cat heredoc without the semicolon remains empty/GREEN436. This false rejection and the six false greens have the same lost pending-heredoc owner; they are one coherent finding, not a request for a general pipeline interpreter.

Necessary fix: preserve pending heredoc records and their command/receiver ownership until the newline consumes the bodies, or reject this finite executable-source handoff explicitly with its actual Source before dropping it. Keep passive recipe bodies passive. Semicolon alone needs no pipeline evaluator; an explicit useful boundary for compound forms is sufficient. Preserve fd0 winner/fd3 passivity, file sources, lexical coordinates, recursion/depth and optional positions.

Evidence: heredoc-tail-probe.mjs/results, new-probe.mjs/new-results.json, passive-recipe-probe.mjs/results, eight active/plain complete shell/YAML sources, passive full Sources, receiving-results.json and passive-receiving-results.json/logs. Original97769 and94091 both reached terminal0. No complete product shell or workload was executed.

## Complete affected owners, graph and scoped evidence currency

Independent complete TypeScript FunctionDeclaration comparison against the author's owning before-source gives128 functions,125 byte-identical and exactly acquiredPythonEnvironmentReads/pythonEnvironmentReads/pythonYamlPrograms changed. Each complete changed function and its AST/reader/acquisition/state/caller path was critically read. The whole shell lexer/flush owner was also read; R2 lies in unchanged code within the affected acquisition scope and therefore is not waived by a three-function diff. Current tests cover the old exact regressions but omit protocol-getter aliases and heredoc command separators. Whole previous71 tests retain70 byte-identical complete bodies, exactly one authorized fd3 expectation superseded, and two new tests. Original80368 terminal1/72 of73 remains historical. No byte-identical71-prefix claim is made.

Current own graph acquisition original46383 reached terminal0:56 qualified Sources,27 operations,841 closure Sources,837 executable Sources,1720 edges and841 dependencies. The complete graph, including inputKey, equals current API author's graph exactly. The full recipe/caller/source guards were read, including ordinary unqualified CommonJS closure/fallback, own-package finite exports, intrinsic require authority, public entry versus canonical emitter/cache/caller identity, unknown capability transfers, finite selected module paths and static PV authority. Full graph/input binding is a Source-identity facet, not Python/shell semantic completeness.

Author95, API34 and Root receiving132 sealed artifacts independently rehash with zero mismatch. Author182 native records independently retain181 exit0 and exactly the deliberate classmethod-binding read-before-exit1; it is not native success. The author's current owning73, twelve source probes and two uncaught source-error children are externally attributed evidence, not reviewer executions. The native/import/runtime consumers and their supporting contract/public-caller dependency bytes remain current; unchanged body/dependency guards allow only narrower reuse. Critical current bootstrap, shell, supervisor, workload, deploy ordering, runtimeConsumer pair lookup/contracts, product default/selected/Secret contracts, canonical reference provenance, captured bearer and diagnostic/publication owners were checked against those guards and current Root evidence. No entire old approval is inherited.

Root ACTUAL current11 original40105/PID416150 terminal0/295 PASS has independently equal result seal ebcd8159e2e07587408e4177a2fc1a61a112548bbb557060c54e8cf2645b419c and all43 current inputs equal. Root ACTUAL63 original86014 terminal0/63 PASS has132 exact artifacts and9 unchanged current Tool inputs. Each63 actual outcome was independently checked for nonzero expected reason plus actual receiving Source, or green436 for positive controls. All six prior global/nonlocal scalar cases and both prior pipe false greens are now useful negatives, and FD3 winning-fd0/baselines remain green436. These are Root's executions, not this reviewer's, and cannot offset the new15 false greens and one passive false rejection.

API input sealing1198 independently compares1195 unchanged and exactly THREE supporting prose/metadata deltas: documentation-completion-matrix.json nowae96309828ad38851ca52e2424e22faf23449eef4ac886ab737b66688f057bc0, use/recovery.md now944988014bbfecd79138d2180f47631218ecea38efef9ae4bc3239e4e76a1a52, use/diagnose.md now5bc06556def06f1edb61193867ea499c9c407f092ffe7530e817d91d5e55853b. The recovery change comprises evidence prose; diagnose adds Source callouts, with intermediate55d5 observed during review and final5bc065 at seal. The matrix is supporting acceptance metadata. Root reports a separate docs/matrix commit and push; this reviewer performs no Git mutation. These are Root/documentation-owner changes, not runtime graph/qualification input drift or reviewer edits. Handbook87cf and governing quality/contract/fixtures/catalogue/execution inputs remain current. The checkout is not described as immutable. Prose/Reader/Quality acceptance is not imported from the API or Root source-bound receipts.

## Individual F1–F10 decisions

| Family | Verdict | Assigned current Source assessment |
| --- | --- | --- |
| F1 function annotation identity/timing | FAIL | Defining-module/active-closure/timing controls pass; protocol alias annotation has native new-key read and false GREEN436 under R1. |
| F2 class annotation/class namespace | FAIL | Class namespace/base/metaclass/metadata controls pass; class protocol alias annotation falsely restores old finite key under R1. |
| F3 method annotation identity/timing | FAIL | Current class-owned method/getter controls pass; method protocol alias annotation is false GREEN436 under R1. |
| F4 Python argv mode | PASS | Own current39 controls and current Root finite-mode tests preserve first selected mode, wrappers, flags and passive script/module trailing data. R2 is fd0 acquisition. |
| F5 executable YAML/shell acquisition | FAIL | Old top-level unresolved stdin/file/depth/recursive fixes pass; six winning-heredoc separator consumers disappear and passive recipe is promoted under R2. |
| F6 recognizable acquisition/capability boundary | FAIL | Current reflection/protocol/default/container controls pass; reader aliases already recognized by role() lose external key sensitivity under R1. |
| F7 os star import | PASS | Exact syntax-only production rejection retained at :5786 and current Root tests; no generic star-import interpreter claim. |
| F8 returned/passed/default/container/escaped custody | FAIL | Own capability/snapshot/forwarding controls pass; supported external scalar custody through recognized getter aliases still fails R1. |
| F9 immutable Source/public caller authority | PASS | Own current complete graph equality and exact Source/recipe/caller checks plus actual current Root consumer negatives support this bounded identity facet. Not semantic completeness. |
| F10 exact captured Codex bearer authority | PASS | Exact shell/source/selected Codex container/bearer Secret volume/mount/bootstrap dependencies current; actual Root captured-custody negatives support bounded facet. No live authentication claim. |

## Individual remaining assigned Source facets

| Facet | Verdict | Evidence and limit |
| --- | --- | --- |
| Syntax-only AST/passive literals/Unicode coordinates | PASS | Isolated -I AST owner unchanged outside bounded correction; Root current coordinate/lexical controls retain byte-to-UTF16 mapping. Python passive literals stay passive; shell pending-data failure is separately R2. |
| Imports/aliases/finite keys/joins/rebindings | FAIL | Existing finite joins/reset controls pass; supported getter/NamedExpr aliases omit external scalar sensitivity under R1. |
| Defining-module/active-closure ownership | FAIL | Own current module/closure controls pass; module/nonlocal scalar restoration still loses new recognized alias readers under R1. |
| Annotation metadata/protocol/string/namespace boundaries | FAIL | Own namespace/metaclass/future/metadata boundaries pass; evaluated supported protocol alias annotations fail R1 in function/class/method. |
| Global/nonlocal capability and scalar writes | FAIL | Known module/getter/reader transfers correctly reject; external finite scalar writes feeding supported aliases fail R1. |
| Local/containing-scope capability and scalar writes | PASS | Current old local-key controls independently checked in Root63; comprehension invalidation preserves useful boundaries, explicit known reset remains supported. |
| Returned/passed/default/container/escaped capabilities | PASS | Own current controls retain useful errors and pure/passive neighbors; no arbitrary helper/callback interpretation. Scalar external failure assessed separately. |
| Exact snapshot/subprocess producer/forwarding | PASS | Own current written/unwritten/defining-module/callee-shadow/closure/reflection/helper controls all pass. No product subprocess targets executed. |
| Shell fd0/heredoc/file/recursive/depth/positions | FAIL | Current file/recursive/depth/fd3/optional-position controls pass; separator discards winning heredoc and its passive body ownership under R2. |
| Ordinary unqualified CommonJS complete closure | PASS | Current exact graph owner/read and Root fallback/cycle/cache/unknown transfer tests retain discoverable output or useful rejection without metadata exemptions. |
| Own-package root/subpath/scoped exports | PASS | Exact finite exports/canonical/module/own-package bodies/dependencies and Root current cases retain bounded resolution; unmodeled exports reject. |
| Public entry/emitter/caller identity/cache | PASS | Canonical bytes/emitter/citation identity remains distinct from admitted public entry and caller; current Root multiple-emitter/cache/public-entry controls pass. |
| Recursive selected/default/product/nonalias shapes | PASS | Complete selected scope/default/omission contracts and actual Root conditional/array/patch/Secret/nonalias controls current. No complete upstream schema replication claim. |
| Reference provenance/canonical citations | PASS | Original contexts/selection and canonical emitter lines are preserved with public entry display; Root current citation/multiple emitter controls current. No rendered Reader approval. |
| Immutable PV Source/mutable registry resistance | PASS | Static Source pin and independent recipe remain separate from mutable ledger; current API four controls and Root public/PV consumers retain denial. |
| Finite unresolved recipe/Source binding | PASS | Own qualification56 and exact graph agree with current author; independent71f620 recipe binds complete cd8c Source. Identity binding does not close R1/R2. |
| Diagnostic three sinks/full producer Source | PASS | Exact producer/classification/caller/sink inputs remain current; actual Root negative controls refuse new publishers/refreshed tuples/changed sinks. New diagnose callouts are prose delta, not Source-role expansion. |
| Native corpus/capture exclusions | PASS | Current complete test/package/caller guard bytes and Root reachability tests preserve synthetic exclusions without public consumers. No actual database/browser corpus execution by reviewer. |
| OPS selector/precedence/file decoding/order/partial effects | PASS | Full bootstrap/deploy Source retains untrimmed path selector, default decoding/stripped contents, prevalidation order and earlier partial effects; current Root OPS contract tests pass. No live rotation/install. |
| Supervisor forwarding/shell value semantics | PASS | Full supervisor/shell bytes retain environment copy, token strip/substitution trim and actual exec semantics; exact contracts/current Root proof support bounded claims. |
| Whole Secret copies/grants/projections | PASS | Current selected API/runtime/controller/consumer bytes and actual Root Secret tests preserve whole-copy sanitation, grant/projection distinctions. No live enforcement. |
| Receipt/event/runtimeConsumer contracts | PASS | Current exact producer/consumer pair lookup and required fields plus receipt/event/proof/default dependencies remain sealed/graph-bound. No live event or receipt effects. |
| New consumers discovered or rejected usefully | FAIL | Nine Python and six shell/YAML complete receiving mutations remain false GREEN436; passive recipe has false rejection. |
| Library publication allowance | PASS | Complete unchanged c930 allowlist/classification/regular-file/symlink/copy owner read and current dependencies sealed. No new publication or generic docs-name exemption. |

## Individual assigned catalogue/gate Source decisions

These are individual assigned Source facets, not whole content, Reader, Quality or package approvals.

| ID | Verdict | Assigned Source reason |
| --- | --- | --- |
| CFG-010 | FAIL | Ops/Codex bootstrap and selected workload Source consumers disappear under R1/R2. |
| CFG-011 | FAIL | Native new external keys/heredoc consumers leave exact coverage green. |
| CFG-013 | FAIL | Effective native external finite scalar key differs from restored inventory under R1. |
| CFG-015 | FAIL | Neither R1 nor R2 active failures gives the intended useful Source boundary; passive data is wrongly diagnosed. |
| CFG-018 | FAIL | Recognized aliases/executable heredoc handoffs silently lose active consumers; selected/default API facet passes separately. |
| OPR-003 | PASS | Exact bootstrap/deploy prevalidation/order/effect Source facet only. |
| OPR-006 | PASS | Exact three diagnostic sinks/full producer qualification Source facet only; current diagnose prose delta separately assigned. |
| OPR-008 | PASS | Exact selectors/file decoding/prevalidation/partial-effects Source facet only. |
| REF-003 | FAIL | Environment acquisition incomplete across supported alias-key and winning heredoc custody. |
| REF-004 | PASS | Current canonical schema/default/selected/caller/reference/graph Source facet only. |
| REF-012 | FAIL | Fifteen new Source receiving consumers remain false green; Secret copy/grant facets pass separately. |
| A98-10 | FAIL | Recursive actual environment consumer Source inventory incomplete under R1/R2. |
| A98-11 | FAIL | External effective finite key custody falsely restores the old value under R1. |
| A98-14 | FAIL | New supported consumer Source mutations remain green. Full preregistered mutation package not executed. |
| A911-01 | FAIL | Declared finite boundaries lose recognized getter aliases and known winning heredoc ownership. |
| A911-02 | FAIL | Environment/source recursion incomplete; API/default facets separately pass. |
| A911-08 | PASS | Assigned source-only receivers/shared Source guard remain read-only; no clean regeneration/determinism acceptance. |
| A911-12 | FAIL | Complete independent assigned Source audit finds two material findings. |
| A912-01 | PASS | Exact diagnostic/static-fixture/publication allowance Source facet only; no renderer/Reader approval. |

## Own checks, failures and unexecuted work

Own originals97769 and94091 reached terminal0 and retain27 complete receiving decisions: fifteen false greens, one false passive rejection, three correct native/key sensitivities, four correct passive controls, four exact baseline/restored green436 decisions. No driver success is claimed as consumer correctness. Exact unchanged current authority inputs were used in complete private checkouts, with existing node_modules read-only as dependency input. Eleven complete Python mutations compile legally; product Sources are never executed.

Own new-probe/current23 native records all exit0 with intended outputs; YAML/shell paired runs of the same program are observations, not extra distinct semantic consumers. Exploratory protocol-alias-results retains the initial illegal setdefault snippet's native1 (missing required value argument); the legal current witness supplies fallback and exits0. Other exploratory records are not inflated into the current23 total. Read-only preparation errors for nonexistent manifest/source/control filenames are explicitly retained in setup-and-exploratory-failures.json and corrected by reading actual authorities. They are not hidden semantic passes.

Own original88842 reached terminal0/39 finite semantic controls PASS, including defining globals/class namespace/closure, metadata/future boundaries, capability containers/defaults/escape, exact snapshot/subprocess forwarding and finite argv/heredoc controls. Original46383 reached terminal0/qualification56 and exact current graph equality. Independent complete body comparison terminal0 confirms128/125/three changed. Every own original handle reached its terminal; none was restarted for quiet output.

Not executed or approved: whole preregistered84 mutation package, generation/build/publication/render, clean Reader/browser tasks, fresh Quality tasks, package/global completion, target images, product bootstrap/shell, provider/cluster/credentials/authentication, install/deployment/host changes or live event/receipt effects. Source unit/native and full private receiver evidence remain separate from those classes. Useful conservative unsupported boundaries suffice; no universal Python/shell/Node interpreter or resolver is requested.

**Final complete assigned Tool Source verdict: FAIL.** A coherent R1/R2 correction batch, native/passive/actual-Source receiving controls, exact updated qualification and a fresh complete independent assigned Source review remain required.
