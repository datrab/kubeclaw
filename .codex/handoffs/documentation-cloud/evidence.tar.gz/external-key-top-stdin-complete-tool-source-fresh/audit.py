import json,hashlib
from pathlib import Path
R=Path('/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04'); E=Path(__file__).parent; A=E.parent
out={}
for name,manifest in [('external-key-top-level-stdin-complete-batch-writer','artifact-manifest.json'),('external-key-top-level-stdin-source-qualification','manifest.json'),('root-external-key-top-level-stdin-receiving','root-terminal-seal.json')]:
 x=json.loads((A/name/manifest).read_text());rows=x if isinstance(x,list) else x.get('artifacts',x.get('files',[]));bad=[]
 for row in rows:
  f=Path(row['path']); f=f if f.is_absolute() else A/name/f
  if not f.exists() or hashlib.sha256(f.read_bytes()).hexdigest()!=row['sha256']:bad.append(str(f))
 out[name]={'artifacts':len(rows),'mismatches':bad}
x=json.loads((A/'external-key-top-level-stdin-source-qualification/input-manifest.json').read_text());bad=[]
for row in x['files']:
 f=Path(row['path']); actual=hashlib.sha256(f.read_bytes()).hexdigest()
 if actual!=row['sha256']:bad.append(dict(row,actual=actual))
out['api-inputs']={'count':len(x['files']),'mismatches':bad}
x=json.loads((A/'root-integrated-external-key-top-level-stdin/result.json').read_text());out['root-integrated']={k:x.get(k) for k in ['exitCode','summary']};out['root-integrated']['currentInputDeltas']=[f for f,h in x['after'].items() if hashlib.sha256((R/f).read_bytes()).hexdigest()!=h];out['root-integrated']['resultSealEqual']=hashlib.sha256((A/'root-integrated-external-key-top-level-stdin/result.json').read_bytes()).hexdigest()==json.loads((A/'root-integrated-external-key-top-level-stdin/root-terminal-seal.json').read_text())['resultSha256']
x=json.loads((A/'root-external-key-top-level-stdin-receiving/receiving-results.json').read_text());print('receiver keys',list(x[0]));out['root-receiving']={'count':len(x),'actual':[{k:r.get(k) for k in ['name','exitCode','exit','passed','expected','stdout','stderr']} for r in x]}
x=json.loads((A/'external-key-top-level-stdin-complete-batch-writer/full-native-results.json').read_text());print('native keys',type(x),list(x)[:3] if isinstance(x,dict) else list(x[0])); rows=x if isinstance(x,list) else x.get('results',x.get('records',[]));out['author-native']={'count':len(rows),'nonzero':[r for r in rows if r.get('exit',r.get('status',r.get('native',{}).get('exit'))) not in [0,None]]}
(E/'external-audit.json').write_text(json.dumps(out,indent=2)); print(json.dumps({k:v if k!='root-receiving' else {a:b for a,b in v.items() if a!='actual'} for k,v in out.items()},indent=2))
ids=['CFG-010','CFG-011','CFG-013','CFG-015','CFG-018','OPR-003','OPR-006','OPR-008','REF-003','REF-004','REF-012'];cat=json.loads((R/'docs/blueprint/generated/ap09-catalogue.json').read_text()); print('cataloguekeys',list(cat)); rows=cat.get('requirements',cat.get('items',[]));selected=[r for r in rows if r.get('id') in ids];(E/'catalogue-records.json').write_text(json.dumps(selected,indent=2))
