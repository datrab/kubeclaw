import fs from 'node:fs';import path from 'node:path';import vm from 'node:vm';import assert from 'node:assert/strict';import {spawnSync} from 'node:child_process';import {createRequire} from 'node:module';
const root='/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04',evidence='/home/node/Documents/Codex/a98-evidence/external-key-top-stdin-complete-tool-source-fresh';const require=createRequire(root+'/package.json');const source=fs.readFileSync(root+'/scripts/docs-configuration-inventory.mjs','utf8');const box={fs,path,assert,Buffer,spawnSync,root,YAML:require('yaml')};vm.createContext(box);for(const name of ['lineAt','pythonEnvironmentReads','pythonArgvMode','pythonInterpreterIndex','pythonShellPrograms','pythonYamlPrograms','acquiredPythonEnvironmentReads']){const start=source.indexOf('function '+name+'('),end=source.indexOf('\n}\n',start)+2;vm.runInContext(source.slice(start,end),box)}
const results=[];
for (const tail of ['', ';', ' | cat', ' && true']) {
 const code=`python3 - <<'PY'${tail}\nimport os\nprint(os.getenv("HEREDOC_KEY_NEW"))\nPY\n`;
 let names,error;try{names=Array.from(box.acquiredPythonEnvironmentReads('ops/pod/shell.sh',code),r=>r.name)}catch(e){error=e.message};
 const native=spawnSync('/bin/sh',['-c',code],{encoding:'utf8',env:{...process.env,HEREDOC_KEY_NEW:'here-observed'}});
 results.push({tail,code,names,error,native:{exit:native.status,stdout:native.stdout,stderr:native.stderr}});
}
fs.writeFileSync(evidence+'/heredoc-tail-results.json',JSON.stringify(results,null,2));console.log(JSON.stringify(results,null,2));