import fs from 'node:fs';import path from 'node:path';import vm from 'node:vm';import assert from 'node:assert/strict';import {spawnSync} from 'node:child_process';import {createRequire} from 'node:module';
const root='/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04',evidence='/home/node/Documents/Codex/a98-evidence/external-key-top-stdin-complete-tool-source-fresh';const require=createRequire(root+'/package.json');const source=fs.readFileSync(root+'/scripts/docs-configuration-inventory.mjs','utf8');const box={fs,path,assert,Buffer,spawnSync,root,YAML:require('yaml')};vm.createContext(box);for(const name of ['lineAt','pythonEnvironmentReads','pythonArgvMode','pythonInterpreterIndex','pythonShellPrograms','pythonYamlPrograms','acquiredPythonEnvironmentReads']){const start=source.indexOf('function '+name+'('),end=source.indexOf('\n}\n',start)+2;vm.runInContext(source.slice(start,end),box)}
const results=[];
for (const getter of ['os.getenv.__call__','os.environ.__getitem__','os.environ.setdefault','os.environ.get.__call__','os.getenv']) {
 const code=`import os\nkey='KUBE_CONTEXT'\ngetter=${getter}\ndef change():\n global key\n key='GLOBAL_KEY_NEW'\nchange()\nchosen=key\nprint(getter(chosen))\n`;
 let names,error;try{names=Array.from(box.pythonEnvironmentReads(code,'ops/pod/bootstrap.py'),r=>r.name)}catch(e){error=e.message};
 const native=spawnSync('python3',['-I','-c',code],{encoding:'utf8',env:{...process.env,GLOBAL_KEY_NEW:'new-observed',KUBE_CONTEXT:'old-observed'}});
 results.push({getter,code,names,error,native:{exit:native.status,stdout:native.stdout,stderr:native.stderr}});
}
fs.writeFileSync(evidence+'/protocol-alias-results.json',JSON.stringify(results,null,2));console.log(JSON.stringify(results,null,2));