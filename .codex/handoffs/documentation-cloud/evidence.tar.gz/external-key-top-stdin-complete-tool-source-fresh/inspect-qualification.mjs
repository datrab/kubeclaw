import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import os from 'node:os';
import {createHash} from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {createRequire} from 'node:module';
const root=process.argv[2],out=path.dirname(new URL(import.meta.url).pathname),require=createRequire(root+'/package.json');
const text=fs.readFileSync(root+'/scripts/docs-api-output-discovery.mjs','utf8');
const checked=Object.assign((...a)=>assert(...a),assert,{deepEqual:(a,b,m)=>assert.deepEqual(JSON.parse(JSON.stringify(a)),JSON.parse(JSON.stringify(b)),m)});
const box={fs,path,vm,assert:checked,os,createHash,spawnSync,ts:require('typescript'),YAML:require('yaml'),process,console};
vm.createContext(box);
vm.runInContext(text.slice(0,text.indexOf('function assertNativeSerializationRoles')).replace(/^import .*;\n/gm,''),box);
for(const name of ['walkProductSources','producerAdapterOperationRecipe']){const s=text.indexOf('export function '+name+'('),e=text.indexOf('\n}\n',s)+2;assert(s>=0&&e>s);vm.runInContext(text.slice(s,e).replace('export function','function'),box);}
const packageBytes=fs.readFileSync(root+'/package.json'),registry=JSON.parse(fs.readFileSync(root+'/scripts/docs-api-producer-adapter-authorities.json'));
const graph=box.documentationModuleGraph(root,packageBytes,registry.documentationToolBoundary);
const hash=x=>createHash('sha256').update(x).digest('hex');
const records=graph.dynamicOperations.map(({source,expression,operation,hints,...others})=>({source,expression,operationSha256:hash(operation),hints,...others}));
fs.writeFileSync(out+'/observed-module-graph.json',JSON.stringify({inputKey:graph.inputKey,edges:graph.edges,dynamicOperations:records,aliases:graph.aliases,closureSources:graph.closureSources,executableSources:graph.executableSources,dependencyPaths:graph.dependencyPaths},null,2)+'\n');
let size,error;try{size=box.documentationToolSources(root).size}catch(e){error=e.message;}
fs.writeFileSync(out+'/observed-qualification.json',JSON.stringify({size,error,inputKey:graph.inputKey,qualificationCandidate:true,independentAcceptance:false},null,2)+'\n');
console.log(JSON.stringify({size,error,dynamicOperations:records.length,closureSources:graph.closureSources.length,inputKey:graph.inputKey}));
