import pathlib,re,json,hashlib,subprocess,shutil
repo=pathlib.Path('/home/node/Documents/Codex/2026-09-15-ich-arbeite-an-pr13-ap01-ap04');out=pathlib.Path(__file__).parent
old=pathlib.Path('/home/node/Documents/Codex/a98-evidence/diagnose-corrected-complete-source-fresh');author=old.parent/'diagnose-evidence-callouts-complete-batch-writer'
hash=lambda b:hashlib.sha256(b).hexdigest()
page=(repo/'docs/site/use/diagnose.md').read_text();before=(old/'frozen/docs/site/use/diagnose.md').read_text()
(out/'diagnose.md').write_text(page)
blocks=lambda p:re.findall(r'```bash\n(.*?)\n```',p,re.S)
assert blocks(page)==blocks(before)
oldnodes=json.loads((old/'node-programs.json').read_text());nodes=[]
for i,b in enumerate(blocks(page)):
 for m in re.finditer(r"\bnode(?P<args>[^\n]*?)\s-e\s*'(?P<code>[\s\S]*?)'",b):nodes.append({'block':i,'mode':'module' if '--input-type=module' in m['args'] else 'native-default-commonjs','code':m['code']})
 for m in re.finditer(r"\bnode(?P<args>[^\n]*(?:\\\n[^\n]*)*?)\s*<<'NODE'\n(?P<code>[\s\S]*?)\nNODE",b):nodes.append({'block':i,'mode':'module' if '--input-type=module' in m['args'] else 'native-default-commonjs','code':m['code']})
assert nodes==[{k:n[k] for k in ('block','mode','code')} for n in oldnodes]
# Remove only exact inserted evidence blocks and their added blank lines using difference opcodes.
import difflib
ops=difflib.SequenceMatcher(a=before.splitlines(True),b=page.splitlines(True),autojunk=False).get_opcodes();changed=[]
for tag,a,b,c,d in ops:
 if tag!='equal':
  content=''.join(page.splitlines(True)[c:d]);assert tag in ('insert','replace') and all(not l.strip() or l.startswith('>') for l in content.splitlines()) and all(not l.strip() or l.startswith('>') for l in before.splitlines(True)[a:b]);changed.append({'line':c+1,'lines':d-c,'sha256':hash(content.encode())})
assert len(re.findall(r'^> \*\*Source evidence',page,re.M))==10
paths={x['path'] for x in json.loads((old/'inputs-after.json').read_text())['files']}|{x['path'] for x in json.loads((old/'supplementary-inputs.json').read_text())}|{x['path'] for x in json.loads((author/'inputs-after.json').read_text())}
pins=[]
for m in re.finditer(r'https://github.com/datrab/kubeclaw/blob/([a-f0-9]{40})/([^\s)#]+)#L(\d+)(?:-L(\d+))?',page):
 rev,p,start,end=m.groups();data=subprocess.check_output(['git','show',f'{rev}:{p}'],cwd=repo);cur=(repo/p).read_bytes();s=int(start);e=int(end or start)
 assert data==cur and 1<=s<=e<=len(data.splitlines()) and e-s+1<=60
 pins.append({'url':m.group(),'path':p,'sha256':hash(data),'fullCurrentEqual':True,'start':s,'end':e});paths.add(p)
inputs=[];oldmap={x['path']:x for x in json.loads((old/'inputs-after.json').read_text())['files']+json.loads((old/'supplementary-inputs.json').read_text())}
for p in sorted(paths):
 data=(repo/p).read_bytes();target=out/'frozen'/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 inputs.append({'path':p,'sha256':hash(data),'bytes':len(data),'equalsOld':hash(data)==oldmap[p]['sha256'] if p in oldmap else None})
# Check all historical artifacts against sealed manifest, then copy only check logs/results and supporting harness/data for traceable reuse.
arts=json.loads((old/'artifacts.json').read_text());checked=[]
for x in arts:
 data=(old/x['path']).read_bytes();assert hash(data)==x['sha256'] and len(data)==x['bytes'];checked.append(x)
(out/'historical-artifacts-verified.json').write_text(json.dumps(checked,indent=2)+'\n')
for name in ('syntax-results.json','native-commonjs-results.json','cause-results.json','guard-results.json','journal-parser-results.json'):
 if (old/name).exists():shutil.copy2(old/name,out/('reused-'+name))
(out/'source-links.json').write_text(json.dumps(pins,indent=2)+'\n');(out/'inputs-before.json').write_text(json.dumps(inputs,indent=2)+'\n')
(out/'equality.json').write_text(json.dumps({'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'pageSha256':hash(page.encode()),'historicalPageSha256':hash(before.encode()),'bashBlocks':len(blocks(page)),'nodePrograms':len(nodes),'commonjs':sum(n['mode']=='native-default-commonjs' for n in nodes),'executableBytesEqual':True,'nonCalloutPageBytesEqual':True,'insertions':changed,'pins':len(pins),'verifiedHistoricalArtifacts':len(checked),'changedInputs':[x for x in inputs if x['equalsOld'] is False]},indent=2)+'\n')
print((out/'equality.json').read_text())
