// PREPARED NOT RUN. Import ORIGINAL reviewed modules only after fixed preflight.
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import childProcess from 'node:child_process';
import {syncBuiltinESMExports} from 'node:module';
import assert from 'node:assert/strict';
const argv=process.argv.slice(2),args={};
assert.equal(argv.length,12);for(let i=0;i<argv.length;i+=2){assert(['--root','--revision','--manifest','--manifest-sha256','--output','--mode'].includes(argv[i]));assert(!Object.hasOwn(args,argv[i]));args[argv[i]]=argv[i+1];}
// Six pairs are required (controller supplies exactly these); reject extras.
assert.equal(Object.keys(args).length,6);
const root=args['--root'],output=args['--output'],mode=args['--mode'];
assert.equal(mode,'public-roles');assert.equal(fs.realpathSync(root),root);
const manifestBytes=fs.readFileSync(args['--manifest']);assert.equal(createHash('sha256').update(manifestBytes).digest('hex'),args['--manifest-sha256']);const manifest=JSON.parse(manifestBytes);
assert.equal(manifest.status,'REVIEWED_FROZEN_READY');assert(manifest.allowedModes.includes(mode),'mode not independently approved');assert.equal(manifest.revision,args['--revision']);assert.equal(manifest.root,root);assert.deepEqual(manifest.preLaunchStops,[],'prelaunch Source/DATA stops remain');
fs.mkdirSync(output,{mode:0o700});
const hash=x=>createHash('sha256').update(x).digest('hex');
const write=(name,value)=>fs.writeFileSync(path.join(output,name),JSON.stringify(value,null,2)+'\n',{flag:'wx'});
function typedNamespaceSnapshot(tool){
 const files=[],directories=[],links=[];
 const order=(a,b)=>a.path<b.path?-1:a.path>b.path?1:0;
 function walk(directory){const st=fs.lstatSync(directory,{bigint:true});assert(st.isDirectory()&&!st.isSymbolicLink()&&fs.realpathSync(directory)===directory);const members=[];
  for(const name of fs.readdirSync(directory)){const file=path.join(directory,name),info=fs.lstatSync(file);let kind;
   if(info.isSymbolicLink()){kind='symlink';links.push({path:file,target:fs.readlinkSync(file),canonical:fs.realpathSync(file)});}
   else if(info.isFile()){kind='file';files.push({path:file,sha256:hash(fs.readFileSync(file)),mode:info.mode&0o7777});}
   else{assert(info.isDirectory(),file);kind='directory';walk(file);}members.push({name,kind});}
  directories.push({path:directory,canonical:fs.realpathSync(directory),device:st.dev.toString(),inode:st.ino.toString(),members:members.sort((a,b)=>a.name<b.name?-1:a.name>b.name?1:0)});
 }walk(tool.root);const actual={root:tool.root,files:files.sort(order),directories:directories.sort(order),links:links.sort(order)};assert.deepEqual(actual,tool,'SYSTEMTOOL complete typed namespace/context drift');return actual;
}
function nativeContext(){
 const packets=[];
 for(const packet of manifest.nativeNamespacePackets){const data=fs.readFileSync(packet.path);assert.equal(hash(data),packet.sha256);const value=JSON.parse(data).namespace;assert.deepEqual(value.other,[]);
  for(const item of value.files){const st=fs.lstatSync(item.path,{bigint:true});assert(st.isFile()&&!st.isSymbolicLink());assert.equal(hash(fs.readFileSync(item.path)),item.sha256);assert.equal(Number(st.size),item.bytes);assert.equal(Number(st.mode)&0o7777,item.mode);assert.equal(st.dev.toString(),String(item.device));assert.equal(st.ino.toString(),String(item.inode));}
  for(const item of value.directories){const st=fs.lstatSync(item.path,{bigint:true});assert(st.isDirectory()&&!st.isSymbolicLink());assert.equal(fs.realpathSync(item.path),item.canonical);assert.deepEqual(fs.readdirSync(item.path).sort(),item.members);assert.equal(Number(st.mode)&0o7777,item.mode);assert.equal(st.dev.toString(),String(item.device));assert.equal(st.ino.toString(),String(item.inode));}
  for(const item of value.links){const st=fs.lstatSync(item.path,{bigint:true});assert(st.isSymbolicLink());assert.equal(fs.readlinkSync(item.path),item.target);assert.equal(fs.realpathSync(item.path),item.canonical);assert.equal(Number(st.mode)&0o7777,item.mode);assert.equal(st.dev.toString(),String(item.device));assert.equal(st.ino.toString(),String(item.inode));}
  packets.push({path:packet.path,sha256:hash(data)});
 }
 for(const item of manifest.nativePathContext){let st;try{st=fs.lstatSync(item.path,{bigint:true});}catch(error){if(error.code==='ENOENT'){assert.equal(item.kind,'absent');continue;}throw error;}assert.notEqual(item.kind,'absent');assert.equal(Number(st.mode)&0o7777,item.mode);
  if(item.kind==='regular-file'){assert(st.isFile()&&!st.isSymbolicLink());assert.equal(Number(st.size),item.bytes);assert.equal(hash(fs.readFileSync(item.path)),item.sha256);}
  else if(item.kind==='link'){assert(st.isSymbolicLink());assert.equal(fs.readlinkSync(item.path),item.target);assert.equal(fs.realpathSync(item.path),item.canonical);}
  else{assert.equal(item.kind,'directory');assert(st.isDirectory()&&!st.isSymbolicLink());assert.equal(fs.realpathSync(item.path),item.canonical);assert.equal(st.dev.toString(),String(item.device));assert.equal(st.ino.toString(),String(item.inode));assert.deepEqual(fs.readdirSync(item.path).sort(),item.members);}
 }
 assert.equal(fs.readFileSync(path.join(path.dirname(output),'go-telemetry','mode'),'utf8'),'off');return {namespacePackets:packets,paths:manifest.nativePathContext};
}
function consumedContext(){
 const packet=manifest.consumedContextPacket,data=fs.readFileSync(packet.path);assert.equal(hash(data),packet.sha256);const rows=JSON.parse(data);
 for(const item of rows){const file=path.join(root,item.source);if(item.status==='ABSENT'){try{fs.lstatSync(file);}catch(error){if(error.code==='ENOENT')continue;throw error;}assert.fail('consumed absent path acquired: '+file);}
  const st=fs.lstatSync(file);assert(!st.isSymbolicLink());assert.equal(fs.realpathSync(file),file);
  if(item.kind==='regular-file'){assert(st.isFile());assert.equal(hash(fs.readFileSync(file)),item.sha256);}
  else{assert.equal(item.kind,'directory-context');assert(st.isDirectory());assert.equal(fs.realpathSync(file),item.canonical);const members=fs.readdirSync(file,{withFileTypes:true}).map(q=>({name:q.name,kind:q.isSymbolicLink()?'symlink':q.isDirectory()?'directory':q.isFile()?'file':'other'}));const order=(a,b)=>a.name<b.name?-1:a.name>b.name?1:0;assert.deepEqual(members.sort(order),[...item.members].sort(order));}
 }return {packetSha256:hash(data),count:rows.length};
}
function physical(){
 const rows=manifest.files.map(item=>{const st=fs.lstatSync(item.path);assert(st.isFile()&&!st.isSymbolicLink()&&fs.realpathSync(item.path)===item.path,item.path);const sha256=hash(fs.readFileSync(item.path));assert.equal(sha256,item.sha256,item.path);assert.equal(st.mode&0o7777,item.mode,item.path);return {path:item.path,sha256};});
 for(const file of manifest.absent){try{fs.lstatSync(file);}catch(error){if(error.code==='ENOENT')continue;throw error;}assert.fail('absent path acquired: '+file);}
 const contextDirectories=manifest.contextDirectories.map(item=>{assert.equal(item.type,'directory','unknown directory context type');const st=fs.lstatSync(item.path,{bigint:true});assert(st.isDirectory()&&!st.isSymbolicLink(),item.path);const actual={path:item.path,type:'directory',canonical:fs.realpathSync(item.path),device:st.dev.toString(),inode:st.ino.toString()};for(const key of Object.keys(actual))assert.equal(actual[key],item[key],item.path+' '+key);return actual;});
 for(const link of manifest.links){assert(fs.lstatSync(link.path).isSymbolicLink());assert.equal(fs.readlinkSync(link.path),link.target);assert.equal(fs.realpathSync(link.path),link.canonical);}
 return {consumedContext:consumedContext(),nativeContext:nativeContext(),systemToolInstallation:typedNamespaceSnapshot(manifest.systemToolInstallation),installedCandidateNamespace:typedNamespaceSnapshot(manifest.installedCandidateNamespace),files:rows,contextDirectories,absent:manifest.absent,links:manifest.links};
}
const before=physical();write('initialization-context-before.json',before);
const environment=Object.fromEntries(Object.entries(process.env).sort(([a],[b])=>a.localeCompare(b)));
const expectedEnvironment={PATH:'/usr/local/bin:/usr/bin:/bin',HOME:'/home/node',LANG:'C.UTF-8',LC_ALL:'C.UTF-8',TZ:'UTC',KUBECLAW_DOCS_GO_BINARY:'/usr/local/go/bin/go',TMPDIR:path.join(path.dirname(output),'tmp')};
if(mode==='public-roles')Object.assign(expectedEnvironment,{npm_config_cache:path.join(path.dirname(output),'npm-cache'),npm_config_update_notifier:'false',npm_config_logs_max:'0',npm_config_logs_dir:path.join(path.dirname(output),'npm-cache','_logs'),npm_config_timing:'false'});
Object.assign(expectedEnvironment,{GOENV:'off',GOTOOLCHAIN:'local',GOROOT:'/usr/local/go',GO111MODULE:'off',GOWORK:'off',GOPROXY:'off',GOSUMDB:'off',CGO_ENABLED:'0',GOOS:'linux',GOARCH:'amd64',GOAMD64:'v1',GOMAXPROCS:'2',GOPATH:path.join(path.dirname(output),'gopath'),GOMODCACHE:path.join(path.dirname(output),'go-mod-cache'),GOCACHE:path.join(path.dirname(output),'go-build-cache'),GOTMPDIR:path.join(path.dirname(output),'go-tmp'),TEST_TELEMETRY_DIR:path.join(path.dirname(output),'go-telemetry'),PYTHONNOUSERSITE:'1',PYTHONDONTWRITEBYTECODE:'1',SETUPTOOLS_USE_DISTUTILS:'stdlib'});
assert.deepEqual(environment,Object.fromEntries(Object.entries(expectedEnvironment).sort(([a],[b])=>a.localeCompare(b))));
const originalSpawn=childProcess.spawnSync;let childIndex=0;const nativeFailures=[];
const childKindLimits={'npm-config':480,'posix-glob':232,'go-ast-custody':2,'python-ast-stdin':1},childKindCounts=Object.fromEntries(Object.keys(childKindLimits).map(kind=>[kind,0]));
const returnedStreamBytes={stdout:0,stderr:0},returnedStreamByteLimit=(480+232+32*(2+1))*1024*1024;
const patterns=['tests/verification/reliability/*.test.mts','tests/verification/reliability/*.test.mjs','tests/verification/historical-branch-acceptance/*.test.mjs','skills/prism/tests/*.native.mts'];
const summarizeError=e=>e?{name:e.name,message:e.message,code:e.code,errno:e.errno,syscall:e.syscall,path:e.path,spawnargs:e.spawnargs,stack:e.stack}:null;
function observeSpawn(command,words,options){
 const index=childIndex++;assert(index<715,'whole-process direct-child ceiling');assert.equal(mode,'public-roles');
 const keys=Object.keys(options??{}).sort();let kind,stdin='ABSENT';
 if(command==='python3'||command==='/usr/local/go/bin/go'){
  assert.deepEqual(keys,['encoding','input','maxBuffer']);assert.equal(options.encoding,'utf8');assert.equal(options.maxBuffer,32*1024*1024);
  const selected=command==='python3'?'scripts/docs-api-python-output-adapter.py':path.relative(root,words[3]).replaceAll(path.sep,'/');
  assert(manifest.selectedNativeSources.includes(selected));
  if(command==='python3'){
   kind='python-ast-stdin';assert.deepEqual(words,[path.join(root,'scripts/docs-api-python-ast-v1.py'),'--stdin-custody',selected]);assert.equal(typeof options.input,'string');assert.equal(options.input,fs.readFileSync(path.join(root,selected),'utf8'));stdin={representation:'EXACT_ORIGINAL_UTF8_SOURCE_STDIN',bytes:Buffer.byteLength(options.input),sha256:hash(Buffer.from(options.input,'utf8'))};
  }else{
   kind='go-ast-custody';assert(['scripts/docs-api-go-output-role-adapter.go','scripts/docs-api-go-output-shapes.go'].includes(selected));assert.deepEqual(words,['run',path.join(root,'scripts/docs-api-go-output-role-adapter.go'),'--documentation-custody',path.join(root,selected)]);assert.equal(options.input,undefined);
  }
 }else if(command==='/usr/local/bin/npm'){
  assert.equal(options.cwd,root);assert.equal(options.encoding,'utf8');assert.equal(options.maxBuffer,1024*1024);
  kind='npm-config';assert.deepEqual(keys,['cwd','encoding','env','maxBuffer']);assert.deepEqual(words.slice(0,2),['config','get']);assert.equal(words.length,3);assert(['script-shell','node-options'].includes(words[2]));assert.deepEqual(options.env,{...process.env,npm_config_offline:'true'});
 }else{
  kind='posix-glob';assert.equal(command,'/bin/sh');assert.equal(options.cwd,root);assert.equal(options.encoding,'utf8');assert.equal(options.maxBuffer,1024*1024);assert.deepEqual(keys,['cwd','encoding','maxBuffer']);assert.equal(words.length,2);assert.equal(words[0],'-c');assert(patterns.some(pattern=>words[1]===`set -- ${pattern}; printf '%s\\0' "$@"`));
 }
 assert(Object.hasOwn(childKindLimits,kind));assert(++childKindCounts[kind]<=childKindLimits[kind],'whole-process direct-child kind ceiling: '+kind);
 const slot=`native-${String(index).padStart(3,'0')}`;fs.mkdirSync(path.join(output,slot));
 const put=(name,v)=>fs.writeFileSync(path.join(output,slot,name),JSON.stringify(v,null,2)+'\n',{flag:'wx'});
 put('launch.json',{index,kind,command,argv:words,options,environment:options.env??process.env,stdin,start:new Date().toISOString()});
 try{
  const result=Reflect.apply(originalSpawn,childProcess,[command,words,options]);
  const strings={};for(const stream of ['stdout','stderr']){assert(typeof result[stream]==='string'||result[stream]===null);const value=result[stream];if(value!==null){const bytes=Buffer.from(value,'utf8');fs.writeFileSync(path.join(output,slot,`${stream}.returned-utf8`),bytes,{flag:'wx'});strings[stream]={representation:'ORIGINAL_SPAWNSYNC_UTF8_RETURN_NOT_RAW_PIPE',value,utf8Bytes:bytes.length,sha256:hash(bytes)};}else strings[stream]={representation:'NULL_UNAVAILABLE'};}
  put('terminal.json',{end:new Date().toISOString(),status:result.status,signal:result.signal,error:summarizeError(result.error),pid:result.pid,streams:strings});
  if(result.status!==0||result.signal||result.error||result.stdout===null||result.stderr===null)nativeFailures.push({index,status:result.status,signal:result.signal,error:summarizeError(result.error)});
  for(const stream of ['stdout','stderr'])if(result[stream]!==null){returnedStreamBytes[stream]+=Buffer.byteLength(result[stream],'utf8');assert(returnedStreamBytes[stream]<=returnedStreamByteLimit,'aggregate returned-UTF8 stream ceiling: '+stream);}
  // Preserve original return unchanged, including failed terminal state. The
  // original guard owns rejection; the capture cannot convert it to success.
  return result;
 }catch(error){put('thrown.json',{end:new Date().toISOString(),error:summarizeError(error)});throw error;}
}
const deniedProcessApis=['spawn','exec','execFile','execFileSync','execSync','fork'];const deniedOriginals=new Map(deniedProcessApis.map(name=>[name,childProcess[name]]));for(const name of deniedProcessApis)childProcess[name]=()=>assert.fail('UNREVIEWED_NODE_PROCESS_API: '+name);
childProcess.spawnSync=observeSpawn;syncBuiltinESMExports();
try{
 const custody=await import(pathToFileURL(path.join(root,'scripts/docs-api-documentation-role-custody.mjs')).href);
 const discovery=await import(pathToFileURL(path.join(root,'scripts/docs-api-output-discovery.mjs')).href);
 const scalar=await import(pathToFileURL(path.join(root,'scripts/docs-deployment-scalar-occurrence-custody.mjs')).href);
 const first=discovery.discoverScriptOutputRoleClassifications(root);
 write('actual-public-role-classifications-first.json',first);assert.equal(nativeFailures.length,0,'failed native child stops before repeat even if original consumer returned');
 const between=physical();assert.deepEqual(between,before);write('initialization-context-between.json',between);
 const second=discovery.discoverScriptOutputRoleClassifications(root);
 write('actual-public-role-classifications-repeat.json',second);assert.deepEqual(second,first,'complete original public role result changed');
 write('public-route-closeout.json',{mode,firstSha256:hash(JSON.stringify(first)),secondSha256:hash(JSON.stringify(second)),equal:true,meaning:'Complete original public consumer return only; not no-unknown/API/generator/CI approval'});
 const after=physical();assert.deepEqual(after,before);assert(fs.readFileSync(args['--manifest']).equals(manifestBytes),'manifest changed');write('initialization-context-after.json',after);
 assert.equal(nativeFailures.length,0,'failed native child revokes whole capture even if original consumer did not reject');
 write('completion.json',{status:'DATA_CAPTURE_COMPLETE_UNACCEPTED',mode,revision:manifest.revision,nativeChildCount:childIndex,roleRecords:first.length,limits:['No scalar constant renewed','No role/module/output/API/generator acceptance; selected native AST receiver launch only','UTF8 native return data is not raw OS pipes']});
}catch(error){write('failure.json',{error:summarizeError(error),completion:false});throw error;}
finally{childProcess.spawnSync=originalSpawn;for(const [name,value]of deniedOriginals)childProcess[name]=value;syncBuiltinESMExports();}
