{{/* Migrated operator settings come only from the authored swarm file. */}}
{{- define "prism.swarmConfig" -}}
{{- if or (hasKey .Values.control "maximumWorkerResponseBytes") (hasKey .Values.control "nativeWorkerDispatchTimeoutMs") -}}
{{- fail "Control result and dispatch limits must be authored under swarm.config.json operator.prism.native" -}}
{{- end -}}
{{- if hasKey .Values.control "nativeResourcePolicy" -}}
{{- fail "Control resource policy must be authored under swarm.config.json operator.prism.native.resourcePolicy" -}}
{{- end -}}
{{- if hasKey .Values.worker "shutdownTimeoutMs" -}}
{{- fail "worker.shutdownTimeoutMs moved to swarm.config.json operator.prism.worker.shutdownTimeoutMs" -}}
{{- end -}}
{{- $raw := required "canonical swarm.config.json is required" (.Files.Get "files/config/swarm.config.json") -}}
{{- $config := mustFromJson $raw -}}
{{- $schema := mustFromJson (.Files.Get "files/config/swarm.schema.json") -}}
{{- range $key, $value := $config -}}
{{- if not (hasKey $schema.properties $key) -}}{{- fail (printf "unsupported swarm key %s" $key) -}}{{- end -}}
{{- end -}}
{{- range $key := $schema.required -}}
{{- if not (hasKey $config $key) -}}{{- fail (printf "required swarm key %s" $key) -}}{{- end -}}
{{- end -}}
{{- range $key := list "profile" "features" "tuning" -}}
{{- if ne (toJson (index $config $key)) (toJson (index $schema.properties $key).const) -}}{{- fail (printf "unsupported swarm %s" $key) -}}{{- end -}}
{{- end -}}
{{- if and (hasKey $config "_doc") (not (kindIs "string" $config._doc)) -}}{{- fail "swarm _doc must be a string" -}}{{- end -}}
{{- if not (kindIs "map" $config.overrides) -}}{{- fail "swarm overrides must be an empty object" -}}{{- end -}}
{{- if ne (len $config.overrides) 0 -}}{{- fail "swarm overrides must be an empty object" -}}{{- end -}}
{{- if not (kindIs "map" $config.operator) -}}{{- fail "swarm operator must be an object" -}}{{- end -}}
{{- if or (ne (len $config.operator) 1) (not (hasKey $config.operator "prism")) -}}{{- fail "swarm operator supports prism only" -}}{{- end -}}
{{- if not (kindIs "map" $config.operator.prism) -}}{{- fail "swarm prism must be an object" -}}{{- end -}}
{{- if or (ne (len $config.operator.prism) 2) (not (hasKey $config.operator.prism "worker")) (not (hasKey $config.operator.prism "native")) -}}{{- fail "swarm prism requires worker and native only" -}}{{- end -}}
{{- if not (kindIs "map" $config.operator.prism.worker) -}}{{- fail "swarm worker must be an object" -}}{{- end -}}
{{- $worker := dig "operator" "prism" "worker" (dict) $config -}}
{{- $keys := list "maximumActiveRequests" "maximumProbeRequests" "maximumConnections" "requestTimeoutMs" "shutdownTimeoutMs" "maximumInputBytes" -}}
{{- if ne (len $worker) (len $keys) -}}{{- fail "swarm worker settings must contain exactly the supported keys" -}}{{- end -}}
{{- range $key := $keys -}}
{{- $value := index $worker $key -}}
{{- if not (kindIs "float64" $value) -}}{{- fail (printf "swarm worker %s must be an integer" $key) -}}{{- end -}}
{{- if or (lt $value (float64 1)) (gt $value (float64 2147483647)) (ne $value (floor $value)) -}}
{{- fail (printf "swarm worker %s must be a positive timer-safe integer" $key) -}}
{{- end -}}
{{- end -}}
{{- $native := $config.operator.prism.native -}}
{{- if not (kindIs "map" $native) -}}{{- fail "swarm native must be an object" -}}{{- end -}}
{{- if ne (len $native) 3 -}}{{- fail "swarm native settings must contain exactly the supported keys" -}}{{- end -}}
{{- range $key := list "maximumResultBytes" "dispatchTimeoutMs" -}}
{{- $value := index $native $key -}}
{{- if not (kindIs "float64" $value) -}}{{- fail (printf "swarm native %s must be an integer" $key) -}}{{- end -}}
{{- if or (lt $value (float64 1)) (gt $value (float64 2147483647)) (ne $value (floor $value)) -}}
{{- fail (printf "swarm native %s must be a positive timer-safe integer" $key) -}}
{{- end -}}
{{- end -}}
{{- $policy := $native.resourcePolicy -}}
{{- if not (kindIs "map" $policy) -}}{{- fail "swarm resourcePolicy must be an object" -}}{{- end -}}
{{- if ne (len $policy) 3 -}}{{- fail "swarm resourcePolicy requires exactly cpuTimeMs, memoryBytes and tasks" -}}{{- end -}}
{{- range $key := list "cpuTimeMs" "memoryBytes" "tasks" -}}
{{- $value := index $policy $key -}}
{{- if not (kindIs "float64" $value) -}}{{- fail (printf "swarm resourcePolicy %s must be an integer" $key) -}}{{- end -}}
{{- if or (lt $value (float64 1)) (gt $value (float64 9007199254740991)) (ne $value (floor $value)) -}}
{{- fail (printf "swarm resourcePolicy %s must be a positive safe integer" $key) -}}
{{- end -}}
{{- end -}}
{{- if gt (add (int $worker.maximumActiveRequests) (int $worker.maximumProbeRequests)) (int $worker.maximumConnections) -}}
{{- fail "swarm worker connection budget is too small" -}}
{{- end -}}
{{- $raw -}}
{{- end -}}
