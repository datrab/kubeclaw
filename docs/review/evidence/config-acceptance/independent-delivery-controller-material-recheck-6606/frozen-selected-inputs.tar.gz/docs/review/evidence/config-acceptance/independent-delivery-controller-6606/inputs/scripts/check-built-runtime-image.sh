#!/usr/bin/env bash
set -euo pipefail

# CI host checks shared by PR images and immutable published candidates.
role="${1:?role required}"
image="${2:?image reference required}"
case "$role" in
  nova|prism-agent|buster-gateway)
    version="$(node -p 'require("./versions.json").openclaw.version')"
    docker run --rm --network none --user 0 --entrypoint bash \
      -v "$PWD/scripts/check-role-image.sh:/check-role-image.sh:ro" \
      "$image" /check-role-image.sh "$role" "$version"
    docker run --rm --network none --entrypoint bash \
      -v "$PWD/scripts/check-role-image.sh:/check-role-image.sh:ro" \
      "$image" /check-role-image.sh "$role" "$version" runtime
    ;;
  buster-runtime)
    # Exercise ownership handoff with exactly the restricted supervisor caps.
    docker run --rm --network none --cap-drop ALL \
      --cap-add CHOWN --cap-add SETUID --cap-add SETGID --cap-add SETPCAP \
      --entrypoint node \
      -v "$PWD/tests/verification/deployment/buster-cgroup-ownership.mjs:/cgroup-proof.mjs:ro" \
      "$image" /cgroup-proof.mjs
    # Nested rootless BuildKit runs only in a disposable CI proof container.
    sudo tee /etc/apparmor.d/kubeclaw-ci-build-proof >/dev/null <<'PROFILE'
abi <abi/4.0>,
include <tunables/global>
profile kubeclaw-ci-build-proof flags=(unconfined) {
  userns,
}
PROFILE
    sudo apparmor_parser -r /etc/apparmor.d/kubeclaw-ci-build-proof
    registry="$(node -p 'require("./versions.json").automation.testRegistry')"
    trap 'docker logs proof-registry; docker rm -f proof-registry' EXIT
    docker run -d --name proof-registry -p 127.0.0.1:5000:5000 "$registry"
    docker run --rm --privileged --security-opt apparmor=kubeclaw-ci-build-proof \
      --network host --entrypoint bash \
      -v "$PWD/tests/verification/deployment/check-buster-build.sh:/proof.sh:ro" \
      "$image" /proof.sh
    ;;
  prism-worker|prism-control|prism-studio)
    # Prove the shipped loader, schema and runtime Ajv dependency against the
    # same authored snapshot that Helm packages, without starting native work.
    docker run --rm --network none --entrypoint node \
      -e SWARM_CONFIG=/etc/kubeclaw/swarm/swarm.config.json \
      -v "$PWD/tests/fixtures/config/swarm-bundle.mjs:/app/prism/tests/fixtures/config/swarm-bundle.mjs:ro" \
      -v "$PWD/charts/kubeclaw/files/config:/etc/kubeclaw/swarm:ro" \
      -v "$PWD/tests/verification/deployment/prism-swarm-image.mjs:/swarm-proof.mjs:ro" \
      "$image" /swarm-proof.mjs "$role"
    if [[ "$role" == prism-studio ]]; then
      docker run --rm --network none --entrypoint node \
        -e SWARM_CONFIG=/etc/kubeclaw/swarm/swarm.config.json \
      -v "$PWD/tests/fixtures/config/swarm-bundle.mjs:/app/prism/tests/fixtures/config/swarm-bundle.mjs:ro" \
        -v "$PWD/charts/kubeclaw/files/config:/etc/kubeclaw/swarm:ro" \
        -v "$PWD/skills/prism/tests/studio-canonical-image.mts:/app/prism/skills/prism/tests/studio-canonical-image.mts:ro" \
        -v "$PWD/skills/prism/tests/fixtures/studio-service.mts:/app/prism/skills/prism/tests/fixtures/studio-service.mts:ro" \
        "$image" --test /app/prism/skills/prism/tests/studio-canonical-image.mts
    fi
    ;;
  namespace-controller|archviewer|prism-ingestion)
    # These Dockerfiles execute their acceptance gates during the build.
    docker image inspect "$image" >/dev/null
    ;;
  *) echo "Unknown runtime role: $role" >&2; exit 2 ;;
esac
