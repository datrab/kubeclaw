import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import test from 'node:test';
import { attestSourceSnapshot } from '@kubeclaw/pipeline-test-gate-contract';
import { createRemotePlanJob } from '@kubeclaw/nova-core';
import { plan } from '../../fixtures/test-gate/remote-plan.mts';
import { assertPreparedSourceShape, preparedPlanHeader, preparationDigest } from '../../../skills/buster/engine/test-gates/preparation-header.ts';
import { assertStagedInput } from '../../../skills/buster/engine/test-gates/preparation-input.ts';
import { assertPreparationCleanupEffects } from '../../../skills/buster/engine/test-gates/preparation-cleanup-binding.ts';

// Decoder-only fixture. These bytes are not claimed to be an extracted archive.
const archive = Buffer.from('source identity decoder fixture');
const archiveDigest = `sha256:${crypto.createHash('sha256').update(archive).digest('hex')}`;
const key = crypto.generateKeyPairSync('ed25519').privateKey.export({ type: 'pkcs8', format: 'pem' });
const snapshot = attestSourceSnapshot({ schemaVersion: 'source-snapshot.v1', sourceType: 'git-commit',
  pipelineStageId: 'stage:test', repositoryId: 'repository:test', revision: `git:${'a'.repeat(40)}`,
  tree: `git:${'b'.repeat(40)}`, archiveContentDigest: archiveDigest,
  archiveSizeBytes: archive.length, creatorAuthority: 'nova:test' }, key);
const job = preparedPlanHeader(createRemotePlanJob({ idempotencyKey: 'identity-test', pipelineStageId: 'stage:test',
  plan: plan('blocking', null), sourceSnapshot: snapshot, repositoryArchive: archive,
  grants: new Map([['test', []]]), maximumConcurrency: 1, submittedAt: '2026-09-21T00:00:00.000Z' }));
const digest = `sha256:${'f'.repeat(64)}`;
const source = { schemaVersion: 'buster-prepared-source.v1', admissionId: 'a'.repeat(32), preparationUid: 1003,
  jobId: job.jobId, requestDigest: job.requestDigest, headerDigest: preparationDigest(job),
  archiveDigest, archiveBytes: archive.length, attemptSpecDigest: digest };
const input = { schemaVersion: 'buster-staged-input.v1', admissionId: source.admissionId,
  preparationUid: 1003, jobId: job.jobId, requestDigest: job.requestDigest, headerDigest: preparationDigest(job),
  wireDigest: digest, wireBytes: 100, attemptSpecDigest: digest };
const effects = { schemaVersion: 'buster-preparation-cleanup-effects.v1', admissionId: source.admissionId,
  originalEnvelopeDigest: digest, gate: { preparationUid: 1003, device: 1, inode: 2, markerDigest: digest }, data: null };

for (const item of [
  { name: 'prepared source', value: source, validate: assertPreparedSourceShape,
    fields: ['admissionId', 'jobId', 'requestDigest', 'headerDigest', 'archiveDigest', 'attemptSpecDigest'] },
  { name: 'staged input', value: input, validate: (value: unknown) => assertStagedInput(value, job),
    fields: ['admissionId', 'wireDigest', 'attemptSpecDigest', 'headerDigest', 'requestDigest', 'jobId'] },
  { name: 'cleanup effects', value: effects, validate: assertPreparationCleanupEffects,
    fields: ['admissionId', 'originalEnvelopeDigest'] },
]) {
  test(`${item.name} accepts valid identity and rejects JSON scalar coercion`, () => {
    assert.doesNotThrow(() => item.validate(item.value));
    for (const field of item.fields) {
      const original = (item.value as Record<string, unknown>)[field];
      for (const malformed of [[original], null, true, 1, {}, []]) {
        assert.throws(() => item.validate({ ...item.value, [field]: malformed }), undefined, `${item.name}.${field}`);
      }
    }
  });
}

test('cleanup gate digest cannot be coerced from a JSON array', () => {
  assert.throws(() => assertPreparationCleanupEffects({ ...effects,
    gate: { ...effects.gate, markerDigest: [digest] } }), /CLEANUP_EFFECTS_INVALID/);
});
