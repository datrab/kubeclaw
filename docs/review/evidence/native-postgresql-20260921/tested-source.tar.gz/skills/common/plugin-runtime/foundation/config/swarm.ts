import fs from 'node:fs';
import Ajv2020 from 'ajv/dist/2020.js';

export interface PrismWorkerSettings {
  readonly maximumActiveRequests: number;
  readonly maximumProbeRequests: number;
  readonly maximumConnections: number;
  readonly maximumInputBytes: number;
  readonly requestTimeoutMs: number;
  readonly shutdownTimeoutMs: number;
}
export interface PrismResourcePolicy {
  readonly cpuTimeMs: number;
  readonly memoryBytes: number;
  readonly tasks: number;
}
export interface PrismNativeSettings {
  readonly resourcePolicy: PrismResourcePolicy;
  readonly maximumResultBytes: number;
  readonly dispatchTimeoutMs: number;
}
interface PrismSettings {
  readonly worker: PrismWorkerSettings;
  readonly native: PrismNativeSettings;
}
interface SwarmConfig {
  readonly operator: { readonly prism: PrismSettings };
}
interface Validator { (value: unknown): boolean; errors?: unknown[] | null }
const AjvConstructor = Ajv2020 as unknown as new (options: { allErrors: boolean; strict: boolean }) => { compile(schema: object): Validator };
const schema = JSON.parse(fs.readFileSync(new URL('./swarm.schema.json', import.meta.url), 'utf8')) as object;
const validate = new AjvConstructor({ allErrors: true, strict: true }).compile(schema);
const migratedEnvironmentKeys = [
  'PRISM_WORKER_MAXIMUM_ACTIVE_REQUESTS', 'PRISM_WORKER_MAXIMUM_PROBE_REQUESTS',
  'PRISM_WORKER_MAXIMUM_CONNECTIONS', 'PRISM_WORKER_REQUEST_BODY_TIMEOUT_MS',
  'PRISM_WORKER_SHUTDOWN_TIMEOUT_MS', 'PRISM_NATIVE_MAXIMUM_INPUT_BYTES',
  'PRISM_NATIVE_ASSIGNED_INPUT_BYTES', 'PRISM_NATIVE_MAXIMUM_RESULT_BYTES',
  'PRISM_NATIVE_DISPATCH_TIMEOUT_MS', 'PRISM_NATIVE_CPU_TIME_MS',
  'PRISM_NATIVE_MEMORY_BYTES', 'PRISM_NATIVE_TASKS',
] as const;

/** Load the single authored snapshot. No legacy environment override or default. */
export function loadPrismSettings(environment: NodeJS.ProcessEnv): PrismSettings {
  for (const key of migratedEnvironmentKeys) {
    if (environment[key] !== undefined) throw new Error(`SWARM_CONFIG_LEGACY_OVERRIDE:${key}:use operator.prism`);
  }
  const file = environment.SWARM_CONFIG ?? '/home/node/.openclaw/swarm.config.json';
  return prismSettingsFromConfig(JSON.parse(fs.readFileSync(file, 'utf8')));
}

/** Validate the authored document before selecting its operator-owned settings. */
function prismSettingsFromConfig(value: unknown): PrismSettings {
  if (!validate(value)) throw new Error(`SWARM_CONFIG_INVALID:${JSON.stringify(validate.errors ?? [])}`);
  const settings = (value as SwarmConfig).operator.prism.worker;
  if (settings.maximumActiveRequests + settings.maximumProbeRequests > settings.maximumConnections) {
    throw new Error('SWARM_CONFIG_WORKER_CONNECTION_BUDGET_INVALID');
  }
  return Object.freeze({ worker: Object.freeze({ ...settings }),
    native: Object.freeze({ ...(value as SwarmConfig).operator.prism.native,
      resourcePolicy: Object.freeze({ ...(value as SwarmConfig).operator.prism.native.resourcePolicy }) }) });
}

export function loadPrismWorkerSettings(environment: NodeJS.ProcessEnv): PrismWorkerSettings {
  return loadPrismSettings(environment).worker;
}

export function prismWorkerSettingsFromConfig(value: unknown): PrismWorkerSettings {
  return prismSettingsFromConfig(value).worker;
}
