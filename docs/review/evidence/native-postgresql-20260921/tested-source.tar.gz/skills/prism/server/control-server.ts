import { productAuthorityHandler } from './product-decisions.ts';
import { assembleBaselineArchive, BASELINE_V2 } from '@kubeclaw/prism-contracts-v1/baseline-archive';
import { handleAgentJobs } from './agent-job-routes.ts';
import { agentJob } from '../control/agent-jobs.ts';
import { agentReceipt, startAgentRevision, admitDesignAgent } from '../control/agent-admission.ts';
import { startDesignRound, assertArchitectureTransition, approvedRoundBaseline } from "../control/design-generations.ts";
import { type loadControlServerConfig, loadControlCompositionConfig } from "./control-config.ts";
import { authorizePipelinePreferenceSubject } from "../control/pipeline-preference-subject.ts";
import { preferenceEvents, setPersonalPreferences, requirePreferenceGeneration } from "../control/preference-snapshot.ts";
import { decideDirection, directionIdempotencyKey } from "../control/direction-decisions.ts";
import { recordPreference } from "../control/preferences.ts";
import {
  createServer,
  type IncomingMessage,
  type ServerResponse,
} from "node:http";
import {
  createHash,
  createHmac,
  randomBytes,
  randomUUID,
  timingSafeEqual,
} from "node:crypto";
import {
  validatePrism,
  type PrismDocument,
} from "@kubeclaw/prism-contracts-v1";
import {
  ContentAddressedArtifactStore,
  RevisionRepository,
  inTransaction,
  type Database,
} from "../storage/index.ts";
import {
  exchangeTailscaleIdentity,
  verifySession,
} from "../control/session.ts";
import { handleInternalArtifact } from "./internal-artifacts.ts";
import { runNativePrismOperation } from '../control/native-operation.ts';
import { ingest, search, type CorpusInput } from "../corpus/index.ts";
import { evaluate } from "../evaluation/index.ts";
import {
  projectPreferences,
  type PreferenceEvent,
} from "../preferences/index.ts";
import { assertMaterialDirectionDiversity } from "../directions/index.ts";
import { authorizeProxiedSpiffePeer } from "@kubeclaw/worker-core";

async function body(
  request: IncomingMessage,
  maxBytes = 2_000_000,
): Promise<unknown> {
  if (
    !(request.headers["content-type"] ?? "")
      .toString()
      .toLowerCase()
      .startsWith("application/json")
  )
    throw new Error("application/json is required");
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const chunk of request) {
    size += chunk.length;
    if (size > maxBytes) throw new Error("request too large");
    chunks.push(chunk);
  }
  return chunks.length
    ? JSON.parse(Buffer.concat(chunks).toString("utf8"))
    : {};
}
function json(response: ServerResponse, status: number, value: unknown): void {
  response.writeHead(status, {
    "content-type": "application/json",
    "cache-control": "no-store",
  });
  response.end(JSON.stringify(value));
}
function cookies(request: IncomingMessage): Record<string, string> {
  return Object.fromEntries(
    (request.headers.cookie ?? "")
      .split(";")
      .filter(Boolean)
      .map(
        (item) =>
          item.trim().split("=").map(decodeURIComponent) as [string, string],
      ),
  );
}
const sha256 = (value: string | Uint8Array) =>
  `sha256:${createHash("sha256").update(value).digest("hex")}`;
const userKey = (identity: string) =>
  `user-${createHash("sha256").update(identity).digest("hex").slice(0, 24)}`;


class ControlService {
  private readonly config: ReturnType<typeof loadControlServerConfig>;
  private readonly repository: RevisionRepository;
  private readonly artifacts: ContentAddressedArtifactStore;
  private readonly pool: Database;

  constructor(pool: Database, config: ReturnType<typeof loadControlServerConfig>) {
    this.config = config;
    this.pool = pool;
    this.repository = new RevisionRepository(pool);
    this.artifacts = new ContentAddressedArtifactStore(this.config.artifactRoot);
  }

private authenticated(request: IncomingMessage): {
  user: string;
  roles: string[];
  csrf: string;
} {
  const {sessionSecret} = this.config;
  const values = cookies(request);
  const session = verifySession(values.prism_session ?? "", sessionSecret);
  const csrf = values.prism_csrf ?? "";
  if (
    !["GET", "HEAD"].includes(request.method ?? "") &&
    (!csrf || request.headers["x-prism-csrf"] !== csrf)
  )
    throw new Error("invalid CSRF token");
  return { user: session.user, roles: session.roles, csrf };
}

private runWorker(
  operation: "generate" | "render" | "evaluate" | "ingest" | "publish",
  input: Record<string, unknown>,
  idempotencyKey: string,
): Promise<Record<string, unknown>> {
  return runNativePrismOperation(this.pool, this.artifacts, this.config, operation, input, idempotencyKey);
}

  async handle(request: IncomingMessage, response: ServerResponse) {
    const {pool, repository, artifacts} = this;
    const controlConfig = this.config;
    const {sessionSecret, ingressSecret, spiffeEnabled, dispatchSecret, workerSecret,
      trustedNovaSpiffeId, trustedTestRunnerSpiffeId, trustedWorkerSpiffeId,
      trustedControlSpiffeId, trustedPrismAgentSpiffeId, ingestionSecret,
      ingestionUrl, controlInternalUrl, studioPublicUrl} = this.config;

  try {
    const url = new URL(request.url ?? "/", "http://prism-control");
    if (url.pathname === "/health")
      return json(response, 200, { status: "ok" });
    if (url.pathname === "/ready") {
      await pool.query("SELECT 1");
      return json(response, 200, { status: "ready" });
    }
    if (await handleInternalArtifact(request, response, url, {
      artifacts, spiffeEnabled, workerSecret, trustedWorkerSpiffeId, trustedControlSpiffeId, trustedPrismAgentSpiffeId,
    })) return;
    if (url.pathname === "/v1/session" && request.method === "POST") {
      const headers = Object.fromEntries(
        Object.entries(request.headers).map(([key, value]) => [
          key,
          Array.isArray(value) ? value[0] : value,
        ]),
      );
      const token = exchangeTailscaleIdentity(
        headers,
        ingressSecret,
        sessionSecret,
      );
      const csrf = randomBytes(24).toString("base64url");
      response.setHeader("set-cookie", [
        `prism_session=${encodeURIComponent(token)}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=900`,
        `prism_csrf=${encodeURIComponent(csrf)}; Secure; SameSite=Strict; Path=/; Max-Age=900`,
      ]);
      return json(response, 201, {
        csrf,
        userId: userKey(verifySession(token, sessionSecret).user),
      });
    }
    if (url.pathname === "/v1/dispatch" && request.method === "POST") {
      if(spiffeEnabled){
        try{authorizeProxiedSpiffePeer(request.headers,request.socket.remoteAddress,new Set([trustedNovaSpiffeId, trustedPrismAgentSpiffeId, trustedTestRunnerSpiffeId].filter(Boolean)));}
        catch{throw new Error("invalid dispatch identity");}
      }
      if (
        !(request.headers["content-type"] ?? "")
          .toString()
          .toLowerCase()
          .startsWith("application/json")
      )
        throw new Error("application/json is required");
      const chunks: Buffer[] = [];
      let size = 0;
      for await (const chunk of request) {
        size += chunk.length;
        if (size > 2_000_000) throw new Error("request too large");
        chunks.push(chunk);
      }
      const raw = Buffer.concat(chunks);
      const key = String(request.headers["idempotency-key"] ?? "");
      if(!key)throw new Error("invalid dispatch idempotency key");
      if(!spiffeEnabled){
        const supplied = String(request.headers["x-kubeclaw-signature"] ?? "").replace(/^v1=/, "");
        const expected = createHmac("sha256", dispatchSecret).update(`${key}.${raw.toString("utf8")}`).digest();
        const actual = Buffer.from(supplied, "hex");
        if(actual.length !== expected.length || !timingSafeEqual(actual, expected))throw new Error("invalid dispatch signature");
      }
      const payload = JSON.parse(raw.toString("utf8")) as {
        preferenceSubjectId?: string;
        request?: { projectId?: string; approvalId?: string; schema?: string; architecture?: {artifactId?:string;contentDigest?:string}; architectureContent?: unknown };
      };
      const preferenceSubjectId = authorizePipelinePreferenceSubject(payload.preferenceSubjectId, controlConfig.pipelinePreferenceSubject);
      const designRequest = validatePrism<{
        schema: "prism.design-request.v1";
        projectId: string;
        architecture: { artifactId: string; contentDigest: string; revision: number };
        architectureContent: Record<string, unknown>;
        approvalId?: string;
      }>("designRequest", payload.request);
      const projectKey = designRequest.projectId;
      const project = await pool.query<{ id: string }>(
        "INSERT INTO prism.project(id,external_id,name) VALUES($1,$2,$3) ON CONFLICT(external_id) DO UPDATE SET updated_at=now() RETURNING id",
        [randomUUID(), projectKey, projectKey],
      );
      await inTransaction(pool, async requestClient => {
        await requestClient.query("SELECT id FROM prism.project WHERE id=$1 FOR UPDATE",[project.rows[0]!.id]);
        const active=await requestClient.query<{architecture_digest:string;architecture_revision:number|string;request:Record<string,unknown>}>("SELECT architecture_digest,architecture_revision,request FROM prism.design_request WHERE project_id=$1 AND status='active' ORDER BY architecture_revision DESC LIMIT 1",[project.rows[0]!.id]);
        if(active.rows[0])assertArchitectureTransition(active.rows[0],designRequest);
        await requestClient.query("UPDATE prism.design_request SET status='superseded' WHERE project_id=$1 AND architecture_revision<$2 AND status='active'",[project.rows[0]!.id,designRequest.architecture.revision]);
        await requestClient.query("INSERT INTO prism.design_request(id,project_id,architecture_artifact_id,architecture_digest,architecture_revision,request,status) VALUES($1,$2,$3,$4,$5,$6::jsonb,'active') ON CONFLICT(project_id,architecture_revision) DO UPDATE SET architecture_artifact_id=excluded.architecture_artifact_id,architecture_digest=excluded.architecture_digest,request=excluded.request,status='active'",[randomUUID(),project.rows[0]!.id,designRequest.architecture.artifactId,designRequest.architecture.contentDigest,designRequest.architecture.revision,JSON.stringify(designRequest)]);
      });
      if (!designRequest.approvalId){
        const preferences=await startDesignRound(pool,{projectId:projectKey,subjectId:preferenceSubjectId,startKey:`dispatch:${key}`,architectureDigest:designRequest.architecture.contentDigest,architectureRevision:designRequest.architecture.revision});
        const agent=await admitDesignAgent(pool,`${trustedControlSpiffeId}/prism/main/v2`,projectKey,preferences);
        return json(response,202,{result:{status:'waiting',projectId:project.rows[0]!.id},preferences,agent});
      }
      const baseline = await approvedRoundBaseline(pool,project.rows[0]!.id,designRequest.approvalId);
      if (!baseline.rows[0])
        throw new Error("approved Prism baseline not found");
      return json(response, 200, {
        result: {
          bundleDigest: baseline.rows[0].bundle_digest,
          artifactId: baseline.rows[0].bundle_artifact_id,
          archiveBase64: Buffer.from(await artifacts.get(baseline.rows[0].bundle_artifact_id)).toString("base64"),
        },
      });
    }
    if(await handleAgentJobs(request,response,url,{db:pool,spiffeEnabled,trustedAgentId:trustedPrismAgentSpiffeId,readBody:body}))return;
    if (url.pathname === "/v1/agent/design-sets" && request.method === "POST") {
      if (!spiffeEnabled) throw new Error("Prism agent tools require SPIFFE worker trust");
      authorizeProxiedSpiffePeer(request.headers,request.socket.remoteAddress,new Set([trustedPrismAgentSpiffeId]));
      const input = (await body(request)) as {
        projectId?: string;
        generationId?: string;
        jobId:string; fence:string;
        designs?: Array<{key?:string;title?:string;summary?:string;document?:PrismDocument;evidence?:Record<string,unknown>}>;
      };
      if (!input.projectId || input.designs?.length !== 3) throw new Error("exactly three Prism designs are required");
      if (new Set(input.designs.map((item)=>item.key)).size !== 3) throw new Error("Prism direction keys must be unique");
      const generation = await requirePreferenceGeneration(pool,input.generationId,input.projectId,{operation:"design-set"});
      const documents=input.designs.map((item)=>validatePrism<PrismDocument>("designDocument",item.document));
      assertMaterialDirectionDiversity(documents);
      const designs = input.designs.map((item, index) => {
        if (!item.key || !item.title || !item.summary) throw new Error("each Prism design requires key, title, and summary");
        return { key: item.key, title: item.title, summary: item.summary, document: documents[index]!, evidence: {...item.evidence, ...generation} };
      });
      const result = await repository.createDirectionSet(input.projectId, input.generationId!, designs,{jobId:input.jobId,fence:input.fence,payload:input});
      return json(response, result.status === 'created' ? 201 : 200, { ...result,
        studioUrl: `${studioPublicUrl}?project=${result.projectId}&document=${result.documentId}` });
    }
    if (url.pathname === "/v1/agent/revisions" && request.method === "POST") {
      if (!spiffeEnabled) throw new Error("Prism agent tools require SPIFFE worker trust");
      authorizeProxiedSpiffePeer(request.headers,request.socket.remoteAddress,new Set([trustedPrismAgentSpiffeId]));
      const input=(await body(request)) as {jobId:string;fence:string;generationId?:string;projectId?:string;documentId?:string;expectedRevision?:number;instruction?:string;document?:PrismDocument};
      if(!input.projectId||!input.documentId||!input.instruction||!Number.isSafeInteger(input.expectedRevision))throw new Error("complete Prism revision input is required");
      const owner=await pool.query<{external_id:string}>("SELECT p.external_id FROM prism.design_document d JOIN prism.project p ON p.id=d.project_id WHERE d.id=$1",[input.documentId]);
      if(owner.rows[0]?.external_id!==input.projectId)throw new Error("document does not belong to the Prism project");
      const generation = await requirePreferenceGeneration(pool,input.generationId,input.projectId,{operation:"revise",documentId:input.documentId,expectedRevision:input.expectedRevision});
      const current=await repository.revision(input.documentId,input.expectedRevision!);
      const document=validatePrism<PrismDocument>("designDocument",input.document);
      if(document.meta.revision!==input.expectedRevision!+1)throw new Error("Prism agent must increment the document revision exactly once");
      const updated=await repository.replace(input.documentId,current.id,document,{type:"agent.revision",instruction:input.instruction,...generation},"agent:prism",{jobId:input.jobId,fence:input.fence,payload:input});
      return json(response,200,{status:"updated",document:updated});
    }
    const actor = this.authenticated(request);
    const agentStatus=/^\/v1\/agent-jobs\/([0-9a-f-]+)$/.exec(url.pathname);
    if(agentStatus && request.method==='GET')return json(response,200,agentReceipt(await agentJob(pool,agentStatus[1]!)));
    if (url.pathname === "/v1/projects" && request.method === "GET") {
      const result=await pool.query<{id:string;external_id:string;name:string;document_id:string|null;direction_count:number}>("SELECT p.id,p.external_id,p.name,(SELECT d.source_document_id FROM prism.direction d JOIN prism.design_document doc ON doc.id=d.source_document_id JOIN prism.design_request r ON r.id=doc.design_request_id AND r.status='active' AND doc.design_round_id IS NOT DISTINCT FROM r.current_round_id WHERE d.project_id=p.id ORDER BY d.created_at,d.id LIMIT 1) AS document_id,(SELECT count(*)::int FROM prism.direction d JOIN prism.design_document doc ON doc.id=d.source_document_id JOIN prism.design_request r ON r.id=doc.design_request_id AND r.status='active' AND doc.design_round_id IS NOT DISTINCT FROM r.current_round_id WHERE d.project_id=p.id) AS direction_count FROM prism.project p ORDER BY p.updated_at DESC,p.id");
      return json(response,200,{items:result.rows});
    }
    const projectBrief=/^\/v1\/projects\/([0-9a-f-]+)\/brief$/.exec(url.pathname);
    if(projectBrief&&request.method==="GET"){
      const result=await pool.query("SELECT architecture_artifact_id,architecture_digest,request,created_at FROM prism.design_request WHERE project_id=$1 AND status='active' ORDER BY created_at DESC LIMIT 1",[projectBrief[1]]);
      if(!result.rows[0])throw new Error("active Prism design request not found");
      return json(response,200,result.rows[0]);
    }
    if (url.pathname === "/v1/projects" && request.method === "POST") {
      const input = (await body(request)) as {
        externalId?: string;
        name?: string;
      };
      if (!input.externalId || !input.name)
        throw new Error("externalId and name are required");
      const architectureContent = {
        schema: "prism.standalone-brief.v1",
        projectId: input.externalId,
        title: input.name,
        source: "standalone-studio",
      };
      const bytes = Buffer.from(JSON.stringify(architectureContent));
      const architecture = await artifacts.put(bytes);
      const designRequest = {
        schema: "prism.design-request.v1",
        projectId: input.externalId,
        architecture: {
          artifactId: architecture.artifactId,
          contentDigest: architecture.digest,
          revision: 1,
        },
        architectureContent,
      };
      const projectId = await inTransaction(pool, async client => {
        const project=await client.query<{id:string}>("INSERT INTO prism.project(id,external_id,name) VALUES($1,$2,$3) RETURNING id",[randomUUID(),input.externalId,input.name]);
        const projectId=project.rows[0]!.id;
        await client.query("INSERT INTO prism.design_request(id,project_id,architecture_artifact_id,architecture_digest,architecture_revision,request,status) VALUES($1,$2,$3,$4,1,$5::jsonb,'active')",[randomUUID(),projectId,architecture.artifactId,architecture.digest,JSON.stringify(designRequest)]);
        return projectId;
      });
      return json(response, 201, { id: projectId });
    }
    if (url.pathname === "/v1/documents" && request.method === "POST") {
      const input = (await body(request)) as {
        projectId?: string;
        key?: string;
        document?: PrismDocument;
      };
      validatePrism<PrismDocument>("designDocument", input.document);
      if (!input.projectId || !input.key)
        throw new Error("projectId and key are required");
      const activeRequest=await pool.query<{id:string}>("SELECT id FROM prism.design_request WHERE project_id=$1 AND status='active' ORDER BY created_at DESC LIMIT 1",[input.projectId]);
      if(!activeRequest.rows[0])throw new Error("active Prism design request is required before document creation");
      return json(response, 201, {
        id: await repository.createDocument(
          input.projectId,
          input.key,
          input.document!,
          actor.user,
          activeRequest.rows[0].id,
        ),
      });
    }
    const directions = /^\/v1\/projects\/([0-9a-f-]+)\/directions$/.exec(
      url.pathname,
    );
    if (directions && request.method === "GET") {
      const activeJob=await pool.query<{id:string}>("SELECT j.id FROM prism.agent_job j JOIN prism.design_request r ON r.current_round_id=j.id WHERE r.project_id=$1 AND r.status='active'",[directions[1]]);
      if(activeJob.rows[0])agentReceipt(await agentJob(pool,activeJob.rows[0].id));
      const result = await pool.query(
        "SELECT d.id,doc.design_round_id AS generation_id,d.source_document_id,d.direction_key,d.title,d.summary,d.proposal,d.state,d.content_digest,d.evidence FROM prism.direction d JOIN prism.design_document doc ON doc.id=d.source_document_id JOIN prism.design_request r ON r.id=doc.design_request_id AND r.status='active' AND doc.design_round_id IS NOT DISTINCT FROM r.current_round_id WHERE d.project_id=$1 ORDER BY d.created_at,d.id",
        [directions[1]],
      );
      return json(response, 200, { items: result.rows });
    }
    if (directions && request.method === "POST") {
      const input = (await body(request)) as { documentId?: string; expectedRevision?: number; parentRoundId?: string; idempotencyKey?: string };
      if (!input.documentId || !Number.isSafeInteger(input.expectedRevision) || !input.idempotencyKey) throw new Error("documentId, expectedRevision and idempotencyKey are required");
      const project=await pool.query<{external_id:string}>("SELECT external_id FROM prism.project WHERE id=$1",[directions[1]]);
      const requestResult=await pool.query<{request:Record<string,unknown>;architecture_digest:string;architecture_revision:number}>("SELECT request,architecture_digest,architecture_revision FROM prism.design_request WHERE project_id=$1 AND status='active' ORDER BY created_at DESC LIMIT 1",[directions[1]]);
      if(!project.rows[0]||!requestResult.rows[0])throw new Error("active Prism project not found");
      const preferences=await startDesignRound(pool,{projectId:project.rows[0].external_id,subjectId:userKey(actor.user),startKey:`studio:${userKey(actor.user)}:${input.idempotencyKey}`,architectureDigest:requestResult.rows[0].architecture_digest,architectureRevision:Number(requestResult.rows[0].architecture_revision),parentRoundId:input.parentRoundId,documentId:input.documentId,expectedRevision:input.expectedRevision});
      return json(response,202,await admitDesignAgent(pool,`${trustedControlSpiffeId}/prism/main/v2`,project.rows[0].external_id,preferences));
    }
    const directionFeedback = /^\/v1\/directions\/([0-9a-f-]+)\/feedback$/.exec(
      url.pathname,
    );
    if (directionFeedback && request.method === "POST") {
      const input = (await body(request)) as {
        action?: "rejected" | "liked" | "disliked" | "preserved";
        trait?: string;
      };
      if (!input.action || !["rejected", "liked", "disliked", "preserved"].includes(input.action))
        throw new Error("supported direction feedback action is required");
      const result = await decideDirection(pool, userKey(actor.user), directionFeedback[1]!, directionIdempotencyKey(request.headers["idempotency-key"]), {action: input.action, ...(input.trait === undefined ? {} : {trait: input.trait})});
      return json(response, 201, result);
    }
    const selectDirection = /^\/v1\/directions\/([0-9a-f-]+)\/select$/.exec(
      url.pathname,
    );
    if (selectDirection && request.method === "POST") {
      const input = (await body(request)) as { documentId?: string };
      if (!input.documentId) throw new Error("documentId is required");
      const result = await decideDirection(pool, userKey(actor.user), selectDirection[1]!, directionIdempotencyKey(request.headers["idempotency-key"]), {action: "selected", documentId: input.documentId});
      return json(response, 200, result);
    }
    const current = /^\/v1\/documents\/([0-9a-f-]+)$/.exec(url.pathname);
    if (current && request.method === "GET")
      return json(response, 200, await repository.current(current[1]!));
    const revisions = /^\/v1\/documents\/([0-9a-f-]+)\/revisions$/.exec(
      url.pathname,
    );
    if (revisions && request.method === "GET")
      return json(response, 200, {
        items: await repository.history(revisions[1]!),
      });
    const restore =
      /^\/v1\/documents\/([0-9a-f-]+)\/revisions\/([0-9a-f-]+)\/restore$/.exec(
        url.pathname,
      );
    if (restore && request.method === "POST")
      return json(
        response,
        200,
        await repository.restore(restore[1]!, restore[2]!, actor.user),
      );
    const operations = /^\/v1\/documents\/([0-9a-f-]+)\/operations$/.exec(
      url.pathname,
    );
    if (operations && request.method === "POST")
      return json(
        response,
        200,
        await repository.apply(
          operations[1]!,
          (await body(request)) as never,
          actor.user,
        ),
      );
    const execute = /^\/v1\/documents\/([0-9a-f-]+)\/engine$/.exec(
      url.pathname,
    );
    if (execute && request.method === "POST") {
      const input = (await body(request)) as {
        operation?: string;
        input?: Record<string, unknown>;
        idempotencyKey?: string;
        baseRevision?: number;
      };
      const idempotencyKey =
        input.idempotencyKey ?? randomBytes(16).toString("hex");
      if (
        !["generate", "render", "evaluate", "publish"].includes(
          input.operation ?? "",
        )
      )
        throw new Error("unsupported Prism engine operation");
      if (
        !Number.isSafeInteger(input.baseRevision) ||
        Number(input.baseRevision) < 1
      )
        throw new Error("baseRevision is required");
      const requestDocument = await repository.revision(
        execute[1]!,
        Number(input.baseRevision),
      );
      const operation = input.operation as
        "generate" | "render" | "evaluate" | "publish";
      if(operation === "generate"){
        const owner=await pool.query<{external_id:string}>("SELECT p.external_id FROM prism.design_document d JOIN prism.project p ON p.id=d.project_id WHERE d.id=$1",[execute[1]]);
        if(!owner.rows[0])throw new Error("Prism project not found");
        const instruction=String(input.input?.instruction??"").trim();
        if(!instruction)throw new Error("Prism revision instruction is required");
        if(!input.idempotencyKey)throw new Error('agent revision idempotency key is required');
        const job=await startAgentRevision(pool,`${trustedControlSpiffeId}/prism/main/v2`,userKey(actor.user),input.idempotencyKey,{projectId:owner.rows[0].external_id,documentId:execute[1]!,expectedRevision:Number(input.baseRevision),instruction,document:requestDocument.document});
        return json(response,202,agentReceipt(job));
      }
      const defaults =
        operation === "render"
          ? { view: "home", state: "default", viewport: "wide" }
          : {};
      const engineInput: Record<string, unknown> = {
        ...defaults,
        ...input.input,
        document: requestDocument.document,
      };
      if (operation === "render") {
        const assetSources: Record<string, string> = {};
        let totalBytes = 0;
        for (const [assetId, rawAsset] of Object.entries(
          requestDocument.document.assets,
        )) {
          const asset = rawAsset as { artifact?: string; mediaType?: string };
          if (!asset.artifact || !asset.mediaType)
            throw new Error(`asset metadata is incomplete for ${assetId}`);
          const bytes = await artifacts.get(asset.artifact);
          totalBytes += bytes.byteLength;
          if (totalBytes > 6_000_000)
            throw new Error("render assets exceed the 6 MB baseline limit");
          assetSources[assetId] =
            `data:${asset.mediaType};base64,${Buffer.from(bytes).toString("base64")}`;
        }
        engineInput.assetSources = assetSources;
      }
      const values = await this.runWorker(operation, engineInput, idempotencyKey);
      const generated = values.document;
      if (input.operation === "generate" && generated) {
        validatePrism<PrismDocument>("designDocument", generated);
        const currentDocument = await repository.current(execute[1]!);
        if (currentDocument.document.meta.revision === input.baseRevision) {
          try {
            await repository.replace(
              execute[1]!,
              currentDocument.id,
              generated as PrismDocument,
              { type: "engine.generate", idempotencyKey },
              actor.user,
            );
          } catch (error) {
            if (
              !(await repository.includesOperation(execute[1]!, idempotencyKey))
            )
              throw error;
          }
        } else if (currentDocument.document.meta.revision < input.baseRevision!)
          throw new Error("design revision moved backwards");
        else if (
          !(await repository.includesOperation(execute[1]!, idempotencyKey))
        )
          throw new Error(
            "revision conflict: generated proposal is based on a stale design",
          );
      }
      return json(response, 200, {
        state: "completed",
        specialistResult: { values },
      });
    }
    if (url.pathname === "/v1/approvals" && request.method === "POST") {
      const input = (await body(request)) as {
        projectId?: string;
        documentId?: string;
        designDigest?: string;
        acceptedWarningIds?: string[];
      };
      if (!input.projectId || !input.documentId || !input.designDigest)
        throw new Error("projectId, documentId, and designDigest are required");
      const documentOwner = await pool.query<{ project_id: string }>(
        "SELECT project_id FROM prism.design_document WHERE id=$1",
        [input.documentId],
      );
      if (
        !documentOwner.rows[0] ||
        documentOwner.rows[0].project_id !== input.projectId
      )
        throw new Error("document does not belong to the approval project");
      const currentDocument = await repository.current(input.documentId);
      const id = `approval-${randomBytes(16).toString("hex")}`;
      const quality = evaluate(currentDocument.document);
      if (quality.status === "blocked")
        throw new Error("design quality gate blocked approval");
      const requiredWarnings = quality.findings
        .filter((finding) => finding.level === "review")
        .map((finding) => finding.id)
        .sort();
      const accepted = [...(input.acceptedWarningIds ?? [])].sort();
      if (JSON.stringify(requiredWarnings) !== JSON.stringify(accepted))
        throw new Error("all design warnings must be accepted explicitly");
      const activeRequest=await pool.query<{architecture_digest:string}>("SELECT r.architecture_digest FROM prism.design_request r JOIN prism.design_document d ON d.design_request_id=r.id WHERE r.project_id=$1 AND r.status='active' AND d.design_round_id IS NOT DISTINCT FROM r.current_round_id AND d.id=$2 ORDER BY r.created_at DESC LIMIT 1",[input.projectId,input.documentId]);
      if(!activeRequest.rows[0])throw new Error("active Prism design request is required for approval");
      await pool.query(
        "INSERT INTO prism.approval(id,project_id,design_revision_id,design_digest,approved_by,accepted_warning_ids,architecture_digest) VALUES($1,$2,$3,$4,$5,$6::jsonb,$7)",
        [
          id,
          input.projectId,
          currentDocument.id,
          input.designDigest,
          actor.user,
          JSON.stringify(accepted),
          activeRequest.rows[0].architecture_digest,
        ],
      );
      return json(response, 201, { id, acceptedWarningIds: accepted });
    }
    if (url.pathname === "/v1/baselines" && request.method === "POST") {
      const input = (await body(request)) as {
        projectId?: string;
        documentId?: string;
        approvalId?: string;
      };
      if (!input.projectId || !input.documentId || !input.approvalId)
        throw new Error("projectId, documentId, and approvalId are required");
      const published = await pool.query<{
        bundle_digest: string;
        bundle_artifact_id: string;
      }>(
        "SELECT b.bundle_digest,b.bundle_artifact_id FROM prism.baseline b JOIN prism.design_revision r ON r.id=b.design_revision_id WHERE b.approval_id=$1 AND b.project_id=$2 AND r.document_id=$3",
        [input.approvalId, input.projectId, input.documentId],
      );
      if (published.rows[0])
        return json(response, 200, {
          bundleDigest: published.rows[0].bundle_digest,
          artifactId: published.rows[0].bundle_artifact_id,
          reused: true,
        });
      const documentOwner = await pool.query<{ project_id: string }>(
        "SELECT project_id FROM prism.design_document WHERE id=$1",
        [input.documentId],
      );
      if (
        !documentOwner.rows[0] ||
        documentOwner.rows[0].project_id !== input.projectId
      )
        throw new Error("document does not belong to the baseline project");
      const currentDocument = await repository.current(input.documentId);
      const approval = await pool.query<{
        design_digest: string;
        approved_at: string;
        accepted_warning_ids: string[];
      }>(
        "SELECT a.design_digest,a.approved_at::text,a.accepted_warning_ids FROM prism.approval a JOIN prism.design_revision rev ON rev.id=a.design_revision_id JOIN prism.design_document d ON d.id=rev.document_id JOIN prism.design_request req ON req.id=d.design_request_id AND req.status='active' AND d.design_round_id IS NOT DISTINCT FROM req.current_round_id WHERE a.id=$1 AND a.project_id=$2 AND a.design_revision_id=$3 AND a.architecture_digest=req.architecture_digest",
        [input.approvalId, input.projectId, currentDocument.id],
      );
      if (!approval.rows[0])
        throw new Error("approval does not match the current design revision");
      const content = Buffer.from(JSON.stringify(currentDocument.document));
      const designDigest = `sha256:${createHash("sha256").update(content).digest("hex")}`;
      if (designDigest !== approval.rows[0].design_digest)
        throw new Error("stale approval digest");
      const quality = evaluate(currentDocument.document);
      if (quality.status === "blocked")
        throw new Error("design quality gate blocked publication");
      const warningIds = quality.findings
        .filter((finding) => finding.level === "review")
        .map((finding) => finding.id)
        .sort();
      if (
        JSON.stringify(warningIds) !==
        JSON.stringify(
          [...(approval.rows[0].accepted_warning_ids ?? [])].sort(),
        )
      )
        throw new Error("design warnings changed after approval");
      const requestRow=await pool.query<{request:Record<string,unknown>}>("SELECT request FROM prism.design_request WHERE project_id=$1 AND status='active' ORDER BY created_at DESC LIMIT 1",[input.projectId]);
      const approvedRequest=requestRow.rows[0]?.request??{};
      const selectedDirection=await pool.query<{title:string;summary:string;evidence:Record<string,unknown>}>("SELECT dir.title,dir.summary,dir.evidence FROM prism.direction dir JOIN prism.design_document d ON d.id=dir.source_document_id JOIN prism.design_request req ON req.id=d.design_request_id AND req.status='active' AND d.design_round_id IS NOT DISTINCT FROM req.current_round_id WHERE dir.project_id=$1 AND dir.source_document_id=$2 AND dir.state='selected' ORDER BY dir.created_at DESC LIMIT 1",[input.projectId,input.documentId]);
      if(!selectedDirection.rows[0])throw new Error("an active design direction must be selected before publication");
      const specification = `# Design specification\n\n## Experience goal\n${currentDocument.document.meta.title}\n\n## Approved architecture and users\n${JSON.stringify(approvedRequest.architectureContent??approvedRequest,null,2)}\n\n## Approved direction\n${selectedDirection.rows[0]?.title??"Approved Design Document direction"}: ${selectedDirection.rows[0]?.summary??""}\n\n## Reference evidence and trade-offs\n${JSON.stringify(selectedDirection.rows[0]?.evidence??{},null,2)}\n\n## Screen, state, and flow inventory\n${Object.entries(currentDocument.document.views).map(([id,view])=>`${id}: ${Object.keys(view.states).join(", ")}`).join("\n")}\n${Object.entries(currentDocument.document.flows).map(([id,flow])=>`${id}: ${(flow as {goal?:string}).goal??"user journey"}`).join("\n")}\n\n## Responsive behavior\nCompact, regular, and wide behavior is defined for every view.\n\n## Accessibility requirements\nUse semantic controls, visible keyboard focus, sufficient contrast, reduced motion, accessible names, and complete keyboard operation.\n\n## Content guidance\nUse clear task language from the approved architecture. Do not invent production facts.\n\n## Important design rules\n${(currentDocument.document.theme.rules as Array<{ instruction?: string }>).map((rule) => `- ${rule.instruction ?? ""}`).join("\n")}\n\n## Implementation notes\nPreserve Prism IDs and implement every required state and flow.\n\n## Known limits\nAll prototype data is synthetic. Production behavior remains owned by the implementation pipeline.\n`;
      const criteria = {
        schema: "prism.acceptance-criteria.v1",
        criteria: [...Object.entries(currentDocument.document.views).flatMap(
          ([view, value]) =>
            Object.keys(value.states).map((state) => ({
              id: `${view.slice(0, 55)}-${state.slice(0, 15)}-visible`,
              category: "visual",
              requirement: `The ${value.title} ${state} state is visible, usable, and keyboard accessible.`,
              targets: [{ view, state }],
              priority: "required",
              verification: ["visual", "automated"],
            })),
        ),...Object.entries(currentDocument.document.flows).map(([flow,value])=>({id:`flow-${flow}`.slice(0,80),category:"flow",requirement:`The ${String((value as {title?:string}).title??flow)} journey reaches its declared success state and supports each declared recovery path.`,targets:[{flow}],priority:"required",verification:["automated","manual"]}))],
      };
      validatePrism("acceptanceCriteria",criteria);
      const previewEntries: Array<Record<string, unknown>> = [];
      const binaryFiles: Record<string, string> = {};
      const manifestAssets: Record<
        string,
        { path: string; mediaType: string; digest: string }
      > = {};
      const renderAssetSources: Record<string, string> = {};
      let renderAssetBytes = 0;
      const textFiles: Record<string, string> = {
        "design-document.json": JSON.stringify(currentDocument.document),
        "design-specification.md": specification,
        "acceptance-criteria.json": JSON.stringify(criteria),
        "quality-report.json": JSON.stringify({
          ...quality,
          acceptedWarningIds: warningIds,
        }),
      };
      for (const [assetId, rawAsset] of Object.entries(
        currentDocument.document.assets,
      )) {
        const asset = rawAsset as { artifact?: string; mediaType?: string };
        if (!asset.artifact || !asset.mediaType)
          throw new Error(`asset metadata is incomplete for ${assetId}`);
        const bytes = await artifacts.get(asset.artifact);
        renderAssetBytes += bytes.byteLength;
        if (renderAssetBytes > 6_000_000)
          throw new Error("render assets exceed the 6 MB baseline limit");
        const extension =
          asset.mediaType === "image/png"
            ? "png"
            : asset.mediaType === "image/webp"
              ? "webp"
              : asset.mediaType === "image/svg+xml"
                ? "svg"
                : asset.mediaType === "font/woff2"
                  ? "woff2"
                  : "bin";
        const path = `assets/${assetId}.${extension}`;
        binaryFiles[path] = Buffer.from(bytes).toString("base64");
        renderAssetSources[assetId] =
          `data:${asset.mediaType};base64,${binaryFiles[path]}`;
        manifestAssets[assetId] = {
          path,
          mediaType: asset.mediaType,
          digest: sha256(bytes),
        };
      }
      const widths = { compact: 390, regular: 768, wide: 1440 } as const;
      for (const [view, value] of Object.entries(
        currentDocument.document.views,
      ))
        for (const state of Object.keys(value.states))
          for (const viewport of ["compact", "regular", "wide"] as const) {
            const targetKey=`${view}-${state}-${viewport}`;
            const id = `${view.slice(0,30)}-${state.slice(0,20)}-${viewport}-${sha256(targetKey).slice(7,15)}`;
            const rendered = await this.runWorker(
              "render",
              {
                document: currentDocument.document,
                view,
                state,
                viewport,
                capture: true,
                assetSources: renderAssetSources,
              },
              `${input.approvalId}:render:${id}`,
            );
            if (
              typeof rendered.screenshotBase64 !== "string" ||
              typeof rendered.ariaSnapshot !== "string"
            )
              throw new Error(`render evidence is missing for ${id}`);
            if (!Array.isArray(rendered.accessibilityFindings))
              throw new Error(
                `rendered accessibility evidence is missing for ${id}`,
              );
            if (rendered.accessibilityFindings.length)
              throw new Error(
                `rendered accessibility gate failed for ${id}: ${rendered.accessibilityFindings.join(",")}`,
              );
            const previewPath = `previews/${id}.png`;
            const ariaPath = `previews/${id}.aria.txt`;
            binaryFiles[previewPath] = rendered.screenshotBase64;
            textFiles[ariaPath] = rendered.ariaSnapshot;
            const previewDigest=sha256(Buffer.from(rendered.screenshotBase64,"base64"));
            const ariaDigest=sha256(rendered.ariaSnapshot);
            previewEntries.push({
              id,
              view,
              state,
              viewport,
              path: previewPath,
              width: widths[viewport],
              height: 1000,
              fidelity: "intent",
              digest: previewDigest,
              ariaPath,
              ariaDigest,
              renderer: rendered.renderer,
            });
          }
      const previewIndex={
        schema: "prism.preview-index.v1",
        previews: previewEntries,
      };
      validatePrism("previewIndex",previewIndex);
      textFiles["previews/index.json"] = JSON.stringify(previewIndex);
      const assembled = assembleBaselineArchive({
        // Select the new format only for a genuinely new publication. The
        // existing-baseline early return above keeps saved approvals/CAS bytes.
        profile: BASELINE_V2,
        textFiles,
        binaryFiles,
        manifest: {
        bundleId: `${currentDocument.document.meta.projectId.slice(0, 71)}-baseline`,
        projectId: currentDocument.document.meta.projectId,
        revision: currentDocument.document.meta.revision,
        designDocument: {
          path: "design-document.json",
          schema: "prism.design-document.v1",
          revision: currentDocument.document.meta.revision,
        },
        designSpecification: { path: "design-specification.md" },
        acceptanceCriteria: { path: "acceptance-criteria.json" },
        assets: manifestAssets,
        previews: { path: "previews/index.json" },
        createdAt: new Date(approval.rows[0].approved_at).toISOString(),
        },
      });
      const { manifest, checksums, bundleDigest } = assembled;
      const bundle = await artifacts.put(assembled.bytes);
      await pool.query(
        "INSERT INTO prism.baseline(id,project_id,design_revision_id,bundle_key,bundle_revision,bundle_digest,bundle_artifact_id,approval_id,specification_digest,criteria_digest,preview_index_digest) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)",
        [
          randomUUID(),
          input.projectId,
          currentDocument.id,
          "primary",
          currentDocument.document.meta.revision,
          bundleDigest,
          bundle.artifactId,
          input.approvalId,
          checksums["design-specification.md"],
          checksums["acceptance-criteria.json"],
          checksums["previews/index.json"],
        ],
      );
      return json(response, 201, {
        bundleDigest,
        artifactId: bundle.artifactId,
        manifest,
      });
    }
    if (url.pathname === "/v1/artifacts" && request.method === "POST") {
      const input = (await body(request, 8_500_000)) as { base64?: string };
      if (!input.base64) throw new Error("base64 is required");
      const decoded = Buffer.from(input.base64, "base64");
      if (
        decoded.byteLength > 6_000_000 ||
        decoded.toString("base64") !== input.base64
      )
        throw new Error("artifact payload is invalid or exceeds 6 MB");
      return json(response, 201, await artifacts.put(decoded));
    }
    if (url.pathname === "/v1/corpus" && request.method === "POST") {
      const input = (await body(request)) as CorpusInput;
      if (input.sourceKind === "public-web")
        throw new Error(
          "public-web ingestion is disabled until a source policy is approved",
        );
      const acquired=await fetch(new URL("/v1/acquisitions",ingestionUrl),{method:"POST",headers:{authorization:`Bearer ${ingestionSecret}`,"content-type":"application/json"},body:JSON.stringify(input),signal:AbortSignal.timeout(30_000)});
      if(!acquired.ok)throw new Error(`corpus acquisition failed: ${acquired.status}`);
      const acquisition=(await acquired.json()) as {normalized?:CorpusInput;quarantineDigest?:string;contentBase64?:string};
      if(!acquisition.normalized||!acquisition.quarantineDigest||!acquisition.contentBase64)throw new Error("corpus acquisition returned invalid evidence");
      let publicationError:unknown;let stored:{id:string;digest:string}|undefined;
      try{
        const sourceBytes=Buffer.from(acquisition.contentBase64,"base64");
        if(`sha256:${createHash("sha256").update(sourceBytes).digest("hex")}`!==acquisition.quarantineDigest)throw new Error("corpus acquisition digest mismatch");
        const normalized={...acquisition.normalized,sourceContentDigest:acquisition.quarantineDigest};
        const text = `${normalized.title} ${normalized.summary} ${normalized.tags.join(" ")}`;
        const embedded = await this.runWorker("ingest",{ text },`corpus:${sha256(JSON.stringify(input))}`);
        stored=await ingest(pool, normalized, {
          embedding: embedded.embedding as number[],
          model: String(embedded.model),
          modelVersion: String(embedded.modelVersion),
          sourceDigest: String(embedded.sourceDigest),
        },{activate:false});
      }catch(error){publicationError=error;}
      let cleanupError:unknown;
      try{await fetch(new URL(`/v1/acquisitions/${acquisition.quarantineDigest.slice(7)}`,ingestionUrl),{method:"DELETE",headers:{authorization:`Bearer ${ingestionSecret}`},signal:AbortSignal.timeout(10_000)}).then((result)=>{if(!result.ok)throw new Error(`quarantine cleanup failed: ${result.status}`);});}
      catch(error){cleanupError=error;}
      if(publicationError&&cleanupError)throw new AggregateError([publicationError,cleanupError],"corpus publication and quarantine cleanup failed");
      if(publicationError)throw publicationError;
      if(cleanupError)throw cleanupError;
      // ingest returns corpus_revision.id so activation remains bound to the exact governed revision.
      await pool.query("UPDATE prism.corpus_item SET status='active' WHERE current_revision_id=$1",[stored!.id]);
      return json(response,201,stored!);
    }
    if (url.pathname === "/v1/corpus/search" && request.method === "GET") {
      const query = url.searchParams.get("q") ?? "";
      const embedded = await this.runWorker(
        "ingest",
        { text: query },
        `query:${sha256(query)}`,
      );
      const parseFilter = (
        name: string,
      ): Record<string, unknown> | undefined => {
        const value = url.searchParams.get(name);
        if (!value) return undefined;
        const parsed = JSON.parse(value);
        if (!parsed || typeof parsed !== "object" || Array.isArray(parsed))
          throw new Error(`${name} filter must be an object`);
        return parsed as Record<string, unknown>;
      };
      const items = await search(
        pool,
        query,
        Math.min(50, Math.max(1, Number(url.searchParams.get("limit") ?? 10))),
        {
          embedding: embedded.embedding as number[],
          model: String(embedded.model),
        },
        {
          required: parseFilter("required"),
          preferred: parseFilter("preferred"),
          avoid: parseFilter("avoid"),
          sourceFamilyLimit: Math.min(
            10,
            Math.max(1, Number(url.searchParams.get("sourceFamilyLimit") ?? 2)),
          ),
        },
      );
      return json(response, 200, {
        items,
        coverageGap:
          items.length <
          Math.min(50, Math.max(1, Number(url.searchParams.get("limit") ?? 10)))
            ? "The approved corpus does not cover all requested result slots."
            : null,
      });
    }
    if (url.pathname === "/v1/preferences/policy" && request.method === "PUT") {
      const input = await body(request) as {projectId?: string; personalEnabled?: boolean};
      if (!input.projectId || typeof input.personalEnabled !== "boolean") throw new Error("projectId and personalEnabled are required");
      await setPersonalPreferences(pool, userKey(actor.user), input.projectId, input.personalEnabled);
      return json(response,200,{projectId:input.projectId,personalEnabled:input.personalEnabled});
    }
    if (url.pathname === "/v1/preferences" && request.method === "POST") {
      const event = validatePrism<PreferenceEvent>(
        "preferenceEvent",
        await body(request),
      );
      if (event.userId !== userKey(actor.user))
        throw new Error("preference user does not match the session");
      if (event.action === "retracted" && !event.retractsEventId)
        throw new Error("retraction target is required");
      await recordPreference(pool, event);
      return json(response, 201, { id: event.eventId });
    }
    if (url.pathname === "/v1/preferences" && request.method === "GET") {
      const projectId = url.searchParams.get("project");
      const events = await preferenceEvents(pool, userKey(actor.user), projectId);
      return json(response, 200, {
        events,
        learned: projectPreferences(events),
      });
    }
    const artifact = /^\/v1\/artifacts\/(sha256:[a-f0-9]{64})$/.exec(
      url.pathname,
    );
    if (artifact && request.method === "GET") {
      const content = await artifacts.get(`artifact:${artifact[1]}`);
      response.writeHead(200, { "content-type": "application/octet-stream" });
      return response.end(content);
    }
    return json(response, 404, { error: "not found" });
  } catch (error) {
    console.error("[prism-control] request failed", {
      method: request.method,
      path: request.url,
      error: error instanceof Error ? error.message : "request failed",
    });
    return json(response, error instanceof SyntaxError ? 400 : 422, {
      error: error instanceof Error ? error.message : "request failed",
    });
  }
  }
}

/** Compose the original HTTP service; the caller owns database/listener lifetime. */
export async function createControlServer(pool: Database, environment?: NodeJS.ProcessEnv) {
  const {service: config, product: productConfig} = await loadControlCompositionConfig(environment);
  const service = new ControlService(pool, config);
  return createServer(productAuthorityHandler((request, response) => service.handle(request, response),
    {db: pool, config: productConfig, sessionSecret: config.sessionSecret}));
}
