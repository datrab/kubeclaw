#!/bin/sh
set -eu

if [ "${BUSTER_PLAN_CONFIG_ROOT+x}" = x ]; then
  echo "BUSTER_PLAN_CONFIG_ROOT is retired; runtime configuration uses the fixed root-owned image namespace" >&2
  exit 1
fi
runtime_config_root="$(node /usr/local/libexec/buster-runtime-config-root.mjs)"
exec 9<>/run/kubeclaw-buster/lifetime.lock
flock -n 9 || { echo "Buster runtime is already active" >&2; exit 1; }

worker_token="${BUSTER_V2_TOKEN:?BUSTER_V2_TOKEN is required when SPIFFE transport is unavailable}"
trusted_peer_spiffe_id="${BUSTER_TRUSTED_PEER_SPIFFE_ID:-}"
unset BUSTER_V2_TOKEN
socket="${BUILDKIT_HOST:?BUILDKIT_HOST is required}"
address="${socket#unix://}"
state="${BUILDKIT_STATE_DIR:?BUILDKIT_STATE_DIR is required}"
otel_socket="${BUILDKIT_OTEL_SOCKET_PATH:-${XDG_RUNTIME_DIR:?XDG_RUNTIME_DIR is required}/buildkit/otel-grpc.sock}"
registry_client_dir="$(mktemp -d /tmp/registry-clients.XXXXXX)"
registry_contract="$registry_client_dir/input.json"
printf '%s' "${KUBECLAW_REGISTRY_CONFIG:?Explicit registry endpoint/transport/auth configuration is required; see docs/operations/registry-clients.md}" >"$registry_contract"
chmod 0600 "$registry_contract"
node /app/scripts/registry-client-config.mjs "$registry_contract" buildkit "$registry_client_dir/buildkit.toml"
node /app/scripts/registry-client-config.mjs "$registry_contract" runtime "$registry_client_dir/runtime.json"
registry="$(node -e 'process.stdout.write(JSON.parse(require("node:fs").readFileSync(process.argv[1],"utf8")).registryReference)' "$registry_client_dir/runtime.json")"
config="$runtime_config_root/buildkit.toml"
buildkit_log="$runtime_config_root/buildkit.log"
mkdir -p "$(dirname "$address")" "$(dirname "$otel_socket")" "$state" "$(dirname "$config")"
cp "$registry_client_dir/buildkit.toml" "$config"
chown root:builder "$config"
chmod 0640 "$config"

setpriv \
  --reuid=1000 \
  --regid=1000 \
  --init-groups \
  rootlesskit --net=host buildkitd \
  --config "$config" \
  --addr "$socket" \
  --otel-socket-path "$otel_socket" \
  --root "$state" \
  --oci-worker-no-process-sandbox \
  >"$buildkit_log" 2>&1 9>&- &
buildkit_pid=$!
worker_pid=""
kube_service_account_root="${BUSTER_KUBERNETES_SERVICE_ACCOUNT_ROOT:-/var/run/buster-worker/kubernetes}"
plan_state_dir="${BUSTER_PLAN_STATE_DIR:-/var/lib/buster-v2/plan-jobs}"
plan_run_dir="${BUSTER_PLAN_RUN_DIR:-/var/lib/buster-v2/runs}"
browser_playwright_cgroup_root="${BUSTER_BROWSER_PLAYWRIGHT_CGROUP_ROOT:?BUSTER_BROWSER_PLAYWRIGHT_CGROUP_ROOT is required}"

cleanup() {
  if [ -n "$worker_pid" ]; then
    kill "$worker_pid" 2>/dev/null || true
    wait "$worker_pid" 2>/dev/null || true
  fi
  kill "$buildkit_pid" 2>/dev/null || true
  wait "$buildkit_pid" 2>/dev/null || true
}
trap cleanup EXIT INT TERM

attempt=0
until buildctl --addr "$socket" debug workers >/dev/null 2>&1; do
  attempt=$((attempt + 1))
  if [ "$attempt" -ge 60 ]; then
    cat "$buildkit_log" >&2
    exit 1
  fi
  sleep 1
done

# The pod mounts one dedicated cgroup v2 subtree. The worker never receives
# the host cgroup root. Production browser execution cannot use sampled
# accounting because short-lived descendants could escape a sample.
test -d "$browser_playwright_cgroup_root"
canonical_browser_playwright_cgroup_root="$(realpath "$browser_playwright_cgroup_root")"
expected_browser_playwright_cgroup_root="$(realpath -m /var/run/kubeclaw-browser-cgroup)"
if [ "$canonical_browser_playwright_cgroup_root" != "$expected_browser_playwright_cgroup_root" ]; then
  echo "browser Playwright cgroup root is unsafe" >&2
  exit 1
fi
# A previous worker may have left this mode-0700 directory owned by builder.
# The supervisor has CHOWN but no DAC override, so reclaim traversal while
# validating/configuring it, then hand off the directory last.
chown root:builder "$browser_playwright_cgroup_root"
test -f "$browser_playwright_cgroup_root/cgroup.controllers"
for controller in pids memory cpu; do
  grep -qw "$controller" "$browser_playwright_cgroup_root/cgroup.controllers" \
    || { echo "required browser cgroup controller is unavailable: $controller" >&2; exit 1; }
done
if [ -s "$browser_playwright_cgroup_root/cgroup.procs" ]; then
  echo "browser Playwright cgroup subtree contains host processes" >&2
  exit 1
fi
# The previous worker also owns the control file. Reclaim write ownership before
# enabling controllers; CHOWN does not grant DAC override on a builder-owned file.
chown root:builder "$browser_playwright_cgroup_root/cgroup.subtree_control"
printf '+pids +memory +cpu' >"$browser_playwright_cgroup_root/cgroup.subtree_control"
for controller in pids memory cpu; do
  grep -qw "$controller" "$browser_playwright_cgroup_root/cgroup.subtree_control" \
    || { echo "required browser cgroup controller is not delegated: $controller" >&2; exit 1; }
done
chown builder:builder "$browser_playwright_cgroup_root/cgroup.procs" "$browser_playwright_cgroup_root/cgroup.subtree_control" "$browser_playwright_cgroup_root"

# BuildKit creates the socket as the non-root builder. Apply its shared-group
# permissions as that owner; the restricted supervisor intentionally does not
# retain CAP_FOWNER.
setpriv \
  --reuid=1000 \
  --regid=1000 \
  --init-groups \
  chgrp 1002 "$address"
setpriv \
  --reuid=1000 \
  --regid=1000 \
  --init-groups \
  chmod 0660 "$address"

# The supervisor retains only CHOWN/SETUID/SETGID/SETPCAP. Keep the pod fsGroup
# (1000) for projected credentials and add the socket group (1002) so its
# BuildKit readiness checks can connect after the ownership transition above.
# worker.ts clears all supplementary groups and capabilities before suite code.
: "${BUSTER_SOURCE_ATTESTATION_PUBLIC_KEY:?BUSTER_SOURCE_ATTESTATION_PUBLIC_KEY is required}"
if [ "$plan_state_dir" != /var/lib/buster-v2/plan-jobs ] || [ "$plan_run_dir" != /var/lib/buster-v2/runs ]; then
  echo 'Buster native state requires the fixed /var/lib/buster-v2 PVC namespace' >&2
  exit 1
fi
if [ -n "${BUSTER_V2_STATE_DIR+x}${BUSTER_V2_RUN_DIR+x}" ]; then
  echo 'BUSTER_V2_STATE_DIR/BUSTER_V2_RUN_DIR were replaced by the fixed Buster PVC namespace' >&2
  exit 1
fi
node /usr/local/libexec/buster-state-root.mjs
# The generated configuration remains root-owned for the full parent lifetime.
# Its fixed ancestor and existing files were validated before acquiring the
# startup lock; the service receives only group read/traverse access.
chown root:root "$runtime_config_root"
chmod 0750 "$runtime_config_root"

test -r "$kube_service_account_root/token"
test -r "$kube_service_account_root/ca.crt"
test -r "$kube_service_account_root/namespace"
kube_namespace="$(tr -d '\r\n' < "$kube_service_account_root/namespace")"
case "$kube_namespace" in
  ''|*[!a-z0-9-]*) echo "projected Kubernetes namespace is invalid" >&2; exit 1 ;;
esac
kubeconfig="$runtime_config_root/kubeconfig"
cat >"$kubeconfig" <<EOF
apiVersion: v1
kind: Config
clusters:
- name: in-cluster
  cluster:
    certificate-authority: $kube_service_account_root/ca.crt
    server: https://${KUBERNETES_SERVICE_HOST:?KUBERNETES_SERVICE_HOST is required}:${KUBERNETES_SERVICE_PORT:?KUBERNETES_SERVICE_PORT is required}
users:
- name: buster
  user:
    tokenFile: $kube_service_account_root/token
contexts:
- name: buster
  context:
    cluster: in-cluster
    namespace: $kube_namespace
    user: buster
current-context: buster
EOF

RUNTIME_CONFIG_ROOT="$runtime_config_root" REGISTRY_CLIENT_RUNTIME="$registry_client_dir/runtime.json" REGISTRY_REFERENCE="$registry" CONTROLLER_NAMESPACE="$kube_namespace" \
  BUSTER_ALLOWED_SOURCE_SECRETS="${BUSTER_ALLOWED_SOURCE_SECRETS:-}" \
  BUSTER_NETWORK_HTTP_EXACT_ORIGINS="${BUSTER_NETWORK_HTTP_EXACT_ORIGINS:-}" \
  BUSTER_BROWSER_AXE_EXACT_ORIGINS="${BUSTER_BROWSER_AXE_EXACT_ORIGINS:-}" \
  BUSTER_NETWORK_HTTP_ALLOW_WEBSOCKET="${BUSTER_NETWORK_HTTP_ALLOW_WEBSOCKET:-false}" \
  BUSTER_BROWSER_PLAYWRIGHT_CGROUP_ROOT="$browser_playwright_cgroup_root" \
  BUSTER_V2_STATE_DIR="$plan_state_dir" BUSTER_V2_RUN_DIR="$plan_run_dir" node <<'NODE'
const fs = require('fs');
const path = require('path');
const root = process.env.RUNTIME_CONFIG_ROOT;
const registry = process.env.REGISTRY_REFERENCE;
const plugins = '/app/skills/buster/plugins';
const exactHttpOrigins = (process.env.BUSTER_NETWORK_HTTP_EXACT_ORIGINS || '')
  .split(',').map((value) => value.trim()).filter(Boolean);
const exactBrowserOrigins = (process.env.BUSTER_BROWSER_AXE_EXACT_ORIGINS || '')
  .split(',').map((value) => value.trim()).filter(Boolean);
fs.writeFileSync(path.join(root, 'platform.json'), `${JSON.stringify({
  schemaVersion: 'pipeline-platform.v2',
  installationRoots: [plugins], trustedBuiltinRoots: [plugins],
  externalTrust: { allowedSourceDigests: {}, verifiedAttestations: {} },
  providers: {}, grants: {}, adapters: {}, activeAdapters: [], observers: {},
  storageRoot: '/tmp/buster-plan-platform', shutdownTimeoutMs: 10_000,
  orchestratorIssuerId: 'buster', administrativeDecisionIssuers: [],
}, null, 2)}\n`);
fs.writeFileSync(path.join(root, 'runtime.json'), `${JSON.stringify({
  schemaVersion: 'buster-remote-plan-runtime.v1', platformConfig: './platform.json',
  host: '0.0.0.0', port: Number(process.env.BUSTER_PLAN_PORT || 18891),
  ...(process.env.BUSTER_TRUSTED_PEER_SPIFFE_ID
    ? { trustedPeerSpiffeIds: [process.env.BUSTER_TRUSTED_PEER_SPIFFE_ID] }
    : { tokenEnvironmentVariable: 'BUSTER_V2_TOKEN' }),
  sourceAttestationPublicKeyEnvironmentVariable: 'BUSTER_SOURCE_ATTESTATION_PUBLIC_KEY',
  trustedSourceAuthority: process.env.BUSTER_PLAN_TRUSTED_SOURCE_AUTHORITY || 'nova:production',
  stateRoot: process.env.BUSTER_V2_STATE_DIR,
  runtimeRoot: process.env.BUSTER_V2_RUN_DIR,
  tarExecutable: '/usr/bin/tar',
  recordLimits: { maximumRecords: 10000, maximumBytes: 1073741824, maximumRecordBytes: 67108864 },
  maximumResultBytes: 67108864, maximumResultStoreBytes: 1073741824,
  maximumResponseBytes: 67108864,
  shutdownTimeoutMs: 15000,
  allowedCapabilities: ['command.execute', 'container.build', 'kubernetes.fixture', 'kubernetes.exposure', 'network.http', 'browser.axe', 'browser.lighthouse', 'browser.visual', 'browser.playwright', 'security.scan', 'kubernetes.runtime-security'],
  directCommand: {
    executableCatalog: {
      node: '/usr/local/bin/node',
      npm: '/usr/local/bin/npm',
      python3: '/usr/bin/python3',
      tar: '/usr/bin/tar',
      cp: '/usr/bin/cp',
    },
    executableSearchPath: ['/usr/local/bin', '/usr/bin', '/bin'],
    runtimeReadRoots: [
      '/usr/local/bin', '/usr/local/lib/node_modules', '/usr/bin', '/bin',
      '/usr/lib', '/lib', '/lib64', '/etc/ssl', '/etc/alternatives',
    ],
    maximumOutputBytes: 16777216,
    maximumExecutionMs: 900000,
    maximumProcesses: 128,
    maximumMemoryBytes: 4294967296,
    maximumCpuMillis: 900000,
    terminationGraceMs: 2000,
    allowSampledProcessLimit: true,
  },
  dependencyReadiness: { maximumExecutionMs: 1000, maximumOutputBytes: 65536 },
  containerBuild: {
    buildctlExecutable: '/usr/local/bin/buildctl', buildkitHost: process.env.BUILDKIT_HOST,
    ...JSON.parse(fs.readFileSync(process.env.REGISTRY_CLIENT_RUNTIME, 'utf8')),
    repositoryPrefix: 'kubeclaw/pipeline', allowedPlatforms: ['linux/amd64', 'linux/arm64'],
    allowedBuildArguments: ['NODE_ENV'], maximumLogBytes: 8388608,
    maximumExecutionMs: 900000, maximumManifestBytes: 16777216,
  },
  kubernetesFixture: {
    kubectlExecutable: '/usr/local/bin/kubectl', controllerNamespace: process.env.CONTROLLER_NAMESPACE,
    leaseApiGroup: process.env.BUSTER_LEASE_API_GROUP || 'kubeclaw.forgestack.ai',
    leaseApiVersion: process.env.BUSTER_LEASE_API_VERSION || 'v1alpha1', allowedNamespacePrefixes: ['test'],
    allowedRegistryPrefixes: [`${registry}/kubeclaw`],
    allowedSecretReferences: (process.env.BUSTER_ALLOWED_SOURCE_SECRETS || '').split(',').filter(Boolean),
    allowedStorageClasses: [], allowDefaultStorageClass: true,
    maximumManifestBytes: 1048576,
    maximumResources: 64, maximumPersistentVolumeClaimBytes: 10737418240,
    maximumPersistentVolumeTotalBytes: 21474836480,
    maximumRetentionSeconds: 604800, maximumExecutionMs: 900000, pollIntervalMs: 1000,
  },
  tailscaleExposure: {
    kubectlExecutable: '/usr/local/bin/kubectl', controllerNamespace: process.env.CONTROLLER_NAMESPACE,
    leaseApiGroup: process.env.BUSTER_LEASE_API_GROUP || 'kubeclaw.forgestack.ai',
    leaseApiVersion: process.env.BUSTER_LEASE_API_VERSION || 'v1alpha1', allowedNamespacePrefixes: ['test'],
    allowedHostSuffixes: ['.ts.net'], maximumExecutionMs: 900000, pollIntervalMs: 1000,
  },
  networkHttp: {
    registryHealth: true,
    allowedOrigins: exactHttpOrigins, allowedHostSuffixes: ['.svc.cluster.local', '.ts.net'], allowedPorts: [80, 443],
    allowedMethods: ['DELETE', 'GET', 'HEAD', 'OPTIONS', 'PATCH', 'POST', 'PUT'],
    allowedRequestHeaders: ['accept', 'authorization', 'content-type', 'cookie', 'x-api-key'],
    allowWebSocket: process.env.BUSTER_NETWORK_HTTP_ALLOW_WEBSOCKET === 'true',
    maximumRequestBytes: 1048576, maximumResponseBytes: 16777216, maximumExecutionMs: 120000,
  },
  browserAxe: {
    allowedOrigins: exactBrowserOrigins,
    allowedBrowsers: ['chromium', 'firefox', 'webkit'],
    maximumCombinations: 32,
    maximumConcurrency: 4,
    maximumExecutionMs: 120000,
    maximumResultBytes: 16777216,
    maximumScreenshots: 16,
    maximumScreenshotBytes: 8388608,
  },
  browserLighthouse: {
    allowedOrigins: exactBrowserOrigins,
    chromeExecutable: require('/app/node_modules/playwright').chromium.executablePath(),
    maximumRuns: 80,
    maximumExecutionMs: 180000,
    maximumResultBytes: 67108864,
  },
  browserVisual: {
    allowedOrigins: exactBrowserOrigins,
    allowedBrowsers: ['chromium', 'firefox', 'webkit'],
    maximumCombinations: 64,
    maximumConcurrency: 4,
    maximumExecutionMs: 120000,
    maximumResultBytes: 134217728,
    maximumScreenshotBytes: 16777216,
    maximumMasksPerCombination: 32,
  },
  browserPlaywright: {
    allowedOrigins: exactBrowserOrigins,
    allowedTargetPorts: [18080],
    playwrightExecutable: '/app/node_modules/.bin/playwright',
    sandboxExecutable: '/opt/kubeclaw-trusted/plugin-sandbox',
    runtimeNodeModules: '/app/node_modules',
    browsersPath: '/ms-playwright',
    readOnlyRoots: ['/app', '/ms-playwright', '/usr', '/lib', '/lib64', '/etc/fonts', '/etc/hosts', '/etc/nsswitch.conf', '/etc/resolv.conf', '/etc/ssl', '/proc', '/sys', '/dev'],
    maximumWorkers: 4,
    maximumExecutionMs: 900000,
    maximumOutputBytes: 16777216,
    maximumResultBytes: 67108864,
    maximumArtifactBytes: 268435456,
    maximumArtifactFiles: 256,
    maximumProcesses: 128,
    maximumMemoryBytes: 4294967296,
    maximumCpuMillis: 900000,
    terminationGraceMs: 5000,
    cgroupRoot: process.env.BUSTER_BROWSER_PLAYWRIGHT_CGROUP_ROOT,
    runAsUid: 1001,
    runAsGid: 1000,
  },
  securityScan: {
    registry: JSON.parse(fs.readFileSync(process.env.REGISTRY_CLIENT_RUNTIME, 'utf8')),
    trivyExecutable: '/usr/local/bin/trivy',
    allowedRegistryPrefixes: [`${registry}/kubeclaw`],
    maximumExecutionMs: 900000,
    maximumOutputBytes: 67108864,
    cacheDirectory: '/home/builder/.cache/trivy',
    databasePolicy: {
      maximumVulnerabilityAgeMs: 48 * 60 * 60 * 1000,
      maximumJavaAgeMs: 7 * 24 * 60 * 60 * 1000,
      maximumDatabaseBytes: 8 * 1024 * 1024 * 1024,
    },
  },
  kubernetesRuntimeSecurity: {
    kubectlExecutable: '/usr/local/bin/kubectl',
    controllerNamespace: process.env.CONTROLLER_NAMESPACE,
    leaseApiGroup: process.env.BUSTER_LEASE_API_GROUP || 'kubeclaw.forgestack.ai',
    allowedNamespacePrefixes: ['test'],
    maximumExecutionMs: 300000,
    maximumOutputBytes: 16777216,
    pollIntervalMs: 1000,
    maximumObservationAgeMs: 10000,
  },
}, null, 2)}\n`);
NODE
rm -rf -- "$registry_client_dir"
chmod 0640 "$runtime_config_root/platform.json" "$runtime_config_root/runtime.json" "$kubeconfig"
chown root:builder "$runtime_config_root" "$runtime_config_root/platform.json" "$runtime_config_root/runtime.json" "$kubeconfig"

if [ -n "$trusted_peer_spiffe_id" ]; then
  BUSTER_TRUSTED_PEER_SPIFFE_ID="$trusted_peer_spiffe_id" KUBECONFIG="$kubeconfig" \
    node /app/skills/buster/engine/native-parent.ts 9>&- &
else
  BUSTER_V2_TOKEN="$worker_token" KUBECONFIG="$kubeconfig" \
    node /app/skills/buster/engine/native-parent.ts 9>&- &
fi
worker_pid=$!

wait "$worker_pid"
