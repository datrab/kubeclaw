import crypto from 'node:crypto';
import {
  canonicalJson,
  type AttemptIdentity,
  type PluginStateEntry,
  type RegistrationProvenance,
} from '@kubeclaw/plugin-sdk';
import { validateContractValue } from '@kubeclaw/plugin-foundation/registry/schema';
import { FileJournal } from './journal.ts';
import { snapshotJson } from './json-value.ts';

export interface PluginStateAppend {
  readonly namespace: string;
  readonly registration: RegistrationProvenance;
  readonly attempt?: AttemptIdentity | null;
  readonly entryType: string;
  readonly entrySchemaVersion?: string;
  readonly idempotencyKey: string;
  readonly payload: Readonly<Record<string, unknown>>;
}

function expectedNamespace(registration: RegistrationProvenance): string {
  return `plugin.${registration.package.package.pluginId}.${registration.registrationId}`;
}

export class PluginStateJournal {
  readonly #journal: FileJournal<PluginStateEntry>;
  readonly #registration: RegistrationProvenance;
  readonly #namespace: string;
  readonly #now: () => Date;

  constructor(
    file: string,
    registration: RegistrationProvenance,
    now: () => Date = () => new Date(),
  ) {
    this.#journal = new FileJournal(file);
    this.#registration = snapshotJson(registration);
    this.#namespace = expectedNamespace(this.#registration);
    this.#now = now;
    this.#validateRecords(this.#journal.records());
  }

  #validateRecords(
    records: ReturnType<FileJournal<PluginStateEntry>['records']>,
  ): void {
    for (const record of records) {
      validateContractValue('pluginStateEntry', record.entry);
      if (record.entry.sequence !== record.sequence) {
        throw new Error(`PLUGIN_STATE_SEQUENCE_INVALID:${record.entry.sequence}`);
      }
      if (record.entry.namespace !== expectedNamespace(record.entry.registration)) {
        throw new Error(`PLUGIN_STATE_NAMESPACE_DENIED:${record.entry.namespace}`);
      }
      if (
        record.entry.namespace !== this.#namespace
        || canonicalJson(record.entry.registration) !== canonicalJson(this.#registration)
      ) {
        throw new Error(`PLUGIN_STATE_REGISTRATION_DENIED:${record.entry.namespace}`);
      }
    }
  }

  append(input: PluginStateAppend): PluginStateEntry {
    input = snapshotJson(input);
    const namespace = expectedNamespace(input.registration);
    if (
      input.namespace !== namespace
      || namespace !== this.#namespace
      || canonicalJson(input.registration) !== canonicalJson(this.#registration)
    ) {
      throw new Error(`PLUGIN_STATE_NAMESPACE_DENIED:${input.namespace}`);
    }
    return this.#journal.transact((records, append) => {
      this.#validateRecords(records);
      const duplicate = records.map(({ entry }) => entry).find(
        (entry) => entry.namespace === namespace
          && entry.idempotencyKey === input.idempotencyKey,
      );
      if (duplicate) {
      const comparable = {
        namespace: input.namespace,
        registration: input.registration,
        attempt: input.attempt ?? null,
        entryType: input.entryType,
        ...(input.entrySchemaVersion === undefined ? {} : { entrySchemaVersion: input.entrySchemaVersion }),
        idempotencyKey: input.idempotencyKey,
        payload: input.payload,
      };
      const existingComparable = {
        namespace: duplicate.namespace,
        registration: duplicate.registration,
        attempt: duplicate.attempt ?? null,
        entryType: duplicate.entryType,
        ...(duplicate.entrySchemaVersion === undefined ? {} : { entrySchemaVersion: duplicate.entrySchemaVersion }),
        idempotencyKey: duplicate.idempotencyKey,
        payload: duplicate.payload,
      };
        if (canonicalJson(comparable) !== canonicalJson(existingComparable)) {
          throw new Error(`PLUGIN_STATE_IDEMPOTENCY_CONFLICT:${input.idempotencyKey}`);
        }
        return duplicate;
      }
      const sequence = records.length + 1;
      const entry: PluginStateEntry = Object.freeze({
      schemaVersion: 'plugin-state-entry.v2',
      entryId: `state:${crypto.createHash('sha256')
        .update(`${namespace}\u0000${input.idempotencyKey}`)
        .digest('hex')}`,
      sequence,
      namespace,
      registration: input.registration,
      attempt: input.attempt ?? null,
      entryType: input.entryType,
      ...(input.entrySchemaVersion ? { entrySchemaVersion: input.entrySchemaVersion } : {}),
      idempotencyKey: input.idempotencyKey,
      occurredAt: this.#now().toISOString(),
      payload: input.payload,
      });
      validateContractValue('pluginStateEntry', entry);
      return append(entry).entry;
    });
  }

  entries(namespace?: string): readonly PluginStateEntry[] {
    const records = this.#journal.refresh();
    this.#validateRecords(records);
    return Object.freeze(records
      .map(({ entry }) => entry)
      .filter((entry) => namespace === undefined || entry.namespace === namespace));
  }

  project<T>(
    namespace: string,
    initial: T,
    reduce: (state: T, entry: PluginStateEntry) => T,
  ): T {
    return this.entries(namespace).reduce(reduce, initial);
  }
}
