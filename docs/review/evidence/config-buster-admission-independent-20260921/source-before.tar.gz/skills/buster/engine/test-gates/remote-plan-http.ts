import crypto from 'node:crypto';
import http from 'node:http';
import https from 'node:https';
import type { BusterRemotePlanService } from './remote-plan-service.ts';
import { authorizeProxiedSpiffePeer } from '@kubeclaw/worker-core';

function authorized(request: http.IncomingMessage, token: string): boolean {
  const value = request.headers.authorization;
  if (!value?.startsWith('Bearer ')) return false;
  const supplied = Buffer.from(value.slice('Bearer '.length));
  const expected = Buffer.from(token);
  return supplied.byteLength === expected.byteLength && crypto.timingSafeEqual(supplied, expected);
}

function authorize(request: http.IncomingMessage, options: {
  readonly token?: string;
  readonly trustedPeerSpiffeIds?: readonly string[];
}): boolean {
  if (options.trustedPeerSpiffeIds) {
    try {
      authorizeProxiedSpiffePeer(request.headers, request.socket.remoteAddress,
        new Set(options.trustedPeerSpiffeIds));
      return true;
    } catch {
      return false;
    }
  }
  return options.token !== undefined && authorized(request, options.token);
}

function send(response: http.ServerResponse, status: number, body: unknown, maximumBytes: number): void {
  const bytes = Buffer.from(JSON.stringify(body));
  if (bytes.byteLength > maximumBytes) {
    const fallback = Buffer.from(JSON.stringify({ error: 'BUSTER_REMOTE_RESPONSE_SIZE_EXCEEDED' }));
    response.writeHead(500, { 'content-type': 'application/json', 'content-length': fallback.byteLength });
    response.end(fallback);
    return;
  }
  response.writeHead(status, {
    'content-type': 'application/json',
    'content-length': bytes.byteLength,
    'cache-control': 'no-store',
  });
  response.end(bytes);
}

function jobId(url: string | undefined): string | null {
  const match = url?.match(/^\/v1\/plan-jobs\/([^/?#]+)$/u);
  if (!match?.[1]) return null;
  try { return decodeURIComponent(match[1]); }
  catch { throw new Error('BUSTER_REMOTE_JOB_ID_INVALID'); }
}

function evidenceRoute(url: string | undefined): { jobId: string; digest: string } | null {
  const match = url?.match(/^\/v1\/plan-jobs\/([^/?#]+)\/evidence\/(sha256%3A|sha256:)([a-f0-9]{64})$/u);
  if (!match?.[1] || !match[2] || !match[3]) return null;
  try { return { jobId: decodeURIComponent(match[1]), digest: `sha256:${match[3]}` }; }
  catch { throw new Error('BUSTER_REMOTE_JOB_ID_INVALID'); }
}

function resultRoute(url: string | undefined): { jobId: string; digest: string } | null {
  const match = url?.match(/^\/v1\/plan-jobs\/([^/?#]+)\/results\/(sha256%3A|sha256:)([a-f0-9]{64})$/u);
  if (!match?.[1] || !match[2] || !match[3]) return null;
  try { return { jobId: decodeURIComponent(match[1]), digest: `sha256:${match[3]}` }; }
  catch { throw new Error('BUSTER_REMOTE_JOB_ID_INVALID'); }
}

async function healthResponse(request: http.IncomingMessage, response: http.ServerResponse, options: {
  readonly service: BusterRemotePlanService;
  readonly maximumResponseBytes: number;
}): Promise<boolean> {
  if (request.method === 'GET' && request.url === '/healthz') {
    send(response, 200, { schemaVersion: 'buster-plan-health.v2', live: true }, options.maximumResponseBytes);
    return true;
  }
  if (request.method === 'GET' && request.url === '/bootstrapz') {
    const ready = options.service.bootstrapReady();
    send(response, ready ? 200 : 503, { schemaVersion: 'buster-plan-bootstrap.v1', initialized: ready }, options.maximumResponseBytes);
    return true;
  }
  if (request.method === 'GET' && request.url === '/readyz') {
    const status = await options.service.readiness();
    send(response, status.ready ? 200 : 503, status, options.maximumResponseBytes);
    return true;
  }
  return false;
}

export function createBusterRemotePlanHttpServer(options: {
  readonly service: BusterRemotePlanService;
  readonly token?: string;
  readonly trustedPeerSpiffeIds?: readonly string[];
  readonly maximumRequestBytes: number;
  readonly maximumResponseBytes: number;
  readonly maximumResultBytes: number;
  readonly tls?: Readonly<{ key: string | Buffer; cert: string | Buffer }>;
}): http.Server {
  if ((options.token === undefined) === (options.trustedPeerSpiffeIds === undefined)) {
    throw new Error('BUSTER_REMOTE_AUTHENTICATION_INVALID');
  }
  if (options.token !== undefined && options.token.length < 32) throw new Error('BUSTER_REMOTE_TOKEN_INVALID');
  if (options.trustedPeerSpiffeIds?.length === 0) throw new Error('BUSTER_REMOTE_SPIFFE_POLICY_INVALID');
  for (const limit of [options.maximumRequestBytes, options.maximumResponseBytes, options.maximumResultBytes]) {
    if (!Number.isSafeInteger(limit) || limit < 1) throw new Error('BUSTER_REMOTE_HTTP_LIMIT_INVALID');
  }
  const handler: http.RequestListener = (request, response) => {
    void (async () => {
      if (await healthResponse(request, response, options)) return;
      if (!authorize(request, options)) {
        send(response, 401, { error: 'unauthorized' }, options.maximumResponseBytes);
        return;
      }
      if (request.method === 'POST' && request.url === '/v1/plan-jobs') {
        const declared = Number(request.headers['content-length']);
        if (Number.isFinite(declared) && declared > options.maximumRequestBytes) throw new Error('BUSTER_REMOTE_REQUEST_SIZE_EXCEEDED');
        const status = await options.service.submit(request);
        send(response, status.state === 'accepted' ? 202 : 200, status, options.maximumResponseBytes);
        return;
      }
      const evidence = evidenceRoute(request.url);
      if (evidence && request.method === 'GET') {
        const bytes = await options.service.evidence(evidence.jobId, evidence.digest, options.maximumResponseBytes);
        response.writeHead(200, {
          'content-type': 'application/octet-stream', 'content-length': bytes.byteLength,
          'content-digest': evidence.digest, 'cache-control': 'private, immutable',
        });
        response.end(bytes);
        return;
      }
      const result = resultRoute(request.url);
      if (result && request.method === 'GET') {
        const bytes = await options.service.result(result.jobId, result.digest, options.maximumResultBytes);
        response.writeHead(200, {
          'content-type': 'application/json', 'content-length': bytes.byteLength,
          'content-digest': result.digest, 'cache-control': 'private, immutable',
        });
        response.end(bytes);
        return;
      }
      const id = jobId(request.url);
      if (id && request.method === 'GET') {
        send(response, 200, await options.service.status(id), options.maximumResponseBytes);
        return;
      }
      if (id && request.method === 'DELETE') {
        send(response, 200, await options.service.cancel(id), options.maximumResponseBytes);
        return;
      }
      send(response, 404, { error: 'not found' }, options.maximumResponseBytes);
    })().catch((error) => {
      const message = error instanceof Error ? error.message : String(error);
      const status = ['BUSTER_REMOTE_ADMISSION_FULL', 'BUSTER_REMOTE_RESULT_CAPACITY_EXCEEDED'].includes(message) ? 429
        : ['BUSTER_REMOTE_SHUTTING_DOWN', 'BUSTER_DEPENDENCY_UNAVAILABLE'].includes(message) ? 503
        : message.includes('NOT_FOUND') ? 404
        : message.includes('CONFLICT') ? 409
          : message.includes('SIZE_EXCEEDED') ? 413 : 400;
      if (!response.headersSent) send(response, status, { error: message }, options.maximumResponseBytes);
      else response.destroy();
    });
  };
  return options.tls ? https.createServer(options.tls, handler) : http.createServer(handler);
}
