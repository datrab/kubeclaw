# b502 actual manifest and finite READY derivation — independent review

**PASS: bounded Source-purpose continuity / actual manifest+derivation / Quality.** Root may create one separate immutable final graph-only copy using only the transitions below. This is not that final copy, seal, or capture launch admission. No open material issue in this finite derivation.

Author manifest1026f298d1b45735bb23f39076a777410d3d7cb4b920057d9e5693bf30591f44 (12,433,735bytes); candidate7fc91312ab5043677745e5462890cdf03f3625784182edbc746043594cf84cf9 (12,436,636bytes).

## Exact actual result and physical/context check

Read original isolatedpreparer launch admission, actual toolterminal0 result and complete rawstreams; allargv/env/cwd/scriptSHA/reviewSHA/streambytes/hashes exact, stderr empty. Structured stdout107roles/115closure/12eager/75foundation/433files is consistent, not acceptance by count.

Recursive comparison against independently accepted actualca11manifest has **exactly three scalar changes**: revisionca11→b502, file264ownerSHA0bea→11cf, ownerbytes96040→96467. Every other object/value including recipe selections,75foundation/12eager,14CIpurpose inputs,433file membership, wholetypednamespace/context/config/YAML/receivinghashes is identical. The changedowner's two static prose responsibilities and actual originalwrite/write/check already have exact independent Source/result proofs; no import/parser/call/guard/purpose/receiver expansion. The three receiving scripts remain byte-identical to complete140/106/91line review, not merely named historical basis. Actual554executed-v2basis and original115guard remain unchanged, no oldercbb substitution.

Fresh independent physical check:433canonicalregular/no-symlink files exact hashes/lengths/modes;153originalabsences retained;4pointers and7directorycontexts exact target/canonical/type/device/inode. Whole npm2993files/488directories/9links and Main28133/3025/100 were again enumerated with full memberships/types/physical bytes/modes/identity and match both objects; no semantic library audit inferred. Mainexactcleanb502 at check.

Candidate differs from actualauthor solely by statuscandidate, allowedModes['graph'], sortedoriginal153absences plus the four separately known npm ancestors, and provenance. All4new package.jsonabsences physically confirmed (including no danglinglinks): /usr/local/lib/node_modules, /usr/local/lib, /usr/local and /usr. These prevent closer ancestor metadata appearing; they do not fabricate package/native entries or alter115qualification. Originalauthor manifest is not falsely relabelled157. Provenance's originalmanifest path/SHA/length and all5namedreport/observation hashes exact; reviewed reasoning remains full-source physicalscope rather than12MBmetadata treated as Source audit.

## Exact permitted separate Root final copy

Preserve author and frozenreadycandidate untouched. One separate immutable copy may change only:

- `/status`: ROOT_READY_DERIVATION_CANDIDATE_NOT_ADMITTED → REVIEWED_FROZEN_READY.
- `/readyDerivationProvenance/status`: CANDIDATE_ONLY_INDEPENDENT_ACTUAL_MANIFEST_AND_READY_REVIEW_PENDING → INDEPENDENT_REVIEWED_GRAPH_DATA_ONLY.
- Add `/readyDerivationProvenance/independentReview` with this review.md's absolute path and actual fullSHA (adjacentpacket-hashes.json).

Every other logical value must equal frozen candidate exactly; allowedModes stays graphonly. Root must separately verify actualfinalcopy and separately admit exact controller/JSlaunch/currentenv. Existingoriginal npmconfig+fourliteralshglob observer, original returns/errors/UTF8vsouterrawstreams, physicalbefore/between/after and publicgraph/caller cold/repeat checks remain required; no actualcold/repeat success is preclaimed.

No finalcopy/seal/preparer/controller/import/JS/npm/native/consumer/graph execution or Mainwrite by this reviewer. Final acquisition is unacceptedanalysisDATA, not role/module/scalar/output/API/CI/producer/global/runtime/release grant. Historicalca11 and b502author preparation proofs remain bounded and unchanged. Detailed checks/provenance/transition in review.json; exact passiveverifier and hashes adjacent.
