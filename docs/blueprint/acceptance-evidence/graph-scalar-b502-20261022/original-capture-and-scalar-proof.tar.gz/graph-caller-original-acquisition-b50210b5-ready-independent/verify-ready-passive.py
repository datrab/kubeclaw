from pathlib import Path
import json,hashlib,os,stat,subprocess
s=Path('/home/node/.openclaw/workspace/tmp/pr13-finish-20261021');r=Path('/home/node/.openclaw/workspace/kubeclaw-pr13-recovery');p=s/'graph-caller-original-acquisition-b50210b5-successor-author';q=s/'graph-caller-original-acquisition-b50210b5-ready-candidate';d=s/'graph-caller-original-acquisition-b50210b5-ready-independent';d.mkdir(exist_ok=True);j=lambda f:json.loads(f.read_text());h=lambda x:hashlib.sha256(x).hexdigest();raw=(p/'manifest.author.json').read_bytes();a=json.loads(raw);rb=(q/'manifest.ready-candidate.json').read_bytes();b=json.loads(rb);old=j(s/'graph-caller-original-acquisition-ca11e55d-successor-author/manifest.author.json')
assert h(raw)=='1026f298d1b45735bb23f39076a777410d3d7cb4b920057d9e5693bf30591f44' and len(raw)==12433735;assert h(rb)=='7fc91312ab5043677745e5462890cdf03f3625784182edbc746043594cf84cf9'
def diff(x,y,path=''):
 if type(x)!=type(y):return [(path,x,y)]
 if isinstance(x,dict):
  assert x.keys()==y.keys();return [v for k in x for v in diff(x[k],y[k],path+'/'+k)]
 if isinstance(x,list):
  assert len(x)==len(y);return [v for i,(u,z) in enumerate(zip(x,y)) for v in diff(u,z,path+'/'+str(i))]
 return [] if x==y else [(path,x,y)]
deltas=diff(old,a);assert {x[0] for x in deltas}=={'/revision','/files/264/sha256','/files/264/bytes'};assert a['files'][264]['path']==str(r/'scripts/generate-buster-error-reference.mjs');assert a['files'][264]['sha256']=='11cf5c42d7b13565534eab04be11b9ed2f16bf8ee5ad6ba025850363f8ddd6d8';assert a['files'][264]['bytes']==96467
assert a['status']=='AUTHOR_PHYSICAL_GRAPH_CONTEXT_UNACCEPTED_NOT_SEALED' and a['allowedModes']==[]
for f in ['capture.py','capture.mjs','prepare-graph-roster.py']:
 assert (p/f).read_bytes()==(s/'graph-caller-original-acquisition-ca11e55d-successor-author'/f).read_bytes()
for name,k in [('capture.py','capturePySha256'),('capture.mjs','captureMjsSha256')]:assert h((p/name).read_bytes())==a[k]
run=s/'graph-caller-original-acquisition-b50210b5-preparer-run';l=j(run/'root-launch-admission.json');t=j(run/'root-actual-manifest-review.json');assert t['originalToolTerminal']['exitCode']==0
assert l['argv']==['/usr/bin/python3','-I','-S','-B',str(p/'prepare-graph-roster.py'),'--revision',a['revision'],'--root',str(r),'--output',str(p/'manifest.author.json')];assert l['cwd']==str(r) and l['environment']=={'PATH':'/usr/bin:/bin','HOME':'/home/node','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC'}
assert h((p/'prepare-graph-roster.py').read_bytes())==l['preparerSha256'];assert h((s/'graph-caller-original-acquisition-b50210b5-independent/review.md').read_bytes())==l['independentReviewSha256']
for f,x in t['streams'].items():z=(run/f).read_bytes();assert len(z)==x['bytes'] and h(z)==x['sha256']
assert (run/'stderr.bin').read_bytes()==b'';out=j(run/'stdout.bin');assert out['status']==a['status'] and out['revision']==a['revision'] and out['files']==433 and out['sourceRoleNames']==107 and out['rootHarnessClosureSources']==115 and out['eagerLocalSources']==12 and out['foundationFiles']==75 and not out['captureExecuted'] and not out['admission']
extra=['/usr/local/lib/node_modules/package.json','/usr/local/lib/package.json','/usr/local/package.json','/usr/package.json'];assert set(b)==set(a)|{'readyDerivationProvenance'}
assert b['status']=='ROOT_READY_DERIVATION_CANDIDATE_NOT_ADMITTED' and b['allowedModes']==['graph'];assert len(a['absent'])==153 and len(b['absent'])==157 and b['absent']==sorted(set(a['absent'])|set(extra))
for k in a:
 if k not in ['status','allowedModes','absent']:assert a[k]==b[k]
pr=b['readyDerivationProvenance'];assert pr['status']=='CANDIDATE_ONLY_INDEPENDENT_ACTUAL_MANIFEST_AND_READY_REVIEW_PENDING';assert pr['author']=='Root' and pr['extraPhysicalAbsences']==extra;assert pr['originalAuthorManifest']=={'path':str(p/'manifest.author.json'),'sha256':h(raw),'bytes':len(raw)}
for x in pr['namedProofs']:assert h(Path(x['path']).read_bytes())==x['sha256']
for x in b['files']:
 f=Path(x['path']);st=f.lstat();assert f.is_file() and not f.is_symlink() and str(f.resolve())==str(f);z=f.read_bytes();assert h(z)==x['sha256'] and len(z)==x['bytes'] and stat.S_IMODE(st.st_mode)==x['mode']
for f in b['absent']:assert not os.path.lexists(f)
for x in b['links']:f=Path(x['path']);assert f.is_symlink() and os.readlink(f)==x['target'] and str(f.resolve())==x['canonical']
for x in b['contextDirectories']:
 f=Path(x['path']);st=f.lstat();assert x['type']=='directory' and f.is_dir() and not f.is_symlink();assert str(f.resolve())==x['canonical'] and str(st.st_dev)==x['device'] and str(st.st_ino)==x['inode']
def snap(root):
 fs=[];ds=[];ls=[]
 for cur,sub,names in os.walk(root,followlinks=False):
  f=Path(cur);st=f.lstat();assert f.is_dir() and not f.is_symlink() and str(f.resolve())==cur;members=[]
  for name in sub+names:
   f=Path(cur)/name;stf=f.lstat()
   if f.is_symlink():kind='symlink';ls.append({'path':str(f),'target':os.readlink(f),'canonical':str(f.resolve())})
   elif f.is_file():kind='file';fs.append({'path':str(f),'sha256':h(f.read_bytes()),'mode':stat.S_IMODE(stf.st_mode)})
   else:assert f.is_dir();kind='directory'
   members.append({'name':name,'kind':kind})
  ds.append({'path':cur,'canonical':str(Path(cur).resolve()),'device':str(st.st_dev),'inode':str(st.st_ino),'members':sorted(members,key=lambda x:x['name'])})
 return {'root':root,'files':sorted(fs,key=lambda x:x['path']),'directories':sorted(ds,key=lambda x:x['path']),'links':sorted(ls,key=lambda x:x['path'])}
counts={}
for k in ['systemToolInstallation','installedCandidateNamespace']:
 actual=snap(b[k]['root']);assert actual==b[k];counts[k]={group:len(actual[group]) for group in ['files','directories','links']}
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==a['revision']=='b50210b5928b26d895bfe6fe2e3110d0da394341';assert not subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=r)
result={'status':'PASS_ACTUAL_MANIFEST_AND_FINITE_READY_DERIVATION_NOT_FINAL_SEAL_OR_LAUNCH','authorSha256':h(raw),'readyCandidateSha256':h(rb),'authorBytes':len(raw),'candidateBytes':len(rb),'exactAuthorDeltaFromCa11':deltas,'all433PhysicalBytesModesCurrent':True,'absences':157,'authorAbsencesPreserved':153,'extraAbsences':extra,'links':len(b['links']),'directories':len(b['contextDirectories']),'namespaces':counts,'rootCleanExact':a['revision'],'allOtherAuthorObjectsExact':True,'allProvenanceHashesExact':True,'actualPreparerTerminal':0}
(d/'passive-checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
