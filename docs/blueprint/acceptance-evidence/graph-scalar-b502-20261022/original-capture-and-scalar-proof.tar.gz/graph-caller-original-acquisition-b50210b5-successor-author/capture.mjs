// PREPARED NOT RUN. Import ORIGINAL reviewed modules only after fixed preflight.
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import childProcess from 'node:child_process';
import {syncBuiltinESMExports} from 'node:module';
import assert from 'node:assert/strict';
const argv=process.argv.slice(2),args={};
assert.equal(argv.length,12);for(let i=0;i<argv.length;i+=2){assert(['--root','--revision','--manifest','--manifest-sha256','--output','--mode'].includes(argv[i]));assert(!Object.hasOwn(args,argv[i]));args[argv[i]]=argv[i+1];}
// Six pairs are required (controller supplies exactly these); reject extras.
assert.equal(Object.keys(args).length,6);
const root=args['--root'],output=args['--output'],mode=args['--mode'];
assert.equal(mode,'graph');assert.equal(fs.realpathSync(root),root);
const manifestBytes=fs.readFileSync(args['--manifest']);assert.equal(createHash('sha256').update(manifestBytes).digest('hex'),args['--manifest-sha256']);const manifest=JSON.parse(manifestBytes);
assert.equal(manifest.status,'REVIEWED_FROZEN_READY');assert(manifest.allowedModes.includes(mode),'mode not independently approved');assert.equal(manifest.revision,args['--revision']);assert.equal(manifest.root,root);
fs.mkdirSync(output,{mode:0o700});
const hash=x=>createHash('sha256').update(x).digest('hex');
const write=(name,value)=>fs.writeFileSync(path.join(output,name),JSON.stringify(value,null,2)+'\n',{flag:'wx'});
function typedNamespaceSnapshot(tool){
 const files=[],directories=[],links=[];
 const order=(a,b)=>a.path<b.path?-1:a.path>b.path?1:0;
 function walk(directory){const st=fs.lstatSync(directory,{bigint:true});assert(st.isDirectory()&&!st.isSymbolicLink()&&fs.realpathSync(directory)===directory);const members=[];
  for(const name of fs.readdirSync(directory)){const file=path.join(directory,name),info=fs.lstatSync(file);let kind;
   if(info.isSymbolicLink()){kind='symlink';links.push({path:file,target:fs.readlinkSync(file),canonical:fs.realpathSync(file)});}
   else if(info.isFile()){kind='file';files.push({path:file,sha256:hash(fs.readFileSync(file)),mode:info.mode&0o7777});}
   else{assert(info.isDirectory(),file);kind='directory';walk(file);}members.push({name,kind});}
  directories.push({path:directory,canonical:fs.realpathSync(directory),device:st.dev.toString(),inode:st.ino.toString(),members:members.sort((a,b)=>a.name<b.name?-1:a.name>b.name?1:0)});
 }walk(tool.root);const actual={root:tool.root,files:files.sort(order),directories:directories.sort(order),links:links.sort(order)};assert.deepEqual(actual,tool,'SYSTEMTOOL complete typed namespace/context drift');return actual;
}
function physical(){
 const rows=manifest.files.map(item=>{const st=fs.lstatSync(item.path);assert(st.isFile()&&!st.isSymbolicLink()&&fs.realpathSync(item.path)===item.path,item.path);const sha256=hash(fs.readFileSync(item.path));assert.equal(sha256,item.sha256,item.path);assert.equal(st.mode&0o7777,item.mode,item.path);return {path:item.path,sha256};});
 for(const file of manifest.absent){try{fs.lstatSync(file);}catch(error){if(error.code==='ENOENT')continue;throw error;}assert.fail('absent path acquired: '+file);}
 const contextDirectories=manifest.contextDirectories.map(item=>{assert.equal(item.type,'directory','unknown directory context type');const st=fs.lstatSync(item.path,{bigint:true});assert(st.isDirectory()&&!st.isSymbolicLink(),item.path);const actual={path:item.path,type:'directory',canonical:fs.realpathSync(item.path),device:st.dev.toString(),inode:st.ino.toString()};for(const key of Object.keys(actual))assert.equal(actual[key],item[key],item.path+' '+key);return actual;});
 for(const link of manifest.links){assert(fs.lstatSync(link.path).isSymbolicLink());assert.equal(fs.readlinkSync(link.path),link.target);assert.equal(fs.realpathSync(link.path),link.canonical);}
 return {systemToolInstallation:typedNamespaceSnapshot(manifest.systemToolInstallation),installedCandidateNamespace:typedNamespaceSnapshot(manifest.installedCandidateNamespace),files:rows,contextDirectories,absent:manifest.absent,links:manifest.links};
}
const before=physical();write('initialization-context-before.json',before);
const environment=Object.fromEntries(Object.entries(process.env).sort(([a],[b])=>a.localeCompare(b)));
const expectedEnvironment={PATH:'/usr/local/go/bin:/usr/local/bin:/usr/bin:/bin',HOME:'/home/node',LANG:'C.UTF-8',LC_ALL:'C.UTF-8',TZ:'UTC',KUBECLAW_DOCS_GO_BINARY:'/usr/local/go/bin/go',TMPDIR:path.join(path.dirname(output),'tmp')};
if(mode==='graph')Object.assign(expectedEnvironment,{npm_config_cache:path.join(path.dirname(output),'npm-cache'),npm_config_update_notifier:'false',npm_config_logs_max:'0',npm_config_logs_dir:path.join(path.dirname(output),'npm-cache','_logs'),npm_config_timing:'false'});
assert.deepEqual(environment,Object.fromEntries(Object.entries(expectedEnvironment).sort(([a],[b])=>a.localeCompare(b))));
const originalSpawn=childProcess.spawnSync;let childIndex=0;const nativeFailures=[];
const patterns=['tests/verification/reliability/*.test.mts','tests/verification/reliability/*.test.mjs','tests/verification/historical-branch-acceptance/*.test.mjs','skills/prism/tests/*.native.mts'];
const summarizeError=e=>e?{name:e.name,message:e.message,code:e.code,errno:e.errno,syscall:e.syscall,path:e.path,spawnargs:e.spawnargs,stack:e.stack}:null;
function observeSpawn(command,words,options){
 const index=childIndex++;assert(index<128,'whole-process native-child ceiling');assert.equal(mode,'graph','facts capture must not launch native children');
 assert.equal(options?.cwd,root);assert.equal(options?.encoding,'utf8');assert.equal(options?.maxBuffer,1024*1024);
 const keys=Object.keys(options).sort();let kind;
 if(command==='/usr/local/bin/npm'){
  kind='npm-config';assert.deepEqual(keys,['cwd','encoding','env','maxBuffer']);assert.deepEqual(words.slice(0,2),['config','get']);assert.equal(words.length,3);assert(['script-shell','node-options'].includes(words[2]));assert.deepEqual(options.env,{...process.env,npm_config_offline:'true'});
 }else{
  kind='posix-glob';assert.equal(command,'/bin/sh');assert.deepEqual(keys,['cwd','encoding','maxBuffer']);assert.equal(words.length,2);assert.equal(words[0],'-c');assert(patterns.some(pattern=>words[1]===`set -- ${pattern}; printf '%s\\0' "$@"`));
 }
 const slot=`native-${String(index).padStart(3,'0')}`;fs.mkdirSync(path.join(output,slot));
 const put=(name,v)=>fs.writeFileSync(path.join(output,slot,name),JSON.stringify(v,null,2)+'\n',{flag:'wx'});
 put('launch.json',{index,kind,command,argv:words,options,environment:options.env??process.env,stdin:'ABSENT',start:new Date().toISOString()});
 try{
  const result=Reflect.apply(originalSpawn,childProcess,[command,words,options]);
  const strings={};for(const stream of ['stdout','stderr']){assert(typeof result[stream]==='string'||result[stream]===null);const value=result[stream];if(value!==null){const bytes=Buffer.from(value,'utf8');fs.writeFileSync(path.join(output,slot,`${stream}.returned-utf8`),bytes,{flag:'wx'});strings[stream]={representation:'ORIGINAL_SPAWNSYNC_UTF8_RETURN_NOT_RAW_PIPE',value,utf8Bytes:bytes.length,sha256:hash(bytes)};}else strings[stream]={representation:'NULL_UNAVAILABLE'};}
  put('terminal.json',{end:new Date().toISOString(),status:result.status,signal:result.signal,error:summarizeError(result.error),pid:result.pid,streams:strings});
  if(result.status!==0||result.signal||result.error||result.stdout===null||result.stderr===null)nativeFailures.push({index,status:result.status,signal:result.signal,error:summarizeError(result.error)});
  // Preserve original return unchanged, including failed terminal state. The
  // original guard owns rejection; the capture cannot convert it to success.
  return result;
 }catch(error){put('thrown.json',{end:new Date().toISOString(),error:summarizeError(error)});throw error;}
}
childProcess.spawnSync=observeSpawn;syncBuiltinESMExports();
try{
 const custody=await import(pathToFileURL(path.join(root,'scripts/docs-api-documentation-role-custody.mjs')).href);
 const discovery=await import(pathToFileURL(path.join(root,'scripts/docs-api-output-discovery.mjs')).href);
 const scalar=await import(pathToFileURL(path.join(root,'scripts/docs-deployment-scalar-occurrence-custody.mjs')).href);
 function consumedContexts(value){
  const sources=new Set();
  for(const source of [...value.graph.closureSources,...value.graph.dependencyPaths,...value.graph.installedFoundationDependencyPaths])sources.add(source);
  for(const row of value.callers)sources.add(row.path);
  return [...sources].sort().map(source=>{assert(!path.isAbsolute(source)&&!source.split('/').includes('..'),source);const file=path.join(root,source);try{const st=fs.lstatSync(file);if(st.isSymbolicLink())return {source,kind:'symlink-pointer',target:fs.readlinkSync(file),canonical:fs.realpathSync(file)};if(st.isDirectory())return {source,kind:'directory-context',canonical:fs.realpathSync(file),members:fs.readdirSync(file,{withFileTypes:true}).map(x=>({name:x.name,kind:x.isDirectory()?'directory':x.isFile()?'file':x.isSymbolicLink()?'symlink':'other'})).sort((a,b)=>a.name.localeCompare(b.name))};assert(st.isFile()&&fs.realpathSync(file)===file,source);return {source,kind:'regular-file',sha256:hash(fs.readFileSync(file)),observationTiming:'AFTER_FIRST_ACTUAL_SELECTOR_RESULT_BEFORE_REPEAT; not fabricated pre-read'};}catch(error){if(error.code==='ENOENT')return {source,status:'ABSENT'};throw error;}});
 }
 const first={graph:discovery.discoverScriptInputAcquisition(root),callers:scalar.deploymentScalarCallerFacts(root)};
 write('actual-graph-and-entries.json',first.graph);write('actual-scalar-caller-facts.json',first.callers);
 write('consumed-context-before-repeat.json',consumedContexts(first));
 const between=physical();assert.deepEqual(between,before);write('initialization-context-between.json',between);
 const second={graph:discovery.discoverScriptInputAcquisition(root),callers:scalar.deploymentScalarCallerFacts(root)};
 write('actual-selected-data-repeat.json',second);assert.deepEqual(second,first,'actual selected DATA changed at completion discovery');
 const consumedAfter=consumedContexts(second);assert.deepEqual(consumedAfter,JSON.parse(fs.readFileSync(path.join(output,'consumed-context-before-repeat.json'),'utf8')));write('consumed-context-after-repeat.json',consumedAfter);
 write('selector-and-discovery-closeout.json',{mode,firstSha256:hash(JSON.stringify(first)),secondSha256:hash(JSON.stringify(second)),equal:true});
 const after=physical();assert.deepEqual(after,before);assert(fs.readFileSync(args['--manifest']).equals(manifestBytes),'manifest changed');write('initialization-context-after.json',after);
 assert.equal(nativeFailures.length,0,'failed native child revokes whole capture even if original consumer did not reject');
 write('completion.json',{status:'DATA_CAPTURE_COMPLETE_UNACCEPTED',mode,revision:manifest.revision,nativeChildCount:childIndex,graphClosureSources:first.graph.closureSources.length,callerFacts:first.callers.length,limits:['No scalar constant renewed','No role/module/output/native-parser/public-consumer grant','UTF8 native return data is not raw OS pipes']});
}catch(error){write('failure.json',{error:summarizeError(error),completion:false});throw error;}
finally{childProcess.spawnSync=originalSpawn;syncBuiltinESMExports();}
