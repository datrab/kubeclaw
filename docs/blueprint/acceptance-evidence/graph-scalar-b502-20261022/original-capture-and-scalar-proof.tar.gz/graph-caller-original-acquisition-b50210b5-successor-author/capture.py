#!/usr/bin/env python3
"""PREPARED NOT RUN. Fixed read-only DATA controller; no automatic renewal."""
import argparse, hashlib, json, os, pathlib, signal, subprocess, time, sys

P=argparse.ArgumentParser()
P.add_argument('--root',required=True);P.add_argument('--revision',required=True)
P.add_argument('--manifest',required=True);P.add_argument('--manifest-sha256',required=True);P.add_argument('--output',required=True)
P.add_argument('--mode',choices=['graph'],required=True)
a=P.parse_args(); assert sys.flags.isolated and sys.flags.no_site,'launch controller with -I -S'; root=pathlib.Path(a.root); output=pathlib.Path(a.output)
assert root.is_absolute() and str(root.resolve())==str(root)
assert len(a.revision)==40 and all(c in '0123456789abcdef' for c in a.revision)
output.mkdir(mode=0o700,parents=False,exist_ok=False);(output/'tmp').mkdir()
env={'PATH':'/usr/local/go/bin:/usr/local/bin:/usr/bin:/bin','HOME':'/home/node','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC','KUBECLAW_DOCS_GO_BINARY':'/usr/local/go/bin/go','TMPDIR':str(output/'tmp')}
if a.mode=='graph':env.update({'npm_config_cache':str(output/'npm-cache'),'npm_config_update_notifier':'false','npm_config_logs_max':'0','npm_config_logs_dir':str(output/'npm-cache'/'_logs'),'npm_config_timing':'false'})
manifest_path=pathlib.Path(a.manifest).resolve();manifest_bytes=manifest_path.read_bytes();assert hashlib.sha256(manifest_bytes).hexdigest()==a.manifest_sha256;manifest=json.loads(manifest_bytes)
assert manifest['status']=='REVIEWED_FROZEN_READY' and manifest['revision']==a.revision
assert manifest['root']==str(root)
assert a.mode in manifest['allowedModes'],'mode has not been independently approved'
assert hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()==manifest['capturePySha256']
sha=lambda data:hashlib.sha256(data).hexdigest()
def put(name,value):
 p=output/name
 with p.open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def typed_namespace_snapshot(tool):
 files=[];directories=[];links=[]
 for current,subdirs,names in os.walk(tool['root'],followlinks=False):
  directory=pathlib.Path(current);st=directory.lstat();assert directory.is_dir() and not directory.is_symlink() and str(directory.resolve())==str(directory)
  members=[]
  for name in [*subdirs,*names]:
   file=directory/name;info=file.lstat()
   if file.is_symlink():
    kind='symlink';links.append({'path':str(file),'target':os.readlink(file),'canonical':str(file.resolve())})
   elif file.is_file():
    kind='file';files.append({'path':str(file),'sha256':sha(file.read_bytes()),'mode':info.st_mode&0o7777})
   else:assert file.is_dir(),str(file);kind='directory'
   members.append({'name':name,'kind':kind})
  directories.append({'path':str(directory),'canonical':str(directory.resolve()),'device':str(st.st_dev),'inode':str(st.st_ino),'members':sorted(members,key=lambda x:x['name'])})
 actual={'root':tool['root'],'files':sorted(files,key=lambda x:x['path']),'directories':sorted(directories,key=lambda x:x['path']),'links':sorted(links,key=lambda x:x['path'])}
 assert actual==tool,'SYSTEMTOOL complete typed namespace/context drift'
 return actual
def snapshot():
 observed=[]
 for item in manifest['files']:
  p=pathlib.Path(item['path']); st=p.lstat()
  assert p.is_file() and not p.is_symlink() and str(p.resolve())==str(p),str(p)
  data=p.read_bytes(); actual={'path':str(p),'sha256':sha(data),'bytes':len(data),'mode':st.st_mode & 0o7777}
  assert actual['sha256']==item['sha256'] and actual['mode']==item['mode'],str(p)
  observed.append(actual)
 for name in manifest['absent']:
  try:pathlib.Path(name).lstat()
  except FileNotFoundError:continue
  raise AssertionError('previously absent path now exists or is a dangling symlink: '+name)
 directories=[]
 for item in manifest['contextDirectories']:
  assert item['type']=='directory','unknown directory context type'
  directory=pathlib.Path(item['path']);st=directory.lstat();assert directory.is_dir() and not directory.is_symlink(),str(directory)
  actual={'path':str(directory),'type':'directory','canonical':str(directory.resolve()),'device':str(st.st_dev),'inode':str(st.st_ino)}
  assert all(actual[key]==item[key] for key in actual),str(directory)
  directories.append(actual)
 for item in manifest['links']:
  p=pathlib.Path(item['path']); assert p.is_symlink() and os.readlink(p)==item['target'] and str(p.resolve())==item['canonical'],str(p)
 tool=typed_namespace_snapshot(manifest['systemToolInstallation'])
 installed=typed_namespace_snapshot(manifest['installedCandidateNamespace'])
 return {'systemToolInstallation':tool,'installedCandidateNamespace':installed,'files':observed,'absent':manifest['absent'],'links':manifest['links'],'contextDirectories':directories}
# Raw outer streams go directly to files; poll size to enforce live bounds.
# A short polling overshoot is possible; preserve all obtained bytes and reject.
def launch(index,argv,timeout=120):
 slot=output/f'process-{index:02d}';slot.mkdir(); begin=time.time()
 launch={'argv':argv,'cwd':str(root),'environment':env,'stdinHex':'','startEpoch':begin}
 (slot/'launch.json').write_text(json.dumps(launch,indent=2)+'\n')
 with (slot/'stdout.bin').open('xb') as out,(slot/'stderr.bin').open('xb') as err:
  try:proc=subprocess.Popen(argv,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
  except BaseException as error:
   (slot/'terminal.json').write_text(json.dumps({'launchFailure':True,'type':type(error).__name__,'message':str(error),'endEpoch':time.time()},indent=2)+'\n');raise
  reason=None
  while proc.poll() is None:
   if time.time()-begin>timeout:reason='TIMEOUT'
   if out.tell()>64*1024*1024 or err.tell()>64*1024*1024:reason='STREAM_CEILING'
   if reason:
    os.killpg(proc.pid,signal.SIGKILL);break
   time.sleep(0.05)
  code=proc.wait()
 data={name:(slot/name).read_bytes() for name in ['stdout.bin','stderr.bin']}
 if any(len(value)>64*1024*1024 for value in data.values()):reason=reason or 'STREAM_CEILING_POST_CAPTURE'
 terminal={'returncode':code,'signal':-code if code<0 else None,'endEpoch':time.time(),'rejection':reason,'streams':{k:{'bytes':len(v),'sha256':sha(v)} for k,v in data.items()}}
 (slot/'terminal.json').write_text(json.dumps(terminal,indent=2)+'\n')
 assert reason is None and code==0,terminal
 return data['stdout.bin']
try:
 before=snapshot();put('context-before.json',before)
 assert launch(0,['/usr/bin/git','rev-parse','HEAD']).decode().strip()==a.revision
 assert launch(1,['/usr/bin/git','status','--porcelain=v1','--untracked-files=all'])==b'', 'owning root must be clean, including untracked files'
 script=pathlib.Path(__file__).with_name('capture.mjs').resolve()
 assert sha(script.read_bytes())==manifest['captureMjsSha256']
 argv=['/usr/local/bin/node',str(script),'--root',str(root),'--revision',a.revision,'--manifest',str(manifest_path),'--manifest-sha256',a.manifest_sha256,'--output',str(output/'node'),'--mode',a.mode]
 launch(2,argv)
 after=snapshot();put('context-after.json',after);assert before==after
 assert manifest_path.read_bytes()==manifest_bytes,'manifest changed during capture'
 assert launch(3,['/usr/bin/git','rev-parse','HEAD']).decode().strip()==a.revision
 assert launch(4,['/usr/bin/git','status','--porcelain=v1','--untracked-files=all'])==b''
 done=json.loads((output/'node'/'completion.json').read_text());assert done['status']=='DATA_CAPTURE_COMPLETE_UNACCEPTED'
 put('completion.json',{'status':'DATA_CAPTURE_COMPLETE_UNACCEPTED','mode':a.mode,'revision':a.revision,'manifestSha256':sha(manifest_path.read_bytes()),'nodeCompletionSha256':sha((output/'node'/'completion.json').read_bytes()),'limits':['No role/receipt automatically accepted or installed','No native/product/test/cluster execution acceptance']})
except BaseException as e:
 try:put('failure-context.json',snapshot())
 except BaseException as context_error:put('failure-context-unavailable.json',{'type':type(context_error).__name__,'message':str(context_error)})
 put('failure.json',{'type':type(e).__name__,'message':str(e),'completion':False});raise
