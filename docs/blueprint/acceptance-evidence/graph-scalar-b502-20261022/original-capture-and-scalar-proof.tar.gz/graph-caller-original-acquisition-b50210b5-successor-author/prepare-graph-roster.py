"""PREPARED NOT RUN. Read-only Source/context preparation, never DATA admission.
Root supplies the eventual clean integrated revision explicitly. No JS/npm import.
"""
from pathlib import Path
import argparse, hashlib, json, os, subprocess
P=argparse.ArgumentParser();P.add_argument('--root',required=True);P.add_argument('--revision',required=True);P.add_argument('--output',required=True);a=P.parse_args()
root=Path(a.root);out=Path(__file__).resolve().parent
assert root.is_absolute() and str(root.resolve())==str(root)
assert len(a.revision)==40 and all(c in '0123456789abcdef' for c in a.revision)
# Original read-only Git identity, not a home-grown HEAD parser. No npm or JS.
observed=subprocess.run(['/usr/bin/git','-C',str(root),'rev-parse','HEAD'],check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,encoding='utf8',env={'PATH':'/usr/bin:/bin','HOME':'/home/node','LANG':'C.UTF-8','LC_ALL':'C.UTF-8'})
assert observed.stdout.strip()==a.revision,'explicit reviewed revision is not current HEAD'
prior=json.loads((out/'prior-eager-context.json').read_text());expected=json.loads((out/'expected-recipe-universe.json').read_text())
reviewed=json.loads((out/'reviewed-current-physical-files.json').read_text());assert a.revision==reviewed['revision']
installed=json.loads((out/'installed-candidate-namespace.json').read_text())['namespace']
assert str(root)==prior['root'],'exact original root context only'
sha=lambda data:hashlib.sha256(data).hexdigest()
custody=(root/'scripts/docs-api-documentation-role-custody.mjs').read_text()
assert sha(custody.encode())==expected['approvedCandidateSha256'],'reviewed 107-role successor has not been installed exactly; STOP'
def literal(text,marker):
 start=text.index(marker)+len(marker);return json.JSONDecoder().raw_decode(text[start:])[0]
recipes=literal(custody,'export const documentationExecutableRoleRecipes = ');harness=literal(custody,'export const reviewedRootNodeEntryRecipes = ')
assert list(recipes)==expected['sourceRoleNames'],'exact reviewed Source recipe universe, not count-based coverage'
local=[*prior['graphEagerLocalSources'],'scripts/docs-documentation-owner-purpose-custody.mjs']
assert len(set(local))==len(local),'duplicate eager local Source'
files={root/source for source in local};missing_declared=[]
for source,recipe in recipes.items():
 files.add(root/source)
 for item in [*recipe.get('authorityInputs',[]),*recipe.get('purposeInputs',[])]:
  selected=root/item['path']
  if selected.is_file():files.add(selected)
  else:missing_declared.append(str(selected))
for receipt in harness['closure']:files.add(root/receipt['source'])
# Keep exactly the prior reviewed75physical TS/YAML implementation/package
# context, not a new resolver or inferred eager selector. Original Node resolves.
foundations=[row for row in prior['files'] if any('/node_modules/'+package+'/' in row['path'] for package in ['typescript','yaml'])]
for row in foundations:
 selected=Path(row['path']);assert selected.is_file() and not selected.is_symlink() and str(selected.resolve())==str(selected)
 assert sha(selected.read_bytes())==row['sha256'],'installed TS/YAML context drift; new review required'
 files.add(selected)
# Include the actual twelfth eager guard and all CURRENT14physical CI purpose
# inputs from its Source-owned declaration, not a stale guessed package/page pin.
owner=(root/'scripts/docs-documentation-owner-purpose-custody.mjs').read_text()
ci_profile=literal(owner,'const readerArtifactCiPurpose=freeze(')
for item in ci_profile['inputs']:
 selected=root/item['path'];assert selected.is_file() and not selected.is_symlink() and str(selected.resolve())==str(selected)
 assert item['canonical']==item['path'] and sha(selected.read_bytes())==item['sha256'],'current CI purpose input drift'
 files.add(selected)
files.update(root/name for name in ['package.json','package-lock.json','scripts/docs-api-producer-adapter-authorities.json'])
absent=set(missing_declared);links=[];contexts=[]
def member(p):
 try:st=p.lstat()
 except FileNotFoundError:absent.add(str(p));return
 if p.is_symlink():links.append({'path':str(p),'target':os.readlink(p),'canonical':str(p.resolve())});return
 if p.is_file():files.add(p)
 else:
  assert p.is_dir(),str(p)
  contexts.append({'path':str(p),'type':'directory','canonical':str(p.resolve()),'device':str(st.st_dev),'inode':str(st.st_ino),'purpose':'original package-search candidate context only; never loaded-code authority'})
# Config absences are not silently reinterpreted as fresh authority if a config
# appears. Independent original config-selection review must precede that change.
for item in prior['configCandidates']:
 assert item['kind']=='absent','unexpected original config contract'
 try:Path(item['path']).lstat()
 except FileNotFoundError:absent.add(item['path']);continue
 raise AssertionError('previous config absence changed; STOP before reading configuration: '+item['path'])
for parent in sorted({p.parent for p in files if p.suffix in ['.mjs','.js']}):
 current=parent
 while True:
  member(current/'package.json')
  if current.name!='node_modules':
   member(current/'node_modules')
   for package in ['typescript','yaml']:member(current/'node_modules'/package)
  if current.parent==current:break
  current=current.parent
for name in ['/usr/local/bin/node','/usr/bin/python3','/usr/bin/git','/bin/sh','/usr/local/bin/npm','/usr/local/lib/node_modules/npm/bin/npm-cli.js','/usr/local/lib/node_modules/npm/package.json']:
 selected=Path(name);member(selected)
 if selected.is_symlink():files.add(selected.resolve())
# The whole installed npm namespace is retained exactly. This is a physical
# comparison to prior reviewed context, not approval of2993module meanings.
tool_json=json.loads((out/'npm-installed-context.author.json').read_text())
tool=prior['systemToolInstallation']
# Raw author context has no directory members and has descriptive link labels.
# Compare exact path identities/physical fields first; never call raw==normalized.
assert set(tool_json)=={'status','root','files','directories','links','limits'}
assert isinstance(tool_json['status'],str) and isinstance(tool_json['limits'],list) and all(isinstance(item,str) for item in tool_json['limits'])
assert tool_json['root']==tool['root']
def indexed_physical(rows,physical,descriptive=()):
 indexed={}
 for row in rows:
  assert set(row)==set(physical)|set(descriptive),'unexpected raw/normalized context fields'
  for field in descriptive:assert isinstance(row[field],str),'descriptive context must remain text'
  assert row['path'] not in indexed,'duplicate physical context path'
  indexed[row['path']]={field:row[field] for field in physical}
 return indexed
for group,physical in [('files',('path','sha256','mode')),('directories',('path','canonical','device','inode')),('links',('path','target','canonical'))]:
 raw=indexed_physical(tool_json[group],physical,('classification',) if group=='links' else ())
 if group=='directories':
  # Members are deliberately absent in raw; retain them exclusively in the
  # original normalized namespace for the full live re-enumeration below.
  assert all(set(row)==set(physical)|{'members'} and isinstance(row['members'],list) for row in tool[group])
  normalized=indexed_physical([{field:row[field] for field in physical} for row in tool[group]],physical)
 else:normalized=indexed_physical(tool[group],physical)
 assert raw==normalized,'raw author physical context differs from prior typed namespace: '+group
observed_files=[];observed_directories=[];observed_links=[]
for current,subdirs,names in os.walk(tool['root'],followlinks=False):
 directory=Path(current);st=directory.lstat();assert directory.is_dir() and not directory.is_symlink() and str(directory.resolve())==str(directory)
 members=[]
 for name in [*subdirs,*names]:
  selected=directory/name;info=selected.lstat()
  if selected.is_symlink():kind='symlink';observed_links.append({'path':str(selected),'target':os.readlink(selected),'canonical':str(selected.resolve())})
  elif selected.is_file():kind='file';observed_files.append({'path':str(selected),'sha256':sha(selected.read_bytes()),'mode':info.st_mode&0o7777})
  else:assert selected.is_dir(),str(selected);kind='directory'
  members.append({'name':name,'kind':kind})
 observed_directories.append({'path':str(directory),'canonical':str(directory.resolve()),'device':str(st.st_dev),'inode':str(st.st_ino),'members':sorted(members,key=lambda row:row['name'])})
actual={'root':tool['root'],'files':sorted(observed_files,key=lambda row:row['path']),'directories':sorted(observed_directories,key=lambda row:row['path']),'links':sorted(observed_links,key=lambda row:row['path'])}
assert actual==tool,'installed npm whole typed namespace changed; STOP'
observed_files=[];observed_directories=[];observed_links=[]
for current,subdirs,names in os.walk(installed['root'],followlinks=False):
 directory=Path(current);st=directory.lstat();assert directory.is_dir() and not directory.is_symlink() and str(directory.resolve())==str(directory)
 members=[]
 for name in [*subdirs,*names]:
  selected=directory/name;info=selected.lstat()
  if selected.is_symlink():kind='symlink';observed_links.append({'path':str(selected),'target':os.readlink(selected),'canonical':str(selected.resolve())})
  elif selected.is_file():kind='file';observed_files.append({'path':str(selected),'sha256':sha(selected.read_bytes()),'mode':info.st_mode&0o7777})
  else:assert selected.is_dir(),str(selected);kind='directory'
  members.append({'name':name,'kind':kind})
 observed_directories.append({'path':str(directory),'canonical':str(directory.resolve()),'device':str(st.st_dev),'inode':str(st.st_ino),'members':sorted(members,key=lambda row:row['name'])})
actual={'root':installed['root'],'files':sorted(observed_files,key=lambda row:row['path']),'directories':sorted(observed_directories,key=lambda row:row['path']),'links':sorted(observed_links,key=lambda row:row['path'])}
assert actual==installed,'Main installed whole typed namespace changed; STOP'
assert {str(selected) for selected in files}==set(reviewed['files']),'reviewed finite file set changed'
rows=[]
for selected in sorted(files):
 st=selected.lstat();assert selected.is_file() and not selected.is_symlink() and str(selected.resolve())==str(selected),str(selected)
 data=selected.read_bytes();assert str(selected) in reviewed['files'],'unreviewed preparation file'
 assert sha(data)==reviewed['files'][str(selected)]['sha256'] and st.st_mode&0o7777==reviewed['files'][str(selected)]['mode'],'reviewed Source/context drift'
 rows.append({'path':str(selected),'sha256':sha(data),'bytes':len(data),'mode':st.st_mode&0o7777})
value={'status':'AUTHOR_PHYSICAL_GRAPH_CONTEXT_UNACCEPTED_NOT_SEALED','allowedModes':[],'allowedModesProposed':['graph'],'revision':a.revision,'root':str(root),'graphEagerLocalSources':local,'sourceRoleNames':list(recipes),'installedCandidateNamespace':installed,'currentExternalCiPurpose':ci_profile,'systemToolInstallation':tool,'configCandidates':prior['configCandidates'],'eagerInstalledPackages':prior['eagerInstalledPackages'],'typescriptEntry':prior['typescriptEntry'],'captureMjsSha256':sha((out/'capture.mjs').read_bytes()),'capturePySha256':sha((out/'capture.py').read_bytes()),'files':rows,'absent':sorted(absent),'links':sorted({row['path']:row for row in links}.values(),key=lambda row:row['path']),'contextDirectories':sorted({row['path']:row for row in contexts}.values(),key=lambda row:row['path']),'yamlLiteralRequireEdges':prior['yamlLiteralRequireEdges'],'yamlUnresolvedNonrelative':prior['yamlUnresolvedNonrelative'],'bootstrapReviewRequired':['Explicit final integrated Source revision is mandatory; no old hardcoded revision selected.','Independent complete actual local12eager initializers and original TS/YAML/npm/tool/ancestor/config/absence/context and launch environment review before Root may separately seal.','Original graph-only hook runs its actual raw graph guards; separate module-input/consumer/role/native/CI/producer/generator guards are NOT granted.','Old115root entry closure has no automatic authority for newly reached helper; current original graph may STOP.','No boundary proposal projection; seven seeds already installed. Original graph + original caller facts only; no scalar hash-renewal or consumer grant.']}
output=Path(a.output);assert output.is_absolute() and output.parent.resolve()==out,'write only one new manifest in this isolated packet'
with output.open('x') as stream:json.dump(value,stream,indent=2);stream.write('\n')
print(json.dumps({'status':value['status'],'sourceRoleNames':len(recipes),'rootHarnessClosureSources':len(harness['closure']),'eagerLocalSources':len(local),'foundationFiles':len(foundations),'files':len(rows),'revision':a.revision,'captureExecuted':False,'admission':False}))
