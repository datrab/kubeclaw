from pathlib import Path
import json,hashlib,os,stat,subprocess,collections
s=Path('/home/node/.openclaw/workspace/tmp/pr13-finish-20261021');r=Path('/home/node/.openclaw/workspace/kubeclaw-pr13-recovery');p=s/'graph-caller-original-b50210b5';packet=s/'graph-caller-original-acquisition-b50210b5-successor-author';seal=s/'graph-caller-original-acquisition-b50210b5-final-seal';d=s/'graph-caller-original-b50210b5-result-independent';d.mkdir(exist_ok=True);j=lambda f:json.loads(f.read_text());h=lambda x:hashlib.sha256(x).hexdigest();ad=j(seal/'root-copy-check-and-launch-admission.json');mf=Path(ad['sealedManifest']['path']);mb=mf.read_bytes();m=json.loads(mb);candidate=j(s/'graph-caller-original-acquisition-b50210b5-ready-candidate/manifest.ready-candidate.json')
assert h(mb)==ad['sealedManifest']['sha256']=='5f51c6938cd71f41be5e9f2db2d6faa30e4c8fc9b4391ec9202e0f3c2162c960' and len(mb)==12436843 and stat.S_IMODE(mf.stat().st_mode)==0o444
check=json.loads(mb);assert check['status']=='REVIEWED_FROZEN_READY';check['status']=candidate['status'];pr=check['readyDerivationProvenance'];assert pr['status']=='INDEPENDENT_REVIEWED_GRAPH_DATA_ONLY';pr['status']=candidate['readyDerivationProvenance']['status'];ind=pr.pop('independentReview');assert ind==ad['independentReview'];assert h(Path(ind['path']).read_bytes())==ind['sha256']=='c669d7beeb54efdace0814d4d9e591f0bd2057ec996ad46d4087e6563921468b';assert check==candidate
for f,key in [('capture.py','capturePySha256'),('capture.mjs','captureMjsSha256')]:assert h((packet/f).read_bytes())==m[key]
env={'PATH':'/usr/local/go/bin:/usr/local/bin:/usr/bin:/bin','HOME':'/home/node','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC','KUBECLAW_DOCS_GO_BINARY':'/usr/local/go/bin/go','TMPDIR':str(p/'tmp'),'npm_config_cache':str(p/'npm-cache'),'npm_config_update_notifier':'false','npm_config_logs_max':'0','npm_config_logs_dir':str(p/'npm-cache/_logs'),'npm_config_timing':'false'}
expectedArgs=[['/usr/bin/git','rev-parse','HEAD'],['/usr/bin/git','status','--porcelain=v1','--untracked-files=all'],['/usr/local/bin/node',str(packet/'capture.mjs'),'--root',str(r),'--revision',m['revision'],'--manifest',str(mf),'--manifest-sha256',h(mb),'--output',str(p/'node'),'--mode','graph'],['/usr/bin/git','rev-parse','HEAD'],['/usr/bin/git','status','--porcelain=v1','--untracked-files=all']]
outer=[]
for i,args in enumerate(expectedArgs):
 q=p/f'process-{i:02d}';l=j(q/'launch.json');t=j(q/'terminal.json');assert l['argv']==args and l['cwd']==str(r) and l['environment']==env and l['stdinHex']=='';assert t['returncode']==0 and t['signal'] is None and t['rejection'] is None and t['endEpoch']>=l['startEpoch']
 for name,x in t['streams'].items():data=(q/name).read_bytes();assert h(data)==x['sha256'] and len(data)==x['bytes']
 assert (q/'stderr.bin').read_bytes()==b''
 if i in [0,3]:assert (q/'stdout.bin').read_text().strip()==m['revision']
 else:assert (q/'stdout.bin').read_bytes()==b''
 outer.append({'index':i,'argv':args,'exitCode':0,'streams':t['streams']})
assert j(p/'context-before.json')==j(p/'context-after.json');oc=j(p/'context-before.json');ic=j(p/'node/initialization-context-before.json');assert ic==j(p/'node/initialization-context-between.json')==j(p/'node/initialization-context-after.json')
for k in ['systemToolInstallation','installedCandidateNamespace','absent','links']:assert oc[k]==ic[k]==m[k]
assert oc['files']==m['files'];assert ic['files']==[{'path':x['path'],'sha256':x['sha256']} for x in m['files']]
expectedDirs=[{k:v for k,v in x.items() if k!='purpose'} for x in m['contextDirectories']];assert oc['contextDirectories']==ic['contextDirectories']==expectedDirs
for x in m['files']:
 f=Path(x['path']);z=f.read_bytes();st=f.lstat();assert f.is_file() and not f.is_symlink() and str(f.resolve())==str(f) and len(z)==x['bytes'] and h(z)==x['sha256'] and stat.S_IMODE(st.st_mode)==x['mode']
for x in m['absent']:assert not os.path.lexists(x)
for x in m['links']:f=Path(x['path']);assert f.is_symlink() and os.readlink(f)==x['target'] and str(f.resolve())==x['canonical']
for x in expectedDirs:
 f=Path(x['path']);st=f.lstat();assert f.is_dir() and not f.is_symlink() and str(f.resolve())==x['canonical'] and str(st.st_dev)==x['device'] and str(st.st_ino)==x['inode']
# Every original native observation, no transformed re-execution.
nativeDirs=sorted((p/'node').glob('native-*'));assert len(nativeDirs)==104;patterns=['tests/verification/reliability/*.test.mts','tests/verification/reliability/*.test.mjs','tests/verification/historical-branch-acceptance/*.test.mjs','skills/prism/tests/*.native.mts'];kinds=collections.Counter();inner=[]
for i,q in enumerate(nativeDirs):
 l=j(q/'launch.json');t=j(q/'terminal.json');assert l['index']==i and t['status']==0 and t['signal'] is None and t['error'] is None;assert l['stdin']=='ABSENT';opts=l['options'];assert opts['cwd']==str(r) and opts['encoding']=='utf8' and opts['maxBuffer']==1048576
 if l['kind']=='npm-config':
  assert l['command']=='/usr/local/bin/npm' and l['argv'] in [['config','get','script-shell'],['config','get','node-options']];assert opts=={'cwd':str(r),'encoding':'utf8','maxBuffer':1048576,'env':dict(env,npm_config_offline='true')};assert l['environment']==opts['env']
 else:
  assert l['kind']=='posix-glob' and l['command']=='/bin/sh';assert l['argv'][0]=='-c' and len(l['argv'])==2 and any(l['argv'][1]==f'set -- {x}; printf \'%s\\0\' "$@"' for x in patterns);assert opts=={'cwd':str(r),'encoding':'utf8','maxBuffer':1048576} and l['environment']==env
 for name,x in t['streams'].items():
  assert x['representation']=='ORIGINAL_SPAWNSYNC_UTF8_RETURN_NOT_RAW_PIPE';data=(q/(name+'.returned-utf8')).read_bytes();assert data==x['value'].encode('utf8') and len(data)==x['utf8Bytes'] and h(data)==x['sha256']
 kinds[l['kind']]+=1;inner.append({'index':i,'kind':l['kind'],'command':l['command'],'argv':l['argv'],'status':0,'returnedUtf8':t['streams']})
gf=p/'node/actual-graph-and-entries.json';cf=p/'node/actual-scalar-caller-facts.json';g=j(gf);c=j(cf);repeat=j(p/'node/actual-selected-data-repeat.json');assert repeat=={'graph':g,'callers':c};assert h(gf.read_bytes())=='40381a920f5081315e15e05de659333e714b86ba6c41ca87918b6a05d9c14ead';assert h(cf.read_bytes())=='cc205aab98418bf750752fbef13b6862525af41e2c80a5ee946e87cff6b739b1';assert g['status']=='UNACCEPTED_DATA'
compact=lambda x:json.dumps(x,ensure_ascii=False,separators=(',',':')).encode();close=j(p/'node/selector-and-discovery-closeout.json');assert h(compact({'graph':g,'callers':c}))==close['firstSha256']==close['secondSha256'] and close['equal'] is True
ctx=j(p/'node/consumed-context-before-repeat.json');assert ctx==j(p/'node/consumed-context-after-repeat.json');selected=set(g['closureSources']+g['dependencyPaths']+g['installedFoundationDependencyPaths']+[x['path'] for x in c]);assert [x['source'] for x in ctx]==sorted(selected)
ctxKinds=collections.Counter()
for x in ctx:
 f=r/x['source'];ctxKinds[x.get('kind',x.get('status'))]+=1
 if x.get('status')=='ABSENT':assert not os.path.lexists(f)
 elif x['kind']=='regular-file':assert f.is_file() and not f.is_symlink() and str(f.resolve())==str(f);assert h(f.read_bytes())==x['sha256'];assert x['observationTiming']=='AFTER_FIRST_ACTUAL_SELECTOR_RESULT_BEFORE_REPEAT; not fabricated pre-read'
 elif x['kind']=='symlink-pointer':assert f.is_symlink() and os.readlink(f)==x['target'] and str(f.resolve())==x['canonical']
 else:
  assert x['kind']=='directory-context' and f.is_dir() and not f.is_symlink() and str(f.resolve())==x['canonical'];actual={v.name:'symlink' if v.is_symlink() else 'directory' if v.is_dir() else 'file' if v.is_file() else 'other' for v in f.iterdir()};assert actual=={v['name']:v['kind'] for v in x['members']} and len(actual)==len(x['members'])
node=j(p/'node/completion.json');done=j(p/'completion.json');assert node['status']==done['status']=='DATA_CAPTURE_COMPLETE_UNACCEPTED';assert node['revision']==done['revision']==m['revision'];assert node['nativeChildCount']==104 and node['graphClosureSources']==len(g['closureSources']) and node['callerFacts']==len(c);assert h((p/'node/completion.json').read_bytes())==done['nodeCompletionSha256'] and done['manifestSha256']==h(mb);assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip()==m['revision'] and not subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=r)
result={'status':'PASS_BOUNDED_ACTUAL_ORIGINAL_GRAPH_CALLER_DATA_RESULT_ONLY','sealedManifestSha256':h(mb),'exactFinalAllowedTransitions':True,'outer':outer,'innerNativeCount':104,'innerKinds':dict(kinds),'innerAllTerminal0ReturnedUtf8Verified':True,'originalGraphFileSha256':h(gf.read_bytes()),'originalCallerFileSha256':h(cf.read_bytes()),'coldRepeatWholeObjectsAndOriginalArrayOrderExact':True,'physicalBeforeBetweenAfterExact':True,'source433CurrentExact':True,'consumedContexts':len(ctx),'consumedContextKinds':dict(ctxKinds),'graphCounts':{k:len(g[k]) for k in ['closureSources','executableSources','edges','aliases','publicEntries','dynamicOperations','resolutionOnlyOperations','dependencyPaths','installedFoundationDependencyPaths','documentationEntries','packageEntries']},'callerFacts':len(c),'currentHeadCleanExact':m['revision']}
(d/'passive-checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
