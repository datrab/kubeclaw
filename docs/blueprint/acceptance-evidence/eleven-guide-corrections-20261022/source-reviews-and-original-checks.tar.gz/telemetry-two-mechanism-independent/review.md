# Independent Telemetry two-mechanism correction

**PASS — Source / semantic Reader / Quality, exactly the two corrected mechanisms.** Candidate telemetry `0c5173ccac50a1d2ca017fa714d281ee8a38ecb76e41f24dfe2be8c654ee8461`; Redis recovery `680069e29d5e690d5f329dc92916416227ae00ba466ac3c9e8d5e1e68134870c`.

Read complete additions/changed box and coherent owning projection/redaction/store/Redis recovery context. Exact prior full5package family Source proof retained only for unchanged responsibilities; freshly reread complete projection94/observer30/store40/streamidentity8/README30 and independently verified every authored whole-object pin against current bytes.

Actual telemetry-envelope fields and intentional omissions match observer; observer provenance and SDK-redacted identity/payload remain distinct from event/schema/producer/canonical journal. Sink admits whole plain JSON input before redaction: genuine root/prototype/dense-array/descriptor/proxy/cycle/Unicode/numeric/domain/depth/node/UTF8byte limits and repeated noncyclic occurrence behavior are faithful. Separate final durable payload bound is not a guarantee that every pre-snapshot admission appends. Awaited sink failure is not success.

Legacy underscore mapping example is genuinely noninjective. Paused writers, original pending-delivery reconciliation/retained records and coordinated external consumer cutover remain required. No supplied rename/copy/republish/trim/delete/consumer migration or automatic command is invented; no change to MAXLEN/dedupTTL or separate host-observer path. Missing consumer inventory remains STOP, not a healthy-newstream success.

Existing Sourcebox retains all six meaningful fields and exact read-not-run assertions; no new Sourcebox/count or execution claim. No further material finding in this two-mechanism union. The newly discovered separate source-hook queue/status lifecycle is explicitly outside these two fixes. Main/role/graph/runtime/product/live and whole A910 gate acceptance remain untouched; Root owns actual integration/Reader checks.
