# Independent supervised operator mechanism — final v2

**PASS — Source / semantic Reader / Quality, exactly REVIEW-SUPERVISED-OPERATOR-PATH.** Final candidate317decfc8b053c3aa69bfb57bc4c53f4d22643c180400f82b8007652b51171ad. Originalv142ccac and initialreview remain preserved. Exact two-clause successor now correctly distinguishes flock acquisition timeout from holding duration and lease semantic validation from heartbeatJSON-only parsing. No other prose/link/Source changed; Root5fbac two earlier corrections remain exact and separately accepted, not recounted.

Read complete237line new mechanism, complete4original operator scripts256/184/105/192 and state63/heartbeat71/runroot65, actualFileMutex24 plus owning state/status/stop assertions and relevant actualpackage/CLIreceivers. Supported command/requiredflags/path/prerequisite/controller/environment inheritance are usable and accurate, with realmodelcost/credentials/service access not implied from static status. Same-run recover and retained artifact authority are not new review acceptance.

Exclusive stableinode/instance-bound lease, confirmedprocfs PID adoption/refusal, detached ownedchild signal/exit, serializedheartbeat/finaldiagnostic, terminal0/1/nonterminal75/stop130 and recoverydelay semantics match actualSource. Crucial constraints are explicit: noSIGKILL-escalation promise; adoptedpipeline not signalled; processstop not externalmodeltermination; malformedinputs/status/storage errors not success.

Status/read-onlyformatter remain bounded observations (1MiBevents/8MiBresources, compactreferencedartifacts, activeTTLlocks, tailcheckpointcounts/freshness), not hash-verified fullreplay, coverage or tokenbilling authority. CurrentCPU/tailpeak/cgroup-lifetimepeak, configuredconcurrency label, unscheduledcadence text and read-onlyreopenmetadata are distinguished.

Optional capacitypreflight really starts retainedmodelchildren; modes/defaults/pacing/admission/completion/deadline and opt-in synchronouswrapper semantics match. PromptPREFLIGHT_OK is not falsely validated. Rejected/failed/timeout cleanup attempts and missingID/listfailure do not prove terminalcleanup; actualownerreconciliation remains required before replay. No oldREADME guarantee of noactivechildren copied unchecked.

All18newSourceURL occurrences (17distinctranges over11wholeobjects) independently verified against immutable569f7/currentbytes/ranges; rootpackage actualcurrent4script mappings read separately, not falselyhistoricallypinned. Three meaningful6fieldboxes preserve read-not-run assertions/limits; operatorownedcontrols and journal/artifact/log/lease/lock remainingdata are explicit. No material finding remains in this new mechanism.

Root owns coherentintegration/actualproductionparser/style/freshReader. No reviewerMainwrite/register/role/graph/native/model/Gateway/product/preflight/test/Readerexecution; no whole51/fourA910gates/count/runtime/releaseapproval.
