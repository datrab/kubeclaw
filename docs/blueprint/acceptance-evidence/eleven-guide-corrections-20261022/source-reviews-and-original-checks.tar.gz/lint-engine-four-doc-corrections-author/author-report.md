# Four lint documentation corrections — frozen author packet

Status: AUTHOR_ONLY_UNACCEPTED. Custody/parent independent review required. No gate, runtime or whole51-family acceptance.

## Scope

Three candidates only: docs/site/reference/lint-rules.md; docs/site/reference/lint-policy.md; docs/site/extend/lint.md. The fourth union member, generated lint facts, needs no change and remains untouched. Baseline b50210b5928b26d895bfe6fe2e3110d0da394341, with exact per-page baseline/candidate hashes in candidate-hashes.json. No Main, registry, Source code, fact hash or generator changes. No product imports, CLI/native/test executions or publication/Reader observations.

The original complete independent lint review and its provisional-order withdrawal remain unchanged in ../lint-engine-31-independent/. Original review SHA d85be8e6d5c615d90bdd04854bde91b037c6f401d9f8740eec134bed5b416208. This authoring does not accept its own corrections or recount other completed scopes. The original Source read roster and four coherent findings supply the bounded purpose/caller/consumer basis; additional exact source ranges were reread for the public safe-action wording, not requalified as new runtime proof.

## Exact correction map

- F1: required-runtime-env row now distinguishes declared env names/resolved optional envFrom keys from absent sources; action no longer falsely requires a nonoptional source. A six-field callout binds name collection, separate missing-reference rule and exact default setting. Limit: static names are not live values. No dedicated optional-resolved-required-name execution/assertion is invented.
- F2: literal evidence uses direct existence, while '*' evidence uses the filtered depth-limited candidate scan. A six-field callout binds detector and admitted evidence vocabulary; repository/native authority remains separate. Test status is Source-read assertions, with the precise literal-excluded/depth test gap disclosed.
- F3: mypy row now distinguishes empty successful output, nonzero empty output and malformed JSON lines. Its six-field callout states no dedicated owning mypy case identified, and no execution; Python remains dormant in the canonical workspace.
- F4: replace the unconditional malformed-output guarantee with the actual syntax-vs-shape boundary, qualify the policy guide's broad failure sentence, and add one substantive extension-guide subsection. It traces conditional normalization → ok report/summary → lost raw-exit distinction → possible passed stage only when all other checks succeed. It explicitly denies native observation and any assertion that pinned binaries emit the counterexample normally. Existing reports/logs can support diagnosis but do not automatically contain complete raw native streams/status. Safe action is retain evidence, inspect actual selected revision/executable-version/config/scope and stop uncertain acceptance; no invented CLI or raw-capture facility. Lint owner and closure conditions require product shape/exit-result validation, relevant actual tests and independent Source review, not a documentation waiver. A six-field callout binds the normalizer/helper/common process guard/report-summary/stage/owning process assertions. Header adds only the newly cited exact SDK values file.

No optional registry-order wording change: the original report explicitly withdrew it as material, because the constructed registry truthfully follows policy.tools order. No other rows, lifecycle procedures, claims, headings, pins, historical executions or the separate Delivery Lint section changed. The new subsection heading is additive. Full exact replacements, rather than a broad rewrite, are in change-mapping.json and candidate.patch.

## Source and quality proof

All new links use the existing allowed immutable 569f7b4933d4859cc67c80ddf40d5154ffd95ce5 revision. Whole linked source bytes equal current Main, not just excerpts. New explicit ranges each span at most60 lines. All original URLs remain, existing evidence revisions remain, all unchanged paragraphs remain byte-identical via exact replacement authoring. candidate.patch is the complete three-page delta; baseline/ retains exact original pages.

static-checks.json records inert filesystem/JSON/quoted-line/Git-object checks: Main baseline unchanged; generated facts unchanged; original URLs preserved; all candidate ranged pins whole-current-equal with valid line ranges; exactly four new contiguous quoted Source boxes each contains Claim/Implementation/Contract-setting/Test evidence/Revision/Limit. The quoted-line check is NOT an actual MarkdownIt parser or rendered Reader proof. Independent reviewer must verify real block structure/rendering as applicable. No original generator, specialist validator, publication/style suite or test ran. Statements about tests distinguish their existing assertions from actual execution; prior historical native/BusyBox-flock limitations stay intact.

Underlying product parser behavior does not change. Four documentation corrections cannot themselves prove fixed output handling, installed analyser behavior, concurrent isolation, policy-pack deployment, all31 native results or deployed lint activation. Original cutover-test experimental_tools=[] drift remains a separately disclosed preexisting test limitation; this packet neither edits nor claims that test passes.

## Delivery

candidate-hashes.json fixes all three shipping candidates. packet-hashes.json seals candidates, baselines, diff, mapping, static checks and this report. author.py is scratch-only reproducibility of exact text replacement and is not a shipping target, target instrumentation, authority selector or execution grant.
