from pathlib import Path
import json,hashlib,difflib,subprocess,re
R=Path('/home/node/.openclaw/workspace/kubeclaw-pr13-recovery');D=Path(__file__).parent
rev='569f7b4933d4859cc67c80ddf40d5154ffd95ce5'
def link(label,p,a,b): return f'[{label}](https://github.com/datrab/kubeclaw/blob/{rev}/{p}#L{a}-L{b})'
paths=['docs/site/reference/lint-rules.md','docs/site/reference/lint-policy.md','docs/site/extend/lint.md'];base={p:(R/p).read_text() for p in paths};new=dict(base);changes=[]
def replace(p,old,val,id):
 assert new[p].count(old)==1,(p,id)
 new[p]=new[p].replace(old,val);changes.append({'id':id,'page':p,'old':old,'new':val})
p=paths[0]
replace(p,'A resolvable `envFrom` ConfigMap or Secret key counts. An optional or missing source does not prove the value. | Add the variable directly or through a resolvable nonoptional source.','A declared `env` name or a resolved `envFrom` ConfigMap/Secret key counts, including a resolved optional source and its prefix. A missing source contributes no names. | Declare the variable directly or supply its key through a resolvable source in the workload namespace.','F1-row')
needle='The pack describes values. Engine code owns rule meaning.'
box=f'''> **Source evidence — required environment names**
> **Claim:** A resolved optional `envFrom` source contributes names; optionality does not exclude its keys from `required-env`.
> **Implementation:** {link('Environment-name collection and evaluation','skills/nova/plugins/lint/src/engine/kubernetes-policy-tools.ts',35,60)}.
> **Contract/setting:** {link('The shipped rule requires REDIS_HOST','charts/kubeclaw/files/config/kubernetes-policy-pack-default.json',6,13)}; {link('missing nonoptional Secret references use a separate rule','skills/nova/plugins/lint/src/engine/kubernetes-policy-tools.ts',63,82)}.
> **Test evidence:** The manifest-lint implementation fixture covers optional missing references and ordinary resolved sources, but no dedicated resolved-optional required-name assertion was identified. Test assertions were read, not executed for this clarification.
> **Revision:** `{rev}`; the complete linked source objects match the reviewed repository bytes.
> **Limit:** This checks declared or statically resolved names, not a live environment value or cluster Secret availability.

'''
replace(p,needle,box+needle,'F1-evidence')
p=paths[1]
replace(p,'Discovery scans only to `discovery_max_depth`, skips hidden directories and\n`node_modules`, applies global exclusions, and matches language evidence. It can\ndetect several languages. Discovery does not grant filesystem access.','For language-evidence patterns containing `*`, discovery scans to\n`discovery_max_depth`, skips hidden directories and `node_modules`, and applies\nglobal exclusions before matching candidate files. A pattern without `*` instead\nuses a direct existence check relative to the project root; the scan depth and\ncandidate exclusions do not filter that literal check. Discovery can detect\nseveral languages and does not grant filesystem access.','F2-prose')
needle='Policy-selected files combine `targets`, `include`, tool `exclude`, and'
box=f'''> **Source evidence — literal and glob discovery**
> **Claim:** Literal language evidence and glob evidence use different selection paths.
> **Implementation:** {link('The detector separates direct existence from filtered candidates','skills/nova/plugins/lint/src/engine/discovery.ts',138,159)}.
> **Contract/setting:** {link('Project evidence admits nonempty repository-relative patterns for enabled languages','skills/nova/plugins/lint/src/engine/policy.ts',86,96)}.
> **Test evidence:** `discovery.test.mjs` contains configured-marker and glob assertions; no dedicated literal-excluded/deeper-than-cap case was identified. Assertions were read, not executed for this clarification.
> **Revision:** `{rev}`; the complete linked source objects match the reviewed repository bytes.
> **Limit:** Detecting a literal marker does not bypass the separate repository, target or native-input authority checks.

'''
replace(p,needle,box+needle,'F2-evidence')
replace(p,'It preserves the error code and treats output without valid findings as a parse failure.','It preserves the error code. Invalid JSON lines fail parsing; empty output is clean at exit zero, while a nonzero exit without findings is a parse failure.','F3-row')
needle='The engine runs selected tools sequentially in registry order. A failed tool\ndoes not masquerade as a clean result. The engine continues to assemble tool\nresults unless cancellation rejects the invocation.'
val=f'''> **Source evidence — mypy empty output**
> **Claim:** A successful mypy process may return no findings; an unexplained nonzero exit may not.
> **Implementation:** {link('NDJSON parsing and the conditional empty-result failure','skills/nova/plugins/lint/src/engine/tool-registry-dependency-tools.ts',27,61)}.
> **Contract/setting:** The adapter requests `--output json --no-color-output`; each nonempty stdout line must parse as JSON before normalization.
> **Test evidence:** No dedicated mypy empty-success/nonzero parser assertion was identified in the reviewed owning tests. This clarification follows Source inspection, not a mypy execution.
> **Revision:** `{rev}`; the complete linked source object matches the reviewed repository bytes.
> **Limit:** This documents the current adapter branch, not success of the dormant Python tools in the shipped workspace policy.

The engine runs selected tools sequentially in registry order. An adapter-detected
failure becomes a tool error. The engine continues to assemble tool results
unless cancellation rejects the invocation. Ruff and the shared ESLint runner
have a [current output-validation limit](../extend/lint.md#current-ruff-and-eslint-output-validation-limit);
a structurally valid report alone does not prove those native outputs were complete.'''
replace(p,needle,val,'F3-evidence-F4-qualifier')
p=paths[2]
replace(p,'- Timeout, failed start, malformed output, and exceptions are not clean results.','- Timeout, failed start and caught tool exceptions are not clean results.\n- Invalid JSON syntax fails parsing; wrong-shape JSON has the Ruff/ESLint limit below.','F4-bullet')
needle='## Activate And Observe The Change'
body=f'''### Current Ruff And ESLint Output-Validation Limit

The Lint owner still needs to close a product parser boundary. Ruff and the
shared runner for `eslint` and all three type-evidence tools convert a parsed
nonarray top-level JSON value to an empty list. The ESLint normalizer also treats
a nonarray `messages` member as empty. These adapters do not separately reject
an ordinary nonzero process exit when the normalized findings are empty. Invalid
JSON syntax, timeout, failed start, output overflow and cancellation follow their
separate failure paths; this limit does not make those failures clean.

The Source counterexample is conditional, not a native observation: with admitted
inputs and a completed native process, stdout `{{}}` can normalize to zero
findings; a valid empty array with an unexplained ordinary nonzero exit can do so
too. The report then records an `ok` tool result without the raw exit status.
Report validation cannot recover that discarded distinction. If every other
selected tool contributes no failures or blocking findings, and authority,
baseline, cancellation and artifact storage checks all succeed, the stage can
return `passed`. This explanation includes no native Ruff or ESLint execution of these
counterexamples; it does not assert that the pinned binaries emit
such output during a normal run.

Do not accept an unexpected empty result solely because its report passes the
schema. Retain the existing report and engine stderr logs, then inspect the
selected source revision, executable/version authority, native configuration and
input scope against the [policy and runtime references](../reference/lint-policy.md#tool-execution-contracts).
The engine does not normally retain complete native stdout, stderr and exit
status in a successful Ruff/ESLint report. Logs may therefore be insufficient to
resolve an unexpected result. Stop acceptance when that evidence is unavailable
or inconsistent; ask the Lint owner for a controlled diagnosis rather than
claiming that the report proves the missing native output.

The Lint owner can close this boundary only with a product change that validates
the expected output shapes and each supported exit/result combination before
success normalization, plus owning tests for clean output, real findings,
wrong-shape JSON and unexplained nonzero empty output through report and stage
classification. Retain timeout, overflow, cancellation and cleanup coverage.
Until that change has independent Source review and actual relevant checks,
keep this limitation explicit; the extension requirement to reject incomplete
output is not proof that every shipped parser already does so.

> **Source evidence — native output versus final stage result**
> **Claim:** Ruff/shared ESLint can discard a wrong JSON shape or unexplained ordinary nonzero exit before the stage classifies the report.
> **Implementation:** {link('Ruff normalization','skills/nova/plugins/lint/src/engine/tool-registry-language-tools.ts',76,93)}, {link('shared ESLint parsing','skills/nova/plugins/lint/src/engine/tool-registry-language-tools.ts',199,226)} and {link('message normalization','skills/nova/plugins/lint/src/engine/tool-registry-language-tools.ts',180,197)} use {link('the nonarray-to-empty helper','skills/common/plugin-runtime/sdk/src/values.ts',27,29)}. {link('Successful report reduction','skills/nova/plugins/lint/src/engine/report.ts',114,164)} and {link('summary accumulation','skills/nova/plugins/lint/src/engine/tool-summary.ts',15,26)} preserve no raw native exit; {link('the stage reduces the validated report','skills/nova/plugins/lint/src/stage.ts',25,54)}.
> **Contract/setting:** {link('The common execution guard rejects timeout/start failure, not every nonzero exit','skills/nova/plugins/lint/src/engine/execution.ts',80,88)}; {link('the stage validates and stores the normalized report before classification','skills/nova/plugins/lint/src/stage.ts',87,106)}. No policy flag closes this parser boundary.
> **Test evidence:** {link('The remediation assertion distinguishes process outcomes','skills/nova/plugins/lint/tests/remediation.test.mjs',76,93)}; hostile report assertions validate normalized report identities/counts, not raw Ruff/ESLint output. These assertions were read, not run here; no end-to-end counterexample execution is claimed.
> **Revision:** `{rev}`; the complete linked source objects match the reviewed repository bytes.
> **Limit:** This is a conditional Source trace and an unresolved Lint-owned product boundary, not a native failure observation, runtime approval or general sandbox guarantee.

'''
replace(p,needle,body+needle,'F4-limit-evidence')
replace(p,'Evidence: skills/nova/plugins/lint/plugin.json; skills/nova/plugins/lint/src; skills/nova/plugins/lint/tests; charts/kubeclaw/files/config; skills/nova/plugins/delivery-lint','Evidence: skills/nova/plugins/lint/plugin.json; skills/nova/plugins/lint/src; skills/nova/plugins/lint/tests; charts/kubeclaw/files/config; skills/nova/plugins/delivery-lint; skills/common/plugin-runtime/sdk/src/values.ts','F4-header-source')
for p in paths:
 for parent in ['baseline','']:
  out=D/parent/p;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(base[p] if parent else new[p])
patch=''.join(''.join(difflib.unified_diff(base[p].splitlines(True),new[p].splitlines(True),fromfile='a/'+p,tofile='b/'+p)) for p in paths)
(D/'candidate.patch').write_text(patch);(D/'change-mapping.json').write_text(json.dumps(changes,indent=2)+'\n')
rows=[]
for p in paths:
 rows.append({'path':p,'baselineSha256':hashlib.sha256(base[p].encode()).hexdigest(),'candidateSha256':hashlib.sha256(new[p].encode()).hexdigest()})
(D/'candidate-hashes.json').write_text(json.dumps({'status':'AUTHOR_ONLY_UNACCEPTED','baselineRevision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'files':rows,'unchangedGeneratedPage':'docs/site/reference/lint-policy-generated.md'},indent=2)+'\n')
print(json.dumps(rows,indent=2))
