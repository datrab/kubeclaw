# A910 package-guide depth and README parity — independent bounded continuation

Revision `81db5f8a72746dd18439d2ca55d47f08ab5a8ba6`. Reviewer `/root/custody_review`. Main read-only.

## Verdict

**A910-07 / A910-08 / A910-09 / A910-12: NOT_READY.** Four material findings in two coherent reviewed families, plus an explicit unfinished package-by-facet semantic closure. This is not a whole51 PASS, not a claim that every unclosed review facet is defective documentation, and not an execution prerequisite imposed on a documentation gate.

All **51 actual policy assignments / 17 canonical guides / 50 available package READMEs** are represented in `coverage.json`; Ops has no README, not a missing invented file. Every available README was read, not merely compared as a file. All original entry Source bytes match the complete Source-read objects recorded in the earlier finite responsibility review. That review establishes actual supported responsibility, not deep-guide completeness. A policy boolean, generated assignment, sourcebox count, complete manifest roster, generic whole-topic acceptance or mechanical Reader PASS is not guide-depth proof.

Actual relevant Git comparison against the fully preserved7ef checkpoint: **16 guide files unchanged; only buster-suites changed, an84-line demo-auth chapter** independently reviewed complete by `/root/workflow_acceptance`. Source plugin roots have no changed files in that comparison. `guide-comparison.json` preserves exact hashes and the full finite diff. Earlier complete chapter verdicts are carried only through their exact original scope and the preservation chain, not recounted or expanded.

## Gate contracts applied

- **07:** Recursive functions/registrations/config/defaults/conditions/input/output/artifact/capability/secret/effects explanation. Neither catalogue nor schema links replace needed explanation.
- **08:** Lifecycle/persistence/concurrency/idempotency/retry/cancel/resume/recovery/cleanup/remaining-data, with reasoned nonapplicability.
- **09:** Each error family needs trigger/effect/state/safe Source action/retry, plus successful and negative reader flow; enumerated codes alone fail.
- **12:** Every valid necessary README claim needs canonical Site transfer; contradicted legacy claims must not be imported. Reading all READMEs is necessary but is not the finished claim-by-claim parity map.

Full original criteria are frozen in `gate-contracts.json`. The quality standard requires usable Source/Reader/Quality evidence and truthful limitations, not live executions for every guide.

## Complete material finding set for the families adjudicated here

### DEPTH-API-CANCELLATION

Packages: kubeclaw.api-flow, kubeclaw.openapi. Gates: A910-08, A910-09, A910-12. Target: `docs/site/reference/buster-suites.md:384`.

API flow prose unconditionally says a capability error attempts cleanup. Original cancellation checks run before new cleanup and in the catch: cancellation prohibits new cleanup requests. OpenAPI has the same stop rule, absent from its explanation. A reader must not infer a remote cleanup attempt or safe retry after cancellation.

Original controlling Source: `skills/buster/plugins/api-flow/src/provider.js:131-150`; `skills/buster/plugins/openapi/src/provider.js:200-262`; `skills/buster/plugins/api-flow/README.md`; `skills/buster/plugins/openapi/README.md`.

Bounded correction contract: Explain ordinary capability failure versus cancellation, possible retained remote state, owner reconciliation before another mutation; no invented successful cleanup or live proof.

### DEPTH-OPENAPI-SUBSET

Packages: kubeclaw.openapi. Gates: A910-07, A910-12. Target: `docs/site/reference/buster-suites.md:411-423`.

The deep guide names a bounded subset and links configuration schemas but does not explain its actual runtime assertion vocabulary/shape restrictions. Valid necessary README semantics absent from Site include Boolean child schemas, recursively checking even unvisited children, only UUID/date-time formats and rejection of assertion siblings of local refs. Generated error names are not a supported-input explanation.

Original controlling Source: `skills/buster/plugins/openapi/src/schema-support.js:1-73`; `skills/buster/plugins/openapi/src/provider.js:65-100`; `skills/buster/plugins/openapi/README.md:19-27`.

Bounded correction contract: Give usable grouped supported assertions and fail-closed unsupported/ref/child boundary; no implementation paste, whole JSON Schema claim or dialect widening.

### DEPTH-REVIEW-FOLLOWUP

Packages: kubeclaw.review. Gates: A910-07, A910-12. Target: `docs/site/understand/echo.md:202-243`.

General job/accounting/completeness advice does not transfer the produced repository-review-follow-up-status.v1 evidence semantics. Requested/selected/deferred context expansion and verification with reserved input tokens must be distinguishable; deliberate deferral is not malformed or incomplete selected work, and a plan is not executed coverage.

Original controlling Source: `skills/nova/plugins/review/src/repository-audit-stage.ts:380-460`; `skills/nova/plugins/review/src/repository-audit-stage.ts:668-686`; `skills/nova/plugins/review/README.md`.

Bounded correction contract: Explain both phases/status evidence and their interpretation with selected-work terminal checks; preserve existing cache/profile/revalidation identities.

### DEPTH-REVIEW-SIMPLIFICATION

Packages: kubeclaw.review. Gates: A910-07, A910-12. Target: `docs/site/understand/echo.md:172`.

The guide gives enablement/rules/confidence but not necessary limits of the optional Source fact producer: bounded lexical forwarding recognition, no JSX/TSX, no certification of default/rest wrappers, visible source/fact omissions, advisory rather than whole-program equivalence. README states these valid limits; current Source supports them.

Original controlling Source: `skills/nova/plugins/review/src/simplification-fact-producer.ts:15-60`; `skills/nova/plugins/review/src/simplification-miner.ts:90-116`; `skills/nova/plugins/review/README.md:241-250`.

Bounded correction contract: Explain positive accepted syntax and negative/omission diagnostics; do not turn advisory evidence into automated equivalence or repair authority.

## Counterchecks and rejected false positives

- `reference/contracts.md:88–90` already explains review frozen profile/cache encoding and original producer/outer encoding mismatch. No cache-version missing-topic finding.
- Review catalogue Failure Behavior already says audit jobs have checkpoints and revalidation does not promise per-finding resume. No missing no-resume finding.
- `reference/contracts.md:100` already names browser-bound Visual v2, explicit reviewed recapture from v1 and forbids relabeling. Visual migration is not missing merely because it is not repeated in its suite section.
- API flow guide already requires an executed main step. This is not a missing-main-coverage finding. The narrow unresolved point is cancellation-versus-cleanup, not a broad absence of API explanation.
- Generated OpenAPI error rows name unsupported-keyword/ref-sibling errors, but do not explain the supported authoring subset. Source-link availability cannot replace the omitted reader contract.
- Deliberate deferred Review work is not silently certified as selected completed work. The required explanation must preserve this difference, not label every deferral a crashed/incomplete selected job.
- Do not blindly copy older README claims: generic “never resolved secrets in network” cannot erase confidential Discord endpoint behavior; old blanket runtime-dispatch blocked claims cannot contradict current supported cleanup; unconditional Delivery Lint report claims cannot erase actual catch/store failure distinctions.
- No additional findings asserted for supervisor CLI commands: their necessary current operator scope has not been fully adjudicated here. This remains explicit unfinished parity work, not an invented defect.

## Reused independent complete chapter scope

Twelve package-specific complete chapter proofs are retained: six appendices (Delivery Lint, Preflight Contract, Project Summary, Architecture Validator, Blueprint Sync, common Command Runner); Git Workspace; Repository Adapter; both report stages; Demo Handoff; new Demo Auth. Reports and exact artifact hashes are in `coverage.json`. Their Source/semantic Reader/Quality PASS remains bounded to the actual chapter and dependencies described in those reports. Existing sourcefield/pin/format preservation to7ef is supported by `preservation-7ef16585/review.md`, and the later demo-auth/guide preservation by `preservation-6a4e6de6/review.md`, both under this task scratch parent. No old semantic work is discarded or reread for a new count.

Authorship is explicit: this reviewer previously authored policy responsibility reasons and some Source-field additions. Those are not independently selfapproved here. Root/workflow/operator named nonauthor reviews supply their semantic acceptance. Independent chapter reviews by this reviewer concern other authors' actual guide/Source scope. Schema/registration Source knowledge does not by itself establish full documentation.

## Exact unfinished scope, not blanket unexplained “pending”

`coverage.json` has one row for every actual assignment, with its owning page, supported responsibility, current original entry-byte comparison, prior independent chapter evidence and each of the four gate facets. The39 assignments without one of the twelve named complete **package-chapter** proofs still require the package-specific facet mapping described there. This does not mean their Sources or whole owning topic were unread; it means old topic proof has not been expanded into a new51-package recursive-depth theorem. Existing accepted topic subscopes stay accepted.

For all non-demo-auth available READMEs, the full valid-claim→canonical-destination (or Source-backed contradiction exclusion) parity ledger is still not closed. Complete reading is recorded separately in `readme-inventory.json`; no sampled README comparison is called whole parity. Demo-auth's full valid protocol transfer has the complete independent workflow verdict. Ops has no README, but actual supported tool/skill depth remains required.

Remaining finite families and actual boundaries:

- `docs/site/understand/openclaw.md`: Host registration/load identity; hook/subscription ownership versus runtime dispatch calls; observer enqueue/backpressure, event provenance and terminal session cleanup; compare supported README claims with current implementation, not stale blocked-work claims.

- `docs/site/understand/ops-mcp.md`: All tools/arguments/results and Kubernetes/Hubble transport gates; authorization and list pressure; service lifecycle and request failure/cleanup. There is no package README: use actual supported skill/entry as authoritative surface.

- `docs/site/understand/prism-runtime.md`: Distinguish host design tools from whole Prism service; actual tool registrations, config, artifact delivery and downstream retained-state lifetime; host hook/load identity versus packaging metadata.

- `docs/site/understand/telemetry.md`: Each observer registration/config and projection, required versus best-effort delivery, preview suppression, failure/checkpoint ordering and teardown; distinguish transport ack/checkpoint from product authority and payload retirement.

- `docs/site/reference/buster-suites.md`: Each actual provider declaration and nested input semantics; evidence result/failed assertion versus execution error; target authority, mutation/retry, cancellation/cleanup and remaining external state; successful/negative reader flow.

- `docs/site/understand/echo.md`: Review registration/input/profile/policy paths; prepared plan versus execution; cache/follow-up/report evidence identity and completion; advisory simplification limits; recovery without unsafe model redispatch.

- `docs/site/understand/data-and-state.md`: Adapter operations/config/defaults and on-disk validation; CAS/fence/index/blob ordering, concurrent instances, partial write/recovery, retention/remaining bytes and caller-owned lifecycle.

- `docs/site/understand/forge.md`: Implementation agent versus Git adapter capabilities and Blueprint stage; each operation/input/output and grant; non-atomic worktree/commit/push state, source approval and retry uncertainty.

- `docs/site/understand/buster.md`: Adapter registration/target grants, fixed source bundle/result identity and artifact import; pending gates and lease ownership, terminal error/cancellation/retry, remote native observation versus local protocol evidence.

- `docs/site/extend/deep-guides/reports.md`: Both stages registration/schema selectors; source/run/artifact reference verification and snapshot/journal integrity; fence conditionality, cancellation, retry/store failures and retained report ownership.

- `docs/site/understand/worker-core.md`: Common command adapter versus Worker/Buster runtime: canonical executable/cwd/env/output admission; process group/grace/descendant cleanup and unresolved effect ownership.

- `docs/site/extend/lint.md`: Native lint 31-tool policy/rules/baselines/reports and environment versus separate Dockerfile lexical Delivery Lint; cancellation/store-write error boundaries and controlled recovery.

- `docs/site/extend/deep-guides/demo-handoff.md`: Candidate/delivery/ready/protocol bindings; lineage, TTL, cleanup and terminal state; actual validator/adapter result versus external deployment readiness and historical local tests.

- `docs/site/use/workflows/wait-resume.md`: Human approval gates and operator messaging receipt identity; wait store CAS, delivery reservation/ack/replay, signal/cancel order and remaining data. Do not import obsolete generic no-secret-network claim into confidential Discord endpoint transport.

- `docs/site/reference/nova-project.md`: Preflight registrations and immutable source declaration/required-file admission versus Summary evidence reduction; artifact selection/version conditionality, outcome/report-write distinctions and downstream retention.

- `docs/site/understand/security-and-trust.md`: Secret resolver providers/config/allowlist and secret reference versus returned confidential value; permission/symlink/size checks, cache ownership, rotation/recovery and no secret output.

- `docs/site/understand/communication.md`: Transport publisher configure/operation/header/signature boundaries; request reservation, per-attempt state and receiver receipt versus network success; concurrent replay, timeout/cancellation, unknown receiver outcome, explicit terminal reconciliation and retained body/receipt policy.

## Source, semantic Reader and Quality separation

**Source:** Completed actual entry/receiver responsibility reads are retained; controlling finding branches reread inertly. No Source code execution, transformation, target imports, generator, tests, native/kernel/cluster/network/service calls occurred. Exact current input hashes are custody evidence, not semantic acceptance. The four material findings are branch-backed, not inferred from filenames or counts.

**Semantic Reader:** Reused bounded chapter verdicts preserve usable owner/config/positive-negative/failure/recovery boundaries. API cancellation and Review omitted-evidence semantics currently prevent whole-guide readiness. Other unclosed row facets need actual semantic adjudication, not more generic schema links.

**Quality:** Existing complete Sourcebox and actual Reader/browser reports retain their own scope, but this audit does not claim a new built Reader. No new live/runtime requirement, paid model call or native deployment observation is required for these doc-only criteria. New corrected prose would need nonauthor Source/semantic/quality review and the parent's actual current Reader checks before new gate acceptance.

## Requirements and register boundary

Every current261 requirement whose exact canonicalTarget is one of these17pages is already accepted in the current matrix; `existingRequirementsNotRecounted` freezes those exact IDs/states. **No new requirement or gate is accepted or recounted here.** No original record author/reviewer/checks/summary/limits/state is edited. This audit does not broaden accepted SPC/TEL/DAT/SEC/WKC/COM/CFG scopes and does not revoke them merely because stronger package-depth gate closure is still pending. Package assignments are an inventory, not acceptance authority.

No Main/registry/qualification data changes. The finding set is frozen for the two adjudicated families; other unadjudicated facets are explicitly disclosed, not silently assumed clean or missing. Parent owns correction author assignment and subsequent independent whole-gate closeout.
