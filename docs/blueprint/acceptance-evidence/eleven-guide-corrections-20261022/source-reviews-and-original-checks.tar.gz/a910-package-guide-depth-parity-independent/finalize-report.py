import json,hashlib,subprocess
from pathlib import Path
O=Path(__file__).parent;R=Path('/home/node/.openclaw/workspace/kubeclaw-pr13-recovery');d=json.load(open(O/'coverage.json'));H=lambda b:hashlib.sha256(b).hexdigest()
readmes=[{'package':r['package'],'path':r['readme'],'sha256':H((R/r['readme']).read_bytes()) if r['readme'] else None,'review':'complete inert original text read; not mere hash inspection'} for r in d['rows']]
(O/'readme-inventory.json').write_text(json.dumps(readmes,indent=2)+'\n')
paths={'docs/config/documentation-plugin-complexity.json','docs/blueprint/07-documentation-quality-standard.md','docs/blueprint/documentation-completion-matrix.json','docs/site/reference/contracts.md','docs/site/extend/plugin-catalogue/kubeclaw.review.md','skills/buster/plugins/api-flow/src/provider.js','skills/buster/plugins/api-flow/README.md','skills/buster/plugins/openapi/src/provider.js','skills/buster/plugins/openapi/src/schema-support.js','skills/buster/plugins/openapi/README.md','skills/nova/plugins/review/src/repository-audit-stage.ts','skills/nova/plugins/review/src/simplification-fact-producer.ts','skills/nova/plugins/review/src/simplification-miner.ts','skills/nova/plugins/review/README.md'}
paths.update(r['canonicalGuide'] for r in d['rows'])
(O/'input-hashes.json').write_text(json.dumps([{'path':p,'sha256':H((R/p).read_bytes())} for p in sorted(paths)],indent=2)+'\n')
text=f'''# A910 package-guide depth and README parity — independent bounded continuation

Revision `{d['revision']}`. Reviewer `/root/custody_review`. Main read-only.

## Verdict

**A910-07 / A910-08 / A910-09 / A910-12: NOT_READY.** Four material findings in two coherent reviewed families, plus an explicit unfinished package-by-facet semantic closure. This is not a whole51 PASS, not a claim that every unclosed review facet is defective documentation, and not an execution prerequisite imposed on a documentation gate.

All **51 actual policy assignments / 17 canonical guides / 50 available package READMEs** are represented in `coverage.json`; Ops has no README, not a missing invented file. Every available README was read, not merely compared as a file. All original entry Source bytes match the complete Source-read objects recorded in the earlier finite responsibility review. That review establishes actual supported responsibility, not deep-guide completeness. A policy boolean, generated assignment, sourcebox count, complete manifest roster, generic whole-topic acceptance or mechanical Reader PASS is not guide-depth proof.

Actual relevant Git comparison against the fully preserved7ef checkpoint: **16 guide files unchanged; only buster-suites changed, an84-line demo-auth chapter** independently reviewed complete by `/root/workflow_acceptance`. Source plugin roots have no changed files in that comparison. `guide-comparison.json` preserves exact hashes and the full finite diff. Earlier complete chapter verdicts are carried only through their exact original scope and the preservation chain, not recounted or expanded.

## Gate contracts applied

- **07:** Recursive functions/registrations/config/defaults/conditions/input/output/artifact/capability/secret/effects explanation. Neither catalogue nor schema links replace needed explanation.
- **08:** Lifecycle/persistence/concurrency/idempotency/retry/cancel/resume/recovery/cleanup/remaining-data, with reasoned nonapplicability.
- **09:** Each error family needs trigger/effect/state/safe Source action/retry, plus successful and negative reader flow; enumerated codes alone fail.
- **12:** Every valid necessary README claim needs canonical Site transfer; contradicted legacy claims must not be imported. Reading all READMEs is necessary but is not the finished claim-by-claim parity map.

Full original criteria are frozen in `gate-contracts.json`. The quality standard requires usable Source/Reader/Quality evidence and truthful limitations, not live executions for every guide.

## Complete material finding set for the families adjudicated here
'''
for f in d['findings']:
 text+=f"\n### {f['id']}\n\nPackages: {', '.join(f['packages'])}. Gates: {', '.join(f['gates'])}. Target: `{f['guide']}`.\n\n{f['finding']}\n\nOriginal controlling Source: "+'; '.join('`'+s+'`' for s in f['source'])+f".\n\nBounded correction contract: {f['repairBoundary']}\n"
text+='''
## Counterchecks and rejected false positives

- `reference/contracts.md:88–90` already explains review frozen profile/cache encoding and original producer/outer encoding mismatch. No cache-version missing-topic finding.
- Review catalogue Failure Behavior already says audit jobs have checkpoints and revalidation does not promise per-finding resume. No missing no-resume finding.
- `reference/contracts.md:100` already names browser-bound Visual v2, explicit reviewed recapture from v1 and forbids relabeling. Visual migration is not missing merely because it is not repeated in its suite section.
- API flow guide already requires an executed main step. This is not a missing-main-coverage finding. The narrow unresolved point is cancellation-versus-cleanup, not a broad absence of API explanation.
- Generated OpenAPI error rows name unsupported-keyword/ref-sibling errors, but do not explain the supported authoring subset. Source-link availability cannot replace the omitted reader contract.
- Deliberate deferred Review work is not silently certified as selected completed work. The required explanation must preserve this difference, not label every deferral a crashed/incomplete selected job.
- Do not blindly copy older README claims: generic “never resolved secrets in network” cannot erase confidential Discord endpoint behavior; old blanket runtime-dispatch blocked claims cannot contradict current supported cleanup; unconditional Delivery Lint report claims cannot erase actual catch/store failure distinctions.
- No additional findings asserted for supervisor CLI commands: their necessary current operator scope has not been fully adjudicated here. This remains explicit unfinished parity work, not an invented defect.

## Reused independent complete chapter scope

Twelve package-specific complete chapter proofs are retained: six appendices (Delivery Lint, Preflight Contract, Project Summary, Architecture Validator, Blueprint Sync, common Command Runner); Git Workspace; Repository Adapter; both report stages; Demo Handoff; new Demo Auth. Reports and exact artifact hashes are in `coverage.json`. Their Source/semantic Reader/Quality PASS remains bounded to the actual chapter and dependencies described in those reports. Existing sourcefield/pin/format preservation to7ef is supported by `preservation-7ef16585/review.md`, and the later demo-auth/guide preservation by `preservation-6a4e6de6/review.md`, both under this task scratch parent. No old semantic work is discarded or reread for a new count.

Authorship is explicit: this reviewer previously authored policy responsibility reasons and some Source-field additions. Those are not independently selfapproved here. Root/workflow/operator named nonauthor reviews supply their semantic acceptance. Independent chapter reviews by this reviewer concern other authors' actual guide/Source scope. Schema/registration Source knowledge does not by itself establish full documentation.

## Exact unfinished scope, not blanket unexplained “pending”

`coverage.json` has one row for every actual assignment, with its owning page, supported responsibility, current original entry-byte comparison, prior independent chapter evidence and each of the four gate facets. The39 assignments without one of the twelve named complete **package-chapter** proofs still require the package-specific facet mapping described there. This does not mean their Sources or whole owning topic were unread; it means old topic proof has not been expanded into a new51-package recursive-depth theorem. Existing accepted topic subscopes stay accepted.

For all non-demo-auth available READMEs, the full valid-claim→canonical-destination (or Source-backed contradiction exclusion) parity ledger is still not closed. Complete reading is recorded separately in `readme-inventory.json`; no sampled README comparison is called whole parity. Demo-auth's full valid protocol transfer has the complete independent workflow verdict. Ops has no README, but actual supported tool/skill depth remains required.

Remaining finite families and actual boundaries:
'''
seen=set()
for r in d['rows']:
 p=r['canonicalGuide']
 if p not in seen:text+=f"\n- `{p}`: {r['requiredResponsibilityAndBoundary']}\n";seen.add(p)
text+='''
## Source, semantic Reader and Quality separation

**Source:** Completed actual entry/receiver responsibility reads are retained; controlling finding branches reread inertly. No Source code execution, transformation, target imports, generator, tests, native/kernel/cluster/network/service calls occurred. Exact current input hashes are custody evidence, not semantic acceptance. The four material findings are branch-backed, not inferred from filenames or counts.

**Semantic Reader:** Reused bounded chapter verdicts preserve usable owner/config/positive-negative/failure/recovery boundaries. API cancellation and Review omitted-evidence semantics currently prevent whole-guide readiness. Other unclosed row facets need actual semantic adjudication, not more generic schema links.

**Quality:** Existing complete Sourcebox and actual Reader/browser reports retain their own scope, but this audit does not claim a new built Reader. No new live/runtime requirement, paid model call or native deployment observation is required for these doc-only criteria. New corrected prose would need nonauthor Source/semantic/quality review and the parent's actual current Reader checks before new gate acceptance.

## Requirements and register boundary

Every current261 requirement whose exact canonicalTarget is one of these17pages is already accepted in the current matrix; `existingRequirementsNotRecounted` freezes those exact IDs/states. **No new requirement or gate is accepted or recounted here.** No original record author/reviewer/checks/summary/limits/state is edited. This audit does not broaden accepted SPC/TEL/DAT/SEC/WKC/COM/CFG scopes and does not revoke them merely because stronger package-depth gate closure is still pending. Package assignments are an inventory, not acceptance authority.

No Main/registry/qualification data changes. The finding set is frozen for the two adjudicated families; other unadjudicated facets are explicitly disclosed, not silently assumed clean or missing. Parent owns correction author assignment and subsequent independent whole-gate closeout.
'''
(O/'review.md').write_text(text)
# Bind completed evidence chain separately; no import or executable evaluation.
reuse=[]
for n in ['preservation-7ef16585/review.md','preservation-6a4e6de6/review.md']:
 p=O.parent/n;reuse.append({'path':str(p),'sha256':H(p.read_bytes()),'scope':'existing exact independent topic/chapter preservation only; not all51depth'})
(O/'preservation-reuse.json').write_text(json.dumps(reuse,indent=2)+'\n')
pack={p.name:H(p.read_bytes()) for p in sorted(O.iterdir()) if p.is_file() and p.name!='packet-hashes.json'}
(O/'packet-hashes.json').write_text(json.dumps(pack,indent=2)+'\n')
print(json.dumps({'report':str(O/'review.md'),'sha256':H((O/'review.md').read_bytes()),'coverageSha256':H((O/'coverage.json').read_bytes()),'packetSha256':H((O/'packet-hashes.json').read_bytes()),'gateVerdict':'NOT_READY','findings':len(d['findings'])},indent=2))
