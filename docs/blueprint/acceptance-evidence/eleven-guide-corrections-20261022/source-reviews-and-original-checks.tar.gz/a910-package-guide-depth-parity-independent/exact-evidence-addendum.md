# Exact Source custody and minimal correction boundary

Addendum to preserved frozen review.md, not an author correction to either guide. four-fact-exact-evidence.json binds every Source/README/current-guide range to full original file bytes and exact range bytes, and states the actual rules. All50 available README files remain byte-exact7ef inputs; comparison is context continuity, not parity proof.

Minimum new prose is exactly the four correction contracts in findings.json: cancellation before new cleanup and retained remote-state uncertainty; finite selected-schema assertion/child/ref/format behavior (not whole-spec preflight); two follow-up phases with requested/selected/deferred/reserved accounting and report/ref interpretation; bounded lexical simplification positive syntax, omissions and advisory limitations. Preserve existing owner/grants/config/cache/revalidation/default/error boundaries. No new success, deployed/live proof or retry guarantee. Root authors the two page fixes; this reviewer can independently review those four whole mechanisms as nonauthor. Other51-facet/parity work remains explicitly open.

No guide prose, Main, matrix, policy or executable Source edited. No target imported or executed. Initial packet-hashes.json and review.md remain unchanged; packet-hashes-v2.json seals this separate evidence addendum.
