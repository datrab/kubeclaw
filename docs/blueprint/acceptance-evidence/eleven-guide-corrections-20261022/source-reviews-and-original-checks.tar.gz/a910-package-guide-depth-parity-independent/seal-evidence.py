import json,hashlib,subprocess
from pathlib import Path
O=Path(__file__).parent;R=Path('/home/node/.openclaw/workspace/kubeclaw-pr13-recovery');H=lambda b:hashlib.sha256(b).hexdigest()
scopes={
'DEPTH-API-CANCELLATION':[('skills/buster/plugins/api-flow/src/provider.js',125,150),('skills/buster/plugins/openapi/src/provider.js',200,262),('skills/buster/plugins/api-flow/README.md',1,26),('skills/buster/plugins/openapi/README.md',28,33),('docs/site/reference/buster-suites.md',360,423)],
'DEPTH-OPENAPI-SUBSET':[('skills/buster/plugins/openapi/src/schema-support.js',1,73),('skills/buster/plugins/openapi/src/provider.js',65,120),('skills/buster/plugins/openapi/README.md',19,27),('docs/site/reference/buster-suites.md',395,423)],
'DEPTH-REVIEW-FOLLOWUP':[('skills/nova/plugins/review/src/repository-audit-stage.ts',380,462),('skills/nova/plugins/review/src/repository-audit-stage.ts',668,686),('skills/nova/plugins/review/src/repository-audit-stage.ts',708,735),('skills/nova/plugins/review/README.md',74,89),('docs/site/understand/echo.md',202,243)],
'DEPTH-REVIEW-SIMPLIFICATION':[('skills/nova/plugins/review/src/simplification-fact-producer.ts',15,60),('skills/nova/plugins/review/src/simplification-miner.ts',90,116),('skills/nova/plugins/review/README.md',241,250),('docs/site/understand/echo.md',161,174)]}
semantics={
'DEPTH-API-CANCELLATION':'Network capability rejection records first error, skips further main selections, and allows explicit cleanup only while signal remains active. throwIfAborted before every selection and in catch wins over that recovery path. Final aborted/error state prevents normal evidence/result return. Cleanup not atomic nor guaranteed to succeed; remote mutation may already exist.',
'DEPTH-OPENAPI-SUBSET':'At depth0 of each actually validated schema, assertSupportedSchema validates its shape and all selected child schemas, even absent property/empty-array children; this is not a promise to prevalidate every unused component/operation of the whole spec. Assertion vocabulary is explicitly finite; Boolean schemas supported; UUID/date-time are the only formats; local ref assertion siblings unsupported. Runtime Boolean false yields mismatch, not automatically malformed schema. Keep bounded regex/ref/depth checks.',
'DEPTH-REVIEW-FOLLOWUP':'Context-expansion and verification scheduling each store a checkpointed follow-up artifact with requested/selected/deferred/reservedInputTokens. Selected results must pass preflight/reduction or throw before final report. Report keeps followUp and completeness; stage returns the follow-up refs separately from immutable report/cache refs. Deliberate deferral and unverified proposal IDs remain distinguishable from incomplete selected jobs.',
'DEPTH-REVIEW-SIMPLIFICATION':'A bounded lexical scanner recognizes JS/TS forwarding function syntax after masking noncode. Default/rest wrappers fail argument-name admission; JSX/TSX omitted count is explicit. Producer sorts and truncates by fixed fact ceiling, parses own evidence, and reports omittedFactCount. Miner exposes unsupported_source/candidate_limit; advisory syntax evidence is not whole-program semantic equivalence.'}
rows=[]
for id,ss in scopes.items():
 x={'id':id,'actualRuleSemantics':semantics[id],'evidence':[]}
 for p,a,b in ss:
  raw=(R/p).read_bytes();lines=raw.decode().splitlines(keepends=True);assert b<=len(lines),(p,len(lines),b)
  x['evidence'].append({'path':p,'fullSha256':H(raw),'range':[a,b],'rangeSha256':H(''.join(lines[a-1:b]).encode()),'purpose':'original Source or canonical prose read; not execution witness'})
 rows.append(x)
(O/'four-fact-exact-evidence.json').write_text(json.dumps(rows,indent=2)+'\n')
readmes=json.load(open(O/'readme-inventory.json'));pairs=[]
for x in readmes:
 if x['path']:
  old=subprocess.check_output(['git','show','7ef16585ba04eba3628cead304be85307436f091:'+x['path']],cwd=R)
  pairs.append({'package':x['package'],'path':x['path'],'baselineSha256':H(old),'currentSha256':H((R/x['path']).read_bytes()),'equal':old==(R/x['path']).read_bytes()})
assert all(p['equal'] for p in pairs)
(O/'readme-baseline-comparison.json').write_text(json.dumps(pairs,indent=2)+'\n')
(O/'exact-evidence-addendum.md').write_text('''# Exact Source custody and minimal correction boundary\n\nAddendum to preserved frozen review.md, not an author correction to either guide. four-fact-exact-evidence.json binds every Source/README/current-guide range to full original file bytes and exact range bytes, and states the actual rules. All50 available README files remain byte-exact7ef inputs; comparison is context continuity, not parity proof.\n\nMinimum new prose is exactly the four correction contracts in findings.json: cancellation before new cleanup and retained remote-state uncertainty; finite selected-schema assertion/child/ref/format behavior (not whole-spec preflight); two follow-up phases with requested/selected/deferred/reserved accounting and report/ref interpretation; bounded lexical simplification positive syntax, omissions and advisory limitations. Preserve existing owner/grants/config/cache/revalidation/default/error boundaries. No new success, deployed/live proof or retry guarantee. Root authors the two page fixes; this reviewer can independently review those four whole mechanisms as nonauthor. Other51-facet/parity work remains explicitly open.\n\nNo guide prose, Main, matrix, policy or executable Source edited. No target imported or executed. Initial packet-hashes.json and review.md remain unchanged; packet-hashes-v2.json seals this separate evidence addendum.\n''')
pack={p.name:H(p.read_bytes()) for p in sorted(O.iterdir()) if p.is_file() and p.name!='packet-hashes-v2.json'}
(O/'packet-hashes-v2.json').write_text(json.dumps(pack,indent=2)+'\n')
print(json.dumps({'evidenceSha256':H((O/'four-fact-exact-evidence.json').read_bytes()),'packetV2Sha256':H((O/'packet-hashes-v2.json').read_bytes()),'unchangedReadmes':len(pairs)}))
