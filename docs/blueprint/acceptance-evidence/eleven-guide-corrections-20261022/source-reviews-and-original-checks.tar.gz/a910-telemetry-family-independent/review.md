# Telemetry/observer five-package depth continuation

Revision `38d5c8f22d9cc3a923a7fdd421a1c02e4d176fdb`. Reviewer `/root/custody_review`. Main read-only.

**Whole finite family reviewed; zero unread assigned package mechanisms.** Two coherent documentation finding mechanisms remain. This is not whole51 PASS, no new acceptance count and no actual runtime/Reader execution.

## Source boundary and exact reuse

All five complete READMEs, original entries, all config/checkpoint schemas (eight physical files: agent2, notification2, telemetry-observer2, telemetry-store1, Redis1), complete Redis exchange37/RESP75/stream identity8, complete telemetry projection94, complete notification199 and actual small observer envelopes were read; SDK107–128 redactor and original Core delivery/recovery paths are kept distinct from file/Redis projections. Prior complete Core/store/telemetry/event producer-consumer topic reviews are reused at their exact named scope after unchanged Source comparison, not merely535hash checks. coverage.json preserves actual entries and helper/context hashes. No new full transitive Core/store semantic proof or current deployment inferred.

Canonical package-specific/projection/sink/delivery/error/change/retention portions of telemetry.md, exact shared configuration authorities and Redis replay/recovery were compared to the supported functions. Previously whole accepted topic Source work is not recounted. Own previous Sourcefield additions/policy author work rely on Root/workflow/operator nonauthor preservation, not independent selfacceptance.

## Findings

### TELEMETRY-EXACT-PROJECTION-AND-INPUT

The actual telemetry observer emits a separate telemetry-envelope.v2 wrapper with deliveryId, observer registration provenance and an event object (eventId/sequence/type/redacted identity/occurredAt/causationId/redacted payload), not a raw lifecycle-event.v2 and not the agent-observability eight-field projection. Site names the wrapper only in a store inventory; the lifecycle table and source-link sentence do not recursively explain the actual output. The file sink also accepts only an explicitly validated plain/null-prototype JSON object graph before redaction, rejecting cycles/accessors/proxies/nonfinite and nonJSON values, invalid Unicode/prototypes/sparse or extra-key arrays; reused noncyclic objects are valid and count per occurrence. Site bounded/accessor-free snapshot wording and limit table do not explain that input admission contract sufficiently for a sink or new observer author.

Target: docs/site/understand/telemetry.md:1452-1499,1556-1580. Gates: A910-07.

Minimum correction boundary: Explain the actual outer wrapper and preserved versus omitted delivery fields; distinguish canonical event from sink record and agent projection. Explain pre-redaction whole-input admissibility/depth/node/byte budget and shared-object counting plus final redacted-record bound, not just broad secret-name redaction. Do not claim semantic privacy, arbitrary object admission, trusted demo provenance or new runtime execution.

Exact Source and guide fullhash/rangehash in findings.json.

### REDIS-LEGACY-NAMESPACE-CUTOVER

Current Site correctly explains v2 kind/encoded-target/dedup identities and restoration but does not transfer the valid README upgrade boundary from old underscore-sanitized namespace. Older names are noninvertible (period and underscore collapse), current writes do not rename/copy/republish/trim/delete them or migrate external consumers. Pause legacy writers, reconcile pending deliveries and upgrade actual consumers together; old-entry inspection and absent current consumer remain explicit. Generic Redis snapshot restoration is not this namespace-version cutover.

Target: docs/site/understand/telemetry.md:1580-1599 and docs/site/use/workflows/redis-replay-recovery.md:42-57. Gates: A910-08, A910-12.

Minimum correction boundary: Add exact legacy-v2 distinction and owner-controlled writer/consumer coordination/no automatic migration; do not invent consumer group/lookup, deployed migration execution, reversible old names or changed MAXLEN/dedupTTL policy.

Exact Source and guide fullhash/rangehash in findings.json.

## Counterchecks

The current Site already explains all five subscriptions/grants, not fake activation; stable IDs and checkpoint/retry/required-best-effort policy; actual eight-field agent projection (different from telemetry wrapper); exact notification presentation/preview/no body fetch/no unused sanitizer; authoritative audit with no retired observer write; Redis encoded targets/kinds/no consumer group/no exactly-once promise/TTL-versus-trimming; file sink defaults/no silent rotation and layered redaction limits. Those are not missing topics. Do not demand “geometric buffer allocation” implementation prose or copy every historical README statement merely because it exists. No native Redis execution is required for these doc-only gates; existing Source-only/controlled-fixture/native proof limits remain.

## Source / semantic Reader / Quality

Source predicates and actual forwarded payload/state ownership are compared, not filename classifications. Per-package gate facets and full valid necessary README claim families are mapped in coverage.json. Lifecycle facets distinguish pure observer projection from Core checkpoint journal, selected adapter/external sink persistence and owner-directed retirement. File sink no query API and Redis no consumer implementation are actual supported limits, not invented commands.

Semantic Reader remains NOT_READY for exact wrapper/admissibility and namespace-upgrade gaps; the other documented package mechanisms are supported with their shared procedures. Quality preserves existing independent Sourcefield and historical/fixture/deployed limits, not a fresh build/browser result. No Main/registry/qualification updates or new acceptance. Remaining canonical families continue separately; this family is not left on an unexplained pending list.
