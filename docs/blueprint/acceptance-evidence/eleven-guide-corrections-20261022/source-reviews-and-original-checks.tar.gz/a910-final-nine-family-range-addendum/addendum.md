# Exact range correction

The frozen finding inventory retained stale line-count endpoints in two metadata ranges. Complete current original reads were actual1–76 ingress-queue.ts and1–65 repository-review-run-root.mjs, not1–87/1–78. Full Source SHA256s are bound in addendum.json. Original report preserved; no semantic finding withdrawn, no new Source or execution claim. Use only corrected ranges for new links.
