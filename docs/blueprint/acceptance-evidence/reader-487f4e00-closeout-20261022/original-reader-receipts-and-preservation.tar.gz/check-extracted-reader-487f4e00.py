from pathlib import Path
import subprocess,json,time,hashlib,http.client,re,os,signal
base=Path('/home/node/.openclaw/workspace/tmp/pr13-finish-20261021');artifact=base/'offline-reader-487f4e00';out=base/'reader-487f4e00-extracted-checks';out.mkdir(exist_ok=False);root='/home/node/.openclaw/workspace/kubeclaw-pr13-recovery';env={'PATH':'/usr/local/bin:/usr/bin:/bin','HOME':'/home/node','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC'};h=lambda b:hashlib.sha256(b).hexdigest()
for name in ['artifact','search']:
 p=out/name;p.mkdir();argv=['/usr/local/bin/node','scripts/docs-reader/check-'+name+'.mjs',str(artifact)];r={'argv':argv,'cwd':root,'environment':env,'start':time.time()}
 with (p/'stdout.raw').open('wb')as so,(p/'stderr.raw').open('wb')as se:c=subprocess.run(argv,cwd=root,env=env,stdout=so,stderr=se)
 r.update(exitCode=c.returncode,end=time.time(),streams={n:{'bytes':(p/n).stat().st_size,'sha256':h((p/n).read_bytes())}for n in ['stdout.raw','stderr.raw']});(p/'result.json').write_text(json.dumps(r,indent=2)+'\n');assert c.returncode==0,r
p=out/'preview';p.mkdir();argv=['/usr/local/bin/node','scripts/docs-reader/serve.mjs',str(artifact),'0'];r={'argv':argv,'cwd':root,'environment':env,'start':time.time()};(p/'invocation.json').write_text(json.dumps(r,indent=2)+'\n');proc=None
try:
 with (p/'stdout.raw').open('wb')as so,(p/'stderr.raw').open('wb')as se:
  proc=subprocess.Popen(argv,cwd=root,env=env,stdin=subprocess.DEVNULL,stdout=so,stderr=se,start_new_session=True)
  for i in range(100):
   data=(p/'stdout.raw').read_bytes();match=re.search(rb'Reader preview: http://127\.0\.0\.1:(\d+)',data)
   if match:break
   assert proc.poll()is None,'preview exited before ready';time.sleep(.05)
  assert match,'preview not ready';port=int(match[1]);observations=[]
  def request(method,path):
   c=http.client.HTTPConnection('127.0.0.1',port,timeout=10);c.request(method,path);res=c.getresponse();b=res.read();v={'method':method,'route':path,'status':res.status,'headers':dict(res.getheaders()),'bytes':len(b),'sha256':h(b)};c.close();return v,b
  manifest=json.loads((artifact/'reader-manifest.json').read_text())
  for record in manifest['outputs']:
   obs,b=request('GET','/'+record['path']);assert obs['status']==200 and b==(artifact/record['path']).read_bytes()and h(b)==record['sha256']and len(b)==record['bytes'];observations.append(obs)
  home,_=request('GET','/?reader=487f4e00');assert home['status']==308 and home['headers']['location']=='/README.html?reader=487f4e00'
  asset='extend/examples/minimal-stage/src/stage.js';head,b=request('HEAD','/'+asset);assert head['status']==200 and b==b''
  unknown,_=request('GET','/not-published-file');assert unknown['status']==404
  post,_=request('POST','/README.html');assert post['status']==405
  plan=json.loads((artifact/manifest['redirectManifest']).read_text());redirects=[]
  for entry in plan['redirects']:
   obs,b=request('GET',entry['from']+'?reader=487f4e00');assert obs['status']==308 and obs['headers']['location']==entry['to']+'?reader=487f4e00';redirects.append(obs)
  (p/'observations.json').write_text(json.dumps({'revision':manifest['revision'],'outputsGET200ExactBytes':len(observations),'copiedAssetsAlreadyWithinOutputs':19,'home':home,'head':head,'unknown':unknown,'post':post,'maintainedRedirects':redirects,'outputs':observations,'limit':'Actual readonly loopback preview of freshly extracted bytes; no deployment/runtime/gate or liveclusterclaim.'},indent=2)+'\n')
finally:
 if proc is not None:
  if proc.poll()is None:os.killpg(proc.pid,signal.SIGTERM)
  code=proc.wait(timeout=10);r.update(returncode=code,signal=-code if code<0 else None,termination='EXPECTED_RECEIVER_TEARDOWN_AFTER_OBSERVATIONS',end=time.time(),streams={n:{'bytes':(p/n).stat().st_size,'sha256':h((p/n).read_bytes())}for n in ['stdout.raw','stderr.raw']});(p/'terminal.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'extractedArtifact':0,'extractedSearch':0,'actualGETs':240,'previewTeardownSignal':r.get('signal')}))
