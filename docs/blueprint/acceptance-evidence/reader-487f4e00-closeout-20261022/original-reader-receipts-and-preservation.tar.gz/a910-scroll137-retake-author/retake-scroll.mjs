// Scratch-only narrowly receiving retake. No original target imports or browser launch before Root review.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {fileURLToPath,pathToFileURL} from 'node:url';
const hash=b=>createHash('sha256').update(b).digest('hex');
const readHash=f=>hash(fs.readFileSync(f));
const here=path.dirname(fileURLToPath(import.meta.url)),prepFile=path.join(here,'preparation.json');
const expectedPrepSha='f1c9a47b4928be70ea830c1c9bcb0d375c140ee0d7812633e38f5050b5c16a22';assert.equal(readHash(prepFile),expectedPrepSha);
const cfg=JSON.parse(fs.readFileSync(prepFile,'utf8')),args=process.argv.slice(2);
assert.equal(args.length,2);assert.equal(args[0],'--run-reviewed-retake');assert(path.isAbsolute(args[1]));
const output=path.resolve(args[1]);assert(!fs.existsSync(output));assert(!output.startsWith(cfg.artifact+path.sep));
assert.equal(readHash(cfg.originalReport),cfg.originalReportSha256);
assert.equal(readHash(cfg.originalPreparation),cfg.originalPreparationSha256);
const prior=JSON.parse(fs.readFileSync(cfg.originalReport,'utf8'));
const originalPrep=JSON.parse(fs.readFileSync(cfg.originalPreparation,'utf8'));
assert.equal(prior.revision,cfg.revision);assert.equal(prior.artifact,cfg.artifact);
assert.equal(prior.observations.length,cfg.expectedOriginal.pages);assert(prior.observations.every(x=>x.pageWidth<=x.viewport+1&&x.articleCount===1));
assert.equal(prior.boxObservations.length,cfg.expectedOriginal.boxes);assert(prior.boxObservations.every(x=>x.ok));
assert.equal(prior.tableObservations.length,cfg.expectedOriginal.tables);assert.equal(prior.findings.length,cfg.expectedOriginal.findings);
assert.equal(prior.network.length,0);assert.equal(prior.fatal,null);
const key=c=>JSON.stringify([c.page,c.width,c.tableIndex??c.index]);
const bad=prior.tableObservations.filter(x=>!x.ok);assert.equal(bad.length,137);
assert.equal(new Set(bad.map(key)).size,bad.length);assert.equal(new Set(cfg.cases.map(key)).size,137);
assert.deepEqual(new Set(cfg.cases.map(key)),new Set(bad.map(key)));
for(const row of bad){
 assert(row.exactCells&&row.contained&&row.cellsUnclipped&&row.overflow&&!row.nativeScroll);
 assert(!row.activation.applicable||row.activation.focused&&row.activation.intersectsViewport&&row.activation.matched);
 assert.equal(prior.findings.filter(f=>f.kind==='table'&&key(f)===key(row)).length,1);
}
assert(prior.findings.every(f=>f.kind==='table'&&bad.some(r=>key(r)===key(f))));
assert(!output.startsWith(originalPrep.repository+path.sep));
const artifact=cfg.artifact;
function seal(){
 assert.equal(readHash(prepFile),expectedPrepSha);
 assert.equal(readHash(cfg.originalReport),cfg.originalReportSha256);
 assert.equal(readHash(cfg.originalPreparation),cfg.originalPreparationSha256);
 for(const b of originalPrep.inputBindings)assert.equal(readHash(b.path),b.sha256,'Bound input drift '+b.path);
 const index=JSON.parse(fs.readFileSync(originalPrep.artifactIndex,'utf8'));
 assert.equal(index.artifact,artifact);assert.equal(index.files.length,originalPrep.expectedArtifactFiles);
 const actual=[];function walk(dir,rel=''){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const name=path.posix.join(rel,e.name),file=path.join(dir,e.name);assert(!e.isSymbolicLink());if(e.isDirectory())walk(file,name);else{assert(e.isFile());actual.push(name);}}}walk(artifact);
 assert.deepEqual(actual.sort(),index.files.map(f=>f.path).sort());
 for(const f of index.files){assert(f.path===path.posix.normalize(f.path)&&!f.path.startsWith('../')&&!path.isAbsolute(f.path));assert.equal(readHash(path.join(artifact,f.path)),f.sha256);assert.equal(fs.statSync(path.join(artifact,f.path)).size,f.bytes);}
 for(const b of originalPrep.pageBindings){assert.equal(readHash(path.join(originalPrep.repository,b.page)),b.sourceSha256);assert.equal(readHash(path.join(artifact,b.htmlPath)),b.htmlSha256);assert.equal(readHash(path.join(artifact,b.page.slice('docs/site/'.length))),b.stagedSha256);}
}
seal();fs.mkdirSync(output);
const require=createRequire(originalPrep.repository+'/package.json'),{chromium}=require('playwright');
const results=[],findings=[],network=[],screenshots=new Set();let browser=null,fatal=null;
const started=Date.now(),limits=cfg.limits;
const record=(kind,data)=>findings.push({kind,...data});
function deadline(){assert(Date.now()-started<limits.maxRunMilliseconds,'Bounded total retake deadline exceeded');}
try{
 browser=await chromium.launch({headless:true,args:['--no-sandbox']});
 for(const c of cfg.cases){
  deadline();const original=bad.find(r=>key(r)===key(c));
  const context=await browser.newContext({javaScriptEnabled:false,offline:true,viewport:{width:c.width,height:1000},serviceWorkers:'block'});
  context.on('request',r=>{if(/^https?:/iu.test(r.url()))network.push({case:key(c),url:r.url()});});
  await context.route(/^https?:/iu,r=>r.abort());
  const page=await context.newPage();page.setDefaultTimeout(10000);
  page.on('requestfailed',r=>record('failed-resource',{case:key(c),url:r.url(),failure:r.failure()}));
  try{
   const binding=originalPrep.pageBindings.find(b=>b.page===c.page);assert(binding);
   await page.goto(pathToFileURL(path.join(artifact,binding.htmlPath)).href,{waitUntil:'load'});
   const table=page.locator('article table').nth(c.tableIndex);await table.scrollIntoViewIfNeeded();await table.focus();
   const metrics=()=>table.evaluate(el=>{const b=el.getBoundingClientRect();return {scrollLeft:el.scrollLeft,clientWidth:el.clientWidth,scrollWidth:el.scrollWidth,focused:document.activeElement===el,bounds:{left:b.left,right:b.right,top:b.top,bottom:b.bottom},pageWidth:document.documentElement.scrollWidth};});
   async function settle(){
    const start=Date.now(),samples=[];let previous=null,stable=0;
    while(Date.now()-start<=limits.settleMaxMilliseconds){
     deadline();const m=await metrics();samples.push({elapsed:Date.now()-start,...m});
     stable=previous!==null&&m.scrollLeft===previous?stable+1:0;previous=m.scrollLeft;
     if(stable>=limits.settleStableSamples&&Date.now()-start>=limits.settleMinimumMilliseconds)return {settled:true,samples,final:m};
     await page.waitForTimeout(limits.settleSampleMilliseconds);
    }
    return {settled:false,samples,final:await metrics()};
   }
   const initial=await settle();assert(initial.settled);assert.equal(initial.final.clientWidth,c.clientWidth);assert.equal(initial.final.scrollWidth,c.scrollWidth);
   const actualCells=await table.evaluate(el=>[...el.rows].map(r=>[...r.cells].map(c=>({tag:c.tagName.toLowerCase(),text:c.innerText.replace(/\s+/gu,' ').trim()}))));
   const priorCells=original.left.rows.map(r=>r.map(c=>({tag:c.tag,text:c.text})));assert.deepEqual(actualCells,priorCells,'Bound successful original cell matrix changed');
   // A real point in the visible table/viewport intersection, not an inferred outer-table corner.
   const b=initial.final.bounds,point={x:(Math.max(1,b.left)+Math.min(c.width-1,b.right))/2,y:(Math.max(1,b.top)+Math.min(999,b.bottom))/2};
   assert(point.x>0&&point.x<c.width&&point.y>0&&point.y<1000);
   const hitBefore=await table.evaluate((el,p)=>{const h=document.elementFromPoint(p.x,p.y);return {point:p,tag:h?.tagName??null,nearestTableId:h?.closest('table')?[...document.querySelectorAll('article table')].indexOf(h.closest('table')):null,withinTarget:!!h&&el.contains(h)};},point);
   await page.mouse.move(point.x,point.y);
   const beforeWheel=await metrics();await page.mouse.wheel(c.scrollWidth+c.width,0);const afterWheel=await settle();
   const wheel={hitBefore,before:beforeWheel,after:afterWheel,delta:afterWheel.final.scrollLeft-beforeWheel.scrollLeft,reachedEnd:afterWheel.final.scrollLeft>=c.scrollWidth-c.clientWidth-1,disposition:'New separate diagnostic only; original V3 wheel/end observations remain unchanged and are not retroactively passed.'};
   const coverageSamples=[];
   async function keyboardTo(direction){
    await table.focus();const begin=Date.now(),steps=[];let current=await settle(),stalls=0;assert(current.settled&&current.final.focused,'Initial native-keyboard state must settle with table focus');
    function atEnd(){return direction==='left'?current.final.scrollLeft<=1:current.final.scrollLeft>=current.final.scrollWidth-current.final.clientWidth-1;}
    coverageSamples.push(current.final);
    for(let n=0;!atEnd()&&n<limits.maxKeysPerDirection&&Date.now()-begin<limits.maxDirectionMilliseconds;n++){
     deadline();assert(current.final.focused,'Native table focus lost');const before=current.final.scrollLeft;
     await page.keyboard.press(direction==='left'?'ArrowLeft':'ArrowRight');current=await settle();
     steps.push({key:direction==='left'?'ArrowLeft':'ArrowRight',observation:current});coverageSamples.push(current.final);
     assert(current.settled,'Keyboard animation did not settle inside explicit bound');assert(current.final.focused,'Native table focus lost after key');assert(direction==='left'?current.final.scrollLeft<=before+1:current.final.scrollLeft>=before-1,'Wrong-direction native motion');
     stalls=current.final.scrollLeft===before?stalls+1:0;if(stalls>=3)break;
    }
    return {direction,steps,final:current.final,reachedEndpoint:atEnd(),elapsed:Date.now()-begin};
   }
   const returnToLeft=await keyboardTo('left');
   const cellRanges=await table.evaluate(el=>{const b=el.getBoundingClientRect();return [...el.rows].flatMap((row,ri)=>[...row.cells].map((c,ci)=>{const range=document.createRange();range.selectNodeContents(c);const rect=c.getBoundingClientRect();return {row:ri,column:ci,tag:c.tagName.toLowerCase(),text:c.innerText.replace(/\s+/gu,' ').trim(),bounds:{left:rect.left,right:rect.right,top:rect.top,bottom:rect.bottom},links:[...c.querySelectorAll('a')].map(a=>{const r=a.getBoundingClientRect();return {href:a.getAttribute('href'),left:r.left,right:r.right,top:r.top,bottom:r.bottom};}),ranges:[...range.getClientRects()].map(r=>({left:r.left-b.left+el.scrollLeft,right:r.right-b.left+el.scrollLeft,top:r.top,bottom:r.bottom}))};}));});
   const capture=!screenshots.has(c.width);if(capture)await page.screenshot({path:path.join(output,'first-case-'+c.width+'-left.png')});
   const toRight=await keyboardTo('right');
   if(capture){await page.screenshot({path:path.join(output,'first-case-'+c.width+'-right.png')});screenshots.add(c.width);}
   const backToLeft=await keyboardTo('left');
   const intervals=coverageSamples.map(m=>[m.scrollLeft,m.scrollLeft+m.clientWidth]).sort((a,b)=>a[0]-b[0]),merged=[];
   for(const interval of intervals){const last=merged.at(-1);if(last&&interval[0]<=last[1]+1)last[1]=Math.max(last[1],interval[1]);else merged.push([...interval]);}
   const covered=cellRanges.map(cell=>({...cell,scrollMediatedReachable:cell.ranges.every(r=>merged.some(([a,b])=>r.left>=a-2&&r.right<=b+2))}));
   const contained=coverageSamples.every(m=>m.bounds.left>=-1&&m.bounds.right<=c.width+1&&m.pageWidth<=c.width+1);
   const ok=returnToLeft.reachedEndpoint&&toRight.reachedEndpoint&&backToLeft.reachedEndpoint&&contained&&covered.every(c=>c.scrollMediatedReachable);
   const row={...c,originalNativeScroll:false,originalKeyObservation:original.key,originalWheelEnd:original.right.scrollLeft,actualCellMatrixUnchanged:true,initial,wheel,returnToLeft,toRight,backToLeft,coverageIntervals:merged,cellRangeObservations:covered,contained,keyboardPassed:ok,access:'Native keyboard scroll-mediated, NOT simultaneous full-column visibility; original successful cell/internal-clipping/link-activation proof retained separately.'};
   results.push(row);if(!ok)record('native-keyboard',{case:key(c)});
   console.log(JSON.stringify({case:key(c),keyboardPassed:ok,wheelHit:hitBefore.withinTarget,wheelDelta:wheel.delta,wheelReachedEnd:wheel.reachedEnd}));
  }catch(e){record('case-error',{case:key(c),message:e.message,stack:e.stack});}finally{await context.close();}
 }
}catch(e){fatal={message:e.message,stack:e.stack};record('fatal',fatal);}
finally{
 if(browser)await browser.close();try{seal();}catch(e){record('closeout',{message:e.message});}
 if(results.length!==cfg.cases.length)record('incomplete',{expected:cfg.cases.length,actual:results.length});
 if(network.length)record('unexpected-network',{count:network.length});
 const report={schemaVersion:'scratch-scroll137-receiving-retake/v1',scriptSha256:readHash(fileURLToPath(import.meta.url)),preparationSha256:expectedPrepSha,originalReportSha256:cfg.originalReportSha256,revision:cfg.revision,artifact,priorSuccessfulScopePreserved:{pages:60,sourceboxObservations:432,tableObservations:633,successfulTablesNotRetested:496,originalFailuresRetained:137},results,findings,network,fatal,limits:['Exactly original137failed nativeScroll table/width IDs only; no new topic/gate/Reader acceptance.','Original137FAILs retained; keyboard endpoint reachability is distinct new evidence, not a wheel-success waiver. Actual wheel hit/delta/end recorded honestly.','Native focus/keypress/wheel only; DOM/attributes/styles/scrollLeft never assigned. Read-only evaluation and Range geometry only.','No new unexposed persona/screenreader/axe/live/native-product claim. Original successful Sourcebox/cell/activation scope reused, not rerun or recounted.']};
 fs.writeFileSync(path.join(output,'report.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({results:results.length,findings:findings.length,network:network.length,output}));
}
if(findings.length)process.exitCode=1;
