from pathlib import Path,PurePosixPath
import hashlib,json,zipfile,stat,subprocess
base=Path('/home/node/.openclaw/workspace/tmp/pr13-finish-20261021');artifact=base/'production-first-487f4e00';root=Path('/home/node/.openclaw/workspace/kubeclaw-pr13-recovery');out=base/'reader-487f4e00-delivery';out.mkdir(exist_ok=False);m=json.loads((artifact/'reader-manifest.json').read_text());r=json.loads((artifact/'build-report.json').read_text());assert m['revision']==r['revision']=='487f4e00af5d330b0fb253c2bdc67210476068f3';h=lambda b:hashlib.sha256(b).hexdigest();names=sorted({x['path']for x in m['outputs']}|set(r['assetPaths'])|{'reader-manifest.json','build-report.json'});assert len(names)==242
assets=[]
for name in r['assetPaths']:
 b=(artifact/name).read_bytes();p='docs/site/'+name;git=subprocess.check_output(['/usr/bin/git','show',m['revision']+':'+p],cwd=root);assert b==git==(root/p).read_bytes();assets.append({'path':name,'sourcePath':p,'bytes':len(b),'sha256':h(b)})
archive=base/'kubeclaw-reader-offline-487f4e00.zip';assert not archive.exists();records=[]
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name in names:
  assert not name.startswith('/')and'..'not in PurePosixPath(name).parts and'\\'not in name;p=artifact/name;assert p.is_file()and not p.is_symlink();b=p.read_bytes();info=zipfile.ZipInfo(name,date_time=(1980,1,1,0,0,0));info.create_system=3;info.external_attr=(stat.S_IFREG|stat.S_IMODE(p.stat().st_mode))<<16;info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,b);records.append({'path':name,'bytes':len(b),'sha256':h(b)})
extract=base/'offline-reader-487f4e00';extract.mkdir(exist_ok=False)
with zipfile.ZipFile(archive)as z:
 infos=z.infolist();assert len(infos)==len({i.filename for i in infos})==242
 for info,record in zip(infos,records):
  assert info.filename==record['path']and stat.S_ISREG(info.external_attr>>16);b=z.read(info);assert len(b)==record['bytes']and h(b)==record['sha256']and b==(artifact/info.filename).read_bytes();p=extract/info.filename;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);assert p.read_bytes()==b
report={'status':'ARCHIVE_BYTES_AND_19_GIT_SOURCE_ASSETS_VERIFIED_NOT_YET_BROWSER_OR_DELIVERED','revision':m['revision'],'archive':{'path':str(archive),'bytes':archive.stat().st_size,'sha256':h(archive.read_bytes())},'manifestOutputs':len(m['outputs']),'assets':assets,'assetsOutsideOutputManifest':sorted(set(r['assetPaths'])-{x['path']for x in m['outputs']}),'extraMarkers':['reader-manifest.json','build-report.json'],'uniqueSafeRegularMembers':len(records),'members':records,'extractedRoot':str(extract),'limits':'240manifestoutputs already containall19assets; two markers produce242actualmembers. Every asset compared to immutableGitSource and physicalSource. No fullruntime/accessibility/freshpersona/gateclaim.'};(out/'archive-review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'archive':report['archive'],'members':len(records),'assets':len(assets)}))
