from pathlib import Path
import subprocess,os,json,time,hashlib
base=Path('/home/node/.openclaw/workspace/tmp/pr13-finish-20261021');out=base/'reader-487f4e00-build';out.mkdir(exist_ok=False);(out/'tmp').mkdir();root='/home/node/.openclaw/workspace/kubeclaw-pr13-recovery'
env={'PATH':'/usr/local/bin:/usr/bin:/bin','HOME':'/home/node','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC','TMPDIR':str(out/'tmp'),'LD_LIBRARY_PATH':'/home/node/.openclaw/workspace/tmp/pr13-reader-apt/root/usr/lib/x86_64-linux-gnu','FONTCONFIG_FILE':'/home/node/.openclaw/workspace/tmp/pr13-reader-apt/fonts.conf'}
argv=['/usr/local/bin/node','--max-old-space-size=4096','scripts/docs-publication.mjs','build'];head=subprocess.check_output(['/usr/bin/git','rev-parse','HEAD'],cwd=root).decode().strip();assert head.startswith('487f4e00');assert subprocess.check_output(['/usr/bin/git','status','--porcelain=v1','--untracked-files=all'],cwd=root)==b''
r={'argv':argv,'cwd':root,'environment':env,'revision':head,'start':time.time(),'statusBefore':'CLEAN'};(out/'invocation.json').write_text(json.dumps(r,indent=2)+'\n')
try:
 with (out/'stdout.raw').open('wb') as stdout,(out/'stderr.raw').open('wb') as stderr:p=subprocess.run(argv,cwd=root,env=env,stdout=stdout,stderr=stderr,timeout=600)
 r.update(exitCode=p.returncode,end=time.time());r['statusAfter']=subprocess.check_output(['/usr/bin/git','status','--porcelain=v1','--untracked-files=all'],cwd=root).decode()
except subprocess.TimeoutExpired as e:r.update(exitCode=None,rejection='TIMEOUT',end=time.time())
r['streams']={n:{'bytes':(out/n).stat().st_size,'sha256':hashlib.sha256((out/n).read_bytes()).hexdigest()}for n in ['stdout.raw','stderr.raw']};(out/'result.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r));raise SystemExit(r['exitCode']if r['exitCode']is not None else 124)
