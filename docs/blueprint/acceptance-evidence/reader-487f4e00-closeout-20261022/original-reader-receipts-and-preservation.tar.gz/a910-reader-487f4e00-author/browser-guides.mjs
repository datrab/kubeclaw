// Scratch preparation only. Root must review this complete program and pin packet before launch.
// No shipping target imports. Installed MarkdownIt/parse5/Playwright are explicitly reviewed fixture dependencies.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {fileURLToPath,pathToFileURL} from 'node:url';
const hash=b=>createHash('sha256').update(b).digest('hex');
const readHash=f=>hash(fs.readFileSync(f));
const here=path.dirname(fileURLToPath(import.meta.url));
const preparationFile=path.join(here,'preparation.json');
const expectedPreparationSha='0a9b4645a639cba95ac556df0adf733a0a3179184e33514f840e68fe18f323b3';
assert.equal(readHash(preparationFile),expectedPreparationSha);
const cfg=JSON.parse(fs.readFileSync(preparationFile,'utf8'));
const args=process.argv.slice(2);
assert.equal(args.length,2,'--preflight-only|--run-reviewed-corpus /absolute/new-output');
assert(['--preflight-only','--run-reviewed-corpus'].includes(args[0]));
assert(path.isAbsolute(args[1]));
const output=path.resolve(args[1]),artifact=cfg.artifact,repo=cfg.repository;
assert(!fs.existsSync(output),'Never overwrite historical results');
assert(!output.startsWith(artifact+path.sep)&&!output.startsWith(repo+path.sep));
const require=createRequire(repo+'/package.json');
const MarkdownIt=createRequire(repo+'/scripts/docs-reader/package.json')('markdown-it');
const {parse:parseHtml}=require('parse5');
const md=new MarkdownIt({html:true});
const norm=s=>s.replace(/\s+/gu,' ').trim();
const textOf=n=>n.nodeName==='#text'?n.value:n.tagName==='br'?'\n':(n.childNodes??[]).map(textOf).join('')+(['p','li','div','tr','blockquote'].includes(n.tagName)?'\n':'');
const nodes=(n,p)=>[...(p(n)?[n]:[]),...(n.childNodes??[]).flatMap(c=>nodes(c,p))];
const visible=s=>norm(textOf(parseHtml(md.render(s))));
const dequote=s=>s.replace(/^> ?/gmu,'');
function boxes(text,page){
 const lines=text.split('\n');
 // Exact production source-previews selection, not a line-regex pseudo-parser.
 return md.parse(text,{}).filter(t=>t.type==='blockquote_open'&&t.level===0)
  .map(t=>({page,startLine:t.map[0]+1,endLine:t.map[1],raw:lines.slice(...t.map).join('\n')}))
  .filter(b=>/^>\s*(?:\*\*)?(?:Source|Code evidence)/iu.test(b.raw))
  .map((b,i)=>({...b,id:page+'#source-'+(i+1),pageOrdinal:i+1,sha256:hash(b.raw),firstParagraph:visible(md.parse(dequote(b.raw),{}).find(t=>t.type==='inline')?.content??'')}));
}
function verifyInputs(){
 const index=JSON.parse(fs.readFileSync(cfg.artifactIndex,'utf8'));assert.equal(index.artifact,artifact);assert.equal(index.files.length,cfg.expectedArtifactFiles);
 const actual=[];function walk(dir,rel=''){for(const e of fs.readdirSync(dir,{withFileTypes:true})){const name=path.posix.join(rel,e.name),file=path.join(dir,e.name);assert(!e.isSymbolicLink(),'Artifact symlink '+name);if(e.isDirectory())walk(file,name);else{assert(e.isFile(),'Nonregular artifact '+name);actual.push(name);}}}walk(artifact);
 assert.deepEqual(actual.sort(),index.files.map(f=>f.path).sort(),'Artifact membership changed');
 for(const f of index.files){const file=path.join(artifact,f.path);assert(f.path===path.posix.normalize(f.path)&&!f.path.startsWith('../')&&!path.isAbsolute(f.path));assert.equal(readHash(file),f.sha256,'Artifact drift '+f.path);assert.equal(fs.statSync(file).size,f.bytes);}
 for(const b of cfg.inputBindings)assert.equal(readHash(b.path),b.sha256,'Input drift: '+b.path);
 for(const b of cfg.pageBindings){
  assert.equal(readHash(path.join(repo,b.page)),b.sourceSha256,'Physical Source drift: '+b.page);
  assert.equal(readHash(path.join(artifact,b.htmlPath)),b.htmlSha256,'HTML drift: '+b.page);
  assert.equal(readHash(path.join(artifact,b.page.slice('docs/site/'.length))),b.stagedSha256,'Staged Markdown drift: '+b.page);
 }
}
verifyInputs();
const baseline=JSON.parse(fs.readFileSync(cfg.baselineLedger,'utf8'));
const manifest=JSON.parse(fs.readFileSync(path.join(artifact,'reader-manifest.json'),'utf8'));
const previews=JSON.parse(fs.readFileSync(path.join(artifact,'source-previews.json'),'utf8'));
assert.equal(manifest.revision,cfg.revision);assert.equal(manifest.pageRecords.pages.length,cfg.expectedSourcePages);
assert.equal(new Set(manifest.pageRecords.pages.map(p=>p.sourcePath)).size,cfg.expectedSourcePages);
assert.equal(previews.sourceBoxes,cfg.expectedBoxes);assert.equal(previews.boxesWithPreviews,cfg.expectedBoxes);
assert.equal(baseline.boxes.length,cfg.expectedBaselineBoxes);
assert.equal(baseline.fieldAliases.contextSpecific.length,11,'Only original11context-specific slots, no new aliases');
const all=[],delta={unchanged:[],changed:[],added:[],removed:[]},pageData=[];
for(const record of manifest.pageRecords.pages){
 const page=record.sourcePath;assert(page.startsWith('docs/site/'));
 const binding=cfg.pageBindings.find(b=>b.page===page);assert(binding);
 assert.equal(record.source.contentHash.value,binding.sourceSha256);
 assert.equal(record.html.contentHash.value,binding.htmlSha256);
 assert.equal(record.route,'/'+binding.htmlPath);
 const previewRows=previews.pages.filter(x=>x.path===page.slice('docs/site/'.length));assert.equal(previewRows.length,1);assert.equal(previewRows[0].sourceMarkdownSha256,binding.stagedSha256,'Preview/staged binding '+page);
 const text=fs.readFileSync(path.join(repo,page),'utf8');
 const current=boxes(text,page),old=baseline.boxes.filter(b=>b.page===page);
 const unused=new Set(old.map((_,i)=>i));
 // Consume full raw-box records with multiplicity. Page ordinal is a locator, never identity.
 for(const b of current){
  const i=[...unused].find(i=>old[i].raw===b.raw&&old[i].boxSha256===b.sha256);
  if(i!==undefined){unused.delete(i);b.old=old[i];b.delta='unchanged';delta.unchanged.push({page,oldId:old[i].id,newId:b.id,rawSha256:b.sha256});}
 }
 for(const b of current.filter(b=>!b.old)){
  const candidates=[...unused].filter(i=>boxes(old[i].raw,page)[0]?.firstParagraph===b.firstParagraph);
  assert(candidates.length<=1,'Ambiguous changed-box identity: '+b.id);
  if(candidates.length){const i=candidates[0];unused.delete(i);b.old=old[i];b.delta='changed';delta.changed.push({page,oldId:old[i].id,newId:b.id,oldSha256:old[i].boxSha256,newSha256:b.sha256});}
  else{b.delta='added';delta.added.push({page,id:b.id,sha256:b.sha256});}
 }
 for(const i of unused)delta.removed.push({page,id:old[i].id,sha256:old[i].boxSha256});
 for(const b of current){
  if(b.delta==='unchanged')b.fields=b.old.fields;
  else{
   // New/changed boxes must use existing standard labels. No generic/contextual alias invention.
   const inline=md.parse(dequote(b.raw),{}).filter(t=>t.type==='inline');
   const fields={};let active=null;
   for(const t of inline){
    const m=/^\*\*([^*]+):\*\*\s*([\s\S]*)$/u.exec(t.content);
    if(m){const field=Object.entries(baseline.fieldAliases.standard).find(([,labels])=>labels.includes(m[1]));
     active=field?.[0]??null;
     if(active){assert(!fields[active],'Duplicate standard field '+b.id+':'+active);fields[active]={mapping:'existing-standard-exact-label',locations:[{label:m[1],text:m[2]}]};}
    }else if(active)fields[active].locations[0].text+='\n\n'+t.content;
   }
   assert.deepEqual(Object.keys(fields).sort(),['Claim','Implementation','Contract','Test','Revision','Limit'].sort(),'Incomplete new Sourcebox '+b.id);
   b.fields=fields;
  }
 }
 const matchedOld=current.filter(b=>b.old).map(b=>old.indexOf(b.old));
 assert(matchedOld.every((n,i)=>i===0||n>matchedOld[i-1]),'Prior Sourcebox order changed: '+page);
 const html=fs.readFileSync(path.join(artifact,binding.htmlPath),'utf8');
 const doc=parseHtml(html),sourceDoc=parseHtml(md.render(text));
 const expectedTables=nodes(sourceDoc,n=>n.tagName==='table').map(t=>nodes(t,n=>n.tagName==='tr').map(tr=>nodes(tr,n=>['td','th'].includes(n.tagName)).map(c=>({tag:c.tagName,text:norm(textOf(c))}))));
 pageData.push({page,route:record.route,binding,boxes:current,expectedTitle:norm(textOf(nodes(doc,n=>n.tagName==='title')[0])),expectedTables});all.push(...current);
}
assert.equal(all.length,cfg.expectedBoxes);
for(const k of ['unchanged','changed','added','removed'])assert.equal(delta[k].length,cfg.expectedDelta[k],'Unexpected corpus delta '+k);
assert.equal(delta.changed[0].page,cfg.expectedDelta.changedPage);
assert(delta.added.every(b=>cfg.pages.includes(b.page)),'New Sourcebox outside assigned guide scope');
const selected=pageData.filter(p=>cfg.pages.includes(p.page));assert.equal(selected.length,cfg.pages.length);
const corpus={revision:cfg.revision,pages:manifest.pageRecords.pages.length,sourceBoxes:all.length,delta,selectedPages:selected.map(p=>({page:p.page,sourceSha256:p.binding.sourceSha256,htmlSha256:p.binding.htmlSha256,boxes:p.boxes.length,tables:p.expectedTables.length}))};
fs.mkdirSync(output);fs.writeFileSync(path.join(output,'corpus.json'),JSON.stringify(corpus,null,2)+'\n');
if(args[0]==='--preflight-only'){verifyInputs();console.log(JSON.stringify({mode:'preflight-only',browser:false,output,...Object.fromEntries(Object.entries(delta).map(([k,v])=>[k,v.length]))}));process.exit(0);}
const observations=[],boxObservations=[],tableObservations=[],findings=[],network=[];
const finding=(kind,data)=>findings.push({kind,...data});
const {chromium}=require('playwright');
const browser=await chromium.launch({headless:true,args:['--no-sandbox']});
let fatal=null;
try{
 for(const width of cfg.widths){
  const context=await browser.newContext({javaScriptEnabled:false,offline:true,viewport:{width,height:1000},serviceWorkers:'block'});
  context.on('request',r=>{if(/^https?:/iu.test(r.url()))network.push({width,url:r.url()});});
  await context.route(/^https?:/iu,r=>r.abort());
  const page=await context.newPage();page.setDefaultTimeout(10000);
  page.on('requestfailed',r=>finding('failed-resource',{width,url:r.url(),failure:r.failure()}));
  try{for(const p of selected){
   const url=pathToFileURL(path.join(artifact,p.binding.htmlPath)).href;
   await page.goto(url,{waitUntil:'load'});
   const state=await page.evaluate(()=>({title:document.title,pageWidth:document.documentElement.scrollWidth,viewport:innerWidth,articleCount:document.querySelectorAll('article').length}));
   observations.push({page:p.page,width,...state});
   if(state.title!==p.expectedTitle||state.pageWidth>width+1||state.articleCount!==1)finding('page',{page:p.page,width,...state});
   const blockquotes=page.locator('article blockquote');
   const indexes=await blockquotes.evaluateAll(es=>es.map((el,index)=>({index,top:!el.parentElement.closest('blockquote'),first:el.querySelector(':scope > p')?.textContent??''})).filter(x=>x.top&&/^(?:Source|Code evidence)/iu.test(x.first.trim())).map(x=>x.index));
   if(indexes.length!==p.boxes.length)finding('sourcebox-count',{page:p.page,width,actual:indexes.length,expected:p.boxes.length});
   for(let i=0;i<Math.min(indexes.length,p.boxes.length);i++){
    const e=p.boxes[i],box=blockquotes.nth(indexes[i]);
    const first=norm(await box.locator(':scope > p').first().innerText());
    const visibleBox=await box.isVisible();const beforeText=norm(await box.innerText());
    const fields=Object.entries(e.fields).map(([field,m])=>({field,locations:m.locations.map(l=>({label:l.label,expectedText:visible(l.text),labelPresent:beforeText.includes(norm(l.label)+':'),textPresent:beforeText.includes(visible(l.text))}))}));
    const details=box.locator('details'),native=[];
    const actualPreviewCount=await details.count();
    const allInitiallyClosed=await details.evaluateAll(es=>es.every(e=>!e.hasAttribute('open')));
    // Every preview of each NEW/CHANGED box; unchanged raw boxes retain separately named prior native proof.
    for(let d=0;e.delta!=='unchanged'&&d<actualPreviewCount;d++){
     const disclosure=details.nth(d),summary=disclosure.locator(':scope > summary');
     const closed=await disclosure.getAttribute('open')===null;
     await summary.focus();const focused=await summary.evaluate(el=>el===document.activeElement);
     await page.keyboard.press('Enter');const opened=await disclosure.getAttribute('open')!==null;
     const codeVisible=await disclosure.locator('pre code.source-preview-code').isVisible();
     const summaryBounds=await summary.boundingBox();
     await summary.focus();await page.keyboard.press('Enter');
     native.push({index:d,closed,focused,opened,codeVisible,summaryBounds,closedAgain:await disclosure.getAttribute('open')===null});
    }
    const bounds=await box.evaluate(el=>{const r=el.getBoundingClientRect();return {left:r.left,right:r.right,clientWidth:el.clientWidth,scrollWidth:el.scrollWidth,pageWidth:document.documentElement.scrollWidth};});
    const ok=visibleBox&&first===e.firstParagraph&&fields.length===6&&fields.every(f=>f.locations.length&&f.locations.every(l=>l.labelPresent&&l.textPresent))&&actualPreviewCount>0&&allInitiallyClosed&&(e.delta==='unchanged'||native.length===actualPreviewCount)&&native.every(n=>n.closed&&n.focused&&n.opened&&n.codeVisible&&n.closedAgain)&&bounds.left>=-1&&bounds.right<=width+1&&bounds.scrollWidth<=bounds.clientWidth+1&&bounds.pageWidth<=width+1;
    boxObservations.push({page:p.page,width,id:e.id,oldId:e.old?.id??null,delta:e.delta,rawSha256:e.sha256,visible:visibleBox,first,expectedFirst:e.firstParagraph,fields,native,actualPreviewCount,allInitiallyClosed,nativeScope:e.delta==='unchanged'?'prior-exact-raw-box-proof-reused-no-current-keyboard-actuation':'all-current-native-previews',bounds,ok});
    if(!ok)finding('sourcebox',{page:p.page,width,id:e.id});
   }
   const tables=page.locator('article table');
   if(await tables.count()!==p.expectedTables.length)finding('table-count',{page:p.page,width,actual:await tables.count(),expected:p.expectedTables.length});
   for(let t=0;t<Math.min(await tables.count(),p.expectedTables.length);t++){
    const table=tables.nth(t);await table.scrollIntoViewIfNeeded();await table.focus();
    const snapshot=()=>table.evaluate(el=>{const rect=e=>{const b=e.getBoundingClientRect();return {left:b.left,right:b.right,top:b.top,bottom:b.bottom,width:b.width,height:b.height};};return {bounds:rect(el),clientWidth:el.clientWidth,scrollWidth:el.scrollWidth,scrollLeft:el.scrollLeft,focused:document.activeElement===el,rows:[...el.rows].map(row=>[...row.cells].map(c=>{const range=document.createRange();range.selectNodeContents(c);return {tag:c.tagName.toLowerCase(),text:c.innerText.replace(/\s+/gu,' ').trim(),bounds:rect(c),textRects:[...range.getClientRects()].map(b=>({left:b.left,right:b.right,top:b.top,bottom:b.bottom})),clientWidth:c.clientWidth,scrollWidth:c.scrollWidth,links:[...c.querySelectorAll('a')].map(a=>({href:a.getAttribute('href'),bounds:rect(a)}))};}))};});
    const tableBox=await table.boundingBox();assert(tableBox);
    await page.mouse.move(Math.max(1,Math.min(width-2,tableBox.x+Math.min(20,tableBox.width/2))),Math.max(1,Math.min(998,Math.max(0,tableBox.y)+10)));
    // Native wheel and key input only. No scrollLeft assignment, style patch or DOM mutation.
    await page.mouse.wheel(-1000000,0);await page.waitForTimeout(80);
    const left=await snapshot();await table.focus();await page.keyboard.press('ArrowRight');await page.waitForTimeout(80);const key=await snapshot();
    await page.mouse.wheel(left.scrollWidth+width,0);await page.waitForTimeout(100);const right=await snapshot();
    const actualCells=left.rows.map(row=>row.map(c=>({tag:c.tag,text:c.text})));
    const exactCells=JSON.stringify(actualCells)===JSON.stringify(p.expectedTables[t]);
    const overflow=left.scrollWidth>left.clientWidth+1;
    const nativeScroll=!overflow||key.scrollLeft>left.scrollLeft&&right.scrollLeft>=right.scrollWidth-right.clientWidth-2;
    const contained=left.bounds.left>=-1&&left.bounds.right<=width+1;
    const cellsUnclipped=left.rows.flat().every(c=>c.scrollWidth<=c.clientWidth+2&&c.textRects.every(b=>b.left>=c.bounds.left-2&&b.right<=c.bounds.right+2&&b.top>=c.bounds.top-2&&b.bottom<=c.bounds.bottom+2));
    // Keyboard link activation only to an existing local artifact; never follow Source/network URLs.
    const local=await table.locator('a').evaluateAll(es=>es.map((a,i)=>({i,href:a.getAttribute('href')})));
    let activation={applicable:false,reason:'No safe local published target in this table; external Source links are inspected/verified separately by Root.'};
    for(const l of local){
     if(!l.href)continue;const target=new URL(l.href,url);
     if(target.protocol!=='file:')continue;
     const targetFile=fileURLToPath(target);if(!targetFile.startsWith(artifact+path.sep)||!targetFile.endsWith('.html')||!fs.existsSync(targetFile))continue;
     const anchor=table.locator('a').nth(l.i);await anchor.focus();const focused=await anchor.evaluate(a=>a===document.activeElement);
     const before=await anchor.boundingBox();await page.keyboard.press('Enter');await page.waitForTimeout(80);
     activation={applicable:true,href:l.href,target:target.href,focused,bounds:before,intersectsViewport:!!before&&before.x<width&&before.x+before.width>0&&before.y<1000&&before.y+before.height>0,actualUrl:page.url(),matched:page.url()===target.href};
     await page.goto(url,{waitUntil:'load'});break;
    }
    const ok=exactCells&&contained&&left.focused&&cellsUnclipped&&nativeScroll&&(!activation.applicable||activation.focused&&activation.intersectsViewport&&activation.matched);
    tableObservations.push({page:p.page,width,index:t,exactCells,overflow,access:overflow?'native-scroll-mediated-not-simultaneous-column-visibility':'nonoverflowing',left,key:{scrollLeft:key.scrollLeft,focused:key.focused},right,nativeScroll,contained,cellsUnclipped,activation,ok});
    if(!ok)finding('table',{page:p.page,width,index:t,exactCells,contained,cellsUnclipped,nativeScroll,activation});
   }
   if(width===320)await page.screenshot({path:path.join(output,p.page.slice(10).replaceAll('/','__')+'.png'),fullPage:false});
  }}finally{await context.close();}
 }
}catch(e){fatal={message:e.message,stack:e.stack};finding('fatal',fatal);}
finally{
 await browser.close();try{verifyInputs();}catch(e){finding('input-closeout',{message:e.message});}
 const expectedPages=cfg.pages.length*cfg.widths.length;
 const expectedBoxes=selected.reduce((n,p)=>n+p.boxes.length,0)*cfg.widths.length;
 const expectedTables=selected.reduce((n,p)=>n+p.expectedTables.length,0)*cfg.widths.length;
 if(observations.length!==expectedPages||boxObservations.length!==expectedBoxes||tableObservations.length!==expectedTables)finding('incomplete',{expectedPages,actualPages:observations.length,expectedBoxes,actualBoxes:boxObservations.length,expectedTables,actualTables:tableObservations.length});
 if(network.length)finding('unexpected-network',{count:network.length});
 const report={schemaVersion:'scratch-a910-current-guide-browser/v1',scriptSha256:readHash(fileURLToPath(import.meta.url)),preparationSha256:expectedPreparationSha,revision:cfg.revision,artifact,corpus,observations,boxObservations,tableObservations,findings,network,fatal,limits:['Exposed Source/Quality reviewer; not a new unexposed persona, screenreader/axe or whole accessibility review.','Actual current17-guide responsive/readable Sourcebox/table observations only; six unchanged guide mechanisms preserved, not newly counted topic reviews.','All177physical Source/staged/HTML/PageRecord hashes and actual433Sourceboxes bound; old411 multiset tracked with multiplicity, order/ordinal locators retained separately.','No Source preview correctness/search/artifact/SVG owner execution here; Root separately runs original checks.','No target product/native/module/role/graph/API-consumer qualification or gate/register promotion.']};
 fs.writeFileSync(path.join(output,'report.json'),JSON.stringify(report,null,2)+'\n');
 console.log(JSON.stringify({output,pages:observations.length,boxes:boxObservations.length,tables:tableObservations.length,findings:findings.length,network:network.length}));
}
if(findings.length)process.exitCode=1;
