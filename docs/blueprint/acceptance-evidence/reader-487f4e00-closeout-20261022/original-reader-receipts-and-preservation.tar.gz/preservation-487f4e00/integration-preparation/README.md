# Exact94-record integration preparation — BROWSER PENDING

Source revision `487f4e00af5d330b0fb253c2bdc67210476068f3`. Scratch only; **not installable yet**.

## Immutable evidence and exact operations

The entire original94objects/matrix/hash snapshot remains frozen in the parent directory. No original authors, reviewers, checks, summary, limits, Source/Reader/Quality verdict, overall verdict, pages, sources, gates, requirements or accepted counts are replaced. Exactly48affected existingPASSrecords have explicit proposed operations: set only `revision` to487and append one bounded `impactReviews` object. The copied proposed records independently verify that **only revision and impactReviews differ**. Original prior impact entries remain exact. The45unaffectedPASSrecords plus the1NOT_READYrecord are wholly unchanged; this preparation adds zero completion records/gates/requirements.

The48union is44Sourceaffected+4additionalwhole-rendered-output-only. The frozen per-record ownrevision/latestimpact actualGitdiff intersections and coherent Source/per-topic nonauthor semantic reasons are reused, not hash-only reacceptance or duplicate Source audit. Nine Sourceeffects are transitive in addition to35literaldeclared intersections; exact actualoriginalgraph ancestry remains identified without executing it again. The four output-only records also retain the exact12changedcanonicalpage list even where their original declaredSource has no literaldelta.

## Checker-aware revision and evidence boundary

Read the unchanged original `check-ap09-acceptance-contract.mjs` trackedFile+validateCompletionRecords consumer. It directly diffs declaredpages/sources from record.revision, not latestimpactrevision, and does not treat supplemental impactReviews as a waiver. Thus explicit bounded affectedrevision transitions are necessary **after** final realReader preservation. No checker/schema change or fake successful human-review command is proposed.

All1,316distinct declaredpages/sources of the48proposedrecords were checked against exactGit487: everyoneis a regular tracked blob with mode100644/100755. Full manifest is `candidate487-tracked-page-source-bindings.json`. This is declaration validity, not a fresh semantic audit of all1,316files. Existing pages/sources arrays do not change. Later report/archive/receipt evidence may be committed later and referenced as such; it must never be incorrectly inserted into `sources` as if it existed at487. The planned final report destination is explicitly labeled unavailable until later evidence adoption.

## Actual receipts already incorporated

The independent `reader-results-addendum` remains authoritative for the actual non-browser boundaries: two original cleanbuilds419byteequal; original artifact/search/SourceLinks/SourcePreviews and declared-environment27SVGchecks0; exact242safeZIPmembers/19Gitassets/extractedartifact+search0/240GET+query308/HEAD/404/405. InitialSVG1, inert orderingdiagnostic1 and previewSIGTERM15 are retained accurately, not successful check entries. Original completion `checks` arrays stay exact, and human prose remains sourceReviewBasis without exitCode.

Current original433Sourcebox preview census replaces no historical411proof. New responsive/nativeScroll and actualextractedofflineJS results are **pending independent finaladjudication**. Current V3 20physicalpages =17policycanonical(8changed+9unchanged)+3changedSupport, total11changed+9unchanged. The omitted12thchangedcanonical generatederrorpage and three actualofflineclientqueries are separate supplement; the137case scrollretake is not a new wholecorpusrun. No PENDING placeholder may be silently promoted from process-green alone.

## Finalization by Root

1. Verify immutable original94/matrix preconditions and latest sourceCandidate state, with no unreviewed contentdelta.
2. Read actualV3/137-retake/supplement rawterminals, complete observations/findings and declaredscope; retain all failedfixture reports and source/viewport limitations. Root/Custody independently adjudicate finalReader+Quality preservation.
3. Create separate finalsuccessor payload, retaining this PENDING packet. Replace appendedimpact PENDING disposition with exact realproofs, finalreviewerattribution and finalreporthashes; no human-process exit0 fiction.
4. Apply only the48revision+appendimpact operations; retain45PASS+1NOT_READYexact. No new counts or recordclaims. Commit later evidence provenance honestly, without retroactive Source487existence.
5. Root alone runs unchanged original structuralchecker afteradoption. This passive Python preparation is not a production checker, product/graph/native/import/browser execution or permission.

Known Knip release stop, parser/output weakness, unavailable/unexecuted product paths and all original limits remain. No consumer/role/currentglobalgraph/API/runtime/deployment/releasegrant follows.

## Preparation diagnostic

The first inert helper assumed literal intersections were strings; they are structured path/scope records. It stopped before any record/payload/Mainwrite. Its script+partialtrackedbinding output+diagnostic are retained in `integration-preparation-initial-inert-diagnostic`. The corrected inert helper completed, producing the48exactoperations; it does not invent an original product processPASS.
