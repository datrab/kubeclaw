# Actual Reader/check/delivery addendum — browser still pending

Candidate: `487f4e00af5d330b0fb253c2bdc67210476068f3`. Reviewer: `/root/operator_acceptance`.

## Verdict and unchanged scope

**PASS for the actual bounded non-browser process/results and byte-correspondence scopes below. Overall Reader preservation remains PENDING.** This addendum reuses the frozen `review.md`/`review.json` Source assessment; it does not duplicate or enlarge that audit. No Main, completion record, product Source, or acceptance count changed. All 94 original objects and the complete matrix byte hash still match the frozen snapshot. Original authors/reviewers/checks/summary/limits/verdicts remain intact.

Impact bookkeeping stays 44 Source-affected / 50 Source-unchanged; four additional whole-rendered-output-only records make the union 48 affected / 46 without identified new Source or whole-output-universe impact. These are not new acceptances. The JSON addendum maps every original ID/hash to its unchanged Source assessment and pending Reader disposition.

## Independently verified actual evidence

- Read all 11 original result/terminal records, exact argv/environment, invocation correspondence where recorded, and verified every raw stdout/stderr byte count and SHA. Two original normal builds and seven successful checker processes have exit 0; the eighth checker process is the retained initial SVG attempt with exit 1. The finite preview server ends with returncode **−15 / SIGTERM 15**, expected teardown after observations, not a fabricated success terminal.
- Both normal builds: complete unique membership and every actual byte of all **419** first/repeat files equal the retained indexed hashes. The initial inert Path-versus-string order-assumption diagnostic remains exit 1, separate from both exit-0 builds. No determinism claim beyond this actual pair.
- Original artifact: **177 canonical pages / 187 HTML / 40,855 local links / 240 output digests**. Original search: **12 questions**, 177 indexed pages, zero internal artifacts. The original extracted artifact/search checks also exit 0, with matching results.
- Original full rendered Source check: **14,972 unique verified links / 4,054 immutable Source objects**. Original previews: **433/433 boxes**, **2,006 excerpts / 1,064 objects**. These verify links and exact excerpts, not independent correctness of every associated semantic assertion.
- Original diagrams rerun: **27/27 fresh render hashes** under the explicitly recorded LD_LIBRARY_PATH/FONTCONFIG_FILE environment. First launch genuinely failed for missing `libglib-2.0.so.0`; its complete raw receipt stays retained. This is not per-edge semantic or human screenreader reacceptance.
- ZIP: **8,106,602 bytes**, SHA `11f177e729b1f66ebd4d1af4493ab42da68bb77eeb1fef8af46d80fef9a5d482`. Inspected every central-directory member: **242 unique safe regular unencrypted files**, no traversal/absolute path/symlink. Every decompressed member equals its indexed hash, immutable first build and extracted file bytes. Exactly **240 manifest outputs + reader-manifest.json + build-report.json**.
- All **19 copied assets** already lie in the 240 outputs. Each actual asset independently equals the exact immutable Git object at candidate revision, current physical canonical Source, ZIP and extracted bytes. No asset extension/filesystem waiver.
- Read complete finite HTTP observation records: **240 GET200 bodies** match exact output path/bytes/hash; all 19 assets included. Home **308** preserves query, asset **HEAD200** has empty body, unlisted route **404**, POST **405** with `Allow: GET, HEAD`. Maintained redirect registry is empty; this result does not invent migration history. Receiver teardown SIGTERM15 stays separate from successful requests.

## Still pending, without weakening old failures

R1/R2/R3/R5 have their stated current original build/check receipts. R7 has archive/extracted-check/finite HTTP byte proof, but its offline-client browser portion remains pending. R4's actual preview census is 433 (not historical 411); six-field/native keyboard/link/containment and ledger-union evidence still needs the current bounded browser receipts. R6 responsive/noJS/visual evidence remains pending. Parent's earlier V1 paragraph assumption and V2 support-page omission are retained fixture failures, not product Source failures or substitute passes; this addendum does not purport to independently adjudicate their still-pending successor run.

The expected successor is 17 canonical + 3 support pages / 60 responsive page observations. No whole Reader/Quality preservation, fresh-persona approval, gate/requirement addition, consumer/graph/native/runtime or release permission follows from this non-browser result review.

## Reproducible passive correspondence work

`verify-reader-results-passive.py` performs only JSON/ZIP/filesystem/hash comparisons and immutable `git show` reads. It was run to completion with terminal 0; this is a passive evidence check, not an original product check, Source execution or browser launch. Detailed result/receipt hashes and exact environments are in `reader-results-addendum.json`. The original frozen Source packet was not rewritten.
