import pathlib,json,hashlib,subprocess,zipfile,stat
P=pathlib.Path('/home/node/.openclaw/workspace/tmp/pr13-finish-20261021'); R=pathlib.Path('/home/node/.openclaw/workspace/kubeclaw-pr13-recovery'); D=P/'preservation-487f4e00'
def sha(b): return hashlib.sha256(b).hexdigest()
def j(p): return json.loads(p.read_text())
def digest(p): return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
def verify(b,row): assert len(b)==row['bytes'] and sha(b)==row['sha256'],row.get('path')
rev='487f4e00af5d330b0fb253c2bdc67210476068f3'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==rev
old=j(D/'review.json'); original=j(D/'original-records.json'); matrixpath=R/'docs/blueprint/documentation-completion-matrix.json'; matrix=j(matrixpath)
assert matrix['completionRecords']==original and len(original)==94
assert sha(matrixpath.read_bytes())==j(D/'original-record-object-hashes.json')['matrixSha256']
terminals=[]
for root in ['reader-487f4e00-build','reader-487f4e00-repeat-build','reader-487f4e00-checks','reader-487f4e00-diagrams-declared-env','reader-487f4e00-extracted-checks']:
 for f in sorted((P/root).rglob('*.json')):
  if f.name not in ['result.json','terminal.json']: continue
  o=j(f)
  for name,row in o['streams'].items(): verify((f.parent/name).read_bytes(),row)
  inv=f.parent/'invocation.json'
  if inv.exists():
   for k,v in j(inv).items(): assert o[k]==v,(f,k)
  status=o.get('exitCode',o.get('returncode'))
  expected=1 if str(f.relative_to(P))=='reader-487f4e00-checks/diagrams/result.json' else (-15 if f.name=='terminal.json' else 0)
  assert status==expected
  if status==-15: assert o['signal']==15 and o['termination']=='EXPECTED_RECEIVER_TEARDOWN_AFTER_OBSERVATIONS'
  terminals.append({'receipt':digest(f),'argv':o['argv'],'environment':o['environment'],'exitCode':o.get('exitCode'),'returncode':o.get('returncode'),'signal':o.get('signal'),'streams':o['streams'],'stdoutText':(f.parent/'stdout.raw').read_text() if (f.parent/'stdout.raw').stat().st_size<5000 else None})
first=j(P/'reader-487f4e00-build/immutable-copy-files.json'); comp=j(P/'reader-487f4e00-repeat-build/byte-comparison.json')
A=pathlib.Path(first['artifact']); B=pathlib.Path(comp['repeat'])
assert first['files']==comp['files'] and len(first['files'])==419
for root in [A,B]:
 actual={str(f.relative_to(root)) for f in root.rglob('*') if f.is_file()}; assert actual=={x['path'] for x in first['files']}
 for row in first['files']: verify((root/row['path']).read_bytes(),row)
archive=j(P/'reader-487f4e00-delivery/archive-review.json'); z=pathlib.Path(archive['archive']['path']);verify(z.read_bytes(),archive['archive'])
E=pathlib.Path(archive['extractedRoot']); manifest=j(A/'reader-manifest.json'); outputs={x['path']:x for x in manifest['outputs']}; assert len(outputs)==240
members=archive['members']; assert len(members)==242 and len({x['path'] for x in members})==242
assert {x['path'] for x in members}==set(outputs)|{'reader-manifest.json','build-report.json'}
with zipfile.ZipFile(z) as f:
 infos=f.infolist(); assert len(infos)==242 and len({x.filename for x in infos})==242
 by={x.filename:x for x in infos}
 for row in members:
  name=row['path']; i=by[name]; pp=pathlib.PurePosixPath(name); assert not pp.is_absolute() and '..' not in pp.parts and '\\' not in name and not i.is_dir() and not i.flag_bits&1
  mode=i.external_attr>>16; assert not stat.S_ISLNK(mode) and stat.S_IFMT(mode) in (0,stat.S_IFREG)
  b=f.read(i);verify(b,row);assert b==(A/name).read_bytes()==(E/name).read_bytes()
assets=archive['assets'];assert len(assets)==19 and not archive['assetsOutsideOutputManifest']
for row in assets:
 b=subprocess.check_output(['git','show',rev+':'+row['sourcePath']],cwd=R);verify(b,row)
 assert b==(R/row['sourcePath']).read_bytes()==(E/row['path']).read_bytes() and row['path'] in outputs
obs=j(P/'reader-487f4e00-extracted-checks/preview/observations.json');assert len(obs['outputs'])==240
assert {x['route'][1:] for x in obs['outputs']}==set(outputs)
for row in obs['outputs']:
 assert row['method']=='GET' and row['status']==200
 verify((E/row['route'][1:]).read_bytes(),row)
assert obs['home']['status']==308 and obs['home']['headers']['location']=='/README.html?reader=487f4e00'
assert obs['head']['status']==200 and obs['head']['bytes']==0 and obs['head']['method']=='HEAD'
assert obs['unknown']['status']==404 and obs['post']['status']==405 and obs['post']['headers']['allow']=='GET, HEAD' and obs['maintainedRedirects']==[]
parsed={}
for name,loc in [('artifact','reader-487f4e00-checks/artifact'),('search','reader-487f4e00-checks/search'),('sourceLinks','reader-487f4e00-checks/source-links'),('sourcePreviews','reader-487f4e00-checks/source-previews'),('diagrams','reader-487f4e00-diagrams-declared-env/diagrams')]:
 o=j(P/loc/'stdout.raw');parsed[name]={k:v for k,v in o.items() if k not in ['primarySources','observed']}
assert parsed['artifact']=={'selectedPages':177,'htmlPages':187,'localLinks':40855,'verifiedOutputDigests':240}
assert parsed['search']['readerQuestionsPassed']==12 and parsed['search']['internalArtifacts']==0
assert parsed['sourceLinks']['uniqueVerifiedLinks']==14972 and parsed['sourceLinks']['uniqueSourceObjects']==4054
assert parsed['sourcePreviews']['sourceBoxes']==433 and parsed['sourcePreviews']['boxesWithPreviews']==433
assert parsed['diagrams']['freshRenderHashesMatched']==27
fail=(P/'reader-487f4e00-checks/diagrams/stderr.raw').read_text(); assert 'libglib-2.0.so.0' in fail
result={'status':'ACTUAL_BUILD_CHECK_ARCHIVE_HTTP_RESULTS_VERIFIED_BROWSER_PENDING','revision':rev,'reviewer':'/root/operator_acceptance','sourcePlanPreserved':digest(D/'review.json'),'original94ObjectsUnchanged':True,'matrix':digest(matrixpath),'terminalReceipts':terminals,'parsedOriginalCheckerResults':parsed,'twoNormalBuilds':{'filesComparedByExactPath':419,'first':str(A),'repeat':str(B),'allActualBytesEqual':True,'initialOrderingDiagnosticRetained':digest(P/'reader-487f4e00-repeat-build/initial-comparison-diagnostic.json')},'archive':archive['archive'],'archiveVerification':{'safeUniqueRegularUnencryptedMembers':242,'manifestOutputs':240,'extraMarkers':['reader-manifest.json','build-report.json'],'allMemberBytesEqualFirstAndExtracted':True,'all19AssetBytesEqualImmutableGitAndPhysicalSource':True},'httpVerification':{'get200ExactBytes':240,'assetsIncluded':19,'queryPreservingHome308':True,'assetHEAD200EmptyBody':True,'unknown404':True,'POST405':True,'maintainedRedirects':0,'serverTeardownReturncode':-15,'signal':15},'retainedFailures':[{'receipt':str(P/'reader-487f4e00-checks/diagrams/result.json'),'exitCode':1,'cause':'Chromium dynamic loader libglib-2.0.so.0 absent from initial environment; exact argv rerun adds declared LD_LIBRARY_PATH/FONTCONFIG_FILE and terminal0.'},{'receipt':str(P/'reader-487f4e00-repeat-build/initial-comparison-diagnostic.json'),'exitCode':1,'cause':'Inert Path tuple vs relative string ordering assumption; not build failure; successor exact-path complete419byte comparison verified.'}],'readerEvidenceDisposition':{'R1':'Original two normal builds and complete artifact PASS; not browser usability acceptance.','R2':'Original built and extracted search12questions PASS; offline interactive browser remains pending.','R3':'Full original SourceLinks and SourcePreviews PASS, not new semantic approval.','R4':'Original current433/433preview census verified; field/native/focus browser and ledger union PENDING.','R5':'Original fresh27SVG check PASS under declared environment; initial exit1 retained.','R6':'PENDING actual20page/60responsive browser and visual receipts; earlier fixture failures retained by Root, no Source fix inferred.','R7':'ZIP242/19Gitassets/extractedartifact+search/240GET+HEAD+308query+404+405 PASS; offline client browser remains PENDING.'},'countsUnchanged':{'records':94,'sourceAffected':44,'sourceUnchanged':50,'additionalRenderedCorpusOnlyAffected':4,'affectedUnion':48,'noNewScopeOrOutputUniverseImpact':46},'records':[{'id':x['id'],'originalRecordCanonicalSha256':x['originalRecordCanonicalSha256'],'originalRecordRawObjectSha256':x['originalRecordRawObjectSha256'],'requiredCurrentReaderEvidence':x['requiredCurrentReaderEvidence'],'sourceAssessment':x['sourceAssessment'],'readerAssessment':'ACTUAL_NON_BROWSER_RECEIPTS_VERIFIED_BROWSER_PENDING_NO_NEW_VERDICT','qualityAssessment':x['qualityAssessment']} for x in old['records']],'limits':['Append-only actual-result addendum to frozen Source plan, no duplicated Source audit or changes to94 original objects/attribution/checks/limits/verdicts.','No Reader overall PASS, matrix writes, new gate/requirement count, target/import/producer/browser execution by reviewer, native/global graph/consumer/release grant.','Only exact named original process receipts have process statuses; this human/inert correspondence review is not a product command execution.']}
(D/'reader-results-addendum.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'rawTerminalReceipts':len(terminals),'safeZipMembers':242,'gitAssets':19,'originalRecords':94,'checks':parsed},indent=2))
