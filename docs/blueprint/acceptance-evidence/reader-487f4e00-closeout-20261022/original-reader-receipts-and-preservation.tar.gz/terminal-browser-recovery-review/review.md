# Recovered terminal browser evidence — bounded receiving PASS

Candidate: `487f4e00af5d330b0fb253c2bdc67210476068f3`.

Both original processes terminated with exit 0. The passive receiving verifier compared invocation/result correspondence, script/preparation SHA-256, complete raw stdout/stderr sizes and hashes, original report identity, exact original failed case IDs, actual endpoint coordinates/focus, and recorded Range coverage. It launches no browser or product code.

- Exactly 137 original failed table/width IDs: 129 at 320px and 8 at 768px. All 137 now have native left/right/left keyboard endpoint evidence and containment, with 4,825 cell Range observations. The separate new wheel observations also reach the endpoint in all 137 cases; these do not rewrite the original failed wheel observations.
- Separate generated-error supplement: three page widths, 57 table/width observations with exact matrices, internal clipping checks and scroll-mediated Range coverage; three extracted offline JavaScript searches with native focus/Enter reaching their expected local page. No external network requests or findings in either report.
- Visually inspected the retained 320px error-table right-end screenshot: table remains inside the viewport with wrapped content and links; offscreen columns are intentionally scroll-mediated, not all visible at once.

Original V3 failures, fixture failures, pending gate preparation, and all 94 original completion objects are untouched. No new completion count, gate PASS, requirement acceptance, Reader delivery, Main update, or runtime qualification follows automatically.

Next: use this sealed receiving addendum for the exact94 Reader-preservation final disposition and four-gate/OPL-001 append-only adjudication; only then integrate the reviewed candidate. The old pending preparation is historical and must not be overwritten. The independent preparation authors are not active in this recovered runtime.

Verification: `python tmp/pr13-finish-20261021/verify-terminal-browser-recovery.py` completed with exit 0 after correcting a local verifier field-name assumption (`covered` was not a supplement schema field). That diagnostic was a verifier error, not a product/browser failure. Full receiving bindings and measurements are in adjacent `review.json`.
