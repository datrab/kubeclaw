from pathlib import Path
import subprocess,json,time,hashlib,concurrent.futures
base=Path('/home/node/.openclaw/workspace/tmp/pr13-finish-20261021');out=base/'reader-487f4e00-diagrams-declared-env';out.mkdir(exist_ok=False);root='/home/node/.openclaw/workspace/kubeclaw-pr13-recovery';artifact=str(base/'production-first-487f4e00')
env={'PATH':'/usr/local/bin:/usr/bin:/bin','HOME':'/home/node','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC','LD_LIBRARY_PATH':'/home/node/.openclaw/workspace/tmp/pr13-reader-apt/root/usr/lib/x86_64-linux-gnu','FONTCONFIG_FILE':'/home/node/.openclaw/workspace/tmp/pr13-reader-apt/fonts.conf'}
def run(name):
 p=out/name;p.mkdir();argv=['/usr/local/bin/node','scripts/docs-reader/check-'+name+'.mjs',artifact];r={'argv':argv,'cwd':root,'environment':env,'start':time.time()};(p/'invocation.json').write_text(json.dumps(r,indent=2)+'\n')
 with (p/'stdout.raw').open('wb')as so,(p/'stderr.raw').open('wb')as se:child=subprocess.run(argv,cwd=root,env=env,stdout=so,stderr=se)
 r.update(exitCode=child.returncode,end=time.time(),streams={n:{'bytes':(p/n).stat().st_size,'sha256':hashlib.sha256((p/n).read_bytes()).hexdigest()}for n in ['stdout.raw','stderr.raw']});(p/'result.json').write_text(json.dumps(r,indent=2)+'\n');return r
with concurrent.futures.ThreadPoolExecutor(max_workers=5)as pool:
 results=list(pool.map(run,['diagrams']))
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps([{'check':r['argv'][1],'exitCode':r['exitCode']}for r in results]));raise SystemExit(0 if all(r['exitCode']==0 for r in results)else 1)
