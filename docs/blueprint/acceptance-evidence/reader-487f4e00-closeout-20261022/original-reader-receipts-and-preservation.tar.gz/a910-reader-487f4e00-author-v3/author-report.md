# V3 — exact supporting-page union, PREPARED NOT RUN

V2's actual token-parser/corpus selection succeeded with410unchanged+1changed+22added/0removed, then its explicit page-scope assertion stopped. That real FAIL is preserved and hash-bound in correction-addendum.json. The supported correction batch contains three already independently reviewed supporting pages outside the17policy canonical assignments. This is a fixture coverage omission, not a documentation defect.

Exactly `docs/site/reference/lint-policy.md`, `docs/site/reference/lint-rules.md` and `docs/site/use/workflows/redis-replay-recovery.md` are added to preparation.pages. The first two carry independently afterreviewed Lint corrections; Redis carries the independently afterreviewed telemetry cutover mechanism. The responsive union is20physicalpages×3widths=60plannedpageobservations, still **17canonicalGuides+3supportPages**, not20newguides/approvals. Every22actualnewSourcebox must lie in that exact union; no prefix/glob/automatic exemption is introduced.

Only that pages-array cell changes in preparation.json. Exactly the corresponding expectedPreparationSha literal changes in browser-guides.mjs; replacing it with the V2 literal reconstructs every V2 code byte. Parser, all six-label/11contextual mappings, original Source selection, corpus counts, multiplicity/order, preview/native/table actions and before/after input seals remain unchanged. scope-only.patch contains the full delta.

V1/V2 reports and failures remain immutable. Root must review this tiny scope/data-hash delta and authorize a new actual preflight in a fresh output directory. V3 is unrun: no program import, parser/preflight/browser launch or Main/register change by this author. No current Reader/gate PASS is claimed.
