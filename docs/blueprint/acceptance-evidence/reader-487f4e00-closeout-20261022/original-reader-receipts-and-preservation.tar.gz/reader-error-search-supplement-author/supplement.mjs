// Scratch-only receiving fixture. Frozen for Root review; author does not launch it.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {fileURLToPath,pathToFileURL} from 'node:url';
const hash=b=>createHash('sha256').update(b).digest('hex'),rh=f=>hash(fs.readFileSync(f));
const here=path.dirname(fileURLToPath(import.meta.url)),pf=path.join(here,'preparation.json');
const prepSHA='c1c62f9a5c582331a8fb074ac0885f6ebcb42e44f36b800c6ea19e6d185bb612';assert.equal(rh(pf),prepSHA);
const cfg=JSON.parse(fs.readFileSync(pf,'utf8')),args=process.argv.slice(2);
assert.equal(args.length,2);assert(['--preflight-only','--run-reviewed-supplement'].includes(args[0]));assert(path.isAbsolute(args[1]));
const out=path.resolve(args[1]);assert(!fs.existsSync(out));
for(const root of [cfg.repository,cfg.artifact,cfg.extracted,here])assert(out!==root&&!out.startsWith(root+path.sep));
const old=JSON.parse(fs.readFileSync(cfg.originalPreparation.path,'utf8'));
const readj=f=>JSON.parse(fs.readFileSync(f,'utf8'));
function bind(row){assert.equal(rh(row.path),row.sha256,'Bound drift '+row.path);if(row.bytes!==undefined)assert.equal(fs.statSync(row.path).size,row.bytes);}
function members(root,rows){
 const found=[];function walk(dir,rel=''){for(const e of fs.readdirSync(dir,{withFileTypes:true})){assert(!e.isSymbolicLink());const r=path.posix.join(rel,e.name);if(e.isDirectory())walk(path.join(dir,e.name),r);else{assert(e.isFile());found.push(r);}}}walk(root);
 assert.deepEqual(found.sort(),rows.map(x=>x.path).sort());
 for(const r of rows){assert(!path.isAbsolute(r.path)&&r.path===path.posix.normalize(r.path)&&!r.path.startsWith('../'));bind({...r,path:path.join(root,r.path)});}
}
function seal(){
 assert.equal(rh(pf),prepSHA);bind(cfg.originalPreparation);bind(cfg.artifactIndex);bind(cfg.archiveReview);
 for(const x of old.inputBindings)bind(x);
 members(cfg.artifact,readj(cfg.artifactIndex.path).files);members(cfg.extracted,cfg.extractedMembers);
 const m=readj(path.join(cfg.artifact,'reader-manifest.json')),e=readj(path.join(cfg.extracted,'reader-manifest.json'));
 assert.deepEqual(m,e);assert.equal(m.revision,cfg.revision);assert.equal(m.pageRecords.pages.length,177);
 assert.equal(old.pageBindings.length,177);assert.equal(new Set(old.pageBindings.map(x=>x.page)).size,177);
 for(const b of old.pageBindings){
  assert.equal(rh(path.join(cfg.repository,b.page)),b.sourceSha256);
  assert.equal(rh(path.join(cfg.artifact,b.page.slice('docs/site/'.length))),b.stagedSha256);
  assert.equal(rh(path.join(cfg.artifact,b.htmlPath)),b.htmlSha256);
  const r=m.pageRecords.pages.find(x=>x.sourcePath===b.page);assert(r);assert.equal(r.source.contentHash.value,b.sourceSha256);assert.equal(r.html.contentHash.value,b.htmlSha256);assert.equal(r.route,'/'+b.htmlPath);
 }
 for(const x of ['reader.js','search-index.js','search.html'])assert.equal(rh(path.join(cfg.extracted,x)),rh(path.join(cfg.artifact,x)));
}
seal();
const require=createRequire(cfg.repository+'/package.json'),MarkdownIt=createRequire(cfg.repository+'/scripts/docs-reader/package.json')('markdown-it'),{parse}=require('parse5');
const md=new MarkdownIt({html:true}),norm=s=>s.replace(/\s+/gu,' ').trim();
const nodes=(n,p)=>[...(p(n)?[n]:[]),...(n.childNodes??[]).flatMap(c=>nodes(c,p))];
const text=n=>n.nodeName==='#text'?n.value:n.tagName==='br'?'\n':(n.childNodes??[]).map(text).join('');
const source=fs.readFileSync(path.join(cfg.repository,cfg.pageBinding.page),'utf8'),tokens=md.parse(source,{});
const hi=tokens.findIndex(t=>t.type==='heading_open'&&t.tag==='h1');assert(hi>=0);const title=norm(text(parse(md.renderInline(tokens[hi+1].content))));
const doc=parse(md.render(source)),matrix=nodes(doc,n=>n.tagName==='table').map(t=>nodes(t,n=>n.tagName==='tr').map(tr=>nodes(tr,n=>['th','td'].includes(n.tagName)).map(c=>({tag:c.tagName,text:norm(text(c)),links:nodes(c,n=>n.tagName==='a').map(a=>a.attrs.find(x=>x.name==='href')?.value??null)}))));assert(matrix.length>0);
const html=parse(fs.readFileSync(path.join(cfg.extracted,cfg.pageBinding.htmlPath),'utf8'));const articles=nodes(html,n=>n.tagName==='article');assert.equal(articles.length,1);
assert.equal(norm(text(nodes(articles[0],n=>n.tagName==='h1')[0])),title);
assert.equal(norm(text(nodes(html,n=>n.tagName==='title')[0])),title+' · KubeClaw Documentation');
const staticInfo={page:cfg.pageBinding.page,title,tables:matrix.length,rows:matrix.reduce((n,t)=>n+t.length,0),cellMatrixSha256:hash(JSON.stringify(matrix)),all177SourceStagedHtmlPageRecordBindings:true,firstArtifactFiles:419,extractedFiles:242};
fs.mkdirSync(out);fs.writeFileSync(path.join(out,'preflight.json'),JSON.stringify(staticInfo,null,2)+'\n');
if(args[0]==='--preflight-only'){seal();console.log(JSON.stringify(staticInfo));process.exit(0);}
const {chromium}=require('playwright'),findings=[],network=[],pages=[],tables=[],searches=[];let browser,fatal=null;
const finding=(kind,data)=>findings.push({kind,...data});
async function context(js,width){const c=await browser.newContext({javaScriptEnabled:js,offline:true,viewport:{width,height:1000},serviceWorkers:'block'});c.on('request',r=>{if(/^https?:/iu.test(r.url()))network.push({url:r.url()});});await c.route(/^https?:/iu,r=>r.abort());return c;}
try{
 browser=await chromium.launch({headless:true,args:['--no-sandbox']});
 for(const width of cfg.widths){
  const c=await context(false,width),page=await c.newPage();page.setDefaultTimeout(10000);
  page.on('pageerror',e=>finding('pageerror',{width,message:e.message}));
  try{
   await page.goto(pathToFileURL(path.join(cfg.extracted,cfg.pageBinding.htmlPath)).href,{waitUntil:'load'});
   assert.equal(await page.locator('article').count(),1);assert.equal(norm(await page.locator('article h1').innerText()),title);assert.equal(await page.title(),title+' · KubeClaw Documentation');
   const pw=await page.evaluate(()=>document.documentElement.scrollWidth);assert(pw<=width+1);pages.push({width,title,pageWidth:pw,sourceSha256:cfg.pageBinding.sourceSha256,stagedSha256:cfg.pageBinding.stagedSha256,htmlSha256:cfg.pageBinding.htmlSha256});
   const ts=page.locator('article table');assert.equal(await ts.count(),matrix.length);
   for(let ti=0;ti<matrix.length;ti++){
    const t=ts.nth(ti);await t.scrollIntoViewIfNeeded();await t.focus();
    const snapshot=()=>t.evaluate(el=>{const b=el.getBoundingClientRect();return {clientWidth:el.clientWidth,scrollWidth:el.scrollWidth,scrollLeft:el.scrollLeft,focused:document.activeElement===el,bounds:{left:b.left,right:b.right},pageWidth:document.documentElement.scrollWidth};});
    async function settle(){let previous=null,stable=0;const begin=Date.now(),samples=[];while(Date.now()-begin<2500){const x=await snapshot();samples.push(x);stable=previous===x.scrollLeft?stable+1:0;previous=x.scrollLeft;if(stable>=3&&Date.now()-begin>=180)return {final:x,samples};await page.waitForTimeout(60);}throw new Error('Native motion did not settle');}
    const actual=await t.evaluate(el=>[...el.rows].map(r=>[...r.cells].map(c=>({tag:c.tagName.toLowerCase(),text:c.innerText.replace(/\s+/gu,' ').trim(),links:[...c.querySelectorAll('a')].map(a=>a.getAttribute('href'))}))));assert.deepEqual(actual,matrix[ti]);
    const initial=await settle(),overflow=initial.final.scrollWidth>initial.final.clientWidth+1,coverage=[initial.final],motion=[];
    async function endpoint(direction){await t.focus();let current=await settle(),stall=0;const steps=[];const atEnd=()=>direction==='left'?current.final.scrollLeft<=1:current.final.scrollLeft>=current.final.scrollWidth-current.final.clientWidth-1;
     for(let n=0;overflow&&!atEnd()&&n<160;n++){const before=current.final.scrollLeft;await page.keyboard.press(direction==='left'?'ArrowLeft':'ArrowRight');current=await settle();assert(current.final.focused);assert(direction==='left'?current.final.scrollLeft<=before+1:current.final.scrollLeft>=before-1);steps.push(current);coverage.push(current.final);stall=current.final.scrollLeft===before?stall+1:0;if(stall>=3)break;}
     assert(atEnd(),'Native '+direction+' endpoint not reached');motion.push({direction,steps,final:current.final});return current.final;}
    if(overflow){assert(initial.final.focused);await endpoint('left');}
    const ranges=await t.evaluate(el=>{const b=el.getBoundingClientRect();return [...el.rows].flatMap((r,ri)=>[...r.cells].map((c,ci)=>{const range=document.createRange();range.selectNodeContents(c);return {row:ri,column:ci,ranges:[...range.getClientRects()].map(x=>({left:x.left-b.left+el.scrollLeft,right:x.right-b.left+el.scrollLeft})),clientWidth:c.clientWidth,scrollWidth:c.scrollWidth};}));});
    if(width===320&&ti===0)await page.screenshot({path:path.join(out,'error-table-320-left.png')});
    if(overflow)await endpoint('right');
    if(width===320&&ti===0&&overflow)await page.screenshot({path:path.join(out,'error-table-320-right.png')});
    const intervals=coverage.map(x=>[x.scrollLeft,x.scrollLeft+x.clientWidth]).sort((a,b)=>a[0]-b[0]),merged=[];
    for(const i of intervals){const last=merged.at(-1);if(last&&i[0]<=last[1]+1)last[1]=Math.max(last[1],i[1]);else merged.push([...i]);}
    assert(coverage.every(x=>x.bounds.left>=-1&&x.bounds.right<=width+1&&x.pageWidth<=width+1),'Table escaped local viewport');
    assert(ranges.every(c=>c.scrollWidth<=c.clientWidth+2&&c.ranges.every(r=>merged.some(([a,b])=>r.left>=a-2&&r.right<=b+2))),'Cell internal clipping or unreached horizontal content');
    if(overflow)await endpoint('left');
    tables.push({width,index:ti,exactMatrix:true,matrixSha256:hash(JSON.stringify(actual)),initial,overflow,motion,coverageIntervals:merged,ranges,access:overflow?'Native keyboard scroll-mediated, not simultaneous columns':'Nonoverflowing',contained:true});
   }
  }catch(e){finding('error-page',{width,message:e.message,stack:e.stack});}finally{await c.close();}
 }
 for(const q of cfg.queries){
  const c=await context(true,768),page=await c.newPage();page.setDefaultTimeout(10000);const loaded=[];
  page.on('request',r=>{if(r.url().endsWith('/reader.js')||r.url().endsWith('/search-index.js'))loaded.push(r.url());});page.on('pageerror',e=>finding('search-pageerror',{query:q.query,message:e.message}));
  try{
   await page.goto(pathToFileURL(path.join(cfg.extracted,'search.html')).href,{waitUntil:'load'});
   await page.locator('#query').fill(q.query);await page.locator('#query').press('Enter');
   await page.waitForFunction(()=>/^\d+ pages found\./u.test(document.querySelector('#search-status')?.textContent??''));
   assert.equal(new URL(page.url()).searchParams.get('q'),q.query);
   const results=await page.locator('#search-results a').evaluateAll(es=>es.map(a=>({href:a.getAttribute('href'),text:a.textContent})));
   assert(results.some(r=>r.href===q.expected));
   assert(loaded.some(x=>x.endsWith('/reader.js'))&&loaded.some(x=>x.endsWith('/search-index.js')),'Original JS/index not loaded');
   const link=page.locator('#search-results a[href="'+q.expected+'"]');assert.equal(await link.count(),1);await link.focus();assert(await link.evaluate(a=>a===document.activeElement));await page.keyboard.press('Enter');await page.waitForURL(pathToFileURL(path.join(cfg.extracted,q.expected)).href);assert.equal(await page.locator('article').count(),1);
   searches.push({query:q.query,expected:q.expected,results,loaded,nativeFocusAndEnter:true,actual:page.url()});
  }catch(e){finding('search',{query:q.query,message:e.message,stack:e.stack});}finally{await c.close();}
 }
}catch(e){fatal={message:e.message,stack:e.stack};finding('fatal',fatal);}
finally{
 if(browser)await browser.close();try{seal();}catch(e){finding('closeout',{message:e.message});}
 if(pages.length!==3||tables.length!==matrix.length*3||searches.length!==3)finding('incomplete',{pages:pages.length,tables:tables.length,searches:searches.length,expectedTables:matrix.length*3});if(network.length)finding('network',{count:network.length});
 const report={revision:cfg.revision,scriptSha256:rh(fileURLToPath(import.meta.url)),preparationSha256:prepSHA,staticInfo,pages,tables,searches,findings,network,fatal,limits:['Supplement only: omitted generated error page×3 widths and three actual extracted offline JS searches; not V3/137-retake replacement or corpus recount.','Native keyboard hscroll/Range coverage is scroll-mediated access, not simultaneous whole-table visibility or1027-row semantic acceptance.','PhysicalSource/stagedMarkdown/HTML distinct;177page originalPageRecord+419first/242extracted byte bindings checked before/after.','No DOM/CSS/attributes/scrollLeft assigned by fixture; only native UI input, readonly measurement, viewport screenshots.','No unexposed persona, screenreader/axe, live product/native/graph/consumer/gate approval.']};fs.writeFileSync(path.join(out,'report.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify({pages:pages.length,tables:tables.length,searches:searches.length,findings:findings.length,network:network.length,out}));
}
if(findings.length)process.exitCode=1;
