# Frozen supplemental browser fixture — NOT EXECUTED

Author: `/root/operator_acceptance`. Source/artifact revision: `487f4e00af5d330b0fb253c2bdc67210476068f3`.

## Exact responsibility

1. Add the omitted generated `reference/buster-error-codes.md` at320/768/1440. Actual physical Source, staged Markdown and HTML retain separate original177-page PageRecord bindings. Installed original MarkdownIt+parse5 derive H1/title and complete row/cell text+href matrices from physical Source, then check actual rendered DOM. Every table measures local client/scroll width and text ranges, real focus/ArrowLeft/ArrowRight endpoint access and horizontal coverage. Native horizontal access is not simultaneous all-column visibility. Two first-table320 viewport screenshots (left and right if overflow) support Root visual inspection, not a full1027-row semantics audit.
2. Load the freshly extracted `search.html` with original `reader.js` and lazy `search-index.js`. Native input/Enter submits three relevant queries: `OPENAPI_SCHEMA_DEPTH_EXCEEDED`→errorreference; `supervisor lease heartbeat`→Echo; `demo session protocol`→Bustersuites. Require expected canonical result among actual first50, then native focus+Enter opens it. No injected search implementation or DOM result synthesis. Record actual script/index load, results and destination.

Allcontexts use file URLs, offline=true, serviceworkers blocked and all HTTP(S) intercepted/aborted+recorded; any observed HTTP(S) fails. Native interactions only; read-only DOM/Range measurements; no attributes/styles/scrollLeft mutation. No persona/screenreader/axe/product execution claim.

## Receiving and execution boundaries

`preparation.json` pins exact originalV3 preparation, immutable419file index, archive-review, complete242extracted member identities and existing page binding. Before and after run, the script independently checks every419first/242extracted member bytes/membership, all177physical/staged/HTML/PageRecord identities and original JS/index equality. It does not import shipping targets. Reuses the validated installed MarkdownIt/parse5/Playwright dependency domain from originalV3, with declared LD_LIBRARY_PATH/FONTCONFIG_FILE in preparation. No npm/install/producer/graph/native run is authorized by this packet.

Root must read complete script+preparation and separately launch with the recorded environment:

`node supplement.mjs --preflight-only /absolute/new-preflight-output`

Then, only after Root approval:

`node supplement.mjs --run-reviewed-supplement /absolute/new-browser-output`

Output must be fresh and outside Main, artifact, extracted Reader and authorpacket. The script checks this before writing. No launch/preflight/target execution was performed by the author; only inert Python file generation and static review.

## Prior evidence and truthful census

Do not replace V3 or custody's137-only retake. V3's20physical pages comprise17policycanonical (8changed+9unchanged)+3support(allchanged):11changed+9unchanged, not11+6. This supplement covers the omitted12thchangedcanonical generatedreference, plus actual extracted offline client queries. Prior60pages/432box/633table observations and137native-scroll findings remain original, unmodified. This is no new wholeReader/gate/count verdict; final94-preservation adjudication remains pending all actualreceipts.

Existing process/check/archive byte results remain in `preservation-487f4e00/reader-results-addendum.md`. The supplemental fixture supplies only currently absent browser responsibilities; it does not re-audit1027semantics or self-accept prior authored prose.
