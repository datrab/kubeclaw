# V2 — narrow actual MarkdownIt field-boundary correction

V1 and Root’s real preflight failure remain immutable. This is an authored fixture correction, not a finding against the documentation, and is UNRUN pending nonauthor Root review. The exact failure and old/new script identities are in correction-addendum.json.

## Actual defect and correction

The first new Lint Sourcebox is one genuine MarkdownIt inline paragraph: title, Claim, Implementation, Contract/setting, Test evidence, Revision and Limit are separated by softbreak children, not blank blockquote lines. V1 tested only inline.content beginning; the field labels occur later in the same paragraph, so V1 returned zero fields.

V2 uses the actual original inline.children array. Each logical line is delimited by a real softbreak/hardbreak token; an exact standard label must be a strong-open + literal text + strong-close marker at that line start. Empty leading text children are skipped. No new alias, label prefix, raw-box scanner, paragraph-padding requirement or Main modification is introduced. Existing standard labels and all11 contextual equivalents remain precisely the old pinned set; new/changed boxes cannot inherit contextual aliases.

Body slices retain each original child token—including links, emphasis, inline code and line-break tokens—with inline index and child start/end. Unlabelled continuation lines and subsequent paragraphs stay with their active field. Slices are regrouped by original inline paragraph before rendering to avoid losing formatting/link nesting across softbreaks. Every field must be present exactly once and have nonempty rendered body. The browser checks each complete rendered field text; its report keeps the actual token slices/provenance.

The Source-first-paragraph comparison is already correct and remains byte-identical: boxes() renders the entire first original inline paragraph; DOM uses the whole first direct p. In a one-paragraph box BOTH contain the title and all six fields. V2 does not weaken it to firststrong, a heading prefix or title-only comparison.

## Unchanged receiving boundary

preparation.json is byte-identical to V1. All433/411/22/1 Sourcebox assertions, duplicate multiplicity/order,177PageRecords/419artifact files,17guides×3widths, exact input seals, native action scope, real table-cell/scroll/link logic and no-DOM-mutation policy are unchanged. parser-only.patch is the entire code delta. Full V1 design report remains archived in a910-reader-487f4e00-author/author-report.md.

Root should review only this coherent parser/expected-field delta, then authorize the same original-corpus preflight in a NEW output directory. Its actual parsed433box/delta/six-field results remain unobserved by this author. No browser launch or parser/preflight execution has occurred in V2, and no new semantic/readability/gate result is claimed.
