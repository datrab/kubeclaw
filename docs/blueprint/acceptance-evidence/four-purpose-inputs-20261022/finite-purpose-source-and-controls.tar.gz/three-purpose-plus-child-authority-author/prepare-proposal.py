from pathlib import Path
import hashlib,json,difflib,subprocess
R=Path('/home/node/.openclaw/workspace/kubeclaw-pr13-recovery');D=Path(__file__).parent;source='scripts/docs-api-documentation-role-custody.mjs';b=(R/source).read_text();new=b
oldSdk='9d4f7a92f51d83303d39b3ec4a3ae0e56d5030f2c53f86cb7e9d676042bd264e';sdk=hashlib.sha256((R/'docs/generated/inventory/sdk-reference.json').read_bytes()).hexdigest();oldError='5b7f48767226cbc0a1bbcf310b879052b4aa55919bb60d52985b01f8f7b2424e';error=hashlib.sha256((R/'scripts/generate-buster-error-reference.mjs').read_bytes()).hexdigest();assert sdk=='c1061422373d61e143322c856fe63ad66bbc7bc9075776b4ff91fee75b933214' and error=='11cf5c42d7b13565534eab04be11b9ed2f16bf8ee5ad6ba025850363f8ddd6d8'
assert b.count(oldSdk)==1 and b.count(oldError)==3;new=new.replace(oldSdk,sdk).replace(oldError,error)
prefix='export const documentationExecutableRoleRecipes = ';i=b.index(prefix)+len(prefix);before,end=json.JSONDecoder().raw_decode(b[i:]);after,end2=json.JSONDecoder().raw_decode(new[i:]);assert len(before)==len(after)==107 and b[:i]==new[:i] and b[i+end:]==new[i+end2:]
deltas=[]
def compare(a,c,path=()):
 assert type(a)==type(c),(path,type(a),type(c))
 if isinstance(a,dict):
  assert list(a)==list(c),path
  for k in a:compare(a[k],c[k],path+(k,))
 elif isinstance(a,list):
  assert len(a)==len(c),path
  for n,(x,y) in enumerate(zip(a,c)):compare(x,y,path+(n,))
 elif a!=c:deltas.append({'path':list(path),'before':a,'after':c})
compare(before,after);expected={('scripts/check-contract-drift.mjs','purposeInputs',1,'sha256'),('scripts/check-error-code-drift-mutations.mjs','purposeInputs',4,'sha256'),('scripts/check-error-code-drift.mjs','authorityInputs',0,'sha256'),('scripts/check-error-code-drift.mjs','purposeInputs',0,'sha256')};assert {tuple(x['path']) for x in deltas}==expected and len(deltas)==4
assert new.replace(sdk,oldSdk,1).replace(error,oldError,3)==b
(D/'baseline').mkdir(exist_ok=True);(D/'baseline'/Path(source).name).write_text(b);out=D/source;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(new)
(D/'candidate.patch').write_text(''.join(difflib.unified_diff(b.splitlines(True),new.splitlines(True),fromfile='a/'+source,tofile='b/'+source)))
(D/'four-cell-invariants.json').write_text(json.dumps({'status':'AUTHOR_ONLY_UNACCEPTED','source':source,'baselineSha256':hashlib.sha256(b.encode()).hexdigest(),'candidateSha256':hashlib.sha256(new.encode()).hexdigest(),'recipeCount':107,'deltas':deltas,'allOtherBytesExact':True,'allObjectKeysOrderArrayLengthsAndPositionsPreserved':True,'originalPublicGuardSelectorsFactsNativeAndCodeOutsideFourLiteralCellsUnchanged':True,'mainUnchangedByAuthor':(R/source).read_text()==b,'noOriginalGetterOrConsumerRun':True},indent=2)+'\n')
print('candidate',hashlib.sha256(new.encode()).hexdigest());print(json.dumps(deltas))
