# Actual facts-only capture result review — Source487f4e00

## Verdict and independence boundary

**PASS for the actual bounded capture's terminal, complete DATA and recorded-context integrity. Five declared factsDigest mismatches remain unaccepted DATA. No metadata update or full-consumer/role/generator qualification follows.**

I (`/root/workflow_acceptance`) authored the receiving wrapper. This is a separate read-only review of Root's actual execution/result, not independent acceptance of my wrapper Source. Receiving Source/context acceptance and the one-run admission are Root's `facts-only-current107-root-reviewed-seal/review.json` and `launch-admission.json`; their exact hashes are bound in `evidence-bindings.json`. No target/controller/getter/native/producer/test was rerun for this review. Inert Python filesystem/JSON/hash comparison was used only to inspect existing results and write this scratch report.

Actual result: `facts-original-487f4e00`, exact Source `487f4e00af5d330b0fb253c2bdc67210476068f3`, sealed manifest SHA `452f357132769839a740c2ddaf926041a907514b3aabb8eec528570ab7cffd34`. The separate seal changes only status/mode/revision/stops plus Root review/remaining-limit provenance; all other author manifest objects remain exact. The sealed fixed Source roster actually contains433 files (not444).

## Raw terminals and launch context

All five recorded outer children have terminal returncode0, no signal, no ceiling/timeout rejection. Every raw stdout/stderr length and SHA was independently recomputed. All stderr files are empty. Processes00/03 are exactly `/usr/bin/git rev-parse HEAD`, returning the exact bound revision;01/04 are exactly the clean porcelain-v1/all-untracked checks, returning empty stdout. Process02 is the original Node receiving wrapper with the exact bound script SHA, manifest/SHA, `facts-only` mode, owned node output and4GiB old-space limit; both raw streams are empty. Its recorded wall duration is about79.3s. The overall Python controller terminal0 is Root's reported execution outcome; the five child terminal files and both completion bindings are directly inspected here, not invented independent OS witnesses.

All five launch records retain the same literal environment, root cwd and empty stdin/DEVNULL representation. The complete environment is in `terminal-validation.json`; no ambient Node/Python/Go loader or LD override is present. The unused native/cache settings remain overinclusive context, not child launch permission. Root's sealed review owns the receiving-source interpretation of these controls.

The result records zero child-process attempts. There are no denied-process or derivation-error records, no partial/failure result, and both completion files report only DATA_CAPTURE_COMPLETE_UNACCEPTED. The exact wrapper and completion files match their sealed/completion SHA references. This demonstrates this bounded observed path; it is not host-wide process surveillance or a native execution grant.

## Whole DATA reconciliation

All107 unique Source rows exactly match the declared current recipe roster/order.103 JavaScript rows preserve full current prior recipe objects; all four native rows preserve the complete current native recipe and physical Source identity with NOT_EXECUTED status:

- `scripts/docs-api-go-output-role-adapter.go`
- `scripts/docs-api-go-output-shapes.go`
- `scripts/docs-api-python-output-adapter.py`
- `scripts/docs-api-python-ast-v1.py`

The later ordinary full consumer's three selected native Sources remain a different boundary; none ran here. Original115closure was neither acquired nor refreshed.

The first/repeat complete107row JSON bytes and parsed objects are equal. The compact original getter-result digest is `0a8a5b83d822639ccfe0d922f4ce60e64c06065fe42b7c9453f1dcc6d6d4c11e`, independently recomputed. All103 factsDigest values were recomputed from the complete ordered operationFacts arrays (12,725 total records). All recorded boolean comparisons were independently recomputed against the full declared prior objects and actual purpose-input bytes. Every original per-Source full-record multiset agrees exactly, including multiplicity and original positions. There happen to be zero repeated identical full records in this actual result; duplicate handling was not inferred by dropping them.

All103 selector comparisons, all103 child-authority comparisons and all103 purpose-input comparisons are true.98 factsDigest comparisons are true. Exactly five are false. Relative to the actual previous7ef107row capture, the remaining98JavaScript ordered operationFacts arrays are byte-value identical; all107Source names remain the same. No fabricated prior:null seed or newly qualified Source exists.

## The finite remaining mismatch family

The five rows below have unchanged selectors/purpose/authority and unchanged operation-fact cardinality. In each, full-record multiset comparison to the previous actual capture finds exactly two removed records and two added records, multiplicity1 each, at the same original positions. All other facts/positions are unchanged. The changed Source is exclusively `scripts/docs-deployment-scalar-occurrence-custody.mjs`; the symbols are `reviewedCallerCensusSha256` and `reviewedSelectedGraphSha256`.

- `scripts/docs-api-output-discovery.mjs`:225facts; prior digest `3f4f535fcb4ae34c7825111461da098c19aafeecc279ca01ae7014952a3b9828`; actual `863bda7f7e7602c5c17da840d7dee822d809b40621d4b5917abfc4805692035a`.
- `scripts/docs-api-product-scope.mjs`:1,418facts; prior `8879c557d4f5dd232cbe8db06df86c817f64a6c7a8d0c3cf048305bd78a0509d`; actual `e8737c52d817297652fea39cc2edda9bd96545f9f88bc253ab341092c23b975a`.
- `scripts/docs-api-reference.mjs`:1,440facts; prior `825de0d3ca7c6ca165f1319bd0ecd0d925251443bb0751d3aa5d32d5b159430b`; actual `3ba18240df29fc64fb643f3967b5c8c460b2a6996d5595fd4f31ca5975f97a1d`.
- `scripts/docs-configuration-inventory.mjs`:2,210facts; prior `71eeb1bb6ea165c44d1aa72e7becd05d34bc84a98972360edae8c70dfd2c7069`; actual `0ed4dbeb70588242b941499537884877358711565b331aecc9fe66d091ab1356`.
- `scripts/docs-generate.mjs`:1,536facts; prior `897e4202b1710f2abb1abd09868ecf86aa8199e1186fbe688be027a61b3f617e`; actual `dd77f3cb825a20d7d0b2e9fad64a1c5645f096eeb0b992987a7808e9f389b43f`.

For all five, the previous actual full-array digest equals the currently declared prior receipt, establishing the old comparison is the right bound baseline. The two new exact statement hashes match the complete current scalar Source statements; whole scalar Source SHA is `700523b17cbee68f423414380fbe3626c7d83a1f86b060677953b04119756817`. The two-literal Source purpose/adoption was already independently reviewed by custody/Root; those reports are reused exactly, not selfaccepted here. The complete added/removed record values, multiplicities and positions are in `finite-five-facts-delta-inventory.json`.

No additional SDK-inventory/error-owner operation-fact mismatch exists in this actual inventory. Those purpose-input/child identities now match all current declarations; this does not broaden their existing finite Source-purpose acceptance.

## Whole context reconciliation

Python before/after snapshots are whole equal; Node before/between/after snapshots are whole equal. Every recorded context object was reconciled against the sealed manifest, not just against its repeat: complete npm2,993files/488dirs/9links and Main-installed28,133files/3,025dirs/100links typed namespaces, all433Source identities,1711prior consumed contexts,157absences,4links,7directory identities, and4native namespace packet hashes/current path declarations. Directory physical objects intentionally omit the manifest's descriptive `purpose` annotation; all path/type/canonical/device/inode fields match exactly. The initial review-only comparison of those descriptions to physical records failed and is retained in `reviewer-first-context-comparison.json`; it was not a capture failure or a relaxation of any actual identity field.

All266fresh reported getter-consumed Source contexts exactly equal the Source names derived from the complete original return, remain whole equal before/after repeat, and independently match current physical bytes/pointers/directory member records. They are separate from, and do not replace, the prior1711pre-import receiving boundary. This review does not claim a fresh independent full installed/native namespace re-enumeration; Root performed the prelaunch physical checks, and this report validates the complete captured snapshots and their sealed bindings.

## Next useful bounded step; no installation here

The finite DATA inventory is exactly the five factsDigest cells above, justified by the same two already-qualified scalar constant statements. Root can independently assess a five-cell-only metadata proposal against `finite-five-facts-delta-inventory.json` plus the scalar Source-purpose review/adoption. No selector, authority-input, purpose-input, native receipt, or other102recipe value needs renewal on this result's evidence. Such a proposal is not installed or independently accepted by this report. After any adoption, current Source/facts continuity and the original ordinary whole consumer's module/caller/alias/dynamic/native/code guards still need their separately qualified launch and actual results. Original115closure, role/API/CI/producer/generator/runtime acceptance remain ungranted.
